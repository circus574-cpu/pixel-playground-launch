"""Kontrola integralności projektu katalogu - bez uruchamiania gry."""
from pathlib import Path
import json,csv
p=Path('/mnt/data')
d=json.loads((p/'KI_LEGENDS_366_PRZEDMIOTOW_V2.json').read_text())
items=d['items']; recipes=d['recipes']; ids={i['id'] for i in items}
assert len(items)==len(ids)==366
assert len(recipes)==140
assert sum(i['source']=='repo' for i in items)==139
assert sum(i['source']=='image_equipment' for i in items)==70
artifacts=[i for i in items if i['source']=='image_buff']
assert len(artifacts)==35
for i in artifacts:
 b=i['buff']
 assert i['stats']=={} and b['mode']=='passive'
 assert b['duration']=='while_equipped' and b['cooldown_s'] is None and b['trigger'] is None
 assert b['activation']=='on_equip'
assert all(len([i for i in artifacts if i['set_id']==f'BUFF-{z:02d}'])==7 for z in range(1,6))
assert len(d['buff_set_bonuses'])==5 and all(len(z)==3 for z in d['buff_set_bonuses'])
assert all(x['mode']=='passive' and x['cooldown_s'] is None for z in d['buff_set_bonuses'] for x in z)
assert len(d['equipment_set_bonuses'])==10
assert all(not ({'hpBonus','kiBonus','HP','KI','atkBonus','defBonus'} & i['stats'].keys()) for i in items)
for recipe in recipes:
 assert recipe['result'] in ids
 assert all(z['id'] in ids for z in recipe['ingredients'])
with (p/'KI_LEGENDS_366_PRZEDMIOTOW_V2.csv').open(encoding='utf-8-sig',newline='') as f:
 rows=list(csv.DictReader(f));assert len(rows)==366
 assert all('source_stats' in row and 'stats' in row and 'source_description' in row for row in rows)
# Test przykładów skalowania: ta sama premia ma proporcjonalny wzrost wartości bezwzględnej.
def max_stat(base, pct):return int(base*(1+pct/100))
assert max_stat(300,10)==330 and max_stat(3000,10)==3300
assert max_stat(500,8)==540 and max_stat(5000,8)==5400
print('PASS: 366 ID, 140 receptur, 35 artefaktów pasywnych, 15 pasywnych progów, skalowanie %')
