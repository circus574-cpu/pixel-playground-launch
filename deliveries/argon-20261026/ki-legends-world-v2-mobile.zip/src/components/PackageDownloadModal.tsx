import React, { useState } from 'react';
import {
  Download,
  FileArchive,
  Terminal,
  Smartphone,
  CheckCircle2,
  Copy,
  X,
  FileCode2,
  BookOpen,
} from 'lucide-react';

interface PackageDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PackageDownloadModal: React.FC<PackageDownloadModalProps> = ({ isOpen, onClose }) => {
  const [copiedBlock, setCopiedBlock] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedBlock(id);
    setTimeout(() => setCopiedBlock(null), 2000);
  };

  const localRunCommands = `unzip ki-legends-world-v2-mobile.zip -d ki-legends-world-v2
cd ki-legends-world-v2
npm install
npm run dev`;

  const gitIntegrateCommands = `git checkout feature/quests-v2
# Rozpakuj archiwum bezpośrednio w katalogu repozytorium:
unzip -o ki-legends-world-v2-mobile.zip
npm run typecheck
npm test
git add src/ INSTRUKCJA_URUCHOMIENIA.md
git commit -m "Feat: World V2 Quest Log, mobile HUD, dialogues, items and bosses"
git push origin feature/quests-v2`;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-zinc-900 border border-zinc-700 rounded-2xl max-w-3xl w-full p-4 sm:p-6 space-y-5 shadow-2xl my-auto max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
              <FileArchive className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white">
                Paczka ZIP — KI Legends World V2 & Mobile Edition
              </h2>
              <p className="text-xs text-zinc-400">
                Kompletny kod źródłowy, Quest Log, Arena Mobilna (Joystick 360° + HUD) oraz łatka
                Git
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 cursor-pointer"
            aria-label="Zamknij okno pobierania"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Direct Download Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div className="bg-zinc-950 border border-emerald-500/40 rounded-xl p-4 flex flex-col justify-between gap-3">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-emerald-400 uppercase tracking-wider">
                  Pełne Archiwum Projektu (ZIP)
                </span>
                <span className="font-mono text-zinc-400">319 KB</span>
              </div>
              <h3 className="text-sm font-bold text-white">ki-legends-world-v2-mobile.zip</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Zawiera cały katalog <code>src/</code> (World V2, Quest Log, mobilną Arenę Walki,
                dialogi, przedmioty, receptury, 8 bossów, testy Vitest), konfigurację projektu oraz
                plik <code>INSTRUKCJA_URUCHOMIENIA.md</code>.
              </p>
            </div>

            <a
              href="/ki-legends-world-v2-mobile.zip"
              download="ki-legends-world-v2-mobile.zip"
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-lg shadow-emerald-950/50 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Pobierz Paczkę ZIP (Pełny Kod + Instrukcja)
            </a>
          </div>

          <div className="bg-zinc-950 border border-amber-500/40 rounded-xl p-4 flex flex-col justify-between gap-3">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-amber-400 uppercase tracking-wider">
                  Łatka Git (Git Patch)
                </span>
                <span className="font-mono text-zinc-400">~189 KB</span>
              </div>
              <h3 className="text-sm font-bold text-white">dialogue-items-bosses.patch</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Czysta łatka wygenerowana komendą{' '}
                <code>git diff -- src/game/dialogue src/game/items src/game/bosses</code> gotowa do
                nałożenia przez <code>git apply</code>.
              </p>
            </div>

            <a
              href="/dialogue-items-bosses.patch"
              download="dialogue-items-bosses.patch"
              className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <FileCode2 className="w-4 h-4" />
              Pobierz Łatkę Git (.patch)
            </a>
          </div>
        </div>

        {/* Co zostało przygotowane pod urządzenia mobilne i różne ekrany */}
        <div className="bg-zinc-950/80 border border-zinc-800 rounded-xl p-4 space-y-2.5">
          <div className="text-xs font-bold uppercase tracking-wider text-sky-400 flex items-center gap-2">
            <Smartphone className="w-4 h-4" />
            Adaptacja Mechaniki na Urządzenia Mobilne i Różne Ekrany
          </div>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-zinc-300">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <b>Wirtualny Joystick 360° & D-Pad 8-kierunkowy:</b> Płynny ruch postaci pod lewym
                kciukiem na ekranach dotykowych.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <b>Mobilny Klaster Bojowy KI:</b> Duży przycisk Ataku oraz przyciski technik{' '}
                <code>Q / E / R</code> pod prawym kciukiem.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <b>Pełny Ekran z HUD i Oddaloną Kamerą:</b> Domyślny szeroki plan (Zoom 85%) z
                opcją przełączenia na pełny ekran na telefonach.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <b>Interaktywna Mapa i Quest Log:</b> Przybliżanie mapy taktycznej (Zoom +/-) oraz
                responsywny układ kart na ekranach od 360px do 1440px+.
              </span>
            </li>
          </ul>
        </div>

        {/* Instrukcja Krok po Kroku */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
              <Terminal className="w-4 h-4 text-emerald-400" />
              1. Instrukcja Uruchomienia Lokalnego (PC + Telefon w sieci Wi-Fi)
            </h3>
            <button
              onClick={() => handleCopy('local', localRunCommands)}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-xs text-zinc-200 cursor-pointer"
            >
              <Copy className="w-3 h-3" />
              {copiedBlock === 'local' ? 'Skopiowano!' : 'Kopiuj komendy'}
            </button>
          </div>
          <pre className="bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 text-xs font-mono text-emerald-300 overflow-x-auto">
            {localRunCommands}
          </pre>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-amber-400" />
              2. Integracja z Gałęzią <code>feature/quests-v2</code> w Git
            </h3>
            <button
              onClick={() => handleCopy('git', gitIntegrateCommands)}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-xs text-zinc-200 cursor-pointer"
            >
              <Copy className="w-3 h-3" />
              {copiedBlock === 'git' ? 'Skopiowano!' : 'Kopiuj komendy'}
            </button>
          </div>
          <pre className="bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 text-xs font-mono text-amber-300 overflow-x-auto">
            {gitIntegrateCommands}
          </pre>
        </div>
      </div>
    </div>
  );
};
