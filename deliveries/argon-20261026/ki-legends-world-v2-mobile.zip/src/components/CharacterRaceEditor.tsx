import React, { useState, useEffect, useRef } from 'react';
import { HERO_RACES, HeroRace, Direction } from '../data/heroes';
import {
  HeroAnimState,
  HERO_ANIM_FRAMES,
  ensureCleanedHeroSprite,
  getCachedCleanedHeroSprite,
  renderAnimatedHero,
} from '../game/heroes/spriteAnimator';
import {
  RaceProvenanceMetadata,
  Stage3RenderContract,
  RaceEditorProfile,
  RaceDynamicTheme,
  RaceVisualRigConfig,
  CANONICAL_RACE_PROVENANCE,
  CANONICAL_STAGE3_CONTRACT,
  RACE_THEME_PRESETS,
  fetchRaceProvenance,
  fetchStage3RenderContract,
  getRaceProfile,
  saveRaceProfile,
  resetRaceProfileToCanonical,
  setActiveUiThemeRaceId,
  applyRaceThemeToDocument,
  computeEffectiveAnimFps,
} from '../game/heroes/raceMetadata';
import {
  Sliders,
  Palette,
  Activity,
  FileJson,
  RotateCcw,
  Play,
  Pause,
  RotateCw,
  Check,
  Copy,
  Eye,
  Layers,
  Crosshair,
  Shield,
  Zap,
  Sparkles,
  ChevronRight,
  Wand2,
} from 'lucide-react';

const DIRECTIONS: { key: Direction; short: string; labelPl: string }[] = [
  { key: 'down', short: 'S', labelPl: 'Południe (Down)' },
  { key: 'down-left', short: 'SW', labelPl: 'Pd.-Zach. (Down-Left)' },
  { key: 'left', short: 'W', labelPl: 'Zachód (Left)' },
  { key: 'up-left', short: 'NW', labelPl: 'Pn.-Zach. (Up-Left)' },
  { key: 'up', short: 'N', labelPl: 'Północ (Up)' },
  { key: 'up-right', short: 'NE', labelPl: 'Pn.-Wsch. (Up-Right)' },
  { key: 'right', short: 'E', labelPl: 'Wschód (Right)' },
  { key: 'down-right', short: 'SE', labelPl: 'Pd.-Wsch. (Down-Right)' },
];

const ANIM_STATES: { key: HeroAnimState; labelPl: string; descPl: string }[] = [
  { key: 'walk', labelPl: 'Chód (Walk)', descPl: '8 klatek · Naprzemienny krok L/P + wahadło tułowia' },
  { key: 'attack', labelPl: 'Atak (Attack)', descPl: '8 klatek · Zamach, wypad bojowy i łuk cięcia KI' },
  { key: 'skill', labelPl: 'Technika KI (Skill)', descPl: '8 klatek · Lewitacja, pieczęć i eksplozja aury' },
  { key: 'idle', labelPl: 'Oddech (Idle)', descPl: '8 klatek · Oddech bojowy i falowanie szat' },
  { key: 'hit', labelPl: 'Obrażenia (Hit)', descPl: '4 klatki · Odrzut kierunkowy i błysk trafienia' },
  { key: 'death', labelPl: 'Upadek (Death)', descPl: '8 klatek · Progresywny upadek na podłoże' },
];

type EditorWorkspaceTab = 'appearance' | 'animation' | 'theme' | 'metadata';

interface CharacterRaceEditorProps {
  initialRaceId?: HeroRace['id'];
  onLaunchCombatWithRace?: (raceId: HeroRace['id']) => void;
  onActiveThemeChange?: (raceId: HeroRace['id'], theme: RaceDynamicTheme) => void;
}

export const CharacterRaceEditor: React.FC<CharacterRaceEditorProps> = ({
  initialRaceId = 'planetary',
  onLaunchCombatWithRace,
  onActiveThemeChange,
}) => {
  const [selectedRaceId, setSelectedRaceId] = useState<HeroRace['id']>(initialRaceId);
  const [profile, setProfile] = useState<RaceEditorProfile>(() => getRaceProfile(initialRaceId));
  const [provenance, setProvenance] = useState<RaceProvenanceMetadata>(
    () => CANONICAL_RACE_PROVENANCE[initialRaceId]
  );
  const [contract, setContract] = useState<Stage3RenderContract>(() => CANONICAL_STAGE3_CONTRACT);

  const [workspaceTab, setWorkspaceTab] = useState<EditorWorkspaceTab>('appearance');
  const [currentDirection, setCurrentDirection] = useState<Direction>('down');
  const [activeAnim, setActiveAnim] = useState<HeroAnimState>('walk');
  const [animFrameIndex, setAnimFrameIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isTurntableRotating, setIsTurntableRotating] = useState<boolean>(false);
  const [applyThemeGlobally, setApplyThemeGlobally] = useState<boolean>(true);
  const [copiedJson, setCopiedJson] = useState<boolean>(false);
  const [spriteReadyTick, setSpriteReadyTick] = useState<number>(0);

  const mainStageCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const directionMiniCanvasRefs = useRef<Record<Direction, HTMLCanvasElement | null>>({
    down: null,
    'down-left': null,
    left: null,
    'up-left': null,
    up: null,
    'up-right': null,
    right: null,
    'down-right': null,
  });

  const hero = HERO_RACES.find((r) => r.id === selectedRaceId) || HERO_RACES[0];
  const totalFrames = HERO_ANIM_FRAMES[activeAnim];
  const effectiveFps = computeEffectiveAnimFps(activeAnim, profile.rig.fpsMultiplier);

  // Load race profile and provenance.json when race changes
  useEffect(() => {
    const loadedProfile = getRaceProfile(selectedRaceId);
    setProfile(loadedProfile);
    setProvenance(CANONICAL_RACE_PROVENANCE[selectedRaceId]);

    let active = true;
    fetchRaceProvenance(selectedRaceId).then((meta) => {
      if (active) setProvenance(meta);
    });
    fetchStage3RenderContract().then((c) => {
      if (active) setContract(c);
    });

    if (applyThemeGlobally) {
      setActiveUiThemeRaceId(selectedRaceId);
      applyRaceThemeToDocument(loadedProfile.theme, selectedRaceId);
      onActiveThemeChange?.(selectedRaceId, loadedProfile.theme);
    }

    return () => {
      active = false;
    };
  }, [selectedRaceId]);

  // Preload and clean all 8 directional master PNGs for the active race
  useEffect(() => {
    let mounted = true;
    Promise.all(DIRECTIONS.map((d) => ensureCleanedHeroSprite(hero, d.key))).then(() => {
      if (mounted) setSpriteReadyTick((t) => t + 1);
    });
    return () => {
      mounted = false;
    };
  }, [hero]);

  // Auto 360 turntable rotation across 8 directions
  useEffect(() => {
    if (!isTurntableRotating) return;
    const timer = setInterval(() => {
      setCurrentDirection((prev) => {
        const idx = DIRECTIONS.findIndex((d) => d.key === prev);
        return DIRECTIONS[(idx + 1) % DIRECTIONS.length].key;
      });
    }, 650);
    return () => clearInterval(timer);
  }, [isTurntableRotating]);

  // Frame index ticker for timeline scrubber highlight
  useEffect(() => {
    if (!isPlaying) return;
    const intervalMs = Math.max(30, Math.round(1000 / effectiveFps));
    const timer = setInterval(() => {
      setAnimFrameIndex((prev) => (prev + 1) % HERO_ANIM_FRAMES[activeAnim]);
    }, intervalMs);
    return () => clearInterval(timer);
  }, [isPlaying, activeAnim, effectiveFps]);

  // 60 FPS Canvas render loop for main stage + 8-direction simultaneous matrix
  useEffect(() => {
    let rafId: number;
    const startTime = performance.now();

    const renderFrame = (now: number) => {
      const framesCount = HERO_ANIM_FRAMES[activeAnim];
      let frameIdx = animFrameIndex % framesCount;
      let subFrame = 0;

      if (isPlaying) {
        const elapsedSec = (now - startTime) / 1000;
        const continuous = (elapsedSec * effectiveFps) % framesCount;
        frameIdx = Math.floor(continuous);
        subFrame = continuous - frameIdx;
      }

      const customization = {
        scaleMultiplier: profile.rig.scaleMultiplier * (profile.rig.worldHeightTrialPx / 96),
        feetAnchorY: profile.rig.feetAnchorY,
        collisionRadiusUnits: profile.rig.collisionRadiusUnits,
        hueShiftDeg: profile.rig.hueShiftDeg,
        saturationPct: profile.rig.saturationPct,
        brightnessPct: profile.rig.brightnessPct,
        contrastPct: profile.rig.contrastPct,
        strideAmplitude: profile.rig.strideAmplitude,
        clothWaveIntensity: profile.rig.clothWaveIntensity,
        attackLungeDistance: profile.rig.attackLungeDistance,
        skillLevitationHeight: profile.rig.skillLevitationHeight,
        breathingDepth: profile.rig.breathingDepth,
        auraIntensity: profile.rig.auraIntensity,
        auraColorOverride: profile.theme.primaryAccent,
        secondaryGlowOverride: profile.theme.auraGlow,
        showFeetAnchor: profile.rig.showFeetAnchor,
        showCollisionCircle: profile.rig.showCollisionCircle,
      };

      // 1. Render Main Stage Canvas
      const stageCanvas = mainStageCanvasRef.current;
      if (stageCanvas) {
        const ctx = stageCanvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, stageCanvas.width, stageCanvas.height);
          renderAnimatedHero(
            ctx,
            hero,
            currentDirection,
            stageCanvas.width / 2,
            stageCanvas.height - 34,
            290,
            {
              state: activeAnim,
              frameIndex: frameIdx,
              subFrame,
              useCleanedSprite: profile.rig.useCleanedSprite,
              showAura: profile.rig.showAura,
              customization,
            }
          );
        }
      }

      // 2. Render 8-Direction Simultaneous Miniature Matrix
      for (const dirItem of DIRECTIONS) {
        const miniCanvas = directionMiniCanvasRefs.current[dirItem.key];
        if (!miniCanvas) continue;
        const mCtx = miniCanvas.getContext('2d');
        if (!mCtx) continue;
        mCtx.clearRect(0, 0, miniCanvas.width, miniCanvas.height);
        renderAnimatedHero(
          mCtx,
          hero,
          dirItem.key,
          miniCanvas.width / 2,
          miniCanvas.height - 10,
          78,
          {
            state: activeAnim,
            frameIndex: frameIdx,
            subFrame,
            useCleanedSprite: profile.rig.useCleanedSprite,
            showAura: profile.rig.showAura,
            customization: {
              ...customization,
              scaleMultiplier: 1.0,
              showFeetAnchor: false,
              showCollisionCircle: false,
            },
          }
        );
      }

      if (isPlaying) {
        rafId = requestAnimationFrame(renderFrame);
      }
    };

    rafId = requestAnimationFrame(renderFrame);
    return () => cancelAnimationFrame(rafId);
  }, [
    hero,
    currentDirection,
    activeAnim,
    animFrameIndex,
    isPlaying,
    effectiveFps,
    profile,
    spriteReadyTick,
  ]);

  const updateRig = (patch: Partial<RaceVisualRigConfig>) => {
    const nextProfile: RaceEditorProfile = {
      ...profile,
      rig: { ...profile.rig, ...patch },
      updatedAt: new Date().toISOString(),
    };
    setProfile(nextProfile);
    saveRaceProfile(nextProfile);
  };

  const updateTheme = (patch: Partial<RaceDynamicTheme>) => {
    const nextTheme: RaceDynamicTheme = {
      ...profile.theme,
      ...patch,
      id: patch.id || `${selectedRaceId}-custom`,
    };
    const nextProfile: RaceEditorProfile = {
      ...profile,
      theme: nextTheme,
      updatedAt: new Date().toISOString(),
    };
    setProfile(nextProfile);
    saveRaceProfile(nextProfile);
    if (applyThemeGlobally) {
      applyRaceThemeToDocument(nextTheme, selectedRaceId);
      onActiveThemeChange?.(selectedRaceId, nextTheme);
    }
  };

  const handleResetToCanonical = () => {
    const fresh = resetRaceProfileToCanonical(selectedRaceId);
    setProfile(fresh);
    if (applyThemeGlobally) {
      applyRaceThemeToDocument(fresh.theme, selectedRaceId);
      onActiveThemeChange?.(selectedRaceId, fresh.theme);
    }
  };

  const handleCopyJson = () => {
    const payload = {
      raceId: selectedRaceId,
      provenancePackId: provenance.pack_id,
      paintedViewsSeed: provenance.painted_views_seed,
      stage3ContractVersion: contract.version,
      theme: profile.theme,
      rig: profile.rig,
    };
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
      setCopiedJson(true);
      setTimeout(() => setCopiedJson(false), 2000);
    }
  };

  const activeSpriteRecord = getCachedCleanedHeroSprite(hero.id, currentDirection);
  const currentMasterMeta = provenance.masters.find((m) =>
    m.file.includes(`master-${currentDirection}.png`)
  );
  const currentPaintedViewMeta = provenance.painted_views.find(
    (v) => v.direction === currentDirection
  );

  return (
    <div
      className="space-y-6 text-stone-100"
      style={
        {
          '--editor-accent': profile.theme.primaryAccent,
          '--editor-secondary': profile.theme.secondaryAccent,
          '--editor-glow': profile.theme.auraGlow,
          '--editor-surface': profile.theme.surfaceTint,
          '--editor-border': profile.theme.borderAccent,
        } as React.CSSProperties
      }
    >
      {/* Top Studio Header */}
      <div
        className="rounded-2xl border p-5 transition-colors"
        style={{
          backgroundColor: 'rgba(12, 10, 9, 0.9)',
          borderColor: `${profile.theme.primaryAccent}44`,
          boxShadow: `0 12px 40px -16px ${profile.theme.primaryAccent}33`,
        }}
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div
              className="text-xs font-mono uppercase tracking-widest flex items-center gap-2"
              style={{ color: profile.theme.primaryAccent }}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>
                Character Race Editor · Pack: {provenance.pack_id} · Seed #{provenance.painted_views_seed} · Stage 3 Contract v{contract.version}
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white mt-1">
              Edytor Rasy, Animacji 2D i Dynamicznego Motywu UI
            </h2>
            <p className="text-sm text-stone-400 mt-1 max-w-3xl">
              Zarządzaj wyglądem 8-kierunkowych masterów ({provenance.tools.rembg_model}), kalibracją kotwicy stóp, kinematyką 6 stanów ruchu oraz dynamiczną paletą kolorystyczną interfejsu rasy.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={handleResetToCanonical}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-mono font-semibold border border-stone-700 bg-stone-900 hover:bg-stone-800 text-stone-300 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Kanoniczny
            </button>

            <button
              onClick={handleCopyJson}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-mono font-semibold border border-stone-700 bg-stone-900 hover:bg-stone-800 text-stone-200 transition-colors cursor-pointer"
            >
              {copiedJson ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  Skopiowano JSON
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  Kopiuj Profil JSON
                </>
              )}
            </button>

            {onLaunchCombatWithRace && (
              <button
                onClick={() => onLaunchCombatWithRace(selectedRaceId)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold text-stone-950 transition-all cursor-pointer shadow-lg"
                style={{
                  backgroundColor: profile.theme.primaryAccent,
                  boxShadow: `0 6px 20px -4px ${profile.theme.primaryAccent}80`,
                }}
              >
                Testuj {hero.polishName} w Walce
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* 4 Race Selector Cards with Dynamic Theme Indicator */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-5">
          {HERO_RACES.map((r) => {
            const rProfile = getRaceProfile(r.id);
            const rMeta = CANONICAL_RACE_PROVENANCE[r.id];
            const isSelected = r.id === selectedRaceId;
            return (
              <button
                key={r.id}
                onClick={() => {
                  setSelectedRaceId(r.id);
                  setAnimFrameIndex(0);
                }}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden ${
                  isSelected ? 'bg-stone-900/95 shadow-lg' : 'bg-stone-950/60 border-stone-800/90 hover:border-stone-700'
                }`}
                style={
                  isSelected
                    ? {
                        borderColor: rProfile.theme.primaryAccent,
                        boxShadow: `0 0 0 1px ${rProfile.theme.primaryAccent}55, 0 8px 24px -8px ${rProfile.theme.primaryAccent}40`,
                      }
                    : undefined
                }
              >
                <div className="flex items-center justify-between text-[11px] font-mono text-stone-400">
                  <span>
                    {r.homeworld.toUpperCase()} · {rMeta.pack_id}
                  </span>
                  <span
                    className="w-3 h-3 rounded-sm border border-white/20"
                    style={{ backgroundColor: rProfile.theme.primaryAccent }}
                  />
                </div>
                <div className="font-bold text-base text-white mt-1 flex items-center justify-between">
                  <span>{r.polishName}</span>
                  <span className="text-xs font-mono text-stone-400">{r.name}</span>
                </div>
                <div className="text-[11px] font-mono text-stone-400 mt-1.5 truncate">
                  Motyw: <span style={{ color: rProfile.theme.primaryAccent }}>{rProfile.theme.namePl}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Two-Column Studio Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT COLUMN (7 cols): Live Interactive Stage + 8-Direction Matrix + Live Dynamic HUD Preview */}
        <div className="lg:col-span-7 space-y-5">
          <div
            className="rounded-2xl border p-5 bg-stone-900/75 backdrop-blur-sm"
            style={{ borderColor: `${profile.theme.primaryAccent}33` }}
          >
            {/* Stage Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-2 pb-4 mb-4 border-b border-stone-800">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => updateRig({ useCleanedSprite: !profile.rig.useCleanedSprite })}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-semibold border transition-all cursor-pointer ${
                    profile.rig.useCleanedSprite
                      ? 'bg-emerald-950/80 border-emerald-500/70 text-emerald-300'
                      : 'bg-amber-950/80 border-amber-500/70 text-amber-300'
                  }`}
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  {profile.rig.useCleanedSprite ? 'Matting Alfa: OCZYSZCZONY' : 'Matting Alfa: SUROWY MASTER'}
                </button>

                <button
                  onClick={() => updateRig({ showAura: !profile.rig.showAura })}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-semibold border transition-all cursor-pointer ${
                    profile.rig.showAura
                      ? 'bg-stone-900 text-white'
                      : 'bg-stone-950 border-stone-800 text-stone-400'
                  }`}
                  style={
                    profile.rig.showAura
                      ? { borderColor: profile.theme.primaryAccent, color: profile.theme.auraGlow }
                      : undefined
                  }
                >
                  <Layers className="w-3.5 h-3.5" />
                  Aura KI: {profile.rig.showAura ? 'AKTYWNA' : 'WYŁ.'}
                </button>

                <button
                  onClick={() => updateRig({ showFeetAnchor: !profile.rig.showFeetAnchor })}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-mono border transition-all cursor-pointer ${
                    profile.rig.showFeetAnchor
                      ? 'bg-emerald-950/70 border-emerald-500 text-emerald-300'
                      : 'bg-stone-950 border-stone-800 text-stone-400 hover:text-stone-200'
                  }`}
                >
                  <Crosshair className="w-3.5 h-3.5" />
                  Kotwica [{profile.rig.feetAnchorY.toFixed(2)}]
                </button>
              </div>

              <button
                onClick={() => setIsTurntableRotating(!isTurntableRotating)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-semibold border transition-all cursor-pointer ${
                  isTurntableRotating
                    ? 'bg-stone-800 text-white border-stone-500'
                    : 'bg-stone-950 border-stone-800 text-stone-300 hover:border-stone-700'
                }`}
              >
                <RotateCw className={`w-3.5 h-3.5 ${isTurntableRotating ? 'animate-spin' : ''}`} />
                {isTurntableRotating ? 'Obrót 360°: WŁ.' : 'Obrót 360°'}
              </button>
            </div>

            {/* Primary 512x512 Calibrated Viewport */}
            <div
              className="relative rounded-xl border overflow-hidden flex items-center justify-center min-h-[360px]"
              style={{
                borderColor: `${profile.theme.borderAccent}55`,
                background: profile.rig.useCleanedSprite
                  ? `radial-gradient(circle at 50% 60%, ${profile.theme.surfaceTint} 0%, #090807 85%)`
                  : 'repeating-conic-gradient(#292524 0% 25%, #1c1917 0% 50%) 50% / 24px 24px',
              }}
            >
              {/* Subtle Isometric Calibration Grid */}
              <div
                className="absolute inset-0 opacity-20 pointer-events-none"
                style={{
                  backgroundImage: `radial-gradient(circle at center, ${profile.theme.primaryAccent} 1px, transparent 1px)`,
                  backgroundSize: '24px 24px',
                }}
              />

              {/* Top-left Metadata Overlay */}
              <div className="absolute top-3 left-3 z-20 space-y-1 text-[11px] font-mono text-stone-300 bg-stone-950/85 border border-stone-800/90 px-3 py-2 rounded-lg backdrop-blur-sm">
                <div>
                  Plik: <span className="text-white">{currentMasterMeta?.file || `${hero.id}-master-${currentDirection}.png`}</span>
                </div>
                <div>
                  SHA-256: <span className="text-stone-400">{currentMasterMeta?.sha256.slice(0, 16)}…</span>
                </div>
                {activeSpriteRecord && (
                  <div>
                    Oczyszczono tło:{' '}
                    <span style={{ color: profile.theme.primaryAccent }}>
                      {(
                        activeSpriteRecord.removedPixelsCount +
                        activeSpriteRecord.defringedPixelsCount
                      ).toLocaleString('pl-PL')}{' '}
                      px
                    </span>{' '}
                    · Bounds: {activeSpriteRecord.bounds.width}×{activeSpriteRecord.bounds.height}px
                  </div>
                )}
              </div>

              {/* Top-right World Size Badge */}
              <div className="absolute top-3 right-3 z-20 text-[11px] font-mono bg-stone-950/85 border border-stone-800/90 px-3 py-1.5 rounded-lg text-stone-300">
                Rozmiar świata: <strong className="text-white">{profile.rig.worldHeightTrialPx}px</strong> · Skala: <strong className="text-white">{profile.rig.scaleMultiplier.toFixed(2)}x</strong>
              </div>

              <canvas
                ref={mainStageCanvasRef}
                width={420}
                height={360}
                className="relative z-10 max-h-[340px] w-auto object-contain drop-shadow-[0_14px_24px_rgba(0,0,0,0.85)]"
              />

              {/* Bottom Status Strip inside Stage */}
              <div className="absolute bottom-3 inset-x-3 z-20 flex flex-wrap items-center justify-between gap-2 px-3 py-1.5 rounded-lg bg-stone-950/90 border border-stone-800/90 text-xs font-mono">
                <div className="flex items-center gap-2">
                  <span style={{ color: profile.theme.primaryAccent }}>
                    Kierunek: {currentDirection.toUpperCase()}
                  </span>
                  <span className="text-stone-600">·</span>
                  <span className="text-stone-200">
                    Animacja: {ANIM_STATES.find((a) => a.key === activeAnim)?.labelPl}
                  </span>
                </div>
                <div className="text-stone-300">
                  Klatka {(animFrameIndex % totalFrames) + 1}/{totalFrames} · {effectiveFps} FPS
                </div>
              </div>
            </div>

            {/* Timeline Scrubber & Quick State Bar */}
            <div className="mt-4 bg-stone-950/90 border border-stone-800/90 rounded-xl p-3.5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-bold text-stone-950 cursor-pointer"
                    style={{ backgroundColor: profile.theme.primaryAccent }}
                  >
                    {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    {isPlaying ? 'PAUZA' : 'ODTWÓRZ'}
                  </button>
                  <span className="text-xs font-mono text-stone-400">
                    Oś klatek ({totalFrames} kl.) — kliknij klatkę aby zbadać pozę
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {Array.from({ length: totalFrames }).map((_, idx) => {
                    const isCurrent = animFrameIndex % totalFrames === idx;
                    return (
                      <button
                        key={idx}
                        onClick={() => {
                          setIsPlaying(false);
                          setAnimFrameIndex(idx);
                        }}
                        className={`w-7 h-7 rounded-md font-mono text-xs font-bold border transition-all cursor-pointer ${
                          isCurrent
                            ? 'text-stone-950 shadow-sm'
                            : 'bg-stone-900 border-stone-800 text-stone-400 hover:text-white'
                        }`}
                        style={
                          isCurrent
                            ? {
                                backgroundColor: profile.theme.primaryAccent,
                                borderColor: profile.theme.auraGlow,
                              }
                            : undefined
                        }
                      >
                        {idx + 1}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 6 Animation States Selector */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                {ANIM_STATES.map((st) => {
                  const active = activeAnim === st.key;
                  return (
                    <button
                      key={st.key}
                      onClick={() => {
                        setActiveAnim(st.key);
                        setAnimFrameIndex(0);
                      }}
                      className={`py-2 px-2 rounded-lg text-xs font-mono font-semibold border transition-all cursor-pointer ${
                        active
                          ? 'text-white shadow-sm'
                          : 'bg-stone-900/70 border-stone-800 text-stone-400 hover:text-stone-200'
                      }`}
                      style={
                        active
                          ? {
                              backgroundColor: `${profile.theme.primaryAccent}28`,
                              borderColor: profile.theme.primaryAccent,
                              color: profile.theme.auraGlow,
                            }
                          : undefined
                      }
                    >
                      {st.key.toUpperCase()}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Simultaneous 8-Direction Miniature Matrix */}
            <div className="mt-4">
              <div className="flex items-center justify-between text-xs font-mono text-stone-400 mb-2">
                <span>PODGLĄD WSZYSTKICH 8 KIERUNKÓW NA ŻYWO (KLIKNIJ ABY WYBRAĆ KIERUNEK GŁÓWNY)</span>
                <span className="text-stone-500">Kamera ortograficzna 60°</span>
              </div>
              <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                {DIRECTIONS.map((dir) => {
                  const isCurrentDir = currentDirection === dir.key;
                  return (
                    <button
                      key={dir.key}
                      onClick={() => {
                        setIsTurntableRotating(false);
                        setCurrentDirection(dir.key);
                      }}
                      className={`p-1.5 rounded-xl border flex flex-col items-center transition-all cursor-pointer ${
                        isCurrentDir
                          ? 'bg-stone-900 shadow-md'
                          : 'bg-stone-950/70 border-stone-800/80 hover:border-stone-700'
                      }`}
                      style={
                        isCurrentDir
                          ? {
                              borderColor: profile.theme.primaryAccent,
                              boxShadow: `0 0 0 1px ${profile.theme.primaryAccent}55`,
                            }
                          : undefined
                      }
                    >
                      <canvas
                        ref={(el) => {
                          directionMiniCanvasRefs.current[dir.key] = el;
                        }}
                        width={88}
                        height={88}
                        className="w-14 h-14 object-contain"
                      />
                      <span
                        className="text-[10px] font-mono font-bold mt-1"
                        style={{ color: isCurrentDir ? profile.theme.primaryAccent : '#a8a29e' }}
                      >
                        {dir.short} ({dir.key})
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Live Dynamic Race UI Theme HUD Preview Card */}
          <div
            className="rounded-2xl border p-5 transition-all"
            style={{
              backgroundColor: profile.theme.surfaceTint,
              borderColor: `${profile.theme.borderAccent}77`,
              boxShadow: `0 12px 32px -12px ${profile.theme.primaryAccent}33`,
            }}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="text-xs font-mono uppercase tracking-wider flex items-center gap-2" style={{ color: profile.theme.auraGlow }}>
                <Palette className="w-3.5 h-3.5" />
                <span>Podgląd HUD na Żywo — Dynamiczny Motyw Rasy: {profile.theme.namePl}</span>
              </div>
              <span className="text-[11px] font-mono text-stone-300">
                Primary {profile.theme.primaryAccent} · Glow {profile.theme.auraGlow}
              </span>
            </div>

            {/* Simulated In-Game Anime RPG HUD Bar using the Race Dynamic Theme */}
            <div className="bg-stone-950/90 border rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4" style={{ borderColor: `${profile.theme.borderAccent}66` }}>
              {/* Left: Portrait & HP/KI Bars */}
              <div className="flex items-center gap-3.5 w-full sm:w-auto">
                <div
                  className="w-14 h-14 rounded-xl border-2 flex items-center justify-center relative overflow-hidden shrink-0 bg-stone-900"
                  style={{
                    borderColor: profile.theme.primaryAccent,
                    boxShadow: `0 0 16px ${profile.theme.primaryAccent}55`,
                  }}
                >
                  <img
                    src={hero.views[currentDirection]}
                    alt={hero.polishName}
                    className="w-12 h-12 object-contain"
                  />
                  <span
                    className="absolute bottom-0 right-0 px-1 text-[9px] font-mono font-bold text-stone-950"
                    style={{ backgroundColor: profile.theme.primaryAccent }}
                  >
                    LV.20
                  </span>
                </div>

                <div className="flex-1 min-w-[180px] space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-white">{hero.polishName}</span>
                    <span className="font-mono text-[11px]" style={{ color: profile.theme.auraGlow }}>
                      {hero.combatRole}
                    </span>
                  </div>

                  {/* HP Bar */}
                  <div>
                    <div className="flex justify-between text-[10px] font-mono text-stone-300 mb-0.5">
                      <span>HP</span>
                      <span>{hero.baseStats.hp * 10} / {hero.baseStats.hp * 10}</span>
                    </div>
                    <div className="w-full h-2.5 bg-stone-900 rounded-sm overflow-hidden border border-stone-800">
                      <div
                        className="h-full transition-all"
                        style={{
                          width: '88%',
                          backgroundColor: profile.theme.hpBarColor,
                          boxShadow: `0 0 10px ${profile.theme.hpBarColor}`,
                        }}
                      />
                    </div>
                  </div>

                  {/* KI Bar */}
                  <div>
                    <div className="flex justify-between text-[10px] font-mono text-stone-300 mb-0.5">
                      <span>ENERGIA KI (+{hero.baseStats.kiRegen}/s)</span>
                      <span>{hero.baseStats.ki} / {hero.baseStats.ki}</span>
                    </div>
                    <div className="w-full h-2 bg-stone-900 rounded-sm overflow-hidden border border-stone-800">
                      <div
                        className="h-full transition-all"
                        style={{
                          width: '94%',
                          backgroundColor: profile.theme.kiBarColor,
                          boxShadow: `0 0 10px ${profile.theme.kiBarColor}`,
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Right: 3 Racial Skill Slots (Q, E, R) */}
              <div className="flex items-center gap-2">
                {hero.skills.map((sk) => (
                  <button
                    key={sk.key}
                    onClick={() => {
                      setActiveAnim(sk.key === 'Q' ? 'attack' : 'skill');
                      setIsPlaying(true);
                    }}
                    title={`${sk.polishName} (${sk.cost} KI)`}
                    className="group relative w-14 h-14 rounded-xl border bg-stone-900/90 flex flex-col items-center justify-center transition-all cursor-pointer hover:-translate-y-0.5"
                    style={{
                      borderColor: `${profile.theme.primaryAccent}88`,
                      boxShadow: `inset 0 0 12px ${profile.theme.primaryAccent}22`,
                    }}
                  >
                    <span
                      className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-stone-950 border"
                      style={{
                        borderColor: profile.theme.borderAccent,
                        color: profile.theme.auraGlow,
                      }}
                    >
                      {sk.key}
                    </span>
                    <span className="text-[10px] font-medium text-stone-200 mt-1 truncate max-w-[48px]">
                      {sk.polishName.split(' ')[0]}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN (5 cols): Tabbed Inspector & Editor Controls */}
        <div className="lg:col-span-5 bg-stone-900/80 border border-stone-800 rounded-2xl p-5 backdrop-blur-sm space-y-5">
          {/* 4 Sub-Workspace Tabs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 bg-stone-950 rounded-xl border border-stone-800 text-xs font-mono">
            <button
              onClick={() => setWorkspaceTab('appearance')}
              className={`py-2 px-2 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                workspaceTab === 'appearance' ? 'text-stone-950 shadow-sm' : 'text-stone-400 hover:text-white'
              }`}
              style={workspaceTab === 'appearance' ? { backgroundColor: profile.theme.primaryAccent } : undefined}
            >
              <Sliders className="w-3.5 h-3.5" />
              Wygląd
            </button>
            <button
              onClick={() => setWorkspaceTab('animation')}
              className={`py-2 px-2 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                workspaceTab === 'animation' ? 'text-stone-950 shadow-sm' : 'text-stone-400 hover:text-white'
              }`}
              style={workspaceTab === 'animation' ? { backgroundColor: profile.theme.primaryAccent } : undefined}
            >
              <Activity className="w-3.5 h-3.5" />
              Rig 2D
            </button>
            <button
              onClick={() => setWorkspaceTab('theme')}
              className={`py-2 px-2 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                workspaceTab === 'theme' ? 'text-stone-950 shadow-sm' : 'text-stone-400 hover:text-white'
              }`}
              style={workspaceTab === 'theme' ? { backgroundColor: profile.theme.primaryAccent } : undefined}
            >
              <Palette className="w-3.5 h-3.5" />
              Motyw UI
            </button>
            <button
              onClick={() => setWorkspaceTab('metadata')}
              className={`py-2 px-2 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                workspaceTab === 'metadata' ? 'text-stone-950 shadow-sm' : 'text-stone-400 hover:text-white'
              }`}
              style={workspaceTab === 'metadata' ? { backgroundColor: profile.theme.primaryAccent } : undefined}
            >
              <FileJson className="w-3.5 h-3.5" />
              Metadane
            </button>
          </div>

          {/* TAB 1: APPEARANCE & MATTING CALIBRATION */}
          {workspaceTab === 'appearance' && (
            <div className="space-y-5">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Eye className="w-4 h-4" style={{ color: profile.theme.primaryAccent }} />
                  Kalibracja Wyglądu, Skali i Mattingu Alfa
                </h3>
                <p className="text-xs text-stone-400 mt-1">
                  Parametry zgodne z kontraktem <code className="text-stone-200">stage3-render-contract.json</code> (źródło {contract.character.sourceFrame[0]}×{contract.character.sourceFrame[1]}px).
                </p>
              </div>

              {/* World Height Trials from stage3-render-contract.json */}
              <div className="p-3.5 rounded-xl bg-stone-950/80 border border-stone-800 space-y-2.5">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-stone-300">Rozmiar w świecie (Stage 3 Height Trials)</span>
                  <span style={{ color: profile.theme.primaryAccent }}>{profile.rig.worldHeightTrialPx}px</span>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {[96, ...contract.character.futureWorldHeightTrials].map((px) => (
                    <button
                      key={px}
                      onClick={() => updateRig({ worldHeightTrialPx: px })}
                      className={`py-1.5 rounded-lg text-xs font-mono font-bold border transition-all cursor-pointer ${
                        profile.rig.worldHeightTrialPx === px
                          ? 'text-stone-950'
                          : 'bg-stone-900 border-stone-800 text-stone-400 hover:text-white'
                      }`}
                      style={
                        profile.rig.worldHeightTrialPx === px
                          ? { backgroundColor: profile.theme.primaryAccent, borderColor: profile.theme.auraGlow }
                          : undefined
                      }
                    >
                      {px}px {px === 96 ? '(Dom.)' : ''}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sliders for Scale, Feet Anchor Y, Collision Radius */}
              <div className="space-y-3.5 p-4 rounded-xl bg-stone-950/80 border border-stone-800">
                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-stone-300">Mnożnik Skali Postaci</span>
                    <span className="text-white">{profile.rig.scaleMultiplier.toFixed(2)}x</span>
                  </div>
                  <input
                    type="range"
                    min={0.7}
                    max={1.35}
                    step={0.05}
                    value={profile.rig.scaleMultiplier}
                    onChange={(e) => updateRig({ scaleMultiplier: parseFloat(e.target.value) })}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-stone-300">Kotwica Stóp Y (Feet Anchor)</span>
                    <span className="text-white">[0.50, {profile.rig.feetAnchorY.toFixed(2)}]</span>
                  </div>
                  <input
                    type="range"
                    min={0.84}
                    max={0.97}
                    step={0.01}
                    value={profile.rig.feetAnchorY}
                    onChange={(e) => updateRig({ feetAnchorY: parseFloat(e.target.value) })}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-stone-300">Promień Kolizji (World Units)</span>
                    <span className="text-white">{profile.rig.collisionRadiusUnits} j.</span>
                  </div>
                  <input
                    type="range"
                    min={8}
                    max={20}
                    step={1}
                    value={profile.rig.collisionRadiusUnits}
                    onChange={(e) =>
                      updateRig({
                        collisionRadiusUnits: parseInt(e.target.value, 10),
                        showCollisionCircle: true,
                      })
                    }
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-stone-800/80 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer text-stone-300">
                    <input
                      type="checkbox"
                      checked={profile.rig.showFeetAnchor}
                      onChange={(e) => updateRig({ showFeetAnchor: e.target.checked })}
                      className="rounded border-stone-700"
                    />
                    Pokaż celownik kotwicy stóp
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-stone-300">
                    <input
                      type="checkbox"
                      checked={profile.rig.showCollisionCircle}
                      onChange={(e) => updateRig({ showCollisionCircle: e.target.checked })}
                      className="rounded border-stone-700"
                    />
                    Pokaż okrąg kolizji
                  </label>
                </div>
              </div>

              {/* Color Grading Filters */}
              <div className="space-y-3.5 p-4 rounded-xl bg-stone-950/80 border border-stone-800">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono uppercase tracking-wider text-stone-400">
                    Korekcja Barwna Sprite&apos;a (Shader 2D)
                  </span>
                  <button
                    onClick={() =>
                      updateRig({
                        hueShiftDeg: 0,
                        saturationPct: 100,
                        brightnessPct: 100,
                        contrastPct: 100,
                      })
                    }
                    className="text-[11px] font-mono text-stone-400 hover:text-white underline cursor-pointer"
                  >
                    Zeruj filtry
                  </button>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-stone-300">Przesunięcie Barwy (Hue)</span>
                    <span className="text-white">{profile.rig.hueShiftDeg}°</span>
                  </div>
                  <input
                    type="range"
                    min={-180}
                    max={180}
                    step={5}
                    value={profile.rig.hueShiftDeg}
                    onChange={(e) => updateRig({ hueShiftDeg: parseInt(e.target.value, 10) })}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-stone-300">Nasycenie (Saturation)</span>
                    <span className="text-white">{profile.rig.saturationPct}%</span>
                  </div>
                  <input
                    type="range"
                    min={50}
                    max={160}
                    step={5}
                    value={profile.rig.saturationPct}
                    onChange={(e) => updateRig({ saturationPct: parseInt(e.target.value, 10) })}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="flex justify-between text-xs font-mono mb-1">
                      <span className="text-stone-300">Jasność</span>
                      <span className="text-white">{profile.rig.brightnessPct}%</span>
                    </div>
                    <input
                      type="range"
                      min={75}
                      max={135}
                      step={5}
                      value={profile.rig.brightnessPct}
                      onChange={(e) => updateRig({ brightnessPct: parseInt(e.target.value, 10) })}
                      className="w-full accent-emerald-500 cursor-pointer"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-xs font-mono mb-1">
                      <span className="text-stone-300">Kontrast</span>
                      <span className="text-white">{profile.rig.contrastPct}%</span>
                    </div>
                    <input
                      type="range"
                      min={80}
                      max={140}
                      step={5}
                      value={profile.rig.contrastPct}
                      onChange={(e) => updateRig({ contrastPct: parseInt(e.target.value, 10) })}
                      className="w-full accent-emerald-500 cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: 2D MESH ANIMATION RIG */}
          {workspaceTab === 'animation' && (
            <div className="space-y-5">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Activity className="w-4 h-4" style={{ color: profile.theme.primaryAccent }} />
                  Kinematyka Rigu 2D i Parametry Animacji (8×6)
                </h3>
                <p className="text-xs text-stone-400 mt-1">
                  Metoda z <code className="text-stone-200">provenance.json</code>: {provenance.method}.
                </p>
              </div>

              <div className="space-y-3.5 p-4 rounded-xl bg-stone-950/80 border border-stone-800">
                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-stone-300">Prędkość Odtwarzania (Mnożnik FPS)</span>
                    <span className="text-white">
                      {profile.rig.fpsMultiplier.toFixed(2)}x ({effectiveFps} FPS)
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.25}
                    max={2.0}
                    step={0.05}
                    value={profile.rig.fpsMultiplier}
                    onChange={(e) => updateRig({ fpsMultiplier: parseFloat(e.target.value) })}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-stone-300">Amplituda Kroku L/P (Walk Stride)</span>
                    <span className="text-white">{(profile.rig.strideAmplitude * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.3}
                    max={1.7}
                    step={0.05}
                    value={profile.rig.strideAmplitude}
                    onChange={(e) => {
                      setActiveAnim('walk');
                      updateRig({ strideAmplitude: parseFloat(e.target.value) });
                    }}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-stone-300">Fizyka Szat i Płaszcza (4 pasma)</span>
                    <span className="text-white">{(profile.rig.clothWaveIntensity * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.0}
                    max={2.0}
                    step={0.05}
                    value={profile.rig.clothWaveIntensity}
                    onChange={(e) => updateRig({ clothWaveIntensity: parseFloat(e.target.value) })}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-stone-300">Zasięg Wypadu Bojowego (Attack Lunge)</span>
                    <span className="text-white">{(profile.rig.attackLungeDistance * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.4}
                    max={1.7}
                    step={0.05}
                    value={profile.rig.attackLungeDistance}
                    onChange={(e) => {
                      setActiveAnim('attack');
                      updateRig({ attackLungeDistance: parseFloat(e.target.value) });
                    }}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-stone-300">Wysokość Lewitacji KI (Skill Surge)</span>
                    <span className="text-white">{(profile.rig.skillLevitationHeight * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.3}
                    max={1.8}
                    step={0.05}
                    value={profile.rig.skillLevitationHeight}
                    onChange={(e) => {
                      setActiveAnim('skill');
                      updateRig({ skillLevitationHeight: parseFloat(e.target.value) });
                    }}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-stone-300">Głębokość Oddechu (Idle Breathing)</span>
                    <span className="text-white">{(profile.rig.breathingDepth * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.2}
                    max={2.0}
                    step={0.05}
                    value={profile.rig.breathingDepth}
                    onChange={(e) => {
                      setActiveAnim('idle');
                      updateRig({ breathingDepth: parseFloat(e.target.value) });
                    }}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-stone-300">Intensywność Warstwy Aury KI</span>
                    <span className="text-white">{(profile.rig.auraIntensity * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.0}
                    max={1.6}
                    step={0.05}
                    value={profile.rig.auraIntensity}
                    onChange={(e) => updateRig({ auraIntensity: parseFloat(e.target.value) })}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: DYNAMIC RACE UI COLOR THEME */}
          {workspaceTab === 'theme' && (
            <div className="space-y-5">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Palette className="w-4 h-4" style={{ color: profile.theme.primaryAccent }} />
                  Dynamiczny Motyw Kolorystyczny Rasy ({hero.polishName})
                </h3>
                <p className="text-xs text-stone-400 mt-1">
                  Zmieniaj paletę akcentów UI, poświatę aury KI oraz paski HUD dla wybranej rasy.
                </p>
              </div>

              {/* Global UI Sync Toggle */}
              <label className="flex items-center justify-between p-3.5 rounded-xl bg-stone-950/90 border border-stone-800 cursor-pointer">
                <div>
                  <div className="text-xs font-bold text-white">
                    Synchronizuj motyw z całym interfejsem aplikacji
                  </div>
                  <div className="text-[11px] text-stone-400">
                    Aktualizuje zmienne CSS <code className="text-stone-300">--race-primary</code> i nawigację na żywo
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={applyThemeGlobally}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    setApplyThemeGlobally(checked);
                    if (checked) {
                      setActiveUiThemeRaceId(selectedRaceId);
                      applyRaceThemeToDocument(profile.theme, selectedRaceId);
                      onActiveThemeChange?.(selectedRaceId, profile.theme);
                    }
                  }}
                  className="w-4 h-4 rounded"
                />
              </label>

              {/* Preset Palettes for Selected Race */}
              <div className="space-y-2">
                <div className="text-xs font-mono uppercase tracking-wider text-stone-400">
                  Gotowe Palety Rasy ({hero.polishName})
                </div>
                <div className="space-y-2">
                  {RACE_THEME_PRESETS[selectedRaceId].map((preset) => {
                    const isCurrentPreset = profile.theme.id === preset.id;
                    return (
                      <button
                        key={preset.id}
                        onClick={() => updateTheme(preset)}
                        className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                          isCurrentPreset
                            ? 'bg-stone-900 border-white/40 shadow-md'
                            : 'bg-stone-950/70 border-stone-800 hover:border-stone-700'
                        }`}
                      >
                        <div>
                          <div className="text-xs font-bold text-white">{preset.namePl}</div>
                          <div className="text-[11px] font-mono text-stone-400 mt-0.5">
                            {preset.primaryAccent} · {preset.secondaryAccent} · {preset.surfaceTint}
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span
                            className="w-5 h-5 rounded-md border border-white/20"
                            style={{ backgroundColor: preset.primaryAccent }}
                          />
                          <span
                            className="w-5 h-5 rounded-md border border-white/20"
                            style={{ backgroundColor: preset.auraGlow }}
                          />
                          <span
                            className="w-5 h-5 rounded-md border border-white/20"
                            style={{ backgroundColor: preset.surfaceTint }}
                          />
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Custom Color Pickers */}
              <div className="p-4 rounded-xl bg-stone-950/80 border border-stone-800 space-y-3">
                <div className="text-xs font-mono uppercase tracking-wider text-stone-400">
                  Niestandardowe Kolory Motywu i Aury
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <label className="flex items-center justify-between p-2.5 rounded-lg bg-stone-900 border border-stone-800 text-xs">
                    <span className="text-stone-300">Akcent Główny</span>
                    <input
                      type="color"
                      value={profile.theme.primaryAccent}
                      onChange={(e) => updateTheme({ primaryAccent: e.target.value, namePl: 'Własna Paleta Rasy' })}
                      className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                    />
                  </label>

                  <label className="flex items-center justify-between p-2.5 rounded-lg bg-stone-900 border border-stone-800 text-xs">
                    <span className="text-stone-300">Poświata Aury</span>
                    <input
                      type="color"
                      value={profile.theme.auraGlow}
                      onChange={(e) => updateTheme({ auraGlow: e.target.value, namePl: 'Własna Paleta Rasy' })}
                      className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                    />
                  </label>

                  <label className="flex items-center justify-between p-2.5 rounded-lg bg-stone-900 border border-stone-800 text-xs">
                    <span className="text-stone-300">Tło Powierzchni</span>
                    <input
                      type="color"
                      value={profile.theme.surfaceTint}
                      onChange={(e) => updateTheme({ surfaceTint: e.target.value, namePl: 'Własna Paleta Rasy' })}
                      className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                    />
                  </label>

                  <label className="flex items-center justify-between p-2.5 rounded-lg bg-stone-900 border border-stone-800 text-xs">
                    <span className="text-stone-300">Obramowanie UI</span>
                    <input
                      type="color"
                      value={profile.theme.borderAccent}
                      onChange={(e) => updateTheme({ borderAccent: e.target.value, namePl: 'Własna Paleta Rasy' })}
                      className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                    />
                  </label>

                  <label className="flex items-center justify-between p-2.5 rounded-lg bg-stone-900 border border-stone-800 text-xs">
                    <span className="text-stone-300">Pasek Zdrowia (HP)</span>
                    <input
                      type="color"
                      value={profile.theme.hpBarColor}
                      onChange={(e) => updateTheme({ hpBarColor: e.target.value, namePl: 'Własna Paleta Rasy' })}
                      className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                    />
                  </label>

                  <label className="flex items-center justify-between p-2.5 rounded-lg bg-stone-900 border border-stone-800 text-xs">
                    <span className="text-stone-300">Pasek Energii (KI)</span>
                    <input
                      type="color"
                      value={profile.theme.kiBarColor}
                      onChange={(e) => updateTheme({ kiBarColor: e.target.value, namePl: 'Własna Paleta Rasy' })}
                      className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                    />
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: PROVENANCE.JSON & STAGE 3 RENDER CONTRACT METADATA INSPECTOR */}
          {workspaceTab === 'metadata' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <FileJson className="w-4 h-4" style={{ color: profile.theme.primaryAccent }} />
                  Inspektor Plików Metadanych Rasy
                </h3>
                <p className="text-xs text-stone-400 mt-1">
                  Dane odczytane bezpośrednio z <code className="text-stone-200">/art/production/heroes/{selectedRaceId}/painted-v1/provenance.json</code>.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-stone-950/90 border border-stone-800 space-y-2 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-stone-400">Pack ID:</span>
                  <span className="text-white font-bold">{provenance.pack_id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">Świat macierzysty:</span>
                  <span className="text-white">{provenance.world}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">Seed widoków:</span>
                  <span style={{ color: profile.theme.primaryAccent }}>#{provenance.painted_views_seed}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">Model mattingu:</span>
                  <span className="text-stone-200">{provenance.tools.rembg_model}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">Checkpoint:</span>
                  <span className="text-stone-200">{provenance.tools.checkpoint}</span>
                </div>
                <div className="pt-1 border-t border-stone-800 text-[11px] text-stone-300">
                  Status właściciela: <span className="text-emerald-400">{provenance.owner_status}</span>
                </div>
              </div>

              {/* 8 Directional Master PNG SHA-256 Table */}
              <div className="p-3.5 rounded-xl bg-stone-950/90 border border-stone-800 space-y-2">
                <div className="text-xs font-mono uppercase tracking-wider text-stone-400">
                  Sumy Kontrolne 8 Masterów PNG (SHA-256)
                </div>
                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {provenance.masters.map((m) => {
                    const isSelectedMaster = m.file.includes(`master-${currentDirection}.png`);
                    return (
                      <div
                        key={m.file}
                        className={`p-2 rounded-lg border text-[11px] font-mono flex items-center justify-between ${
                          isSelectedMaster
                            ? 'bg-stone-900 border-stone-600 text-white'
                            : 'bg-stone-950 border-stone-800/80 text-stone-400'
                        }`}
                      >
                        <span className="truncate mr-2">{m.file}</span>
                        <span className="text-stone-500 shrink-0">{m.sha256.slice(0, 14)}…</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Stage 3 Validation Checklist */}
              <div className="p-3.5 rounded-xl bg-stone-950/90 border border-stone-800 space-y-2">
                <div className="text-xs font-mono uppercase tracking-wider text-stone-400">
                  Walidacja Kontraktu Renderowania (Stage 3)
                </div>
                <div className="flex flex-wrap gap-1.5 text-[11px] font-mono">
                  {contract.validation.map((rule) => (
                    <span
                      key={rule}
                      className="px-2 py-1 rounded bg-stone-900 border border-stone-800 text-stone-300"
                    >
                      ✓ {rule}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
