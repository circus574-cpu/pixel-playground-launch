import React, { useState, useEffect, useRef } from 'react';
import { HERO_RACES, HeroRace, Direction } from '../data/heroes';
import {
  HeroAnimState,
  HERO_ANIM_FPS,
  HERO_ANIM_FRAMES,
  ensureCleanedHeroSprite,
  getCachedCleanedHeroSprite,
  renderAnimatedHero,
} from '../game/heroes/spriteAnimator';
import { getRaceProfile } from '../game/heroes/raceMetadata';
import {
  Shield,
  Zap,
  RotateCw,
  Play,
  Pause,
  Sparkles,
  Heart,
  Flame,
  Wind,
  Crosshair,
  ChevronRight,
  Info,
  Wand2,
  Eye,
  Layers,
  Sliders,
} from 'lucide-react';

const DIRECTIONS: { key: Direction; label: string; angle: number }[] = [
  { key: 'up', label: 'N (Góra)', angle: 0 },
  { key: 'up-right', label: 'NE', angle: 45 },
  { key: 'right', label: 'E (Prawo)', angle: 90 },
  { key: 'down-right', label: 'SE', angle: 135 },
  { key: 'down', label: 'S (Dół)', angle: 180 },
  { key: 'down-left', label: 'SW', angle: 225 },
  { key: 'left', label: 'W (Lewo)', angle: 270 },
  { key: 'up-left', label: 'NW', angle: 315 },
];

const ANIM_LABELS: Record<HeroAnimState, { pl: string; en: string }> = {
  walk: { pl: 'Chód (Walk)', en: 'Walk' },
  attack: { pl: 'Atak (Attack)', en: 'Attack' },
  skill: { pl: 'Technika KI (Skill)', en: 'Skill' },
  idle: { pl: 'Oddech (Idle)', en: 'Idle' },
  hit: { pl: 'Obrażenia (Hit)', en: 'Hit' },
  death: { pl: 'Upadek (Death)', en: 'Death' },
};

interface HeroExplorerProps {
  onSelectForCombat?: (heroId: HeroRace['id']) => void;
  onOpenRaceEditor?: (heroId: HeroRace['id']) => void;
}

export const HeroExplorer: React.FC<HeroExplorerProps> = ({
  onSelectForCombat,
  onOpenRaceEditor,
}) => {
  const [selectedRaceId, setSelectedRaceId] = useState<HeroRace['id']>('planetary');
  const [currentDirection, setCurrentDirection] = useState<Direction>('down');
  const [isRotating, setIsRotating] = useState(false);
  const [activeAnim, setActiveAnim] = useState<HeroAnimState>('walk');
  const [animFrameIndex, setAnimFrameIndex] = useState(0);
  const [isAnimPlaying, setIsAnimPlaying] = useState(true);
  const [viewMode, setViewMode] = useState<'animation' | 'masters' | 'sheet'>('animation');
  const [useCleanedSprite, setUseCleanedSprite] = useState(true);
  const [showAura, setShowAura] = useState(true);
  const [spriteReadyVersion, setSpriteReadyVersion] = useState(0);

  const stageCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const stripCanvasRefs = useRef<(HTMLCanvasElement | null)[]>([]);

  const hero = HERO_RACES.find((h) => h.id === selectedRaceId) || HERO_RACES[0];
  const raceProfile = getRaceProfile(hero.id);
  const totalFrames = HERO_ANIM_FRAMES[activeAnim];

  // Preload and clean all 8 directional master sprites for the selected race
  useEffect(() => {
    let mounted = true;
    Promise.all(DIRECTIONS.map((d) => ensureCleanedHeroSprite(hero, d.key))).then(() => {
      if (mounted) {
        setSpriteReadyVersion((v) => v + 1);
      }
    });
    return () => {
      mounted = false;
    };
  }, [hero]);

  // Auto rotation loop across 8 directions
  useEffect(() => {
    if (!isRotating) return;
    const interval = setInterval(() => {
      setCurrentDirection((prev) => {
        const idx = DIRECTIONS.findIndex((d) => d.key === prev);
        const nextIdx = (idx + 1) % DIRECTIONS.length;
        return DIRECTIONS[nextIdx].key;
      });
    }, 650);
    return () => clearInterval(interval);
  }, [isRotating]);

  // Discrete frame counter for UI badge & frame strip highlight
  useEffect(() => {
    if (!isAnimPlaying || viewMode !== 'animation') return;
    const fps = HERO_ANIM_FPS[activeAnim] || 10;
    const interval = setInterval(() => {
      setAnimFrameIndex((prev) => (prev + 1) % HERO_ANIM_FRAMES[activeAnim]);
    }, Math.round(1000 / fps));
    return () => clearInterval(interval);
  }, [isAnimPlaying, viewMode, activeAnim]);

  // Smooth 60fps Canvas stage loop
  useEffect(() => {
    if (viewMode === 'sheet') return;
    let rafId: number;
    const startTime = performance.now();

    const renderLoop = (now: number) => {
      const canvas = stageCanvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, canvas.width, canvas.height);

          const effectiveState: HeroAnimState = viewMode === 'masters' ? 'idle' : activeAnim;
          const fps = HERO_ANIM_FPS[effectiveState];
          const framesCount = HERO_ANIM_FRAMES[effectiveState];

          let frameIdx = animFrameIndex % framesCount;
          let subFrame = 0;

          if (viewMode === 'masters') {
            frameIdx = 0;
            subFrame = 0;
          } else if (isAnimPlaying) {
            const elapsedSec = (now - startTime) / 1000;
            const totalElapsedFrames = (elapsedSec * fps) % framesCount;
            frameIdx = Math.floor(totalElapsedFrames);
            subFrame = totalElapsedFrames - frameIdx;
          }

          renderAnimatedHero(
            ctx,
            hero,
            currentDirection,
            canvas.width / 2,
            canvas.height - 28,
            320,
            {
              state: effectiveState,
              frameIndex: frameIdx,
              subFrame,
              useCleanedSprite,
              showAura: viewMode === 'animation' ? showAura : false,
              customization: {
                scaleMultiplier: raceProfile.rig.scaleMultiplier,
                feetAnchorY: raceProfile.rig.feetAnchorY,
                hueShiftDeg: raceProfile.rig.hueShiftDeg,
                saturationPct: raceProfile.rig.saturationPct,
                brightnessPct: raceProfile.rig.brightnessPct,
                contrastPct: raceProfile.rig.contrastPct,
                strideAmplitude: raceProfile.rig.strideAmplitude,
                clothWaveIntensity: raceProfile.rig.clothWaveIntensity,
                attackLungeDistance: raceProfile.rig.attackLungeDistance,
                skillLevitationHeight: raceProfile.rig.skillLevitationHeight,
                breathingDepth: raceProfile.rig.breathingDepth,
                auraIntensity: raceProfile.rig.auraIntensity,
                auraColorOverride: raceProfile.theme.primaryAccent,
                secondaryGlowOverride: raceProfile.theme.auraGlow,
              },
            }
          );
        }
      }

      if (isAnimPlaying && viewMode === 'animation') {
        rafId = requestAnimationFrame(renderLoop);
      }
    };

    rafId = requestAnimationFrame(renderLoop);
    return () => cancelAnimationFrame(rafId);
  }, [
    hero,
    raceProfile,
    currentDirection,
    activeAnim,
    animFrameIndex,
    isAnimPlaying,
    viewMode,
    useCleanedSprite,
    showAura,
    spriteReadyVersion,
  ]);

  // Render 8-frame strip thumbnails whenever direction, race, anim, or cleanup mode changes
  useEffect(() => {
    if (viewMode !== 'animation') return;
    for (let i = 0; i < totalFrames; i++) {
      const c = stripCanvasRefs.current[i];
      if (!c) continue;
      const ctx = c.getContext('2d');
      if (!ctx) continue;
      ctx.clearRect(0, 0, c.width, c.height);
      renderAnimatedHero(ctx, hero, currentDirection, c.width / 2, c.height - 8, 86, {
        state: activeAnim,
        frameIndex: i,
        subFrame: 0,
        useCleanedSprite,
        showAura,
        customization: {
          auraColorOverride: raceProfile.theme.primaryAccent,
          secondaryGlowOverride: raceProfile.theme.auraGlow,
        },
      });
    }
  }, [hero, raceProfile, currentDirection, activeAnim, totalFrames, useCleanedSprite, showAura, viewMode, spriteReadyVersion]);

  const currentSpriteRecord = getCachedCleanedHeroSprite(hero.id, currentDirection);

  return (
    <div className="space-y-8 text-stone-100">
      {/* Top Banner & Hero Selector */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-800 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-emerald-400">
            <Sparkles className="w-4 h-4" />
            Ki Legends Production Masters — 2D Mesh & Alpha Cleanup V2
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight text-white mt-1">
            Postacie Ras, Czyszczenie Alfa i Animacje 8×6
          </h2>
          <p className="text-sm text-stone-400 mt-1">
            Oczyszczone sprite&apos;y 8-kierunkowe wszystkich 4 ras z rigiem kończyn, fizyką szat/płaszcza i osobną warstwą aury KI.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {onOpenRaceEditor && (
            <button
              onClick={() => onOpenRaceEditor(hero.id)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg font-bold text-xs bg-stone-900 border border-stone-700 hover:bg-stone-800 text-stone-200 transition-all cursor-pointer"
            >
              <Sliders className="w-4 h-4 text-emerald-400" />
              Otwórz w Edytorze Ras 2D
            </button>
          )}

          {onSelectForCombat && (
            <button
              onClick={() => onSelectForCombat(hero.id)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg font-bold text-sm bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-lg shadow-emerald-950/40 transition-all text-white cursor-pointer"
            >
              Testuj {hero.polishName} na Arenie PvE
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Race Selector Tabs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {HERO_RACES.map((r) => {
          const isSelected = r.id === selectedRaceId;
          return (
            <button
              key={r.id}
              onClick={() => {
                setSelectedRaceId(r.id);
                setAnimFrameIndex(0);
              }}
              className={`p-4 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden ${
                isSelected
                  ? 'bg-stone-900/90 border-emerald-500/80 shadow-lg shadow-emerald-950/30 ring-1 ring-emerald-500/50'
                  : 'bg-stone-900/40 border-stone-800 hover:border-stone-700 hover:bg-stone-900/60'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono uppercase tracking-widest text-stone-400">
                  {r.homeworld}
                </span>
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: r.accentColor }}
                />
              </div>
              <div className="font-bold text-lg text-white">{r.polishName}</div>
              <div className="text-xs text-stone-400 mt-0.5">{r.name} • 8 kierunków × 6 animacji</div>
              <div className="text-xs text-stone-500 mt-2 line-clamp-1">{r.combatRole}</div>
            </button>
          );
        })}
      </div>

      {/* Hero Showcase Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Visual Turntable & Motion Viewer */}
        <div className="lg:col-span-6 bg-stone-900/60 border border-stone-800 rounded-2xl p-6 backdrop-blur-sm">
          {/* View Mode Switcher */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-800 pb-4 mb-5">
            <div className="flex items-center gap-1.5 p-1 bg-stone-950 rounded-lg border border-stone-800/80 text-xs">
              <button
                onClick={() => setViewMode('animation')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                  viewMode === 'animation'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                Animacje 8×6 (Rig 2D)
              </button>
              <button
                onClick={() => setViewMode('masters')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                  viewMode === 'masters'
                    ? 'bg-stone-800 text-white shadow-sm'
                    : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                8 Kierunków (Statyczny)
              </button>
              <button
                onClick={() => setViewMode('sheet')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                  viewMode === 'sheet'
                    ? 'bg-stone-800 text-white shadow-sm'
                    : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                Arkusz Master
              </button>
            </div>

            {viewMode !== 'sheet' && (
              <button
                onClick={() => setIsRotating(!isRotating)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                  isRotating
                    ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300'
                    : 'bg-stone-800/80 border-stone-700 text-stone-300 hover:bg-stone-700'
                }`}
              >
                <RotateCw className={`w-3.5 h-3.5 ${isRotating ? 'animate-spin' : ''}`} />
                {isRotating ? 'Auto Obrót (8 kier.)' : 'Obracaj 360°'}
              </button>
            )}
          </div>

          {/* Cleanup & Aura Layer Toggles */}
          {viewMode !== 'sheet' && (
            <div className="flex flex-wrap items-center justify-between gap-2 mb-4 bg-stone-950/80 p-2.5 rounded-xl border border-stone-800/80 text-xs">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setUseCleanedSprite(!useCleanedSprite)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-mono font-semibold border transition-all cursor-pointer ${
                    useCleanedSprite
                      ? 'bg-emerald-950/90 border-emerald-500/70 text-emerald-300'
                      : 'bg-amber-950/80 border-amber-600/70 text-amber-300'
                  }`}
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  {useCleanedSprite ? 'Alfa/Tło: OCZYSZCZONE' : 'Alfa/Tło: SUROWY ORYGINAŁ'}
                </button>

                {viewMode === 'animation' && (
                  <button
                    onClick={() => setShowAura(!showAura)}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-mono font-semibold border transition-all cursor-pointer ${
                      showAura
                        ? 'bg-cyan-950/80 border-cyan-500/70 text-cyan-300'
                        : 'bg-stone-900 border-stone-700 text-stone-400'
                    }`}
                  >
                    <Layers className="w-3.5 h-3.5" />
                    Aura KI: {showAura ? 'WŁ.' : 'WYŁ.'}
                  </button>
                )}
              </div>

              {currentSpriteRecord && (
                <div className="text-[11px] font-mono text-stone-400 flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-emerald-400" />
                  <span>
                    Usunięto tło/halo:{' '}
                    <strong className="text-emerald-400">
                      {(
                        currentSpriteRecord.removedPixelsCount +
                        currentSpriteRecord.defringedPixelsCount
                      ).toLocaleString('pl-PL')}{' '}
                      px
                    </strong>
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Central Character Stage */}
          <div
            className="relative aspect-square max-h-[380px] w-full mx-auto flex items-center justify-center rounded-xl border border-stone-800 overflow-hidden"
            style={{
              background: useCleanedSprite
                ? 'radial-gradient(circle at center, rgba(28,38,32,0.75) 0%, rgba(12,10,9,0.95) 100%)'
                : 'repeating-conic-gradient(#292524 0% 25%, #1c1917 0% 50%) 50% / 24px 24px',
            }}
          >
            {/* Grid Floor Effect */}
            <div
              className="absolute inset-0 opacity-20 pointer-events-none"
              style={{
                backgroundImage: `radial-gradient(circle at center, ${hero.accentColor} 1px, transparent 1px)`,
                backgroundSize: '24px 24px',
              }}
            />

            {/* Animated or Static 8-Direction Canvas */}
            {viewMode !== 'sheet' && (
              <div className="relative z-10 flex flex-col items-center justify-center w-full h-full">
                <canvas
                  ref={stageCanvasRef}
                  width={380}
                  height={350}
                  className="max-h-[320px] w-auto object-contain drop-shadow-[0_12px_20px_rgba(0,0,0,0.85)]"
                />
                <div className="absolute bottom-3 flex flex-wrap items-center justify-center gap-2">
                  <span className="px-2.5 py-0.5 bg-stone-900/90 border border-stone-700 rounded-full text-xs font-mono text-emerald-400">
                    Kierunek: {currentDirection.toUpperCase()}
                  </span>
                  {viewMode === 'animation' && (
                    <>
                      <span className="px-2.5 py-0.5 bg-stone-900/90 border border-stone-700 rounded-full text-xs font-mono text-stone-200">
                        Stan: {ANIM_LABELS[activeAnim].pl}
                      </span>
                      <span className="px-2 py-0.5 bg-emerald-950/90 border border-emerald-700/60 rounded-full text-xs font-mono text-emerald-300">
                        Klatka {(animFrameIndex % totalFrames) + 1}/{totalFrames} ({HERO_ANIM_FPS[activeAnim]} FPS)
                      </span>
                    </>
                  )}
                </div>
              </div>
            )}

            {/* Master Sheet Full Texture */}
            {viewMode === 'sheet' && (
              <div className="relative z-10 w-full h-full p-4 overflow-auto flex items-center justify-center">
                <img
                  src={hero.masterSheet}
                  alt={`${hero.name} Master Sheet`}
                  className="max-h-full max-w-full object-contain rounded-lg border border-stone-700 shadow-xl"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = hero.previewGif;
                  }}
                />
              </div>
            )}
          </div>

          {/* 8-Frame Strip Preview */}
          {viewMode === 'animation' && (
            <div className="mt-4 bg-stone-950/80 border border-stone-800/90 rounded-xl p-3">
              <div className="flex items-center justify-between text-[11px] font-mono text-stone-400 mb-2">
                <span>SEKWENCJA KLATEK ({totalFrames} KLATEK • KLIKNIJ ABY ZATRZYMAĆ NA KLATCE)</span>
                <button
                  onClick={() => setIsAnimPlaying(!isAnimPlaying)}
                  className="flex items-center gap-1 text-xs text-emerald-400 hover:text-emerald-300 font-semibold cursor-pointer"
                >
                  {isAnimPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  {isAnimPlaying ? 'Pauza' : 'Odtwórz'}
                </button>
              </div>
              <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                {Array.from({ length: totalFrames }).map((_, idx) => {
                  const isCurrent = animFrameIndex % totalFrames === idx;
                  return (
                    <button
                      key={idx}
                      onClick={() => {
                        setIsAnimPlaying(false);
                        setAnimFrameIndex(idx);
                      }}
                      className={`relative rounded-lg border p-1 flex flex-col items-center justify-center transition-all cursor-pointer ${
                        isCurrent
                          ? 'bg-emerald-950/60 border-emerald-500 ring-1 ring-emerald-500/40'
                          : 'bg-stone-900/70 border-stone-800 hover:border-stone-700'
                      }`}
                    >
                      <canvas
                        ref={(el) => {
                          stripCanvasRefs.current[idx] = el;
                        }}
                        width={96}
                        height={96}
                        className="w-12 h-12 object-contain"
                      />
                      <span className="text-[10px] font-mono text-stone-400">#{idx + 1}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Animation State Controls */}
          {viewMode === 'animation' && (
            <div className="mt-5 space-y-2.5">
              <div className="text-xs text-stone-400 font-mono">WYBIERZ STAN ANIMACJI (6 STANÓW)</div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {(['walk', 'attack', 'skill', 'idle', 'hit', 'death'] as const).map((anim) => (
                  <button
                    key={anim}
                    onClick={() => {
                      setActiveAnim(anim);
                      setAnimFrameIndex(0);
                      setIsAnimPlaying(true);
                    }}
                    className={`py-2 px-3 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                      activeAnim === anim
                        ? 'bg-emerald-900/60 border-emerald-500 text-emerald-200 shadow-sm'
                        : 'bg-stone-950/60 border-stone-800 text-stone-400 hover:border-stone-700 hover:text-stone-200'
                    }`}
                  >
                    {ANIM_LABELS[anim].pl}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Direction Controls (Compass - active in both Animation and Masters mode!) */}
          {viewMode !== 'sheet' && (
            <div className="mt-5">
              <div className="text-xs text-stone-400 mb-2 font-mono">
                KIERUNEK KAMERY (8 KIERUNKÓW ORTOGRAFICZNYCH)
              </div>
              <div className="grid grid-cols-4 gap-2">
                {DIRECTIONS.map((d) => (
                  <button
                    key={d.key}
                    onClick={() => {
                      setIsRotating(false);
                      setCurrentDirection(d.key);
                    }}
                    className={`py-2 px-2.5 rounded-lg text-xs font-mono font-medium border transition-all cursor-pointer ${
                      currentDirection === d.key
                        ? 'bg-emerald-900/60 border-emerald-500 text-emerald-200 shadow-sm'
                        : 'bg-stone-950/60 border-stone-800 text-stone-400 hover:border-stone-700 hover:text-stone-200'
                    }`}
                  >
                    {d.key}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Lore, Stats & Skills */}
        <div className="lg:col-span-6 space-y-6">
          {/* Header & Lore */}
          <div className="bg-stone-900/60 border border-stone-800 rounded-2xl p-6 backdrop-blur-sm">
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="px-2.5 py-1 rounded bg-stone-800 text-stone-300 text-xs font-mono font-semibold">
                Klasa: {hero.combatRole}
              </span>
              <span className="px-2.5 py-1 rounded bg-stone-800 text-stone-300 text-xs font-mono font-semibold">
                Kontynent: {hero.homeworld}
              </span>
              <span className="px-2.5 py-1 rounded bg-emerald-950/80 border border-emerald-700/50 text-emerald-300 text-xs font-mono font-semibold">
                Status: ACCEPTED + Rig 2D V2
              </span>
            </div>
            <h3 className="text-2xl font-black text-white">{hero.tagline}</h3>
            <p className="text-sm text-stone-300 mt-3 leading-relaxed">{hero.lore}</p>
          </div>

          {/* Combat Attributes */}
          <div className="bg-stone-900/60 border border-stone-800 rounded-2xl p-6 backdrop-blur-sm">
            <h4 className="text-xs font-mono uppercase tracking-widest text-stone-400 mb-4 flex items-center gap-2">
              <Zap className="w-4 h-4 text-emerald-400" />
              Bazowy Profil Bojowy
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="bg-stone-950/60 p-3.5 rounded-xl border border-stone-800/80">
                <div className="flex items-center gap-1.5 text-xs text-rose-400 font-medium">
                  <Heart className="w-3.5 h-3.5" />
                  Health Pool
                </div>
                <div className="text-2xl font-black text-white mt-1">{hero.baseStats.hp}</div>
                <div className="w-full bg-stone-800 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div
                    className="bg-rose-500 h-full rounded-full"
                    style={{ width: `${(hero.baseStats.hp / 200) * 100}%` }}
                  />
                </div>
              </div>

              <div className="bg-stone-950/60 p-3.5 rounded-xl border border-stone-800/80">
                <div className="flex items-center gap-1.5 text-xs text-cyan-400 font-medium">
                  <Zap className="w-3.5 h-3.5" />
                  Ki Capacity
                </div>
                <div className="text-2xl font-black text-white mt-1">{hero.baseStats.ki}</div>
                <div className="w-full bg-stone-800 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div
                    className="bg-cyan-500 h-full rounded-full"
                    style={{ width: `${(hero.baseStats.ki / 180) * 100}%` }}
                  />
                </div>
              </div>

              <div className="bg-stone-950/60 p-3.5 rounded-xl border border-stone-800/80">
                <div className="flex items-center gap-1.5 text-xs text-amber-400 font-medium">
                  <Flame className="w-3.5 h-3.5" />
                  Base Attack
                </div>
                <div className="text-2xl font-black text-white mt-1">{hero.baseStats.atk}</div>
                <div className="w-full bg-stone-800 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div
                    className="bg-amber-500 h-full rounded-full"
                    style={{ width: `${(hero.baseStats.atk / 30) * 100}%` }}
                  />
                </div>
              </div>

              <div className="bg-stone-950/60 p-3.5 rounded-xl border border-stone-800/80">
                <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                  <Shield className="w-3.5 h-3.5" />
                  Defense
                </div>
                <div className="text-2xl font-black text-white mt-1">{hero.baseStats.def}</div>
                <div className="w-full bg-stone-800 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full rounded-full"
                    style={{ width: `${(hero.baseStats.def / 25) * 100}%` }}
                  />
                </div>
              </div>

              <div className="bg-stone-950/60 p-3.5 rounded-xl border border-stone-800/80">
                <div className="flex items-center gap-1.5 text-xs text-blue-400 font-medium">
                  <Wind className="w-3.5 h-3.5" />
                  Base Speed
                </div>
                <div className="text-2xl font-black text-white mt-1">{hero.baseStats.speed}x</div>
                <div className="w-full bg-stone-800 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div
                    className="bg-blue-500 h-full rounded-full"
                    style={{ width: `${hero.baseStats.speed * 70}%` }}
                  />
                </div>
              </div>

              <div className="bg-stone-950/60 p-3.5 rounded-xl border border-stone-800/80">
                <div className="flex items-center gap-1.5 text-xs text-purple-400 font-medium">
                  <Sparkles className="w-3.5 h-3.5" />
                  Ki Regen /s
                </div>
                <div className="text-2xl font-black text-white mt-1">+{hero.baseStats.kiRegen}</div>
                <div className="w-full bg-stone-800 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div
                    className="bg-purple-500 h-full rounded-full"
                    style={{ width: `${(hero.baseStats.kiRegen / 20) * 100}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="mt-4 flex items-center gap-2 p-3 bg-stone-950/40 rounded-xl border border-stone-800 text-xs text-stone-400">
              <Info className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                Zasada właściciela: Szybkość ruchu rośnie o +5% bazowej na poziom aż do poziomu 20.
              </span>
            </div>
          </div>

          {/* Active Skills */}
          <div className="bg-stone-900/60 border border-stone-800 rounded-2xl p-6 backdrop-blur-sm">
            <h4 className="text-xs font-mono uppercase tracking-widest text-stone-400 mb-4 flex items-center gap-2">
              <Crosshair className="w-4 h-4 text-cyan-400" />
              Techniki KI i Przypisanie Klawiszy
            </h4>

            <div className="space-y-3">
              {hero.skills.map((skill) => (
                <div
                  key={skill.name}
                  className="p-4 bg-stone-950/60 rounded-xl border border-stone-800 hover:border-stone-700 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-md bg-stone-800 text-white font-mono font-bold text-xs flex items-center justify-center border border-stone-700">
                          {skill.key}
                        </span>
                        <span className="font-bold text-white text-base">{skill.polishName}</span>
                        <span className="text-xs text-stone-400">({skill.name})</span>
                      </div>
                      <p className="text-xs text-stone-300 mt-1.5 leading-relaxed">
                        {skill.description}
                      </p>
                    </div>

                    <div className="text-right shrink-0 ml-4">
                      <div className="text-xs font-mono font-semibold text-cyan-400">
                        {skill.cost} Ki
                      </div>
                      <div className="text-[11px] font-mono text-stone-400 mt-0.5">
                        {skill.cooldown}s CD
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
