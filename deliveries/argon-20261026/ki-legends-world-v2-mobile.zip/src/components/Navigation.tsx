import React from 'react';
import { Swords, Skull, Users, Globe, BookOpen, Sparkles, Compass, Layout, Sliders, Download } from 'lucide-react';
import { RaceDynamicTheme } from '../game/heroes/raceMetadata';

export type ActiveTab =
  | 'world-v2'
  | 'race-editor'
  | 'hud-ui'
  | 'combat'
  | 'heroes'
  | 'bestiary'
  | 'atlas'
  | 'lore';

interface NavigationProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  activeTheme?: RaceDynamicTheme;
  onOpenDownloadModal?: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  activeTheme,
  onOpenDownloadModal,
}) => {
  const accentColor = activeTheme?.primaryAccent || '#10b981';

  const tabs = [
    {
      id: 'world-v2' as const,
      label: 'World V2 & Questy',
      sublabel: '106 Przygód • 16 Miast',
      icon: Compass,
      badge: 'V2',
    },
    {
      id: 'race-editor' as const,
      label: 'Edytor Ras 2D',
      sublabel: 'Wygląd • Animacje • Motyw',
      icon: Sliders,
      badge: 'STUDIO',
    },
    {
      id: 'heroes' as const,
      label: 'Rasy (4)',
      sublabel: '8-Dir Sprites',
      icon: Users,
    },
    {
      id: 'combat' as const,
      label: 'Arena Walki',
      sublabel: 'PvE Playground',
      icon: Swords,
    },
    {
      id: 'hud-ui' as const,
      label: 'Grafiki HUD / UI',
      sublabel: '3 Plansze • 29 Węzłów',
      icon: Layout,
    },
    {
      id: 'bestiary' as const,
      label: 'Bestiariusz (40)',
      sublabel: 'Kanon Właściciela',
      icon: Skull,
    },
    {
      id: 'atlas' as const,
      label: 'Atlas Planety',
      sublabel: '4 Kontynenty',
      icon: Globe,
    },
    {
      id: 'lore' as const,
      label: 'Księga Przygody',
      sublabel: 'Zasady & Kanon',
      icon: BookOpen,
    },
  ];

  return (
    <nav
      className="border-b bg-stone-950/90 backdrop-blur-md sticky top-0 z-40 transition-colors"
      style={{ borderColor: `${accentColor}33` }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Logo Brand */}
          <div className="flex items-center gap-3 shrink-0">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center shadow-lg transition-colors"
              style={{
                backgroundColor: accentColor,
                boxShadow: `0 6px 20px -4px ${accentColor}66`,
              }}
            >
              <Sparkles className="w-5 h-5 text-stone-950 font-bold" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-lg tracking-tight text-white">KI LEGENDS</span>
                <span
                  className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-stone-900 border"
                  style={{
                    borderColor: `${accentColor}66`,
                    color: activeTheme?.auraGlow || accentColor,
                  }}
                >
                  WORLD V2
                </span>
              </div>
              <p className="text-[11px] text-stone-400 -mt-0.5 font-mono hidden md:block">
                feature/quests-v2 • Żyjąca Planeta, Rasy 8×6 i Przygody
              </p>
            </div>
          </div>

          {/* Tab Links */}
          <div className="flex items-center gap-1 sm:gap-1.5 overflow-x-auto py-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => onSelectTab(tab.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap border ${
                    isActive
                      ? 'bg-stone-900 text-white shadow-md'
                      : 'border-transparent text-stone-400 hover:text-stone-200 hover:bg-stone-900/60'
                  }`}
                  style={
                    isActive
                      ? {
                          borderColor: `${accentColor}88`,
                          boxShadow: `0 0 14px -4px ${accentColor}55`,
                        }
                      : undefined
                  }
                >
                  <Icon
                    className="w-4 h-4"
                    style={{ color: isActive ? accentColor : '#a8a29e' }}
                  />
                  <div className="text-left">
                    <div className="leading-tight">{tab.label}</div>
                  </div>
                  {tab.badge && (
                    <span
                      className="hidden lg:inline px-1.5 py-0.2 text-[9px] font-mono rounded border"
                      style={{
                        backgroundColor: `${accentColor}22`,
                        borderColor: `${accentColor}55`,
                        color: activeTheme?.auraGlow || accentColor,
                      }}
                    >
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}

            {onOpenDownloadModal && (
              <button
                onClick={onOpenDownloadModal}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-stone-950 transition-colors cursor-pointer whitespace-nowrap shadow-md ml-1 shrink-0 min-h-[40px]"
                title="Pobierz pełną paczkę ZIP oraz instrukcję uruchomienia"
              >
                <Download className="w-4 h-4" />
                <span>Pobierz ZIP</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};
