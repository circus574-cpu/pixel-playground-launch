import React, { useState, useEffect, useRef, useCallback } from 'react';
import { HERO_RACES, HeroRace, Direction } from '../data/heroes';
import { MONSTERS, Monster, WORLDS } from '../data/bestiary';
import {
  HeroAnimState,
  HERO_ANIM_FPS,
  HERO_ANIM_FRAMES,
  ensureCleanedHeroSprite,
  renderAnimatedHero,
} from '../game/heroes/spriteAnimator';
import {
  Swords,
  Heart,
  Zap,
  Plus,
  Sparkles,
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  Smartphone,
  Gamepad2,
  Navigation,
} from 'lucide-react';

interface ActiveMonster {
  instanceId: string;
  monsterId: string;
  name: string;
  world: string;
  x: number;
  y: number;
  maxHp: number;
  currentHp: number;
  atk: number;
  def: number;
  speed: number;
  agro: number;
  range: number;
  xp: number;
  color: string;
  state: 'idle' | 'chase' | 'attack' | 'dead';
  lastAttackTime: number;
}

interface Projectile {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  color: string;
  radius: number;
  duration: number;
}

interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  time: number;
}

interface CombatSandboxProps {
  initialHeroId?: HeroRace['id'];
  queuedMonster?: Monster | null;
  onClearQueuedMonster?: () => void;
  onMonsterKilledForQuest?: (monsterId: string, monsterName: string, xpGained: number) => void;
}

export const CombatSandbox: React.FC<CombatSandboxProps> = ({
  initialHeroId = 'planetary',
  queuedMonster,
  onClearQueuedMonster,
  onMonsterKilledForQuest,
}) => {
  const [selectedHeroId, setSelectedHeroId] = useState<HeroRace['id']>(initialHeroId);
  const hero = HERO_RACES.find((h) => h.id === selectedHeroId) || HERO_RACES[0];

  // Player Progression
  const [playerLevel, setPlayerLevel] = useState(1);
  const [playerXp, setPlayerXp] = useState(0);
  const xpNeeded = playerLevel * 60;
  const [playerHp, setPlayerHp] = useState(hero.baseStats.hp);
  const [playerKi, setPlayerKi] = useState(hero.baseStats.ki);
  const [playerDirection, setPlayerDirection] = useState<Direction>('down');
  const [combatLog, setCombatLog] = useState<
    { id: string; time: string; text: string; type: 'hit' | 'damage' | 'kill' | 'level' | 'info' }[]
  >([]);
  const [selectedSpawnMonsterId, setSelectedSpawnMonsterId] = useState<string>(MONSTERS[0].id);

  // Mobile, Fullscreen & Camera Zoom State (Zoomed out by default per AGENTS.md)
  const [isStageFullscreen, setIsStageFullscreen] = useState(false);
  const [cameraZoom, setCameraZoom] = useState<number>(0.85); // Default zoomed-out view
  const [mobileControlStyle, setMobileControlStyle] = useState<'joystick' | 'dpad'>('joystick');
  const [showTouchControls, setShowTouchControls] = useState(true);
  const [joystickVisual, setJoystickVisual] = useState<{ active: boolean; dx: number; dy: number }>({
    active: false,
    dx: 0,
    dy: 0,
  });

  // Canvas & Game State Refs
  const stageContainerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const playerPosRef = useRef({ x: 480, y: 320 });
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const touchVectorRef = useRef<{ mx: number; my: number }>({ mx: 0, my: 0 });
  const joystickCenterRef = useRef<{ x: number; y: number } | null>(null);
  const monstersRef = useRef<ActiveMonster[]>([]);
  const projectilesRef = useRef<Projectile[]>([]);
  const floatingTextsRef = useRef<FloatingText[]>([]);
  const lastTimeRef = useRef<number>(performance.now());
  const heroImgCacheRef = useRef<Record<string, HTMLImageElement>>({});
  const playerDirectionRef = useRef<Direction>('down');
  const playerActionRef = useRef<{ state: HeroAnimState; startTime: number; durationMs: number }>({
    state: 'idle',
    startTime: 0,
    durationMs: 0,
  });

  // Arena world dimensions (expanded for zoomed-out camera)
  const ARENA_WIDTH = 960;
  const ARENA_HEIGHT = 640;

  // Skill cooldown trackers
  const [cooldowns, setCooldowns] = useState<{ [key: string]: number }>({ Q: 0, E: 0, R: 0 });

  const addLog = useCallback(
    (text: string, type: 'hit' | 'damage' | 'kill' | 'level' | 'info' = 'info') => {
      const time = new Date().toLocaleTimeString().split(' ')[0];
      setCombatLog((prev) => [
        { id: Math.random().toString(), time, text, type },
        ...prev.slice(0, 19),
      ]);
    },
    [],
  );

  // Preload & clean hero 8-direction images
  useEffect(() => {
    Object.entries(hero.views).forEach(([dir, src]) => {
      const img = new Image();
      img.src = src;
      heroImgCacheRef.current[dir] = img;
      ensureCleanedHeroSprite(hero, dir as Direction);
    });
  }, [hero]);

  // Spawn initial monster so the player has something to test immediately on mobile/desktop
  useEffect(() => {
    if (monstersRef.current.length === 0) {
      spawnMonster(MONSTERS[0]);
    }
  }, []);

  // Handle incoming monster spawn from bestiary explorer
  useEffect(() => {
    if (queuedMonster) {
      spawnMonster(queuedMonster);
      if (onClearQueuedMonster) onClearQueuedMonster();
    }
  }, [queuedMonster, onClearQueuedMonster]);

  // Toggle Fullscreen (supports native Fullscreen API with CSS fixed fallback for mobile iframes)
  const handleToggleFullscreen = async () => {
    const nextState = !isStageFullscreen;
    setIsStageFullscreen(nextState);
    try {
      if (nextState && stageContainerRef.current?.requestFullscreen) {
        await stageContainerRef.current.requestFullscreen();
      } else if (!nextState && document.fullscreenElement && document.exitFullscreen) {
        await document.exitFullscreen();
      }
    } catch {
      // Fallback to CSS fixed fullscreen inside iframe/mobile webview
    }
  };

  useEffect(() => {
    const onFsChange = () => {
      if (!document.fullscreenElement && isStageFullscreen) {
        // Keep state synced if exited via ESC
      }
    };
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, [isStageFullscreen]);

  // Spawn monster function
  const spawnMonster = (m: Monster) => {
    const angle = Math.random() * Math.PI * 2;
    const dist = 200 + Math.random() * 140;
    const px = playerPosRef.current.x + Math.cos(angle) * dist;
    const py = playerPosRef.current.y + Math.sin(angle) * dist;

    const x = Math.max(60, Math.min(ARENA_WIDTH - 60, px));
    const y = Math.max(60, Math.min(ARENA_HEIGHT - 60, py));

    const newMonster: ActiveMonster = {
      instanceId: `mob-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      monsterId: m.id,
      name: m.name,
      world: m.world,
      x,
      y,
      maxHp: m.stats.hp,
      currentHp: m.stats.hp,
      atk: m.stats.atk,
      def: m.stats.def,
      speed: m.speed * 1.3,
      agro: m.agro,
      range: Math.max(45, m.range * 0.4),
      xp: m.stats.xp,
      color: WORLDS[m.world]?.color || '#10b981',
      state: 'idle',
      lastAttackTime: 0,
    };

    monstersRef.current.push(newMonster);
    addLog(`Pojawił się [${m.name}] Lv.${m.level} (${m.world})`, 'info');
  };

  // Basic Attack (optionally aimed toward target angle)
  const triggerBasicAttack = useCallback(
    (aimAngle?: number) => {
      playerActionRef.current = {
        state: 'attack',
        startTime: performance.now(),
        durationMs: 520,
      };
      const px = playerPosRef.current.x;
      const py = playerPosRef.current.y;

      let dx = 0;
      let dy = 0;

      if (typeof aimAngle === 'number') {
        dx = Math.cos(aimAngle);
        dy = Math.sin(aimAngle);
      } else {
        const dir = playerDirectionRef.current;
        if (dir.includes('right')) dx = 1;
        if (dir.includes('left')) dx = -1;
        if (dir.includes('down')) dy = 1;
        if (dir.includes('up')) dy = -1;
        if (dx === 0 && dy === 0) dy = 1;
        const len = Math.hypot(dx, dy) || 1;
        dx /= len;
        dy /= len;
      }

      projectilesRef.current.push({
        id: Math.random().toString(),
        x: px + dx * 20,
        y: py + dy * 20,
        vx: dx * 8.0,
        vy: dy * 8.0,
        damage: Math.round(hero.baseStats.atk * (1 + (playerLevel - 1) * 0.1)),
        color: hero.accentColor,
        radius: 6,
        duration: 50,
      });
    },
    [hero, playerLevel],
  );

  // Ki Skills
  const triggerSkill = useCallback(
    (key: 'Q' | 'E' | 'R') => {
      const skill = hero.skills.find((s) => s.key === key);
      if (!skill) return;

      if (playerKi < skill.cost) {
        addLog(`Za mało KI dla ${skill.name} (wymagane ${skill.cost} KI)`, 'info');
        return;
      }

      if ((cooldowns[key] || 0) > 0) {
        return;
      }

      playerActionRef.current = {
        state: 'skill',
        startTime: performance.now(),
        durationMs: 680,
      };

      setPlayerKi((prev) => Math.max(0, prev - skill.cost));
      setCooldowns((prev) => ({ ...prev, [key]: skill.cooldown }));

      const px = playerPosRef.current.x;
      const py = playerPosRef.current.y;
      const dir = playerDirectionRef.current;

      if (key === 'Q') {
        addLog(`Użyto techniki [${skill.name}]!`, 'hit');
        [-0.2, 0, 0.2].forEach((offsetAngle) => {
          let baseAngle = 0;
          if (dir === 'down') baseAngle = Math.PI / 2;
          else if (dir === 'up') baseAngle = -Math.PI / 2;
          else if (dir === 'left') baseAngle = Math.PI;
          else if (dir === 'right') baseAngle = 0;
          else if (dir === 'down-right') baseAngle = Math.PI / 4;
          else if (dir === 'down-left') baseAngle = (3 * Math.PI) / 4;
          else if (dir === 'up-right') baseAngle = -Math.PI / 4;
          else if (dir === 'up-left') baseAngle = -(3 * Math.PI) / 4;

          const a = baseAngle + offsetAngle;
          projectilesRef.current.push({
            id: Math.random().toString(),
            x: px,
            y: py,
            vx: Math.cos(a) * 8.5,
            vy: Math.sin(a) * 8.5,
            damage: Math.round(hero.baseStats.atk * 1.6),
            color: hero.accentColor,
            radius: 9,
            duration: 55,
          });
        });
      } else if (key === 'E') {
        addLog(`Aktywowano [${skill.name}]!`, 'info');
        let dx = 0;
        let dy = 0;
        if (dir.includes('right')) dx = 1;
        if (dir.includes('left')) dx = -1;
        if (dir.includes('down')) dy = 1;
        if (dir.includes('up')) dy = -1;
        const len = Math.hypot(dx, dy) || 1;

        playerPosRef.current.x = Math.max(40, Math.min(ARENA_WIDTH - 40, px + (dx / len) * 120));
        playerPosRef.current.y = Math.max(40, Math.min(ARENA_HEIGHT - 40, py + (dy / len) * 120));

        floatingTextsRef.current.push({
          id: Math.random().toString(),
          x: px,
          y: py - 20,
          text: 'ZRYW KI!',
          color: '#38bdf8',
          alpha: 1,
          time: 0,
        });
      } else if (key === 'R') {
        addLog(`ULTIMATE KI: [${skill.name}]!`, 'hit');
        const count = 16;
        for (let i = 0; i < count; i++) {
          const a = (i / count) * Math.PI * 2;
          projectilesRef.current.push({
            id: Math.random().toString(),
            x: px,
            y: py,
            vx: Math.cos(a) * 6.5,
            vy: Math.sin(a) * 6.5,
            damage: Math.round(hero.baseStats.atk * 2.8),
            color: '#fbbf24',
            radius: 11,
            duration: 65,
          });
        }
      }
    },
    [hero, playerKi, cooldowns, addLog],
  );

  // Keyboard handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        e.preventDefault();
      }
      keysRef.current[e.code] = true;
      keysRef.current[e.key.toLowerCase()] = true;

      if (e.code === 'KeyQ') triggerSkill('Q');
      if (e.code === 'KeyE') triggerSkill('E');
      if (e.code === 'KeyR') triggerSkill('R');
      if (e.code === 'Space') triggerBasicAttack();
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
      keysRef.current[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [triggerSkill, triggerBasicAttack]);

  // Virtual Analog Joystick Handlers (Touch & Pointer unified)
  const handleJoystickStart = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    const rect = e.currentTarget.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    joystickCenterRef.current = { x: cx, y: cy };
    updateJoystickPosition(e.clientX, e.clientY, cx, cy, rect.width / 2);
  };

  const handleJoystickMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!joystickCenterRef.current) return;
    e.preventDefault();
    const rect = e.currentTarget.getBoundingClientRect();
    updateJoystickPosition(
      e.clientX,
      e.clientY,
      joystickCenterRef.current.x,
      joystickCenterRef.current.y,
      rect.width / 2,
    );
  };

  const handleJoystickEnd = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    joystickCenterRef.current = null;
    touchVectorRef.current = { mx: 0, my: 0 };
    setJoystickVisual({ active: false, dx: 0, dy: 0 });
  };

  const updateJoystickPosition = (
    clientX: number,
    clientY: number,
    cx: number,
    cy: number,
    maxRadius: number,
  ) => {
    const rawDx = clientX - cx;
    const rawDy = clientY - cy;
    const dist = Math.hypot(rawDx, rawDy);
    const clampedDist = Math.min(dist, maxRadius * 0.75);
    const angle = Math.atan2(rawDy, rawDx);

    const visualDx = Math.cos(angle) * clampedDist;
    const visualDy = Math.sin(angle) * clampedDist;

    if (dist > 6) {
      touchVectorRef.current = {
        mx: Math.cos(angle) * Math.min(1, dist / (maxRadius * 0.6)),
        my: Math.sin(angle) * Math.min(1, dist / (maxRadius * 0.6)),
      };
      setJoystickVisual({ active: true, dx: visualDx, dy: visualDy });
    } else {
      touchVectorRef.current = { mx: 0, my: 0 };
      setJoystickVisual({ active: true, dx: 0, dy: 0 });
    }
  };

  // D-Pad helper for discrete 8-directional buttons
  const setDpadDirection = (mx: number, my: number) => {
    touchVectorRef.current = { mx, my };
  };

  // Canvas tap-to-aim and attack
  const handleCanvasPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const clickX = (e.clientX - rect.left) * scaleX;
    const clickY = (e.clientY - rect.top) * scaleY;

    // Convert screen canvas coordinates to world coordinates taking camera zoom into account
    const worldClickX =
      playerPosRef.current.x + (clickX - canvas.width / 2) / cameraZoom;
    const worldClickY =
      playerPosRef.current.y + (clickY - canvas.height / 2) / cameraZoom;

    const angle = Math.atan2(
      worldClickY - playerPosRef.current.y,
      worldClickX - playerPosRef.current.x,
    );

    // Update facing direction toward tap
    const deg = (angle * 180) / Math.PI;
    let tapDir: Direction = 'down';
    if (deg >= -22.5 && deg < 22.5) tapDir = 'right';
    else if (deg >= 22.5 && deg < 67.5) tapDir = 'down-right';
    else if (deg >= 67.5 && deg < 112.5) tapDir = 'down';
    else if (deg >= 112.5 && deg < 157.5) tapDir = 'down-left';
    else if (deg >= 157.5 || deg < -157.5) tapDir = 'left';
    else if (deg >= -157.5 && deg < -112.5) tapDir = 'up-left';
    else if (deg >= -112.5 && deg < -67.5) tapDir = 'up';
    else if (deg >= -67.5 && deg < -22.5) tapDir = 'up-right';

    playerDirectionRef.current = tapDir;
    setPlayerDirection(tapDir);
    triggerBasicAttack(angle);
  };

  // Cooldown countdown loop
  useEffect(() => {
    const interval = setInterval(() => {
      setCooldowns((prev) => {
        let changed = false;
        const next = { ...prev };
        Object.keys(next).forEach((k) => {
          if (next[k] > 0) {
            next[k] = Math.max(0, parseFloat((next[k] - 0.1).toFixed(1)));
            changed = true;
          }
        });
        return changed ? next : prev;
      });
    }, 100);
    return () => clearInterval(interval);
  }, []);

  // Main Canvas Game Loop
  useEffect(() => {
    let animId: number;

    const gameLoop = (currentTime: number) => {
      const dt = Math.min(0.05, (currentTime - lastTimeRef.current) / 1000);
      lastTimeRef.current = currentTime;

      const canvas = canvasRef.current;
      if (!canvas) {
        animId = requestAnimationFrame(gameLoop);
        return;
      }
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // 1. Process Player Movement (Keyboard + Touch Joystick/D-Pad)
      // Owner Rule: +5% base speed per level up to 20
      const speedMult = 1 + Math.min(19, playerLevel - 1) * 0.05;
      const moveSpeed = hero.baseStats.speed * 185 * speedMult * dt;

      let mx = touchVectorRef.current.mx;
      let my = touchVectorRef.current.my;

      if (keysRef.current['KeyW'] || keysRef.current['ArrowUp'] || keysRef.current['w']) my -= 1;
      if (keysRef.current['KeyS'] || keysRef.current['ArrowDown'] || keysRef.current['s']) my += 1;
      if (keysRef.current['KeyA'] || keysRef.current['ArrowLeft'] || keysRef.current['a']) mx -= 1;
      if (keysRef.current['KeyD'] || keysRef.current['ArrowRight'] || keysRef.current['d']) mx += 1;

      if (mx !== 0 || my !== 0) {
        const len = Math.hypot(mx, my);
        const normX = len > 1 ? mx / len : mx;
        const normY = len > 1 ? my / len : my;

        playerPosRef.current.x = Math.max(
          45,
          Math.min(ARENA_WIDTH - 45, playerPosRef.current.x + normX * moveSpeed),
        );
        playerPosRef.current.y = Math.max(
          45,
          Math.min(ARENA_HEIGHT - 45, playerPosRef.current.y + normY * moveSpeed),
        );

        // Determine 8-direction facing from angle
        const angleDeg = (Math.atan2(normY, normX) * 180) / Math.PI;
        let nextDir: Direction = playerDirectionRef.current;
        if (angleDeg >= -22.5 && angleDeg < 22.5) nextDir = 'right';
        else if (angleDeg >= 22.5 && angleDeg < 67.5) nextDir = 'down-right';
        else if (angleDeg >= 67.5 && angleDeg < 112.5) nextDir = 'down';
        else if (angleDeg >= 112.5 && angleDeg < 157.5) nextDir = 'down-left';
        else if (angleDeg >= 157.5 || angleDeg < -157.5) nextDir = 'left';
        else if (angleDeg >= -157.5 && angleDeg < -112.5) nextDir = 'up-left';
        else if (angleDeg >= -112.5 && angleDeg < -67.5) nextDir = 'up';
        else if (angleDeg >= -67.5 && angleDeg < -22.5) nextDir = 'up-right';

        if (nextDir !== playerDirectionRef.current) {
          playerDirectionRef.current = nextDir;
          setPlayerDirection(nextDir);
        }
      }

      // 2. Ki Regeneration
      setPlayerKi((prev) => Math.min(hero.baseStats.ki, prev + hero.baseStats.kiRegen * dt));

      // 3. Update Projectiles
      const remainingProjectiles: Projectile[] = [];
      projectilesRef.current.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.duration -= 1;

        let hit = false;
        monstersRef.current.forEach((m) => {
          if (m.state === 'dead' || hit) return;
          const dist = Math.hypot(m.x - p.x, m.y - p.y);
          if (dist < p.radius + 24) {
            hit = true;
            const actualDamage = Math.max(1, p.damage - Math.floor(m.def * 0.3));
            m.currentHp -= actualDamage;

            floatingTextsRef.current.push({
              id: Math.random().toString(),
              x: m.x + (Math.random() * 20 - 10),
              y: m.y - 15,
              text: `-${actualDamage}`,
              color: '#f87171',
              alpha: 1,
              time: 0,
            });

            if (m.currentHp <= 0) {
              m.state = 'dead';
              addLog(`Pokonano ${m.name}! +${m.xp} XP`, 'kill');
              onMonsterKilledForQuest?.(m.monsterId, m.name, m.xp);

              setPlayerXp((currXp) => {
                const nextXp = currXp + m.xp;
                if (nextXp >= xpNeeded && playerLevel < 20) {
                  setPlayerLevel((lvl) => lvl + 1);
                  setPlayerHp(hero.baseStats.hp + playerLevel * 10);
                  addLog(
                    `★ AWANS! Poziom ${playerLevel + 1}! (+5% Szybkości ruchu, +HP)`,
                    'level',
                  );
                  return nextXp - xpNeeded;
                }
                return nextXp;
              });
            }
          }
        });

        if (
          !hit &&
          p.duration > 0 &&
          p.x >= 0 &&
          p.x <= ARENA_WIDTH &&
          p.y >= 0 &&
          p.y <= ARENA_HEIGHT
        ) {
          remainingProjectiles.push(p);
        }
      });
      projectilesRef.current = remainingProjectiles;

      // 4. Update Monsters
      const px = playerPosRef.current.x;
      const py = playerPosRef.current.y;

      monstersRef.current.forEach((m) => {
        if (m.state === 'dead') return;
        const distToPlayer = Math.hypot(px - m.x, py - m.y);

        if (distToPlayer <= m.agro) {
          m.state = 'chase';
          if (distToPlayer > m.range) {
            const dx = (px - m.x) / distToPlayer;
            const dy = (py - m.y) / distToPlayer;
            m.x += dx * m.speed * 60 * dt;
            m.y += dy * m.speed * 60 * dt;
          } else {
            if (currentTime - m.lastAttackTime > 1200) {
              m.lastAttackTime = currentTime;
              const dmg = Math.max(1, Math.round(m.atk - hero.baseStats.def * 0.4));
              setPlayerHp((prev) => Math.max(0, prev - dmg));
              if (
                currentTime - playerActionRef.current.startTime >=
                playerActionRef.current.durationMs
              ) {
                playerActionRef.current = {
                  state: 'hit',
                  startTime: currentTime,
                  durationMs: 360,
                };
              }
              addLog(`${m.name} zadaje ${dmg} obrażeń!`, 'damage');

              floatingTextsRef.current.push({
                id: Math.random().toString(),
                x: px + (Math.random() * 20 - 10),
                y: py - 20,
                text: `-${dmg}`,
                color: '#ef4444',
                alpha: 1,
                time: 0,
              });
            }
          }
        } else {
          m.state = 'idle';
        }
      });

      monstersRef.current = monstersRef.current.filter(
        (m) => m.state !== 'dead' || m.currentHp > 0,
      );

      // 5. Render Scene with Camera Zoom
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#0e1712';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.save();
      // Center camera around player with zoomed-out perspective
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.scale(cameraZoom, cameraZoom);
      ctx.translate(-px, -py);

      // Arena Floor
      ctx.fillStyle = '#141e17';
      ctx.fillRect(0, 0, ARENA_WIDTH, ARENA_HEIGHT);

      // Grid / Tactical Ground
      ctx.strokeStyle = '#1e3325';
      ctx.lineWidth = 1;
      const gridSize = 48;
      for (let x = 0; x <= ARENA_WIDTH; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, ARENA_HEIGHT);
        ctx.stroke();
      }
      for (let y = 0; y <= ARENA_HEIGHT; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(ARENA_WIDTH, y);
        ctx.stroke();
      }

      // Arena Boundary
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 4;
      ctx.strokeRect(12, 12, ARENA_WIDTH - 24, ARENA_HEIGHT - 24);

      // Render Monsters
      monstersRef.current.forEach((m) => {
        if (m.state === 'dead') return;

        ctx.fillStyle = 'rgba(0,0,0,0.45)';
        ctx.beginPath();
        ctx.ellipse(m.x, m.y + 18, 18, 8, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = m.color;
        ctx.beginPath();
        ctx.arc(m.x, m.y, 18, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#ffffff90';
        ctx.lineWidth = 2;
        ctx.stroke();

        if (m.state === 'chase') {
          ctx.strokeStyle = 'rgba(239, 68, 68, 0.35)';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(m.x, m.y, m.range, 0, Math.PI * 2);
          ctx.stroke();
        }

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 11px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(m.name, m.x, m.y - 26);

        const barWidth = 42;
        const hpPct = Math.max(0, m.currentHp / m.maxHp);
        ctx.fillStyle = '#1c1917';
        ctx.fillRect(m.x - barWidth / 2, m.y - 21, barWidth, 5);
        ctx.fillStyle = hpPct > 0.4 ? '#ef4444' : '#dc2626';
        ctx.fillRect(m.x - barWidth / 2, m.y - 21, barWidth * hpPct, 5);
      });

      // Render Player
      const isMoving = mx !== 0 || my !== 0;
      const actionElapsed = currentTime - playerActionRef.current.startTime;
      let activeAnimState: HeroAnimState = isMoving ? 'walk' : 'idle';
      let frameIdx = 0;
      let subFrame = 0;

      if (actionElapsed < playerActionRef.current.durationMs) {
        activeAnimState = playerActionRef.current.state;
        const totalActionFrames = HERO_ANIM_FRAMES[activeAnimState];
        const exactFrame =
          (actionElapsed / playerActionRef.current.durationMs) * totalActionFrames;
        frameIdx = Math.min(totalActionFrames - 1, Math.floor(exactFrame));
        subFrame = exactFrame - frameIdx;
      } else {
        const loopFps = HERO_ANIM_FPS[activeAnimState] * (isMoving ? speedMult : 1);
        const totalLoopFrames = HERO_ANIM_FRAMES[activeAnimState];
        const totalElapsedFrames = ((currentTime / 1000) * loopFps) % totalLoopFrames;
        frameIdx = Math.floor(totalElapsedFrames);
        subFrame = totalElapsedFrames - frameIdx;
      }

      renderAnimatedHero(ctx, hero, playerDirectionRef.current, px, py + 28, 96, {
        state: activeAnimState,
        frameIndex: frameIdx,
        subFrame,
        useCleanedSprite: true,
        showAura: true,
      });

      // Render Projectiles
      projectilesRef.current.forEach((p) => {
        ctx.fillStyle = p.color;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      // Render Floating Texts
      const nextTexts: FloatingText[] = [];
      floatingTextsRef.current.forEach((t) => {
        t.y -= 0.6;
        t.alpha -= 0.02;
        if (t.alpha > 0) {
          ctx.save();
          ctx.globalAlpha = Math.max(0, t.alpha);
          ctx.fillStyle = t.color;
          ctx.font = 'bold 13px monospace';
          ctx.textAlign = 'center';
          ctx.fillText(t.text, t.x, t.y);
          ctx.restore();
          nextTexts.push(t);
        }
      });
      floatingTextsRef.current = nextTexts;

      ctx.restore();

      animId = requestAnimationFrame(gameLoop);
    };

    animId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animId);
  }, [hero, playerLevel, cameraZoom, xpNeeded, addLog, onMonsterKilledForQuest]);

  return (
    <div className="space-y-5 text-stone-100">
      {/* Header Bar */}
      <div className="border-b border-stone-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-emerald-400">
            <Swords className="w-4 h-4" />
            Stage 2 Authorized Local PvE • Mobile & Multi-Screen Ready
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mt-1">
            Arena Walki PvE (Desktop & Mobile HUD)
          </h2>
          <p className="text-xs sm:text-sm text-stone-400 mt-1">
            Obsługa dotykowego Joysticka 360°, D-Pada 8-kierunkowego, kamery oddalonej oraz pełnego
            ekranu z HUD na smartfonach i tabletach.
          </p>
        </div>

        {/* Hero Selector Quick Buttons */}
        <div className="flex flex-wrap items-center gap-1.5 bg-stone-900 p-1.5 rounded-xl border border-stone-800">
          {HERO_RACES.map((r) => (
            <button
              key={r.id}
              onClick={() => {
                setSelectedHeroId(r.id);
                setPlayerHp(r.baseStats.hp);
                setPlayerKi(r.baseStats.ki);
              }}
              className={`px-3 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer min-h-[40px] ${
                selectedHeroId === r.id
                  ? 'bg-stone-800 text-white shadow-sm ring-1 ring-emerald-500/50'
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              {r.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Play Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Stage & HUD Container (expands in Fullscreen mode) */}
        <div
          ref={stageContainerRef}
          className={
            isStageFullscreen
              ? 'fixed inset-0 z-50 bg-stone-950 flex flex-col justify-between p-2 sm:p-4 overflow-hidden'
              : 'lg:col-span-8 bg-stone-900/60 border border-stone-800 rounded-2xl p-3 sm:p-5 backdrop-blur-sm space-y-4'
          }
        >
          {/* Top HUD Stats & Camera/Fullscreen Controls */}
          <div className="flex flex-wrap items-center justify-between gap-2 bg-stone-950/95 p-3 rounded-xl border border-stone-800">
            <div className="grid grid-cols-3 gap-2 sm:gap-4 flex-1 min-w-[240px]">
              {/* Level & XP */}
              <div>
                <div className="flex items-center justify-between text-[11px] font-mono mb-1">
                  <span className="font-bold text-amber-400">Lv.{playerLevel}</span>
                  <span className="text-stone-400">
                    {playerXp}/{xpNeeded} XP
                  </span>
                </div>
                <div className="w-full bg-stone-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-amber-400 h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, (playerXp / xpNeeded) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Health Bar */}
              <div>
                <div className="flex items-center justify-between text-[11px] font-mono mb-1">
                  <span className="flex items-center gap-1 font-bold text-rose-400">
                    <Heart className="w-3 h-3" /> HP
                  </span>
                  <span className="text-stone-300">
                    {Math.round(playerHp)}/{hero.baseStats.hp + (playerLevel - 1) * 10}
                  </span>
                </div>
                <div className="w-full bg-stone-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-rose-500 h-full rounded-full transition-all duration-150"
                    style={{
                      width: `${Math.max(
                        0,
                        (playerHp / (hero.baseStats.hp + (playerLevel - 1) * 10)) * 100,
                      )}%`,
                    }}
                  />
                </div>
              </div>

              {/* Ki Energy Bar */}
              <div>
                <div className="flex items-center justify-between text-[11px] font-mono mb-1">
                  <span className="flex items-center gap-1 font-bold text-cyan-400">
                    <Zap className="w-3 h-3" /> KI
                  </span>
                  <span className="text-stone-300">
                    {Math.round(playerKi)}/{hero.baseStats.ki}
                  </span>
                </div>
                <div className="w-full bg-stone-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-cyan-500 h-full rounded-full transition-all duration-100"
                    style={{ width: `${Math.max(0, (playerKi / hero.baseStats.ki) * 100)}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Camera Zoom & Whole-Stage Fullscreen Toolbar */}
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                onClick={() =>
                  setCameraZoom((z) => (z <= 0.75 ? 1.0 : z <= 0.9 ? 0.7 : 0.85))
                }
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-stone-900 hover:bg-stone-800 border border-stone-700 text-xs font-mono text-stone-200 cursor-pointer min-h-[38px]"
                title="Przełącz przybliżenie kamery (domyślnie oddalona)"
              >
                {cameraZoom < 1 ? (
                  <ZoomOut className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <ZoomIn className="w-3.5 h-3.5 text-amber-400" />
                )}
                <span>Zoom {Math.round(cameraZoom * 100)}%</span>
              </button>

              <button
                onClick={() => setShowTouchControls((v) => !v)}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer min-h-[38px] ${
                  showTouchControls
                    ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                    : 'bg-stone-900 border-stone-700 text-stone-400'
                }`}
                title="Pokaż/ukryj dotykowe kontrolki ekranowe"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">HUD Mobilny</span>
              </button>

              <button
                onClick={handleToggleFullscreen}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs cursor-pointer min-h-[38px]"
                title="Pełny ekran całej sceny wraz z HUD"
              >
                {isStageFullscreen ? (
                  <>
                    <Minimize2 className="w-3.5 h-3.5" />
                    <span>Zamknij Pełny Ekran</span>
                  </>
                ) : (
                  <>
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>Pełny Ekran</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Canvas Viewport + Mobile Touch Overlay */}
          <div
            className={`relative rounded-xl overflow-hidden border border-stone-700/80 shadow-2xl bg-stone-950 select-none touch-none ${
              isStageFullscreen ? 'flex-1 flex items-center justify-center' : ''
            }`}
          >
            <canvas
              ref={canvasRef}
              width={800}
              height={500}
              className={`w-full block cursor-crosshair touch-none ${
                isStageFullscreen ? 'h-full object-contain' : 'aspect-[16/10]'
              }`}
              onPointerDown={handleCanvasPointerDown}
            />

            {/* Top-left quick info & monster spawn button for mobile fullscreen */}
            <div className="absolute top-2.5 left-2.5 flex flex-wrap items-center gap-2 pointer-events-auto">
              <button
                onClick={() => {
                  const m =
                    MONSTERS.find((item) => item.id === selectedSpawnMonsterId) || MONSTERS[0];
                  spawnMonster(m);
                }}
                className="px-2.5 py-1.5 rounded-lg bg-emerald-600/90 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 shadow-md cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Spawn: {MONSTERS.find((m) => m.id === selectedSpawnMonsterId)?.name}
              </button>

              <button
                onClick={() =>
                  setMobileControlStyle((s) => (s === 'joystick' ? 'dpad' : 'joystick'))
                }
                className="px-2.5 py-1.5 rounded-lg bg-stone-950/85 border border-stone-700 text-stone-200 text-[11px] font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Gamepad2 className="w-3.5 h-3.5 text-amber-400" />
                {mobileControlStyle === 'joystick' ? 'Tryb: Joystick 360°' : 'Tryb: D-Pad 8-Kier.'}
              </button>
            </div>

            {/* Speed & Direction status */}
            <div className="absolute top-2.5 right-2.5 bg-stone-950/85 backdrop-blur-sm border border-stone-800 px-2.5 py-1 rounded-lg text-[11px] font-mono text-emerald-400 pointer-events-none">
              Szybkość: +{Math.round((playerLevel - 1) * 5)}% • Kierunek: {playerDirection}
            </div>

            {/* ON-SCREEN MOBILE TOUCH CONTROLS (Left: Joystick or D-Pad | Right: Attack & Ki Skills) */}
            {showTouchControls && (
              <div className="absolute inset-x-3 bottom-3 flex items-end justify-between pointer-events-none">
                {/* LEFT THUMB: Virtual Analog Joystick OR 8-Way D-Pad */}
                {mobileControlStyle === 'joystick' ? (
                  <div
                    onPointerDown={handleJoystickStart}
                    onPointerMove={handleJoystickMove}
                    onPointerUp={handleJoystickEnd}
                    onPointerCancel={handleJoystickEnd}
                    className="w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-stone-950/75 border-2 border-stone-600/80 backdrop-blur-md flex items-center justify-center relative pointer-events-auto touch-none cursor-grab active:cursor-grabbing shadow-xl"
                  >
                    {/* Crosshair lines */}
                    <div className="w-full h-px bg-stone-700/50 absolute" />
                    <div className="h-full w-px bg-stone-700/50 absolute" />
                    {/* Movable Thumb Stick */}
                    <div
                      className="w-12 h-12 rounded-full bg-emerald-500/80 border-2 border-emerald-200 shadow-lg flex items-center justify-center transition-transform duration-75"
                      style={{
                        transform: `translate(${joystickVisual.dx}px, ${joystickVisual.dy}px)`,
                      }}
                    >
                      <Navigation className="w-4 h-4 text-stone-950" />
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-3 gap-1 w-32 h-32 bg-stone-950/80 p-1.5 rounded-2xl border border-stone-700 pointer-events-auto touch-none">
                    {[
                      { label: '↖', mx: -0.7, my: -0.7 },
                      { label: '↑', mx: 0, my: -1 },
                      { label: '↗', mx: 0.7, my: -0.7 },
                      { label: '←', mx: -1, my: 0 },
                      { label: '•', mx: 0, my: 0 },
                      { label: '→', mx: 1, my: 0 },
                      { label: '↙', mx: -0.7, my: 0.7 },
                      { label: '↓', mx: 0, my: 1 },
                      { label: '↘', mx: 0.7, my: 0.7 },
                    ].map((btn, idx) => (
                      <button
                        key={idx}
                        onPointerDown={(e) => {
                          e.preventDefault();
                          setDpadDirection(btn.mx, btn.my);
                        }}
                        onPointerUp={() => setDpadDirection(0, 0)}
                        onPointerLeave={() => setDpadDirection(0, 0)}
                        className="rounded-lg bg-stone-800/90 active:bg-emerald-500 active:text-stone-950 text-stone-200 font-bold text-sm flex items-center justify-center border border-stone-700 select-none"
                      >
                        {btn.label}
                      </button>
                    ))}
                  </div>
                )}

                {/* RIGHT THUMB: Ergonomic Action & Ki Skill Buttons */}
                <div className="flex flex-col items-end gap-2 pointer-events-auto">
                  <div className="flex items-center gap-2">
                    {hero.skills.map((s) => {
                      const cd = cooldowns[s.key] || 0;
                      const hasKi = playerKi >= s.cost;
                      return (
                        <button
                          key={s.key}
                          onPointerDown={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            triggerSkill(s.key as 'Q' | 'E' | 'R');
                          }}
                          disabled={cd > 0 || !hasKi}
                          className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full border-2 font-bold text-xs flex flex-col items-center justify-center shadow-lg transition-transform active:scale-90 select-none ${
                            cd > 0 || !hasKi
                              ? 'bg-stone-950/85 border-stone-700 text-stone-500'
                              : 'bg-cyan-950/85 border-cyan-400 text-white'
                          }`}
                        >
                          <span className="text-xs font-black">{s.key}</span>
                          <span className="text-[9px] font-mono text-cyan-300">
                            {cd > 0 ? `${cd}s` : `${s.cost}KI`}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  <button
                    onPointerDown={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      triggerBasicAttack();
                    }}
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-amber-500 active:bg-amber-400 border-4 border-amber-200 text-stone-950 font-black text-xs flex flex-col items-center justify-center shadow-xl active:scale-90 transition-transform select-none"
                  >
                    <Swords className="w-6 h-6" />
                    <span className="text-[10px] mt-0.5">ATAK</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Standard Desktop / Tablet Toolbar below canvas */}
          {!isStageFullscreen && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
              <button
                onClick={() => triggerBasicAttack()}
                className="py-3 px-3 rounded-xl bg-stone-800 hover:bg-stone-700 border border-stone-700 font-bold text-xs flex flex-col items-center justify-center gap-1 cursor-pointer transition-all active:scale-95 min-h-[52px]"
              >
                <div className="flex items-center gap-1 text-white">
                  <Swords className="w-4 h-4 text-amber-400" />
                  <span>Atak Podstawowy</span>
                </div>
                <span className="text-[10px] text-stone-400 font-mono">[SPACJA / DOTYK]</span>
              </button>

              {hero.skills.map((s) => {
                const cd = cooldowns[s.key] || 0;
                const hasKi = playerKi >= s.cost;
                return (
                  <button
                    key={s.key}
                    onClick={() => triggerSkill(s.key as 'Q' | 'E' | 'R')}
                    disabled={cd > 0 || !hasKi}
                    className={`py-3 px-3 rounded-xl border font-bold text-xs flex flex-col items-center justify-center gap-1 transition-all cursor-pointer min-h-[52px] ${
                      cd > 0 || !hasKi
                        ? 'bg-stone-950/80 border-stone-800 text-stone-500 cursor-not-allowed'
                        : 'bg-emerald-950/50 hover:bg-emerald-900/60 border-emerald-700/60 text-white active:scale-95'
                    }`}
                  >
                    <div className="flex items-center gap-1">
                      <span className="w-4 h-4 rounded bg-stone-800 text-[10px] flex items-center justify-center font-mono">
                        {s.key}
                      </span>
                      <span className="truncate">{s.name}</span>
                    </div>
                    <span className="text-[10px] text-cyan-400 font-mono">
                      {cd > 0 ? `${cd}s CD` : `${s.cost} KI`}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Sidebar: Spawner & Combat Log */}
        <div className="lg:col-span-4 space-y-6">
          {/* Monster Spawner Tool */}
          <div className="bg-stone-900/60 border border-stone-800 rounded-2xl p-5 backdrop-blur-sm space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-widest text-stone-400 flex items-center gap-2">
              <Plus className="w-4 h-4 text-emerald-400" />
              Generator Przeciwników (40 Bestii)
            </h4>

            <div className="space-y-2">
              <label className="text-xs text-stone-300 font-medium block">
                Wybierz potwora z kanonicznego Bestiariusza:
              </label>
              <select
                value={selectedSpawnMonsterId}
                onChange={(e) => setSelectedSpawnMonsterId(e.target.value)}
                className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500 cursor-pointer min-h-[42px]"
              >
                {MONSTERS.map((m) => (
                  <option key={m.id} value={m.id} className="bg-stone-900">
                    [{m.world.toUpperCase()}] Lv.{m.level} {m.name} ({m.stats.hp} HP)
                  </option>
                ))}
              </select>

              <button
                onClick={() => {
                  const m = MONSTERS.find((item) => item.id === selectedSpawnMonsterId);
                  if (m) spawnMonster(m);
                }}
                className="w-full py-3 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-950/40 transition-all flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
              >
                <Plus className="w-4 h-4" />
                Przywołaj na Arenę
              </button>
            </div>

            <div className="pt-2 border-t border-stone-800/80 flex items-center justify-between text-xs text-stone-400 font-mono">
              <span>Aktywne na arenie:</span>
              <span className="font-bold text-white">{monstersRef.current.length}</span>
            </div>

            <button
              onClick={() => {
                monstersRef.current = [];
                addLog('Wyczyszczono arenę z potworów', 'info');
              }}
              className="w-full py-2 rounded-lg text-xs text-stone-400 hover:text-rose-300 hover:bg-stone-800/40 transition-colors cursor-pointer"
            >
              Wyczyść Arenę
            </button>
          </div>

          {/* Combat Log */}
          <div className="bg-stone-900/60 border border-stone-800 rounded-2xl p-5 backdrop-blur-sm space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-mono uppercase tracking-widest text-stone-400 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                Dziennik Walki na Żywo
              </h4>
              <button
                onClick={() => setCombatLog([])}
                className="text-[11px] text-stone-500 hover:text-stone-300 font-mono cursor-pointer"
              >
                Wyczyść
              </button>
            </div>

            <div className="h-[220px] overflow-y-auto space-y-1.5 pr-1 font-mono text-[11px]">
              {combatLog.length === 0 ? (
                <div className="text-stone-500 text-center py-8 italic">
                  Użyj dotykowego joysticka lub klawiszy WASD i walcz z potworami.
                </div>
              ) : (
                combatLog.map((log) => (
                  <div
                    key={log.id}
                    className={`p-2 rounded-lg border text-left ${
                      log.type === 'kill'
                        ? 'bg-amber-950/30 border-amber-800/40 text-amber-200'
                        : log.type === 'level'
                          ? 'bg-emerald-950/40 border-emerald-800/50 text-emerald-300 font-bold'
                          : log.type === 'damage'
                            ? 'bg-rose-950/30 border-rose-800/40 text-rose-300'
                            : 'bg-stone-950/40 border-stone-800 text-stone-300'
                    }`}
                  >
                    <span className="text-stone-500 mr-2">[{log.time}]</span>
                    {log.text}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
