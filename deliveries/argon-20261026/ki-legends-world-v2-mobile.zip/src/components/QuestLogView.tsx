import React, { useMemo, useState } from 'react';
import {
  ScrollText,
  CheckCircle2,
  CircleDot,
  Lock,
  Award,
  Coins,
  Sparkles,
  Compass,
  Search,
  Play,
  Target,
  ChevronRight,
  MessageSquare,
  ShieldAlert,
  RefreshCw,
  MapPin,
  Swords,
  PackageCheck,
  Eye,
  TrendingUp,
} from 'lucide-react';
import { ALL_QUESTS_V2, QUEST_BY_ID, recordQuestObjectiveEvent, startQuest } from '../game/quests/engine';
import {
  CanonicalItemId,
  ObjectiveType,
  PlayerSaveV5,
  QuestCategory,
  QuestDefinition,
  QuestObjective,
} from '../game/quests/types';
import { CONTINENTS_WORLD_V2, ContinentId } from '../game/worlds';
import { getItemById } from '../game/items';
import { getNpcQuestDialogue } from '../game/dialogue';

interface QuestLogViewProps {
  save: PlayerSaveV5;
  selectedContinent: ContinentId;
  onUpdateSave: (next: PlayerSaveV5) => void;
  onJumpToMapLocation?: (continent: ContinentId, coords?: { x: number; y: number }) => void;
  onLogAction?: (message: string) => void;
}

type StatusFilter = 'all' | 'active' | 'upcoming' | 'locked' | 'completed';
type CategoryFilter = 'all' | QuestCategory;
type ContinentFilter = 'all' | ContinentId;

const FACTION_NAMES: Record<string, string> = {
  'F-V': 'Krąg Korzeni (Verdant)',
  'F-P': 'Bractwo Żaru (Pyra)',
  'F-A': 'Zakon Obserwatorów (Aether)',
  'F-N': 'Rada Rdzenia (Nexus)',
  'F-L': 'Liga Szlaków (Międzykontynentalna)',
};

const CATEGORY_LABELS: Record<QuestCategory, string> = {
  main: 'Kampania Główna',
  side: 'Zadanie Poboczne',
  hidden: 'Ukryta Przygoda',
  intercontinental: 'Misja Międzykontynentalna',
};

const OBJECTIVE_TYPE_LABELS: Record<ObjectiveType, string> = {
  combat: 'Walka',
  talk: 'Rozmowa',
  discover: 'Odkrycie',
  visit: 'Podróż',
  deliver: 'Dostawa',
};

export const QuestLogView: React.FC<QuestLogViewProps> = ({
  save,
  selectedContinent,
  onUpdateSave,
  onJumpToMapLocation,
  onLogAction,
}) => {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('active');
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>('all');
  const [continentFilter, setContinentFilter] = useState<ContinentFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedQuestId, setSelectedQuestId] = useState<string>(() => {
    if (save.trackedQuestId && QUEST_BY_ID[save.trackedQuestId]) {
      return save.trackedQuestId;
    }
    const firstActive = ALL_QUESTS_V2.find((q) => save.quests[q.id]?.state === 'active');
    return firstActive ? firstActive.id : ALL_QUESTS_V2[0].id;
  });

  // Helper calculating completion metrics for any quest
  const getQuestProgressMetrics = (quest: QuestDefinition) => {
    const rec = save.quests[quest.id];
    const state = rec?.state ?? 'unavailable';

    let totalObjectives = 0;
    let completedObjectives = 0;
    let totalSteps = 0;
    let completedSteps = 0;

    quest.stages.forEach((stage, stageIdx) => {
      stage.objectives.forEach((obj) => {
        totalObjectives += 1;
        totalSteps += obj.targetCount;

        if (state === 'completed') {
          completedObjectives += 1;
          completedSteps += obj.targetCount;
        } else if (state === 'active' && rec) {
          if (stageIdx < rec.currentStageIndex) {
            completedObjectives += 1;
            completedSteps += obj.targetCount;
          } else if (stageIdx === rec.currentStageIndex) {
            const currentCount = Math.min(obj.targetCount, rec.objectiveProgress[obj.id] ?? 0);
            completedSteps += currentCount;
            if (currentCount >= obj.targetCount) {
              completedObjectives += 1;
            }
          }
        }
      });
    });

    const percent = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0;

    return {
      state,
      rec,
      totalObjectives,
      completedObjectives,
      totalSteps,
      completedSteps,
      percent,
    };
  };

  // Global summary metrics across all quests
  const summaryStats = useMemo(() => {
    let activeCount = 0;
    let availableCount = 0;
    let completedCount = 0;
    let lockedCount = 0;

    let activeCompletedObjectives = 0;
    let activeTotalObjectives = 0;

    let upcomingPotentialXp = 0;
    let upcomingPotentialCoins = 0;

    for (const q of ALL_QUESTS_V2) {
      const m = getQuestProgressMetrics(q);
      if (m.state === 'active') {
        activeCount += 1;
        activeCompletedObjectives += m.completedObjectives;
        activeTotalObjectives += m.totalObjectives;
        upcomingPotentialXp += q.reward.xp;
        upcomingPotentialCoins += q.reward.coins;
      } else if (m.state === 'available') {
        availableCount += 1;
        upcomingPotentialXp += q.reward.xp;
        upcomingPotentialCoins += q.reward.coins;
      } else if (m.state === 'completed') {
        completedCount += 1;
      } else {
        lockedCount += 1;
      }
    }

    return {
      activeCount,
      availableCount,
      completedCount,
      lockedCount,
      activeCompletedObjectives,
      activeTotalObjectives,
      upcomingPotentialXp,
      upcomingPotentialCoins,
    };
  }, [save.quests]);

  // Filtered quest list
  const filteredQuests = useMemo(() => {
    const qLower = searchQuery.trim().toLowerCase();

    return ALL_QUESTS_V2.filter((quest) => {
      const state = save.quests[quest.id]?.state ?? 'unavailable';

      if (statusFilter === 'active' && state !== 'active') return false;
      if (statusFilter === 'upcoming' && state !== 'available') return false;
      if (statusFilter === 'locked' && state !== 'unavailable') return false;
      if (statusFilter === 'completed' && state !== 'completed') return false;

      if (categoryFilter !== 'all' && quest.category !== categoryFilter) return false;
      if (continentFilter !== 'all' && quest.continent !== continentFilter) return false;

      if (qLower) {
        const matchId = quest.id.toLowerCase().includes(qLower);
        const matchTitle = quest.title.toLowerCase().includes(qLower);
        const matchGiver = quest.giverName.toLowerCase().includes(qLower);
        const matchSummary = quest.summary.toLowerCase().includes(qLower);
        if (!matchId && !matchTitle && !matchGiver && !matchSummary) return false;
      }

      return true;
    });
  }, [save.quests, statusFilter, categoryFilter, continentFilter, searchQuery]);

  const selectedQuest = useMemo(() => {
    return (
      QUEST_BY_ID[selectedQuestId] ||
      filteredQuests[0] ||
      ALL_QUESTS_V2[0]
    );
  }, [selectedQuestId, filteredQuests]);

  const selectedMetrics = useMemo(
    () => getQuestProgressMetrics(selectedQuest),
    [selectedQuest, save.quests],
  );

  const npcDialogue = useMemo(
    () => getNpcQuestDialogue(selectedQuest.giverNpcId, selectedQuest.id),
    [selectedQuest],
  );

  const canonicalRewardItem = useMemo(
    () => (selectedQuest.reward.itemId ? getItemById(selectedQuest.reward.itemId) : undefined),
    [selectedQuest],
  );

  const plannedBookArtifact = useMemo(
    () =>
      selectedQuest.reward.plannedFutureItemId
        ? getItemById(selectedQuest.reward.plannedFutureItemId)
        : undefined,
    [selectedQuest],
  );

  const handleStartQuest = (quest: QuestDefinition) => {
    if (!quest.playableInCurrentRuntime) return;
    const next = startQuest(save, quest.id);
    onUpdateSave(next);
    setSelectedQuestId(quest.id);
    onLogAction?.(`Rozpoczęto misję z Dziennika: [${quest.id}] ${quest.title}`);
  };

  const handleTrackQuest = (questId: string) => {
    onUpdateSave({
      ...save,
      trackedQuestId: save.trackedQuestId === questId ? null : questId,
    });
    onLogAction?.(`Ustawiono śledzenie zadania: [${questId}]`);
  };

  const handleAdvanceObjective = (quest: QuestDefinition, obj: QuestObjective) => {
    if (!quest.playableInCurrentRuntime) return;
    if (obj.type === 'deliver') {
      const itemId = obj.targetId as CanonicalItemId;
      if ((save.inventory[itemId] ?? 0) <= 0) {
        onLogAction?.(
          `Brak przedmiotu "${itemId}" w ekwipunku, by ukończyć cel: ${obj.description}`,
        );
        return;
      }
    }
    const next = recordQuestObjectiveEvent(save, obj.type, obj.targetId, 1);
    onUpdateSave(next);
    onLogAction?.(`Postęp celu w misji [${quest.id}]: ${obj.description} (+1)`);
  };

  return (
    <div className="space-y-6">
      {/* Pasek podsumowania postępu misji i potencjalnych nagród */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-zinc-900/95 border border-zinc-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-zinc-400 font-medium">Aktywne Misje w Toku</div>
            <div className="text-2xl font-bold text-white mt-1 font-mono">
              {summaryStats.activeCount}
            </div>
            <div className="text-xs text-amber-400 mt-1">
              Cele: {summaryStats.activeCompletedObjectives}/{summaryStats.activeTotalObjectives}{' '}
              ukończonych
            </div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Target className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-zinc-900/95 border border-zinc-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-zinc-400 font-medium">Ukończone Przygody</div>
            <div className="text-2xl font-bold text-emerald-400 mt-1 font-mono">
              {summaryStats.completedCount}{' '}
              <span className="text-sm text-zinc-500 font-normal">/ {ALL_QUESTS_V2.length}</span>
            </div>
            <div className="text-xs text-zinc-400 mt-1">
              {Math.round((summaryStats.completedCount / ALL_QUESTS_V2.length) * 100)}% całej
              kampanii planety
            </div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-zinc-900/95 border border-zinc-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-zinc-400 font-medium">Nadchodzące i Dostępne</div>
            <div className="text-2xl font-bold text-sky-400 mt-1 font-mono">
              {summaryStats.availableCount}
            </div>
            <div className="text-xs text-zinc-400 mt-1">
              Oraz {summaryStats.lockedCount} zablokowanych tajemnic
            </div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400">
            <Compass className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-zinc-900/95 border border-zinc-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-zinc-400 font-medium">
              Pula Nagród (Aktywne + Dostępne)
            </div>
            <div className="text-lg font-bold text-amber-300 mt-1 font-mono">
              +{summaryStats.upcomingPotentialXp.toLocaleString('pl-PL')} XP
            </div>
            <div className="text-xs text-yellow-400 font-mono mt-0.5">
              +{summaryStats.upcomingPotentialCoins.toLocaleString('pl-PL')} monet w zasięgu
            </div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-yellow-500/15 border border-yellow-500/30 flex items-center justify-center text-yellow-400">
            <Award className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Pasek filtrów i wyszukiwarki Dziennika Misji */}
      <div className="bg-zinc-900/95 border border-zinc-800 rounded-xl p-4 space-y-3.5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Statusy misji */}
          <div className="flex flex-wrap items-center gap-1.5 bg-zinc-950 p-1 rounded-lg border border-zinc-800">
            {[
              { id: 'active', label: `Aktywne (${summaryStats.activeCount})` },
              { id: 'upcoming', label: `Nadchodzące / Dostępne (${summaryStats.availableCount})` },
              { id: 'completed', label: `Ukończone (${summaryStats.completedCount})` },
              { id: 'locked', label: `Zablokowane (${summaryStats.lockedCount})` },
              { id: 'all', label: `Wszystkie (${ALL_QUESTS_V2.length})` },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setStatusFilter(tab.id as StatusFilter)}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                  statusFilter === tab.id
                    ? 'bg-amber-500 text-zinc-950 shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Wyszukiwarka */}
          <div className="relative flex-1 min-w-[220px] max-w-sm">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Szukaj po ID (np. O-V01), tytule lub NPC..."
              className="w-full bg-zinc-950 border border-zinc-800 focus:border-amber-500/60 rounded-lg pl-9 pr-3 py-1.5 text-xs text-zinc-100 placeholder:text-zinc-500 outline-none"
            />
          </div>
        </div>

        {/* Dodatkowe filtry: Kontynent i Kategoria */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-zinc-800/80 text-xs">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-zinc-400 mr-1">Kontynent:</span>
            {[
              { id: 'all', label: 'Cała Planeta' },
              { id: 'verdant', label: 'Verdant (Planetarni)' },
              { id: 'pyra', label: 'Pyra (Legendy)' },
              { id: 'aether', label: 'Aether (Mędrcy)' },
              { id: 'nexus', label: 'Nexus (Androidy)' },
            ].map((c) => (
              <button
                key={c.id}
                onClick={() => setContinentFilter(c.id as ContinentFilter)}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                  continentFilter === c.id
                    ? 'bg-zinc-800 text-white border border-zinc-600'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-zinc-400 mr-1">Kategoria:</span>
            {[
              { id: 'all', label: 'Wszystkie' },
              { id: 'main', label: 'Główne' },
              { id: 'side', label: 'Poboczne' },
              { id: 'hidden', label: 'Ukryte' },
              { id: 'intercontinental', label: 'Międzykontynentalne' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setCategoryFilter(cat.id as CategoryFilter)}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                  categoryFilter === cat.id
                    ? 'bg-zinc-800 text-amber-300 border border-amber-500/40'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Główny układ Master-Detail: Lista Misji (lewa 5/12) + Szczegółowy Inspektor Misji, Celów i Nagród (prawa 7/12) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Lista Misji (Master) */}
        <div className="lg:col-span-5 bg-zinc-900/95 border border-zinc-800 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-2.5">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ScrollText className="w-4 h-4 text-amber-400" />
              Lista Zadań ({filteredQuests.length})
            </h3>
            {continentFilter !== selectedContinent && (
              <button
                onClick={() => setContinentFilter(selectedContinent)}
                className="text-xs text-amber-400 hover:underline cursor-pointer"
              >
                Filtruj: {CONTINENTS_WORLD_V2[selectedContinent].name}
              </button>
            )}
          </div>

          <div className="space-y-2.5 max-h-[760px] overflow-y-auto pr-1">
            {filteredQuests.length === 0 ? (
              <div className="text-center py-10 px-4 space-y-2">
                <div className="text-sm font-semibold text-zinc-300">
                  Brak zadań spełniających wybrane kryteria
                </div>
                <p className="text-xs text-zinc-500">
                  Przełącz zakładkę statusu na „Nadchodzące / Dostępne” lub „Wszystkie”, aby
                  przejrzeć pozostałe misje i ich potencjalne nagrody.
                </p>
                <button
                  onClick={() => {
                    setStatusFilter('all');
                    setCategoryFilter('all');
                    setContinentFilter('all');
                    setSearchQuery('');
                  }}
                  className="mt-2 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs text-zinc-200 cursor-pointer"
                >
                  Pokaż wszystkie 106 zadań
                </button>
              </div>
            ) : (
              filteredQuests.map((quest) => {
                const metrics = getQuestProgressMetrics(quest);
                const isSelected = selectedQuest.id === quest.id;
                const isTracked = save.trackedQuestId === quest.id;

                return (
                  <div
                    key={quest.id}
                    onClick={() => setSelectedQuestId(quest.id)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-zinc-950 border-amber-500/70 ring-1 ring-amber-500/30'
                        : 'bg-zinc-950/60 border-zinc-800/90 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-1.5 text-xs text-zinc-400">
                          <span className="font-mono font-bold text-amber-400">[{quest.id}]</span>
                          <span>·</span>
                          <span>{CATEGORY_LABELS[quest.category]}</span>
                          <span>·</span>
                          <span>Lv.{quest.recommendedLevel}</span>
                          {isTracked && (
                            <>
                              <span>·</span>
                              <span className="text-amber-300 font-semibold">★ Śledzone</span>
                            </>
                          )}
                        </div>
                        <h4 className="text-sm font-bold text-white leading-snug">{quest.title}</h4>
                      </div>

                      <div className="shrink-0">
                        {metrics.state === 'completed' ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        ) : metrics.state === 'active' ? (
                          <CircleDot className="w-4 h-4 text-amber-400" />
                        ) : metrics.state === 'available' ? (
                          <Sparkles className="w-4 h-4 text-sky-400" />
                        ) : (
                          <Lock className="w-4 h-4 text-zinc-500" />
                        )}
                      </div>
                    </div>

                    {/* Pasek postępu misji dla aktywnych lub ukończonych */}
                    {(metrics.state === 'active' || metrics.state === 'completed') && (
                      <div className="mt-2.5 space-y-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-zinc-400">
                            Ukończone cele:{' '}
                            <b className="text-emerald-400">
                              {metrics.completedObjectives}/{metrics.totalObjectives}
                            </b>
                          </span>
                          <span className="font-mono font-bold text-zinc-200">
                            {metrics.percent}%
                          </span>
                        </div>
                        <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                          <div
                            className={`h-full transition-all ${
                              metrics.state === 'completed' ? 'bg-emerald-500' : 'bg-amber-400'
                            }`}
                            style={{ width: `${metrics.percent}%` }}
                          />
                        </div>
                      </div>
                    )}

                    {/* Skrót potencjalnych nagród na karcie listy */}
                    <div className="mt-2.5 pt-2 border-t border-zinc-800/70 flex flex-wrap items-center justify-between gap-2 text-[11px] text-zinc-400">
                      <span>
                        Zleceniodawca: <b className="text-zinc-300">{quest.giverName}</b>
                      </span>
                      <span className="font-mono text-amber-300/90">
                        +{quest.reward.xp} XP · +{quest.reward.coins} monet
                        {quest.reward.plannedFutureItemId || quest.reward.itemId ? ' · +Łup' : ''}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Szczegółowy Inspektor Misji, Podświetlonych Celów i Nagród (Detail - 7/12) */}
        <div className="lg:col-span-7 bg-zinc-900/95 border border-zinc-800 rounded-xl p-5 space-y-6">
          {/* Nagłówek wybranej misji */}
          <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-zinc-800">
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-400">
                <span className="font-mono font-bold text-amber-400 text-sm">
                  [{selectedQuest.id}]
                </span>
                <span>·</span>
                <span className="text-zinc-200 font-medium">
                  {CATEGORY_LABELS[selectedQuest.category]}
                </span>
                <span>·</span>
                <span>Kontynent: {CONTINENTS_WORLD_V2[selectedQuest.continent].name}</span>
                <span>·</span>
                <span>Sugerowany Poziom: Lv.{selectedQuest.recommendedLevel}</span>
                {selectedQuest.repeatable && (
                  <>
                    <span>·</span>
                    <span className="text-emerald-400 flex items-center gap-1">
                      <RefreshCw className="w-3 h-3" /> Zlecenie Odnawialne
                    </span>
                  </>
                )}
              </div>
              <h2 className="text-xl font-bold text-white">{selectedQuest.title}</h2>
              <p className="text-xs text-zinc-300 leading-relaxed max-w-2xl">
                {selectedQuest.summary}
              </p>
            </div>

            {/* Akcje dla misji */}
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              {selectedMetrics.state === 'available' && selectedQuest.playableInCurrentRuntime && (
                <button
                  onClick={() => handleStartQuest(selectedQuest)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold transition-colors cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  Rozpocznij Misję
                </button>
              )}

              {selectedMetrics.state === 'active' && (
                <button
                  onClick={() => handleTrackQuest(selectedQuest.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                    save.trackedQuestId === selectedQuest.id
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                      : 'bg-zinc-950 text-zinc-300 border-zinc-700 hover:border-zinc-500'
                  }`}
                >
                  <Target className="w-3.5 h-3.5" />
                  {save.trackedQuestId === selectedQuest.id
                    ? 'Śledzone na Kompasie ★'
                    : 'Śledź na Kompasie'}
                </button>
              )}

              {selectedMetrics.state === 'completed' && selectedQuest.repeatable && (
                <button
                  onClick={() => handleStartQuest(selectedQuest)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-semibold cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  Powtórz Zlecenie
                </button>
              )}
            </div>
          </div>

          {/* Pasek postępu całej misji */}
          <div className="bg-zinc-950/90 border border-zinc-800 rounded-xl p-4 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-amber-400" />
                <span className="font-bold text-white">Postęp Realizacji Misji</span>
                <span className="text-zinc-400">
                  (Etap{' '}
                  {selectedMetrics.state === 'completed'
                    ? selectedQuest.stages.length
                    : (selectedMetrics.rec?.currentStageIndex ?? 0) + 1}{' '}
                  z {selectedQuest.stages.length})
                </span>
              </div>
              <div className="font-mono text-xs">
                <span className="text-emerald-400 font-bold">
                  {selectedMetrics.completedObjectives}
                </span>{' '}
                / {selectedMetrics.totalObjectives} celów ukończonych ({selectedMetrics.percent}%)
              </div>
            </div>

            <div className="w-full h-2.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
              <div
                className={`h-full transition-all duration-300 ${
                  selectedMetrics.state === 'completed'
                    ? 'bg-emerald-500'
                    : selectedMetrics.state === 'active'
                      ? 'bg-amber-400'
                      : 'bg-zinc-700'
                }`}
                style={{ width: `${selectedMetrics.percent}%` }}
              />
            </div>

            {/* Warunki odblokowania dla zadań niedostępnych / nadchodzących */}
            {selectedMetrics.state === 'unavailable' && (
              <div className="pt-2 border-t border-zinc-800/80 text-xs text-amber-200/90 space-y-1">
                <div className="font-semibold flex items-center gap-1.5 text-amber-400">
                  <Lock className="w-3.5 h-3.5" /> Wymagania do odblokowania tej misji:
                </div>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-zinc-300">
                  <span>• Minimalny poziom: Lv.{selectedQuest.unlockCondition.minLevel}</span>
                  {selectedQuest.unlockCondition.prerequisiteQuestIds &&
                    selectedQuest.unlockCondition.prerequisiteQuestIds.length > 0 && (
                      <span className="flex items-center gap-1 flex-wrap">
                        • Wymagane ukończenie:
                        {selectedQuest.unlockCondition.prerequisiteQuestIds.map((preId) => (
                          <button
                            key={preId}
                            onClick={() => setSelectedQuestId(preId)}
                            className="font-mono text-amber-300 underline hover:text-amber-200 cursor-pointer"
                          >
                            [{preId}]
                          </button>
                        ))}
                      </span>
                    )}
                  {selectedQuest.unlockCondition.requiredDiscoveredLocationIds &&
                    selectedQuest.unlockCondition.requiredDiscoveredLocationIds.length > 0 && (
                      <span>
                        • Odkrycie lokacji:{' '}
                        <b className="font-mono text-sky-300">
                          {selectedQuest.unlockCondition.requiredDiscoveredLocationIds.join(', ')}
                        </b>
                      </span>
                    )}
                  {selectedQuest.unlockCondition.requiredTalkedNpcId && (
                    <span>
                      • Rozmowa z NPC:{' '}
                      <b className="font-mono text-emerald-300">
                        {selectedQuest.unlockCondition.requiredTalkedNpcId}
                      </b>
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Sekcja Potencjalnych Nagród (Potential Rewards for Active & Upcoming Quests) */}
          <div className="bg-zinc-950/90 border border-amber-500/30 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Award className="w-4 h-4" />
                {selectedMetrics.state === 'completed'
                  ? 'Odebrane Nagrody za Ukończenie'
                  : 'Potencjalne Nagrody za Ukończenie Misji'}
              </h3>
              {save.rewardClaimedQuestIds.includes(selectedQuest.id) && (
                <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Nagroda odebrana
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {/* Doświadczenie i Monety */}
              <div className="bg-zinc-900/90 border border-zinc-800 rounded-lg p-3 space-y-1">
                <div className="text-[11px] text-zinc-400">Doświadczenie i Waluta</div>
                <div className="text-sm font-bold text-white flex items-center gap-2">
                  <span className="text-amber-300 font-mono">+{selectedQuest.reward.xp} XP</span>
                  <span>·</span>
                  <span className="text-yellow-300 font-mono flex items-center gap-1">
                    <Coins className="w-3.5 h-3.5" /> +{selectedQuest.reward.coins} monet
                  </span>
                </div>
                {selectedQuest.reward.factionReputation && (
                  <div className="text-[11px] text-sky-300 pt-0.5">
                    +{selectedQuest.reward.factionReputation.amount} pkt reputacji:{' '}
                    {FACTION_NAMES[selectedQuest.reward.factionReputation.factionId] ||
                      selectedQuest.reward.factionReputation.factionId}
                  </div>
                )}
              </div>

              {/* Przedmiot bazowy runtime */}
              <div className="bg-zinc-900/90 border border-zinc-800 rounded-lg p-3 space-y-1">
                <div className="text-[11px] text-zinc-400">Nagroda Rzeczowa (Ekwipunek)</div>
                {selectedQuest.reward.itemId ? (
                  <>
                    <div className="text-sm font-bold text-emerald-300">
                      {selectedQuest.reward.itemCount ?? 1}×{' '}
                      {canonicalRewardItem?.name || selectedQuest.reward.itemId}
                    </div>
                    <div className="text-[11px] text-zinc-400 line-clamp-2">
                      {canonicalRewardItem?.description ||
                        `Przedmiot kanoniczny (${selectedQuest.reward.itemId})`}
                    </div>
                  </>
                ) : (
                  <div className="text-xs text-zinc-500 italic pt-1">
                    Brak standardowego zasobu rzeczowego
                  </div>
                )}
              </div>

              {/* Specjalny przedmiot z Księgi Przygody v1.0 */}
              <div className="bg-zinc-900/90 border border-zinc-800 rounded-lg p-3 space-y-1">
                <div className="text-[11px] text-zinc-400">Artefakt z Księgi Przygody v1.0</div>
                {plannedBookArtifact ? (
                  <>
                    <div className="text-sm font-bold text-purple-300">
                      {plannedBookArtifact.name}{' '}
                      <span className="text-[11px] font-mono text-zinc-400">
                        ({plannedBookArtifact.id})
                      </span>
                    </div>
                    <div className="text-[11px] text-zinc-300">
                      Rzadkość: <b className="uppercase">{plannedBookArtifact.rarity}</b> · Wartość:{' '}
                      {plannedBookArtifact.price} monet
                    </div>
                    {plannedBookArtifact.stats && (
                      <div className="text-[11px] text-emerald-400 font-mono">
                        {plannedBookArtifact.stats.atkBonus
                          ? `+${plannedBookArtifact.stats.atkBonus} ATK `
                          : ''}
                        {plannedBookArtifact.stats.defBonus
                          ? `+${plannedBookArtifact.stats.defBonus} DEF `
                          : ''}
                        {plannedBookArtifact.stats.hpBonus
                          ? `+${plannedBookArtifact.stats.hpBonus} HP `
                          : ''}
                        {plannedBookArtifact.stats.kiBonus
                          ? `+${plannedBookArtifact.stats.kiBonus} KI`
                          : ''}
                      </div>
                    )}
                  </>
                ) : selectedQuest.reward.plannedFutureItemId ? (
                  <div className="text-xs text-purple-300 font-mono pt-1">
                    Kod przedmiotu: {selectedQuest.reward.plannedFutureItemId}
                  </div>
                ) : (
                  <div className="text-xs text-zinc-500 italic pt-1">
                    Nagroda oparta na doświadczeniu i złocie
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Lista etapów i celów z wyróżnieniem ukończonych zadań (Highlighted Completed Objectives) */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Etapy Misji i Lista Celów ({selectedMetrics.completedObjectives}/
              {selectedMetrics.totalObjectives} Ukończono)
            </h3>

            <div className="space-y-3">
              {selectedQuest.stages.map((stage, stageIdx) => {
                const currentStageIdx = selectedMetrics.rec?.currentStageIndex ?? 0;
                const isStageCompleted =
                  selectedMetrics.state === 'completed' ||
                  (selectedMetrics.state === 'active' && stageIdx < currentStageIdx);
                const isStageCurrent =
                  selectedMetrics.state === 'active' && stageIdx === currentStageIdx;

                return (
                  <div
                    key={stage.id}
                    className={`rounded-xl border p-4 space-y-3 transition-all ${
                      isStageCompleted
                        ? 'bg-emerald-950/15 border-emerald-500/40'
                        : isStageCurrent
                          ? 'bg-zinc-950 border-amber-500/50'
                          : 'bg-zinc-950/50 border-zinc-800/80 opacity-80'
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span
                          className={`w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center ${
                            isStageCompleted
                              ? 'bg-emerald-500 text-zinc-950'
                              : isStageCurrent
                                ? 'bg-amber-500 text-zinc-950'
                                : 'bg-zinc-800 text-zinc-400'
                          }`}
                        >
                          {isStageCompleted ? '✓' : stageIdx + 1}
                        </span>
                        <div>
                          <h4 className="text-sm font-bold text-white">
                            Etap {stageIdx + 1}: {stage.title}
                          </h4>
                        </div>
                      </div>

                      <span
                        className={`text-xs font-semibold ${
                          isStageCompleted
                            ? 'text-emerald-400'
                            : isStageCurrent
                              ? 'text-amber-400'
                              : 'text-zinc-500'
                        }`}
                      >
                        {isStageCompleted
                          ? 'Etap Ukończony'
                          : isStageCurrent
                            ? 'W Trakcie Realizacji'
                            : 'Kolejny Etap'}
                      </span>
                    </div>

                    <p className="text-xs text-zinc-300 leading-relaxed">{stage.narrativeText}</p>

                    {stage.discoveryOrTwistNote && (
                      <div className="bg-purple-950/25 border border-purple-500/30 rounded-lg p-2.5 text-xs text-purple-200">
                        <b>Sekret / Zwrot fabularny:</b> {stage.discoveryOrTwistNote}
                      </div>
                    )}

                    {/* Cele w obrębie etapu */}
                    <div className="space-y-2 pt-1">
                      {stage.objectives.map((obj) => {
                        const rawProgress =
                          selectedMetrics.rec?.objectiveProgress[obj.id] ?? 0;
                        const currentCount = isStageCompleted
                          ? obj.targetCount
                          : isStageCurrent
                            ? Math.min(obj.targetCount, rawProgress)
                            : 0;
                        const isObjDone = currentCount >= obj.targetCount;
                        const objPercent =
                          obj.targetCount > 0
                            ? Math.round((currentCount / obj.targetCount) * 100)
                            : 0;

                        return (
                          <div
                            key={obj.id}
                            className={`p-3 rounded-lg border transition-all ${
                              isObjDone
                                ? 'bg-emerald-950/30 border-emerald-500/50'
                                : isStageCurrent
                                  ? 'bg-zinc-900 border-zinc-700'
                                  : 'bg-zinc-900/50 border-zinc-800/80'
                            }`}
                          >
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <div className="flex items-start gap-2.5">
                                {isObjDone ? (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                                ) : (
                                  <CircleDot className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                                )}
                                <div>
                                  <div
                                    className={`text-xs font-semibold ${
                                      isObjDone
                                        ? 'text-emerald-300 line-through decoration-emerald-500/60'
                                        : 'text-white'
                                    }`}
                                  >
                                    {obj.description}
                                  </div>
                                  <div className="flex flex-wrap items-center gap-2 text-[11px] text-zinc-400 mt-0.5">
                                    <span>Typ: {OBJECTIVE_TYPE_LABELS[obj.type]}</span>
                                    <span>·</span>
                                    <span className="font-mono">Cel: {obj.targetId}</span>
                                    {obj.coordinates && (
                                      <>
                                        <span>·</span>
                                        <span className="font-mono">
                                          ({obj.coordinates.x}, {obj.coordinates.y})
                                        </span>
                                      </>
                                    )}
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-2 shrink-0">
                                <span
                                  className={`font-mono text-xs font-bold px-2 py-0.5 rounded ${
                                    isObjDone
                                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                      : 'bg-zinc-800 text-zinc-200'
                                  }`}
                                >
                                  {currentCount}/{obj.targetCount}{' '}
                                  {isObjDone ? '• UKOŃCZONO' : ''}
                                </span>

                                {isStageCurrent &&
                                  !isObjDone &&
                                  selectedQuest.playableInCurrentRuntime && (
                                    <button
                                      onClick={() => handleAdvanceObjective(selectedQuest, obj)}
                                      className="px-2.5 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-semibold cursor-pointer"
                                      title="Zarejestruj wykonanie kroku tego celu"
                                    >
                                      +1 Postęp
                                    </button>
                                  )}

                                {obj.coordinates && onJumpToMapLocation && (
                                  <button
                                    onClick={() =>
                                      onJumpToMapLocation(obj.continent, obj.coordinates)
                                    }
                                    className="px-2 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs flex items-center gap-1 cursor-pointer"
                                    title="Pokaż lokalizację celu na mapie kontynentu"
                                  >
                                    <MapPin className="w-3 h-3 text-sky-400" />
                                    Mapa
                                  </button>
                                )}
                              </div>
                            </div>

                            {/* Pasek postępu pojedynczego celu */}
                            <div className="w-full h-1 bg-zinc-800 rounded-full overflow-hidden mt-2">
                              <div
                                className={`h-full transition-all ${
                                  isObjDone ? 'bg-emerald-400' : 'bg-amber-400'
                                }`}
                                style={{ width: `${objPercent}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Powiązane dialogi NPC z katalogu src/game/dialogue */}
          {npcDialogue && (
            <div className="bg-zinc-950/90 border border-zinc-800 rounded-xl p-4 space-y-2.5">
              <div className="text-xs font-bold uppercase tracking-wider text-sky-400 flex items-center gap-1.5">
                <MessageSquare className="w-4 h-4" />
                Wypowiedzi Zleceniodawcy ({selectedQuest.giverName})
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 text-xs">
                <div className="bg-zinc-900/90 border border-zinc-800 rounded-lg p-3 space-y-1">
                  <div className="text-[11px] font-semibold text-amber-300">
                    Przed rozpoczęciem:
                  </div>
                  <p className="text-zinc-300 italic leading-relaxed">
                    „{npcDialogue.before}”
                  </p>
                </div>
                <div className="bg-zinc-900/90 border border-zinc-800 rounded-lg p-3 space-y-1">
                  <div className="text-[11px] font-semibold text-sky-300">W trakcie misji:</div>
                  <p className="text-zinc-300 italic leading-relaxed">
                    „{npcDialogue.during}”
                  </p>
                </div>
                <div className="bg-zinc-900/90 border border-zinc-800 rounded-lg p-3 space-y-1">
                  <div className="text-[11px] font-semibold text-emerald-300">Po ukończeniu:</div>
                  <p className="text-zinc-300 italic leading-relaxed">
                    „{npcDialogue.after}”
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Informacja o ograniczeniach silnika dla zadań międzykontynentalnych oczekujących */}
          {!selectedQuest.playableInCurrentRuntime && selectedQuest.runtimeLimitationNote && (
            <div className="bg-rose-950/30 border border-rose-500/40 rounded-xl p-3.5 flex items-start gap-3 text-xs text-rose-200">
              <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-rose-300">
                  Zadanie oczekujące na przyszły etap silnika
                </div>
                <p className="mt-0.5">{selectedQuest.runtimeLimitationNote}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
