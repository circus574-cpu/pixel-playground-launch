import React, { useState, useEffect } from 'react';
import { Navigation, ActiveTab } from './components/Navigation';
import { HeroExplorer } from './components/HeroExplorer';
import { CharacterRaceEditor } from './components/CharacterRaceEditor';
import { BestiaryExplorer } from './components/BestiaryExplorer';
import { CombatSandbox } from './components/CombatSandbox';
import { WorldAtlas } from './components/WorldAtlas';
import { LoreRules } from './components/LoreRules';
import { WorldV2Explorer } from './components/WorldV2Explorer';
import { HudShowcase } from './components/HudShowcase';
import { PackageDownloadModal } from './components/PackageDownloadModal';
import { HeroRace } from './data/heroes';
import { Monster } from './data/bestiary';
import { loadSaveFromStorage, recordQuestObjectiveEvent, saveToStorage } from './game/quests/engine';
import { PlayerSaveV5 } from './game/quests/types';
import {
  RaceDynamicTheme,
  getActiveUiThemeRaceId,
  getRaceProfile,
  applyRaceThemeToDocument,
} from './game/heroes/raceMetadata';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('world-v2');
  const [selectedHeroId, setSelectedHeroId] = useState<HeroRace['id']>(() => getActiveUiThemeRaceId());
  const [activeRaceTheme, setActiveRaceTheme] = useState<RaceDynamicTheme>(
    () => getRaceProfile(getActiveUiThemeRaceId()).theme
  );
  const [queuedMonster, setQueuedMonster] = useState<Monster | null>(null);
  const [playerSave, setPlayerSave] = useState<PlayerSaveV5>(() => loadSaveFromStorage());
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  useEffect(() => {
    applyRaceThemeToDocument(activeRaceTheme, selectedHeroId);
  }, [activeRaceTheme, selectedHeroId]);

  const handleUpdateSave = (next: PlayerSaveV5) => {
    setPlayerSave(next);
    saveToStorage(next);
  };

  const handleSelectHeroForCombat = (heroId: HeroRace['id']) => {
    setSelectedHeroId(heroId);
    setActiveRaceTheme(getRaceProfile(heroId).theme);
    setActiveTab('combat');
  };

  const handleOpenRaceEditor = (heroId: HeroRace['id']) => {
    setSelectedHeroId(heroId);
    setActiveRaceTheme(getRaceProfile(heroId).theme);
    setActiveTab('race-editor');
  };

  const handleActiveThemeChange = (raceId: HeroRace['id'], theme: RaceDynamicTheme) => {
    setSelectedHeroId(raceId);
    setActiveRaceTheme(theme);
  };

  const handleSpawnMonsterInArena = (monster: Monster) => {
    setQueuedMonster(monster);
    setActiveTab('combat');
  };

  return (
    <div
      className="min-h-screen bg-stone-950 text-stone-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-black"
      style={
        {
          '--race-primary': activeRaceTheme.primaryAccent,
          '--race-secondary': activeRaceTheme.secondaryAccent,
          '--race-glow': activeRaceTheme.auraGlow,
          '--race-surface': activeRaceTheme.surfaceTint,
          '--race-border': activeRaceTheme.borderAccent,
        } as React.CSSProperties
      }
    >
      {/* Navigation */}
      <Navigation
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        activeTheme={activeRaceTheme}
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6">
        {activeTab === 'world-v2' && (
          <WorldV2Explorer
            save={playerSave}
            onUpdateSave={handleUpdateSave}
            onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
          />
        )}

        {activeTab === 'race-editor' && (
          <CharacterRaceEditor
            initialRaceId={selectedHeroId}
            onLaunchCombatWithRace={handleSelectHeroForCombat}
            onActiveThemeChange={handleActiveThemeChange}
          />
        )}

        {activeTab === 'hud-ui' && <HudShowcase />}

        {activeTab === 'combat' && (
          <CombatSandbox
            initialHeroId={selectedHeroId}
            queuedMonster={queuedMonster}
            onClearQueuedMonster={() => setQueuedMonster(null)}
            onMonsterKilledForQuest={(monsterId) => {
              const nextSave = recordQuestObjectiveEvent(playerSave, 'combat', monsterId, 1);
              handleUpdateSave(nextSave);
            }}
          />
        )}

        {activeTab === 'heroes' && (
          <HeroExplorer
            onSelectForCombat={handleSelectHeroForCombat}
            onOpenRaceEditor={handleOpenRaceEditor}
          />
        )}

        {activeTab === 'bestiary' && (
          <BestiaryExplorer onSpawnInArena={handleSpawnMonsterInArena} />
        )}

        {activeTab === 'atlas' && <WorldAtlas />}

        {activeTab === 'lore' && <LoreRules />}
      </main>

      {/* Footer */}
      <footer
        className="border-t bg-stone-950 py-6 text-xs text-stone-500 transition-colors"
        style={{ borderColor: `${activeRaceTheme.primaryAccent}33` }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-stone-300">KI Legends — World V2 & Race Studio</span>
            <span>•</span>
            <span>Gałąź: feature/quests-v2 (Save v5)</span>
            <span>•</span>
            <span style={{ color: activeRaceTheme.primaryAccent }}>
              Motyw UI: {activeRaceTheme.namePl}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-stone-400 font-mono text-[11px]">
            <span>4 Kontynenty</span>
            <span>•</span>
            <span>16 Miast</span>
            <span>•</span>
            <span>16 Sławnych Lokacji</span>
            <span>•</span>
            <span>106 Questów</span>
            <span>•</span>
            <span>40 Potworów Bestiariusza</span>
          </div>
        </div>
      </footer>

      <PackageDownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />
    </div>
  );
}
