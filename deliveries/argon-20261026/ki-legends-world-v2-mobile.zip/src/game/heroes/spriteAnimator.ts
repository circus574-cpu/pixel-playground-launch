import { Direction, HeroRace } from '../../data/heroes';

export type HeroAnimState = 'idle' | 'walk' | 'attack' | 'skill' | 'hit' | 'death';

export const HERO_ANIM_FPS: Record<HeroAnimState, number> = {
  idle: 6,
  walk: 10,
  attack: 12,
  skill: 12,
  hit: 12,
  death: 10,
};

export const HERO_ANIM_FRAMES: Record<HeroAnimState, number> = {
  idle: 8,
  walk: 8,
  attack: 8,
  skill: 8,
  hit: 4,
  death: 8,
};

export interface CleanedSpriteRecord {
  rawImage: HTMLImageElement;
  cleanedCanvas: HTMLCanvasElement;
  bounds: {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
    width: number;
    height: number;
  };
  removedPixelsCount: number;
  defringedPixelsCount: number;
}

const spriteCache = new Map<string, CleanedSpriteRecord>();
const loadingPromises = new Map<string, Promise<CleanedSpriteRecord | null>>();

/**
 * Checks whether a pixel is likely a residual background / matting artifact
 * left over by automated background removal (gray backdrop boxes, floor smudges, white fringes).
 */
function isBackgroundArtifactPixel(
  r: number,
  g: number,
  b: number,
  a: number,
  x: number,
  y: number,
  w: number,
  h: number,
  raceId: HeroRace['id']
): boolean {
  if (a === 0) return true;

  const maxC = Math.max(r, g, b);
  const minC = Math.min(r, g, b);
  const chroma = maxC - minC;
  const luma = 0.299 * r + 0.587 * g + 0.114 * b;
  const normY = y / h;
  const normX = x / w;
  const distFromCenterX = Math.abs(normX - 0.5);

  // Very low alpha noise anywhere
  if (a < 28) return true;

  // Semi-transparent white/light-gray halo around outlines
  if (a < 185 && luma > 185 && chroma < 26) {
    return true;
  }

  // Semi-transparent neutral gray/dark-gray matting residue (common in sage-right, planetary hair, android cape)
  if (a < 215 && chroma < 22 && luma > 28 && luma < 145) {
    return true;
  }

  // Opaque or near-opaque neutral gray studio backdrop remnants connected to exterior (e.g. sage right/up dark box)
  if (chroma < 16 && luma >= 34 && luma <= 96) {
    return true;
  }

  // Race-specific floor/backdrop artifacts
  if (raceId === 'legend') {
    // Legend has semi-transparent gray/red floor smudge at the bottom (y > 0.72) and outer sides
    if (normY > 0.73 && (a < 175 || (luma > 110 && chroma < 45))) {
      return true;
    }
    if (normY > 0.82 && distFromCenterX > 0.26 && a < 230) {
      return true;
    }
  }

  if (raceId === 'sage') {
    // Sage has dark olive-gray rectangle remnants behind sleeves/hair in right & up-left views
    if (chroma < 28 && luma >= 30 && luma <= 88 && (distFromCenterX > 0.18 || normY < 0.65)) {
      return true;
    }
  }

  if (raceId === 'android') {
    // Android has bright grayish-white webbing between cape tails
    if (normY > 0.55 && a < 165 && luma > 150 && chroma < 32) {
      return true;
    }
  }

  return false;
}

/**
 * Cleans the 8-direction master PNG on an offscreen 512x512 canvas:
 * 1. Flood-fills from exterior and transparent regions to strip gray backdrop boxes & floor smudges
 * 2. De-fringes white/gray alpha halos along the silhouette contour
 * 3. Smooths hard bottom cuts (Sage robe) and normalizes feet anchor at [0.5, 0.92]
 */
export function cleanHeroMasterSprite(
  img: HTMLImageElement,
  raceId: HeroRace['id']
): CleanedSpriteRecord {
  const targetSize = 512;
  const workCanvas = document.createElement('canvas');
  workCanvas.width = targetSize;
  workCanvas.height = targetSize;
  const workCtx = workCanvas.getContext('2d', { willReadFrequently: true });

  if (!workCtx) {
    return {
      rawImage: img,
      cleanedCanvas: workCanvas,
      bounds: { minX: 64, minY: 32, maxX: 448, maxY: 480, width: 384, height: 448 },
      removedPixelsCount: 0,
      defringedPixelsCount: 0,
    };
  }

  workCtx.clearRect(0, 0, targetSize, targetSize);
  workCtx.drawImage(img, 0, 0, targetSize, targetSize);

  const imgData = workCtx.getImageData(0, 0, targetSize, targetSize);
  const data = imgData.data;
  const totalPixels = targetSize * targetSize;
  const visited = new Uint8Array(totalPixels);
  const queue = new Int32Array(totalPixels);
  let qHead = 0;
  let qTail = 0;

  // Seed flood-fill with all border pixels and all nearly-transparent pixels
  for (let y = 0; y < targetSize; y++) {
    for (let x = 0; x < targetSize; x++) {
      const idx = y * targetSize + x;
      const a = data[idx * 4 + 3];
      const isBorder = x === 0 || y === 0 || x === targetSize - 1 || y === targetSize - 1;
      if (a < 18 || isBorder) {
        visited[idx] = 1;
        queue[qTail++] = idx;
      }
    }
  }

  let removedPixelsCount = 0;
  const dirs = [-1, 1, -targetSize, targetSize, -targetSize - 1, -targetSize + 1, targetSize - 1, targetSize + 1];

  // BFS flood-fill from outside inward to strip connected background remnants & floor smudges
  while (qHead < qTail) {
    const curr = queue[qHead++];
    const cx = curr % targetSize;
    const cy = (curr / targetSize) | 0;

    const pIdx = curr * 4;
    if (data[pIdx + 3] > 0) {
      data[pIdx + 3] = 0;
      removedPixelsCount++;
    }

    for (let d = 0; d < 8; d++) {
      const next = curr + dirs[d];
      if (next < 0 || next >= totalPixels || visited[next]) continue;
      const nx = next % targetSize;
      if (Math.abs(nx - cx) > 1) continue;
      const ny = (next / targetSize) | 0;

      const np = next * 4;
      const r = data[np];
      const g = data[np + 1];
      const b = data[np + 2];
      const a = data[np + 3];

      if (isBackgroundArtifactPixel(r, g, b, a, nx, ny, targetSize, targetSize, raceId)) {
        visited[next] = 1;
        queue[qTail++] = next;
      }
    }
  }

  // Pass 2: Edge de-fringing (2-pixel contour pass to remove white/gray matting halo)
  let defringedPixelsCount = 0;
  const alphaCopy = new Uint8ClampedArray(totalPixels);
  for (let i = 0; i < totalPixels; i++) {
    alphaCopy[i] = data[i * 4 + 3];
  }

  for (let y = 2; y < targetSize - 2; y++) {
    for (let x = 2; x < targetSize - 2; x++) {
      const idx = y * targetSize + x;
      const a = alphaCopy[idx];
      if (a === 0) continue;

      // Check if adjacent to transparent pixel
      const hasZeroNeighbor =
        alphaCopy[idx - 1] === 0 ||
        alphaCopy[idx + 1] === 0 ||
        alphaCopy[idx - targetSize] === 0 ||
        alphaCopy[idx + targetSize] === 0;

      const hasNearZeroNeighbor =
        hasZeroNeighbor ||
        alphaCopy[idx - 2] === 0 ||
        alphaCopy[idx + 2] === 0 ||
        alphaCopy[idx - targetSize * 2] === 0 ||
        alphaCopy[idx + targetSize * 2] === 0;

      if (!hasNearZeroNeighbor) continue;

      const p = idx * 4;
      const r = data[p];
      const g = data[p + 1];
      const b = data[p + 2];
      const maxC = Math.max(r, g, b);
      const minC = Math.min(r, g, b);
      const chroma = maxC - minC;
      const luma = 0.299 * r + 0.587 * g + 0.114 * b;

      // If contour pixel has low saturation and bright/gray fringe, erode or recolor from interior
      if ((luma > 175 && chroma < 38) || (a < 190 && chroma < 24)) {
        if (hasZeroNeighbor && a < 150) {
          data[p + 3] = 0;
          defringedPixelsCount++;
        } else {
          // Pull RGB from the nearest opaque interior pixel within a 3x3 window
          let bestA = 0;
          let bestR = r;
          let bestG = g;
          let bestB = b;
          for (let dy = -2; dy <= 2; dy++) {
            for (let dx = -2; dx <= 2; dx++) {
              const nIdx = (y + dy) * targetSize + (x + dx);
              const na = alphaCopy[nIdx];
              const np = nIdx * 4;
              const nChroma =
                Math.max(data[np], data[np + 1], data[np + 2]) -
                Math.min(data[np], data[np + 1], data[np + 2]);
              if (na > 220 && nChroma > chroma && na > bestA) {
                bestA = na;
                bestR = data[np];
                bestG = data[np + 1];
                bestB = data[np + 2];
              }
            }
          }
          data[p] = bestR;
          data[p + 1] = bestG;
          data[p + 2] = bestB;
          data[p + 3] = Math.min(a, (a * 0.72) | 0);
          defringedPixelsCount++;
        }
      }
    }
  }

  // Pass 3: Compute clean opaque bounding box
  let minX = targetSize;
  let minY = targetSize;
  let maxX = 0;
  let maxY = 0;

  for (let y = 0; y < targetSize; y++) {
    for (let x = 0; x < targetSize; x++) {
      const a = data[(y * targetSize + x) * 4 + 3];
      if (a > 35) {
        if (x < minX) minX = x;
        if (x > maxY) {
          // keep separate
        }
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }

  if (minX >= maxX || minY >= maxY) {
    minX = 64;
    minY = 32;
    maxX = 448;
    maxY = 480;
  }

  // Soften flat-cut bottom edge on Sage robes (stage3-render-contract: no-cut-feet)
  if (raceId === 'sage' && maxY >= targetSize - 6) {
    for (let y = maxY - 10; y <= maxY; y++) {
      if (y < 0 || y >= targetSize) continue;
      for (let x = minX; x <= maxX; x++) {
        const normX = (x - (minX + maxX) / 2) / Math.max(1, (maxX - minX) / 2);
        // Rounded hem curve so robe bottom is naturally arched instead of flat-cropped
        const curveOffset = Math.round(normX * normX * 7);
        const distFromBottom = maxY - curveOffset - y;
        const p = (y * targetSize + x) * 4;
        if (distFromBottom < 0) {
          data[p + 3] = 0;
        } else if (distFromBottom < 5 && data[p + 3] > 0) {
          data[p + 3] = Math.round(data[p + 3] * (distFromBottom / 5));
        }
      }
    }
  }

  workCtx.putImageData(imgData, 0, 0);

  // Pass 4: Normalize character placement onto calibrated 512x512 output canvas
  // Target feet anchor: [0.5, 0.91] (y = 466px), target height ~ 410px
  const outCanvas = document.createElement('canvas');
  outCanvas.width = targetSize;
  outCanvas.height = targetSize;
  const outCtx = outCanvas.getContext('2d');

  const rawW = Math.max(1, maxX - minX + 1);
  const rawH = Math.max(1, maxY - minY + 1);
  const desiredHeight = 408;
  const scale = Math.min(desiredHeight / rawH, 410 / rawW);

  const dstW = rawW * scale;
  const dstH = rawH * scale;
  const dstX = (targetSize - dstW) / 2;
  const dstY = 468 - dstH; // Feet anchored consistently at y = 468

  if (outCtx) {
    outCtx.imageSmoothingEnabled = true;
    outCtx.imageSmoothingQuality = 'high';
    outCtx.drawImage(workCanvas, minX, minY, rawW, rawH, dstX, dstY, dstW, dstH);
  }

  return {
    rawImage: img,
    cleanedCanvas: outCanvas,
    bounds: {
      minX: Math.round(dstX),
      minY: Math.round(dstY),
      maxX: Math.round(dstX + dstW),
      maxY: Math.round(dstY + dstH),
      width: Math.round(dstW),
      height: Math.round(dstH),
    },
    removedPixelsCount,
    defringedPixelsCount,
  };
}

/**
 * Loads and caches a cleaned master sprite for a given hero and direction.
 */
export function ensureCleanedHeroSprite(
  race: HeroRace,
  direction: Direction
): Promise<CleanedSpriteRecord | null> {
  const key = `${race.id}:${direction}`;
  const cached = spriteCache.get(key);
  if (cached) return Promise.resolve(cached);

  const existingPromise = loadingPromises.get(key);
  if (existingPromise) return existingPromise;

  const src = race.views[direction];
  const promise = new Promise<CleanedSpriteRecord | null>((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const cleaned = cleanHeroMasterSprite(img, race.id);
      spriteCache.set(key, cleaned);
      loadingPromises.delete(key);
      resolve(cleaned);
    };
    img.onerror = () => {
      loadingPromises.delete(key);
      resolve(null);
    };
    img.src = src;
  });

  loadingPromises.set(key, promise);
  return promise;
}

export function getCachedCleanedHeroSprite(
  raceId: HeroRace['id'],
  direction: Direction
): CleanedSpriteRecord | undefined {
  return spriteCache.get(`${raceId}:${direction}`);
}

/**
 * Direction unit vector helper for directional lunges, stride, and slash VFX.
 */
function getDirectionVector(direction: Direction): { dx: number; dy: number; angle: number } {
  switch (direction) {
    case 'right':
      return { dx: 1, dy: 0, angle: 0 };
    case 'down-right':
      return { dx: 0.707, dy: 0.707, angle: Math.PI / 4 };
    case 'down':
      return { dx: 0, dy: 1, angle: Math.PI / 2 };
    case 'down-left':
      return { dx: -0.707, dy: 0.707, angle: (3 * Math.PI) / 4 };
    case 'left':
      return { dx: -1, dy: 0, angle: Math.PI };
    case 'up-left':
      return { dx: -0.707, dy: -0.707, angle: -(3 * Math.PI) / 4 };
    case 'up':
      return { dx: 0, dy: -1, angle: -Math.PI / 2 };
    case 'up-right':
      return { dx: 0.707, dy: -0.707, angle: -Math.PI / 4 };
  }
}

export interface RenderHeroCustomization {
  scaleMultiplier?: number;
  feetAnchorY?: number;
  collisionRadiusUnits?: number;
  hueShiftDeg?: number;
  saturationPct?: number;
  brightnessPct?: number;
  contrastPct?: number;
  strideAmplitude?: number;
  clothWaveIntensity?: number;
  attackLungeDistance?: number;
  skillLevitationHeight?: number;
  breathingDepth?: number;
  auraIntensity?: number;
  auraColorOverride?: string;
  secondaryGlowOverride?: string;
  showFeetAnchor?: boolean;
  showCollisionCircle?: boolean;
}

export interface RenderHeroOptions {
  state: HeroAnimState;
  /** Normalized progress within the animation loop [0..1) or discrete frame index */
  frameIndex: number;
  /** Smooth sub-frame phase [0..1) for 60fps interpolation */
  subFrame?: number;
  /** Whether to use the cleaned sprite (true) or raw uncleaned image (false) */
  useCleanedSprite?: boolean;
  /** Whether to render the separate race Ki aura & combat VFX layer */
  showAura?: boolean;
  /** Optional appearance, rig, and theme customization from CharacterRaceEditor */
  customization?: RenderHeroCustomization;
}

/**
 * Renders a single animated frame of a HeroRace in any of the 8 directions and 6 states
 * onto the target 2D canvas context centered at (cx, footY) with target height `drawSize`.
 *
 * Uses 2D Anatomical Mesh Slicing + Left/Right Limb Articulation + Separate Ki Aura Layer:
 * - Upper Head & Hair (0.00 - 0.24)
 * - Torso, Shoulders & Arms (0.22 - 0.56)
 * - Waist, Sash & Robe/Cape (0.52 - 0.72)
 * - Left Leg & Right Leg independent stride/stance rigs (0.68 - 1.00)
 */
export function renderAnimatedHero(
  ctx: CanvasRenderingContext2D,
  race: HeroRace,
  direction: Direction,
  cx: number,
  footY: number,
  drawSize: number,
  options: RenderHeroOptions
): void {
  const {
    state,
    frameIndex,
    subFrame = 0,
    useCleanedSprite = true,
    showAura = true,
    customization,
  } = options;

  const scaleMultiplier = customization?.scaleMultiplier ?? 1.0;
  const feetAnchorY = customization?.feetAnchorY ?? 0.91;
  const collisionRadiusUnits = customization?.collisionRadiusUnits ?? 12;
  const hueShiftDeg = customization?.hueShiftDeg ?? 0;
  const saturationPct = customization?.saturationPct ?? 100;
  const brightnessPct = customization?.brightnessPct ?? 100;
  const contrastPct = customization?.contrastPct ?? 100;
  const strideAmplitude = customization?.strideAmplitude ?? 1.0;
  const clothWaveIntensity = customization?.clothWaveIntensity ?? 1.0;
  const attackLungeDistance = customization?.attackLungeDistance ?? 1.0;
  const skillLevitationHeight = customization?.skillLevitationHeight ?? 1.0;
  const breathingDepth = customization?.breathingDepth ?? 1.0;
  const auraIntensity = customization?.auraIntensity ?? 1.0;
  const auraColor = customization?.auraColorOverride || race.accentColor;
  const secondaryGlow = customization?.secondaryGlowOverride || '#ffffff';
  const showFeetAnchor = customization?.showFeetAnchor ?? false;
  const showCollisionCircle = customization?.showCollisionCircle ?? false;

  const effectiveDrawSize = drawSize * scaleMultiplier;
  const totalFrames = HERO_ANIM_FRAMES[state];
  const continuousFrame = (frameIndex % totalFrames) + subFrame;
  const phase = (continuousFrame / totalFrames) * Math.PI * 2;
  const progress = Math.min(1, continuousFrame / Math.max(1, totalFrames - 0.001));
  const { dx: dirX, dy: dirY, angle: dirAngle } = getDirectionVector(direction);

  const record = getCachedCleanedHeroSprite(race.id, direction);
  if (!record) {
    ensureCleanedHeroSprite(race, direction);
    return;
  }

  const sourceImage: CanvasImageSource = useCleanedSprite ? record.cleanedCanvas : record.rawImage;
  const srcW = useCleanedSprite ? 512 : record.rawImage.naturalWidth || 512;
  const srcH = useCleanedSprite ? 512 : record.rawImage.naturalHeight || 512;

  // Compute kinematic articulation parameters per state
  let bodyBobY = 0;
  let bodyShiftX = 0;
  let bodyShiftY = 0;
  let torsoTilt = 0;
  let torsoScaleX = 1;
  let torsoScaleY = 1;
  let headBobY = 0;
  let headTilt = 0;
  let clothWaveAmp = 2.5;
  let leftLegLiftY = 0;
  let rightLegLiftY = 0;
  let leftLegShiftX = 0;
  let rightLegShiftX = 0;
  let leftLegRot = 0;
  let rightLegRot = 0;
  let hitFlashAlpha = 0;
  let globalAlpha = 1;

  const scaleFactor = effectiveDrawSize / 512;

  if (state === 'idle') {
    // Deep martial breathing + gentle cape/robe sway
    const breath = Math.sin(phase) * breathingDepth;
    bodyBobY = breath * 4.5 * scaleFactor;
    torsoScaleX = 1 + breath * 0.022;
    torsoScaleY = 1 - breath * 0.015;
    headBobY = Math.sin(phase - 0.5) * 3.0 * breathingDepth * scaleFactor;
    clothWaveAmp = 4.5 * clothWaveIntensity * scaleFactor;
  } else if (state === 'walk') {
    // 8-frame full stride cycle: 2 vertical bounces per full left+right step cycle
    const stride = Math.sin(phase) * strideAmplitude;
    const bounce = Math.abs(Math.cos(phase)) * strideAmplitude;
    bodyBobY = -bounce * 9.5 * scaleFactor;
    bodyShiftX = dirX * Math.sin(phase * 2) * 3.5 * strideAmplitude * scaleFactor;
    torsoTilt = (dirX !== 0 ? dirX * 0.065 : stride * 0.045) + stride * 0.04;
    torsoScaleX = 1 + stride * 0.035;
    headBobY = -bounce * 6.0 * scaleFactor;
    headTilt = -stride * 0.035;
    clothWaveAmp = 8.5 * clothWaveIntensity * scaleFactor;

    // Alternating left & right leg articulation
    const leftStep = Math.sin(phase) * strideAmplitude;
    const rightStep = Math.sin(phase + Math.PI) * strideAmplitude;

    leftLegLiftY = Math.min(0, leftStep) * 22 * scaleFactor;
    rightLegLiftY = Math.min(0, rightStep) * 22 * scaleFactor;

    // Horizontal stride displacement works in both frontal and side/diagonal views
    const lateralStride = Math.abs(dirX) > 0.3 ? dirX : 0.65;
    leftLegShiftX = leftStep * 15 * lateralStride * scaleFactor;
    rightLegShiftX = rightStep * 15 * lateralStride * scaleFactor;

    leftLegRot = leftStep * 0.16;
    rightLegRot = rightStep * 0.16;
  } else if (state === 'attack') {
    // Wind-up (0..0.25) -> Explosive strike lunge (0.25..0.6) -> Recovery (0.6..1.0)
    let lunge = 0;
    if (progress < 0.25) {
      const t = progress / 0.25;
      lunge = -0.35 * Math.sin((t * Math.PI) / 2);
    } else if (progress < 0.62) {
      const t = (progress - 0.25) / 0.37;
      lunge = -0.35 + 1.35 * Math.sin((t * Math.PI) / 2);
    } else {
      const t = (progress - 0.62) / 0.38;
      lunge = 1.0 * (1 - t);
    }
    lunge *= attackLungeDistance;

    bodyShiftX = dirX * lunge * 28 * scaleFactor;
    bodyShiftY = dirY * lunge * 18 * scaleFactor - Math.max(0, lunge) * 6 * scaleFactor;
    torsoTilt = (dirX !== 0 ? dirX : 0.6) * lunge * 0.18;
    torsoScaleX = 1 + Math.max(0, lunge) * 0.08;
    torsoScaleY = 1 - Math.max(0, lunge) * 0.04;
    headTilt = torsoTilt * 0.6;
    clothWaveAmp = 12 * clothWaveIntensity * scaleFactor;

    // Wide martial combat stance during strike
    leftLegShiftX = -Math.abs(lunge) * 10 * scaleFactor + dirX * lunge * 8 * scaleFactor;
    rightLegShiftX = Math.abs(lunge) * 12 * scaleFactor + dirX * lunge * 14 * scaleFactor;
    rightLegLiftY = -Math.max(0, lunge) * 10 * scaleFactor;
  } else if (state === 'skill') {
    // Ki channeling levitation + power surge release around frame 4-5
    const surge = Math.sin(progress * Math.PI) * skillLevitationHeight;
    const pulse = Math.sin(phase * 2);
    bodyBobY = -surge * 18 * scaleFactor + pulse * 3 * scaleFactor;
    torsoScaleX = 1 + surge * 0.075;
    torsoScaleY = 1 + surge * 0.045;
    headBobY = -surge * 6 * scaleFactor;
    clothWaveAmp = 14 * clothWaveIntensity * scaleFactor;
    leftLegLiftY = -surge * 8 * scaleFactor;
    rightLegLiftY = -surge * 12 * scaleFactor;
    leftLegShiftX = -surge * 6 * scaleFactor;
    rightLegShiftX = surge * 6 * scaleFactor;
  } else if (state === 'hit') {
    // Sharp recoil away from facing direction + hit flash
    const recoil = Math.sin(progress * Math.PI);
    bodyShiftX = -dirX * recoil * 22 * scaleFactor;
    bodyShiftY = -dirY * recoil * 12 * scaleFactor;
    torsoTilt = -(dirX !== 0 ? dirX : 0.7) * recoil * 0.22;
    headTilt = torsoTilt * 1.3;
    leftLegLiftY = -recoil * 8 * scaleFactor;
    hitFlashAlpha = recoil * 0.65;
  } else if (state === 'death') {
    // Progressive collapse to ground
    const collapse = Math.min(1, Math.pow(progress, 1.15));
    bodyShiftX = -dirX * collapse * 18 * scaleFactor;
    bodyBobY = collapse * 64 * scaleFactor;
    torsoTilt = (dirX >= 0 ? 1 : -1) * collapse * 1.28; // ~73 deg fall
    torsoScaleY = 1 - collapse * 0.25;
    leftLegLiftY = -collapse * 18 * scaleFactor;
    rightLegLiftY = -collapse * 12 * scaleFactor;
    globalAlpha = 1 - Math.max(0, (progress - 0.75) * 2.2);
  }

  ctx.save();
  ctx.globalAlpha = Math.max(0.15, globalAlpha);

  // 1. Ground Contact Shadow (scales with levitation/jump height)
  const shadowScale = Math.max(0.55, 1 - Math.abs(bodyBobY) / (effectiveDrawSize * 0.35));
  ctx.save();
  ctx.fillStyle = 'rgba(0, 0, 0, 0.52)';
  ctx.beginPath();
  ctx.ellipse(
    cx + bodyShiftX * 0.6,
    footY - 4 * scaleFactor,
    58 * scaleFactor * shadowScale,
    18 * scaleFactor * shadowScale,
    0,
    0,
    Math.PI * 2
  );
  ctx.fill();
  ctx.restore();

  // Optional Stage 3 Collision Radius World Units Circle overlay (collision-independent-from-art)
  if (showCollisionCircle) {
    ctx.save();
    const radiusPx = (collisionRadiusUnits / 12) * 56 * scaleFactor;
    ctx.strokeStyle = auraColor;
    ctx.fillStyle = auraColor;
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 4]);
    ctx.globalAlpha = 0.75;
    ctx.beginPath();
    ctx.ellipse(cx, footY - 2, radiusPx, radiusPx * 0.38, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 0.14;
    ctx.fill();
    ctx.restore();
  }

  // 2. Back Aura Layer (separate from character body per stage3-render-contract: auraSeparate: true)
  if (showAura && state !== 'death' && auraIntensity > 0.02) {
    renderHeroBackAura(
      ctx,
      race,
      cx + bodyShiftX,
      footY - 42 * scaleFactor + bodyShiftY,
      effectiveDrawSize,
      state,
      phase,
      progress,
      auraColor,
      auraIntensity
    );
  }

  // Destination character box centered at (cx + bodyShiftX, footY + bodyBobY + bodyShiftY)
  const anchorPixel512 = Math.round(feetAnchorY * 512);
  const charCenterX = cx + bodyShiftX;
  const charFootY = footY + bodyBobY + bodyShiftY;
  const dstTopY = charFootY - anchorPixel512 * scaleFactor;

  // Apply color grading filters if customized
  const hasColorFilter =
    hueShiftDeg !== 0 || saturationPct !== 100 || brightnessPct !== 100 || contrastPct !== 100;
  if (hasColorFilter && typeof ctx.filter === 'string') {
    ctx.filter = `hue-rotate(${hueShiftDeg}deg) saturate(${saturationPct}%) brightness(${brightnessPct}%) contrast(${contrastPct}%)`;
  }

  // Define normalized vertical zones in the 512x512 master canvas
  const headY0 = 0;
  const headY1 = 158;
  const torsoY0 = 150;
  const torsoY1 = 290;
  const waistY0 = 282;
  const waistY1 = 356;
  const legsY0 = 348;
  const legsY1 = 500;

  // 3A. Draw Left & Right Legs (independent left/right articulation for real walking/combat steps!)
  const legsSrcY = (legsY0 / 512) * srcH;
  const legsSrcH = ((legsY1 - legsY0) / 512) * srcH;
  const legsDstY = dstTopY + legsY0 * scaleFactor;
  const legsDstH = (legsY1 - legsY0) * scaleFactor;

  // Left Leg (x: 0..256)
  ctx.save();
  const leftHipX = charCenterX - 38 * scaleFactor + leftLegShiftX;
  const leftHipY = legsDstY + leftLegLiftY;
  ctx.translate(leftHipX, leftHipY);
  ctx.rotate(leftLegRot + torsoTilt * 0.35);
  ctx.drawImage(
    sourceImage,
    0,
    legsSrcY,
    srcW * 0.52,
    legsSrcH,
    -256 * scaleFactor + 38 * scaleFactor,
    0,
    256 * 1.04 * scaleFactor,
    legsDstH
  );
  ctx.restore();

  // Right Leg (x: 256..512)
  ctx.save();
  const rightHipX = charCenterX + 38 * scaleFactor + rightLegShiftX;
  const rightHipY = legsDstY + rightLegLiftY;
  ctx.translate(rightHipX, rightHipY);
  ctx.rotate(rightLegRot + torsoTilt * 0.35);
  ctx.drawImage(
    sourceImage,
    srcW * 0.48,
    legsSrcY,
    srcW * 0.52,
    legsSrcH,
    -38 * scaleFactor - 256 * 0.04 * scaleFactor,
    0,
    256 * 1.04 * scaleFactor,
    legsDstH
  );
  ctx.restore();

  // 3B. Draw Waist / Robe / Cape Mid-Section with cloth wave strips
  const clothStrips = 4;
  const stripHeight512 = (waistY1 - waistY0) / clothStrips;
  for (let s = 0; s < clothStrips; s++) {
    const sy512 = waistY0 + s * stripHeight512;
    const waveX = Math.sin(phase * 1.5 - s * 0.9) * clothWaveAmp * ((s + 1) / clothStrips);
    ctx.save();
    ctx.translate(charCenterX + waveX, dstTopY + sy512 * scaleFactor);
    ctx.rotate(torsoTilt * 0.65);
    ctx.scale(torsoScaleX, 1);
    ctx.drawImage(
      sourceImage,
      0,
      (sy512 / 512) * srcH,
      srcW,
      ((stripHeight512 + 3) / 512) * srcH,
      -256 * scaleFactor,
      0,
      512 * scaleFactor,
      (stripHeight512 + 3) * scaleFactor
    );
    ctx.restore();
  }

  // 3C. Draw Torso, Shoulders & Arms
  ctx.save();
  const torsoPivotY = dstTopY + ((torsoY0 + torsoY1) * 0.5) * scaleFactor;
  ctx.translate(charCenterX, torsoPivotY);
  ctx.rotate(torsoTilt);
  ctx.scale(torsoScaleX, torsoScaleY);
  ctx.drawImage(
    sourceImage,
    0,
    (torsoY0 / 512) * srcH,
    srcW,
    ((torsoY1 - torsoY0 + 6) / 512) * srcH,
    -256 * scaleFactor,
    -((torsoY1 - torsoY0) * 0.5) * scaleFactor,
    512 * scaleFactor,
    (torsoY1 - torsoY0 + 6) * scaleFactor
  );
  ctx.restore();

  // 3D. Draw Head, Hair & Upper Scarf
  ctx.save();
  const headPivotY = dstTopY + headY1 * scaleFactor + headBobY;
  ctx.translate(charCenterX + Math.sin(torsoTilt) * 14 * scaleFactor, headPivotY);
  ctx.rotate(torsoTilt * 0.75 + headTilt);
  ctx.drawImage(
    sourceImage,
    0,
    (headY0 / 512) * srcH,
    srcW,
    ((headY1 - headY0 + 6) / 512) * srcH,
    -256 * scaleFactor,
    -(headY1 - headY0) * scaleFactor,
    512 * scaleFactor,
    (headY1 - headY0 + 6) * scaleFactor
  );
  ctx.restore();

  if (hasColorFilter && typeof ctx.filter === 'string') {
    ctx.filter = 'none';
  }

  // 4. Hit Recoil Flash Overlay
  if (hitFlashAlpha > 0.05) {
    ctx.save();
    ctx.globalAlpha = hitFlashAlpha * 0.45;
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(charCenterX, charFootY - 190 * scaleFactor, 95 * scaleFactor, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // 5. Foreground Combat & Skill VFX (Attack Slashes, Ki Bursts, Runes)
  if (showAura && (state === 'attack' || state === 'skill') && auraIntensity > 0.02) {
    renderHeroForegroundVfx(
      ctx,
      charCenterX,
      charFootY - 175 * scaleFactor,
      effectiveDrawSize,
      state,
      dirAngle,
      progress,
      auraColor,
      secondaryGlow,
      auraIntensity
    );
  }

  // 6. Optional Feet Anchor Crosshair Overlay ([0.5, feetAnchorY] calibration marker)
  if (showFeetAnchor) {
    ctx.save();
    ctx.strokeStyle = '#10b981';
    ctx.fillStyle = '#10b981';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(cx - 24, footY);
    ctx.lineTo(cx + 24, footY);
    ctx.moveTo(cx, footY - 14);
    ctx.lineTo(cx, footY + 14);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx, footY, 3.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.font = '10px monospace';
    ctx.fillText(`anchor [0.5, ${feetAnchorY.toFixed(2)}]`, cx + 8, footY - 6);
    ctx.restore();
  }

  ctx.restore();
}

/**
 * Renders the race-specific ground seal and rising Ki aura behind the character.
 */
function renderHeroBackAura(
  ctx: CanvasRenderingContext2D,
  race: HeroRace,
  cx: number,
  groundY: number,
  drawSize: number,
  state: HeroAnimState,
  phase: number,
  progress: number,
  auraColor: string,
  auraIntensity: number
): void {
  const s = drawSize / 512;
  const baseIntensity = state === 'skill' ? 1.0 : state === 'attack' ? 0.75 : 0.42;
  const intensity = Math.min(1.6, baseIntensity * auraIntensity);

  ctx.save();
  ctx.strokeStyle = auraColor;
  ctx.fillStyle = auraColor;

  // Ground energy ring / seal
  ctx.save();
  ctx.translate(cx, groundY + 34 * s);
  ctx.scale(1, 0.36);
  ctx.rotate(phase * (state === 'skill' ? 1.5 : 0.5));
  ctx.globalAlpha = Math.min(1, (0.28 + intensity * 0.38) * auraIntensity);
  ctx.lineWidth = (state === 'skill' ? 5 : 3) * s;

  ctx.beginPath();
  const ringRadius = (state === 'skill' ? 105 + Math.sin(progress * Math.PI) * 35 : 74) * s;
  ctx.arc(0, 0, ringRadius, 0, Math.PI * 2);
  ctx.stroke();

  if (race.id === 'sage' || state === 'skill') {
    // Inner geometric seal for Sage or during any race's Skill cast
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const rx = Math.cos(a) * ringRadius * 0.78;
      const ry = Math.sin(a) * ringRadius * 0.78;
      if (i === 0) ctx.moveTo(rx, ry);
      else ctx.lineTo(rx, ry);
    }
    ctx.closePath();
    ctx.stroke();
  }
  ctx.restore();

  // Rising Ki particles / flame wisps
  const particleCount = state === 'skill' ? 8 : 4;
  for (let i = 0; i < particleCount; i++) {
    const pPhase = (phase + i * 1.57) % (Math.PI * 2);
    const normP = pPhase / (Math.PI * 2);
    const px = cx + Math.sin(i * 2.3 + phase) * (58 + i * 8) * s;
    const py = groundY + 20 * s - normP * 260 * s;
    const pRadius = (1 - normP) * (state === 'skill' ? 9 : 5.5) * s;

    ctx.globalAlpha = Math.min(1, (1 - normP) * (0.35 + intensity * 0.45));
    ctx.beginPath();
    ctx.arc(px, py, Math.max(1, pRadius), 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

/**
 * Renders directional weapon/martial slash arcs on `attack` and Ki shockwaves on `skill`.
 */
function renderHeroForegroundVfx(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  drawSize: number,
  state: HeroAnimState,
  dirAngle: number,
  progress: number,
  auraColor: string,
  secondaryGlow: string,
  auraIntensity: number
): void {
  const s = drawSize / 512;

  ctx.save();
  if (state === 'attack' && progress >= 0.22 && progress <= 0.75) {
    const slashProgress = (progress - 0.22) / 0.53;
    const alpha = Math.sin(slashProgress * Math.PI) * Math.min(1.3, auraIntensity);

    ctx.translate(cx, cy);
    ctx.rotate(dirAngle);
    ctx.globalAlpha = Math.min(1, alpha * 0.9);
    ctx.strokeStyle = auraColor;
    ctx.shadowColor = auraColor;
    ctx.shadowBlur = 16 * s;
    ctx.lineWidth = 14 * s * alpha;
    ctx.lineCap = 'round';

    const arcRadius = (95 + slashProgress * 45) * s;
    const startAngle = -1.05 + slashProgress * 0.6;
    const endAngle = 0.65 + slashProgress * 0.7;

    ctx.beginPath();
    ctx.arc(18 * s, 0, arcRadius, startAngle, endAngle);
    ctx.stroke();

    // Inner bright core arc
    ctx.strokeStyle = secondaryGlow;
    ctx.lineWidth = 5 * s * alpha;
    ctx.beginPath();
    ctx.arc(22 * s, 0, arcRadius * 0.96, startAngle + 0.1, endAngle - 0.1);
    ctx.stroke();
  } else if (state === 'skill') {
    const burst = Math.sin(progress * Math.PI) * Math.min(1.3, auraIntensity);
    ctx.translate(cx, cy);
    ctx.globalAlpha = Math.min(1, burst * 0.75);
    ctx.strokeStyle = auraColor;
    ctx.shadowColor = auraColor;
    ctx.shadowBlur = 22 * s;
    ctx.lineWidth = 8 * s * burst;

    const r = (60 + progress * 130) * s;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}
