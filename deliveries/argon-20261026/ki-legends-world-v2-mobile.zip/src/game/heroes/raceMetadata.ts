import { Direction, HERO_RACES, HeroRace } from '../../data/heroes';
import { HeroAnimState, HERO_ANIM_FPS, HERO_ANIM_FRAMES } from './spriteAnimator';

export interface ProvenancePaintedView {
  file: string;
  direction: Direction;
  source_png_sha256: string;
  sha256: string;
}

export interface ProvenanceMasterFile {
  file: string;
  sha256: string;
}

export interface RaceProvenanceMetadata {
  hero: HeroRace['id'];
  pack_id: string;
  world: string;
  owner_status: string;
  method: string;
  identity_candidate: string;
  identity_sha256: string;
  painted_views_seed: number;
  views_source: string;
  painted_views: ProvenancePaintedView[];
  masters: ProvenanceMasterFile[];
  pack_manifest_sha256: string;
  frames_tarball_on_volume: string;
  tools: {
    checkpoint: string;
    diffusers: string;
    torch: string;
    rembg_model: string;
    controlnet: string;
    ip_adapter: string;
  };
  render: {
    KI_SAFE: number;
    clips: string;
  };
  rights: string;
}

export interface Stage3RenderContract {
  version: number;
  status: string;
  projection: string;
  camera: {
    azimuthDegrees: number;
    elevationDegrees: number;
    rollDegrees: number;
    lockedForAllAssets: boolean;
  };
  lighting: {
    key: string;
    bakedContactShadow: boolean;
    auraSeparate: boolean;
  };
  character: {
    sourceFrame: [number, number];
    runtimeCurrentWorldSize: [number, number];
    futureWorldHeightTrials: number[];
    feetAnchor: [number, number];
    collisionRadiusWorldUnits: number;
    directions: Direction[];
    states: Record<string, number>;
    fps: Record<string, number>;
    namePattern: string;
    firstDelivery: string;
  };
  validation: string[];
}

export interface RaceDynamicTheme {
  id: string;
  namePl: string;
  primaryAccent: string;
  secondaryAccent: string;
  auraGlow: string;
  surfaceTint: string;
  borderAccent: string;
  hpBarColor: string;
  kiBarColor: string;
}

export interface RaceVisualRigConfig {
  // Appearance & Calibration
  useCleanedSprite: boolean;
  showAura: boolean;
  showFeetAnchor: boolean;
  showCollisionCircle: boolean;
  scaleMultiplier: number;
  worldHeightTrialPx: number;
  feetAnchorY: number;
  collisionRadiusUnits: number;
  hueShiftDeg: number;
  saturationPct: number;
  brightnessPct: number;
  contrastPct: number;
  // Animation Rig & Kinematics
  fpsMultiplier: number;
  strideAmplitude: number;
  clothWaveIntensity: number;
  attackLungeDistance: number;
  skillLevitationHeight: number;
  breathingDepth: number;
  auraIntensity: number;
}

export interface RaceEditorProfile {
  raceId: HeroRace['id'];
  theme: RaceDynamicTheme;
  rig: RaceVisualRigConfig;
  updatedAt: string;
}

export const CANONICAL_STAGE3_CONTRACT: Stage3RenderContract = {
  version: 1,
  status: 'specification-only-no-gpu-job-started',
  projection: 'orthographic-top-down-with-visible-south-facade',
  camera: {
    azimuthDegrees: 0,
    elevationDegrees: 60,
    rollDegrees: 0,
    lockedForAllAssets: true,
  },
  lighting: {
    key: 'north-west',
    bakedContactShadow: false,
    auraSeparate: true,
  },
  character: {
    sourceFrame: [512, 512],
    runtimeCurrentWorldSize: [96, 96],
    futureWorldHeightTrials: [128, 144, 160],
    feetAnchor: [0.5, 0.91],
    collisionRadiusWorldUnits: 12,
    directions: ['down', 'down-left', 'left', 'up-left', 'up', 'up-right', 'right', 'down-right'],
    states: { ...HERO_ANIM_FRAMES },
    fps: { ...HERO_ANIM_FPS },
    namePattern: 'hero/{state}/{direction}/{frame:02}',
    firstDelivery: 'one-canonical-hero-before-four-race-batch',
  },
  validation: [
    'canonical-identity',
    'same-camera-and-light',
    'contact-at-feet',
    'no-aura-on-body',
    'no-frame-flicker',
    'no-cut-feet',
    'readable-at-360x800',
    'collision-independent-from-art',
    'atlas-padding-no-bleed',
  ],
};

export const CANONICAL_RACE_PROVENANCE: Record<HeroRace['id'], RaceProvenanceMetadata> = {
  planetary: {
    hero: 'planetary',
    pack_id: 'hero-planetary-painted',
    world: 'verdant',
    owner_status: 'ACCEPTED by owner (2026-10-22)',
    method: 'painted base views (ControlNet OpenPose + IP-Adapter) + 2D mesh skinning; no per-frame redraw',
    identity_candidate: 'docs/design/identity/planetary-v1/planetary-s5741102-d62.png',
    identity_sha256: '086d7e1377b2c8639c9c01532298631e44e952d18b9bfdc64733e27214a3eeb8',
    painted_views_seed: 5741103,
    views_source: 'renders/planetary-painted-v1 on the GPU volume (webp copies here are lossless)',
    painted_views: [
      { file: 'planetary-down-s5741103.webp', direction: 'down', source_png_sha256: 'd4bd0d2d8fa219e71f8e0372a9c4d1924f3b2e99883744c3513504cc9b2fde77', sha256: '5ae592836c121cc171557d413a1f0220546672b0b9fdcab5ce82c40ddf55770c' },
      { file: 'planetary-down-left-s5741103.webp', direction: 'down-left', source_png_sha256: 'ab799f8c6429304090160c5e72db8848337b7c0cb8fa72e40fd477fae9973cf7', sha256: 'd27e58312644bc4acfc7b11d21cd56ea060c3657e87527f0bf75fe726de9e54e' },
      { file: 'planetary-left-s5741103.webp', direction: 'left', source_png_sha256: '0ad6cec6cd57fbc29951145cf524967fa1df88d600659a0a8cdcc5ce41dbe903', sha256: '970e4bf33cf18b376f06fc98ad5eb270b6ee1fef6eebc577f3356e0f2f69a278' },
      { file: 'planetary-up-left-s5741103.webp', direction: 'up-left', source_png_sha256: 'a19b2a6c2e37868654698141a10b38f15da64c09a2f1f6834cf53b59963c82e4', sha256: 'ae4b386b050733ab38aabc86e055bb1ff9437fbfc1f30f5426ddc3a258eb9210' },
      { file: 'planetary-up-s5741103.webp', direction: 'up', source_png_sha256: 'd30252c6a733488ed07f0ef527405cfa9d46716d780fa9366714c70ec6a1072f', sha256: '5945c53b117da17aaee07d605d807d10794048ebd00a6647d510b4e173d79520' },
      { file: 'planetary-up-right-s5741103.webp', direction: 'up-right', source_png_sha256: '8b630e5a9556a30eedca92d3a35f457726192e6a3e83d1695aa7b277e7cc9270', sha256: '8f22a62da877fda869bd7744e0e52c3cf7acb0da8b71bcaec2d5c5b04754c1ae' },
      { file: 'planetary-right-s5741103.webp', direction: 'right', source_png_sha256: 'f87c1a2acafcd8890f4333d8ddaebd24a46c1805db5646b3dc156051d8922e6e', sha256: '4b825e8dfbc28ae916946a54ec26f7cfdfc8db3db1844c9cf951564da5fa5542' },
      { file: 'planetary-down-right-s5741103.webp', direction: 'down-right', source_png_sha256: '40f6eb9e2d97b8d93642800aff78ed3a1df3c610862947ae33431bc54ea5e268', sha256: '2a1d3b90fbe7e81b24865389e17d96a0b7b6d3984581ded194ba946d0c2b6a02' },
    ],
    masters: [
      { file: 'planetary-master-down.png', sha256: 'e0d2f123ff8a131eb5ebd877e1bc4b92acf3af7c26c3d529188d937ea73abca4' },
      { file: 'planetary-master-down-left.png', sha256: 'ad7c4cfe9ae27353ab75f3906edbd909693eb3a0f656605f91d8e8a03dd63baf' },
      { file: 'planetary-master-left.png', sha256: '4cfaa50456c702a72c0cc151b5b46c6068b024f68258c9865bcb68fd94199fce' },
      { file: 'planetary-master-up-left.png', sha256: '80fa71d850119965494fc850adf535d5522cdabfd99beecae7e254d20619595d' },
      { file: 'planetary-master-up.png', sha256: '772906503fa74602024e4de7155ffd393f61c3acf4e18700ddfc8781344e33e6' },
      { file: 'planetary-master-up-right.png', sha256: '3074c02f4a13d531f2756f4625a3044b9c2a34117d9bb6479b38263619ea2e5f' },
      { file: 'planetary-master-right.png', sha256: 'babe4970f651c277d5215cb571d66062b3ad0acea7ca975805c789818cb08232' },
      { file: 'planetary-master-down-right.png', sha256: 'd0cd8b5b64f3e08490f81dd40de73dc495a47caeb59dfe9c5dafa8fd2d144872' },
    ],
    pack_manifest_sha256: 'ae59e5153b5a90c35e5aa46b44bec61c5407928364e585bc5907c5655e43dea5',
    frames_tarball_on_volume: 'ki-legends-gpu/deliveries-src/layout-planetary-v6.tar (416 PNG 512x512)',
    tools: {
      checkpoint: 'animagine-xl-3.1.safetensors',
      diffusers: '0.41.0',
      torch: '2.8.0+cu128',
      rembg_model: 'isnet-anime',
      controlnet: 'xinsir/controlnet-openpose-sdxl-1.0 (Apache-2.0)',
      ip_adapter: 'h94/IP-Adapter sdxl_models (Apache-2.0)',
    },
    render: {
      KI_SAFE: 22,
      clips: 'idle8 walk8 attack8 skill8 hit4 death8 respawn8 x 8 directions = 416',
    },
    rights: 'Accepted canonical identity; local 2D mesh & alpha matting active',
  },
  sage: {
    hero: 'sage',
    pack_id: 'hero-sage-painted',
    world: 'aether',
    owner_status: 'ACCEPTED by owner (2026-10-22)',
    method: 'painted base views (ControlNet OpenPose + IP-Adapter) + 2D mesh skinning; no per-frame redraw',
    identity_candidate: 'docs/design/identity/sage-v2/sage-s5741102-d55.png',
    identity_sha256: 'f8c049347ccf2ffa0e3364c8c2bfa46488d37edf528c02a9066cad393a10d38a',
    painted_views_seed: 5741102,
    views_source: 'renders/sage-painted-v1 on the GPU volume (webp copies here are lossless)',
    painted_views: [
      { file: 'sage-down-s5741102.webp', direction: 'down', source_png_sha256: 'a6970f5ed77266a5b916191a473fec65be10a947080b770b7eb097268d684dfd', sha256: '7b6293a871dffa6122fd70e84ca59209bf66fa91f767ebd15b1ddffb6305df38' },
      { file: 'sage-down-left-s5741102.webp', direction: 'down-left', source_png_sha256: 'f1630c15793159f75a5da7d6274b8126862053bdb942e7788b0c400d4105498d', sha256: '306df2e528ef04990ce1c1f950ddc810b89b2d15f6848b2d5e3a9950d67fa681' },
      { file: 'sage-left-s5741102.webp', direction: 'left', source_png_sha256: 'c81a0e41c2c05b1150a56e72d1adb8a00bb4d7e6352aedb4b94a03c69f89b666', sha256: 'd9e1ec1c1c27c9da74016a0600a1feeec139dc43968a8bd6c42d704bd4f0ec87' },
      { file: 'sage-up-left-s5741102.webp', direction: 'up-left', source_png_sha256: 'de52d9c5d85dba8b8f6a7466ed4a8b53edb1b3152a8d6431456dc0792208c150', sha256: 'a3feafb806b580b1f88b13c4157f71175ec573a925f47c7d5ff49506358905ea' },
      { file: 'sage-up-s5741102.webp', direction: 'up', source_png_sha256: 'c0a660971f9b8389e736ebecd9860bd95b8e758472718deb191cf001ebedb560', sha256: '40e3de32a888667028b2d952b6124b3cb741c4a9819702e944f617d60faf13ca' },
      { file: 'sage-up-right-s5741102.webp', direction: 'up-right', source_png_sha256: 'cc0a2f6aa4fdca3d8e10e18a59f5c689c717656651c0011b046d37526b548aae', sha256: '6fe41214bd17c819386dfc0ce1ec9802f4369c8b7e10fe90be785bccd1b18147' },
      { file: 'sage-right-s5741102.webp', direction: 'right', source_png_sha256: '6918c5a59ee768be250fad6d4f5188f523a1a4386494954c55f94b69997329cc', sha256: 'afa7d7c0977a3d87a7e8e838862c7efbb453bcbb9dff14db44a2c1ece2a1eb4e' },
      { file: 'sage-down-right-s5741102.webp', direction: 'down-right', source_png_sha256: '90859d6c1bf7cefc47192ce9b1d8d2ee9f2941d9ad0825f692f8a2c8ba0ef239', sha256: '5fa7f9e4db6985878a7421609af6284451713d577ed93d9e05dc4450c4850ba2' },
    ],
    masters: [
      { file: 'sage-master-down.png', sha256: '1251ccb4c83f0410bf76398188b45c74ab451e1d40b01ef296d4dca0417f39df' },
      { file: 'sage-master-down-left.png', sha256: '338df7e0d94482e7f6985eb351fbe37501a5977113b5c3381c227b0f1b0032f0' },
      { file: 'sage-master-left.png', sha256: 'e425cf9dcefec7eb42dd0af2ea09b91b013b76fb6c14584cfe9bc830f979326e' },
      { file: 'sage-master-up-left.png', sha256: '039a658c307dcbe90bd4f79d75ae4d7413577d807df9d8c155012eef330c7256' },
      { file: 'sage-master-up.png', sha256: 'd1c588b96a24001c320137771be0947072e8e0e2296e09f92170807bad1c6a7e' },
      { file: 'sage-master-up-right.png', sha256: '332d5fb604be429fd9f6c70e1407f7a4be3dc1fb6417311ba8cba85773dfffe9' },
      { file: 'sage-master-right.png', sha256: 'bd848373718559645cc49c3b5a02b06e7bd6f2f69878454a364328db866cf4c8' },
      { file: 'sage-master-down-right.png', sha256: 'a6bcf7887fee54ecdb3577ad2aff2b67e8d192586f328794edd8f58db513f42e' },
    ],
    pack_manifest_sha256: '1aed6563555daaece5e7230afcf39f9d94d2eac6ff095537c8932ad0bc47566a',
    frames_tarball_on_volume: 'ki-legends-gpu/deliveries-src/layout-sage-v6.tar (416 PNG 512x512)',
    tools: {
      checkpoint: 'animagine-xl-3.1.safetensors',
      diffusers: '0.41.0',
      torch: '2.8.0+cu128',
      rembg_model: 'isnet-anime',
      controlnet: 'xinsir/controlnet-openpose-sdxl-1.0 (Apache-2.0)',
      ip_adapter: 'h94/IP-Adapter sdxl_models (Apache-2.0)',
    },
    render: {
      KI_SAFE: 22,
      clips: 'idle8 walk8 attack8 skill8 hit4 death8 respawn8 x 8 directions = 416',
    },
    rights: 'Accepted canonical identity; local 2D mesh & alpha matting active',
  },
  android: {
    hero: 'android',
    pack_id: 'hero-android',
    world: 'nexus',
    owner_status: 'identity candidate accepted; motion review accepted by owner (2026-10-22)',
    method: 'painted base views (ControlNet OpenPose + IP-Adapter) + 2D mesh skinning; no per-frame redraw',
    identity_candidate: 'docs/design/identity/android-v1/android-s5741102-d62.png',
    identity_sha256: '02a5fdc8cd3f465267c44a05cfb01b8f46ff24cd8cb98911c68047ff9b50ae67',
    painted_views_seed: 5741102,
    views_source: 'renders/android-painted-v3 on the GPU volume (webp copies here are lossless)',
    painted_views: [
      { file: 'android-down-s5741102.webp', direction: 'down', source_png_sha256: '208d580aeb307e80e9b40f8521cf58ddfb2d5c94eec33a2e8851a5fddc614493', sha256: '4b0fb5c4977960b68298bb8bcb20d77fb9d2f27f962e7fe4eafc815dcdfc833f' },
      { file: 'android-down-left-s5741102.webp', direction: 'down-left', source_png_sha256: '5284f359724786d4459de49fdd2d68effbab436354eb85cf437b27a6cdf8be97', sha256: 'db07b6e77c8272c5501729b6258958477f16a7c96a47bf1b6ac5b3ae204ba2ce' },
      { file: 'android-left-s5741102.webp', direction: 'left', source_png_sha256: '79885d71f69f7dd13dcbaa6b2d2d57fb212e847e5291376fe78acd1f837cc37c', sha256: 'a2172c50338e76f38468f6bae62ae44d908b7a92e90badd0bca945e3507c77d5' },
      { file: 'android-up-left-s5741102.webp', direction: 'up-left', source_png_sha256: 'e118bec7e0ba00aa8223362adff0a2998c788a299ff7aff19e6917846110afe5', sha256: '3654a3880fadae74432725d03070c532dc898e0db42bfc2bc3b1d90c6f34350b' },
      { file: 'android-up-s5741102.webp', direction: 'up', source_png_sha256: '0e722b8a859223633f635328aae27617ff9062c3e06ea92391a556ea65496675', sha256: '8ba208cad128927c55206a82c503059bd35e6796e05d24278858be373284769f' },
      { file: 'android-up-right-s5741102.webp', direction: 'up-right', source_png_sha256: 'f3504d1962c9f38c9e7e3c18f72c9cec556088033893e7d95fadec378fda0892', sha256: '9f46e02809c8d05d2fb56048e33069d6195e1dff1bce7b787c3ccdd7b4dd7032' },
      { file: 'android-right-s5741102.webp', direction: 'right', source_png_sha256: '413ac578ba57e62d7023532d88e622b8e79f5e43874f243925444662061dc04f', sha256: '1815b41a82826fa5863dd40af64d10c726ac4dbb8671a3e9402c7567b4361751' },
      { file: 'android-down-right-s5741102.webp', direction: 'down-right', source_png_sha256: 'b432a4dbdf4e4bbfad31830b2baafa7de6914128bef868db9d0a34b304bb491f', sha256: '36eeb92350357722c31ae61b1130b7478c51daf88ad78659aa46627a1b772848' },
    ],
    masters: [
      { file: 'android-master-down.png', sha256: 'd30a922bcd6d4f87fcf5dcb3934ab7a9496fc6909aa22873457bf3f00127e4e7' },
      { file: 'android-master-down-left.png', sha256: '95370d4a8fd1e25b8c8325506ddd86e2b05327ceb80177b5a28fec443067a60f' },
      { file: 'android-master-left.png', sha256: 'b174ff2b8bf772f5f19e8e899914248aec814a8f0401f195831743fa7ad9874e' },
      { file: 'android-master-up-left.png', sha256: '7e6cd87ac138a6e8b88dd29088658a82b0d543aa9b1b4e4b084858014577f7fc' },
      { file: 'android-master-up.png', sha256: 'd58eeb527b24797324762510c193e1c5b87da0fbb70049623830e713b62d5f43' },
      { file: 'android-master-up-right.png', sha256: 'de2f9c149d1528704303f8b55d4f1bed5d0b366b181701576f3b380e59144aaa' },
      { file: 'android-master-right.png', sha256: '422038d24901fddc33bf3f6d789e381974c07408d1ee610ef4b39ec16963bda9' },
      { file: 'android-master-down-right.png', sha256: 'd0cb87fbead54992c8e20820f0ab621e4714b2f0dfbc3d73d09bd18d02b06e31' },
    ],
    pack_manifest_sha256: 'e729ce083a3afc67296492f5154006efa2a996b3b45c52b3972a6101409556f4',
    frames_tarball_on_volume: 'ki-legends-gpu/deliveries-src/layout-android-v6.tar (416 PNG 512x512)',
    tools: {
      checkpoint: 'animagine-xl-3.1.safetensors',
      diffusers: '0.41.0',
      torch: '2.8.0+cu128',
      rembg_model: 'isnet-anime',
      controlnet: 'xinsir/controlnet-openpose-sdxl-1.0 (Apache-2.0)',
      ip_adapter: 'h94/IP-Adapter sdxl_models (Apache-2.0)',
    },
    render: {
      KI_SAFE: 22,
      clips: 'idle8 walk8 attack8 skill8 hit4 death8 respawn8 x 8 directions = 416',
    },
    rights: 'Accepted canonical identity; local 2D mesh & alpha matting active',
  },
  legend: {
    hero: 'legend',
    pack_id: 'hero-legend',
    world: 'pyra',
    owner_status: 'identity candidate accepted; local 2D mesh & alpha matting active',
    method: 'painted base views (ControlNet OpenPose + IP-Adapter) + 2D mesh skinning; no per-frame redraw',
    identity_candidate: 'docs/design/identity/legend-v1/legend-s5741102-d62.png',
    identity_sha256: '35421413ffe928e53aa50916fa2028cdb3d89cf5c0db3d0982c6db32d29d121b',
    painted_views_seed: 5741102,
    views_source: 'renders/legend-painted-v1 on the GPU volume (webp copies here are lossless)',
    painted_views: [
      { file: 'legend-down-s5741102.webp', direction: 'down', source_png_sha256: '7c77c4703738f71c6d36b172fae3540996c6d90bd5043f398b5eb3fbe8627cd4', sha256: 'e301371ee20343b6215ae6f31bc6c04773272e88ae5d81a5ef4eda45d847c495' },
      { file: 'legend-down-left-s5741102.webp', direction: 'down-left', source_png_sha256: 'b8fd126e42713e2aa26e3004362736d8ed2803baed15ad12485718bf057c173d', sha256: '849e7f7991e93d6057669af9ae9e61e1fa2809416d68342ff7026c7e85bbe752' },
      { file: 'legend-left-s5741102.webp', direction: 'left', source_png_sha256: '42bf637f8033c78fec71965aff92622e6c1ecff5a75760c62daec84100338734', sha256: '776217a5238be350bf5985d85ad72775aef89f004dffc26418ea9742862f473d' },
      { file: 'legend-up-left-s5741102.webp', direction: 'up-left', source_png_sha256: '0a66b619af394407b40f0473f23f76c9968b9fc2797d7161a778889e5137a431', sha256: 'cc953d894f4dc18a1017a533ebaa17de5ef47c90fad79844b2200477ae8ffc65' },
      { file: 'legend-up-s5741102.webp', direction: 'up', source_png_sha256: 'cc6d96353322e8b0c7ebdf34ed46436dc9eca873d5a26e901fc2c48423eaadce', sha256: '27d21dd3ee992f138ba22946ab58c05d7995f4537eafb37840b34c4c78309c9a' },
      { file: 'legend-up-right-s5741102.webp', direction: 'up-right', source_png_sha256: 'f7e3c4fcc868d122c3d029040f7daa90981bd609680b6f6aab3d416c3687c913', sha256: '529b18cd306413b42431ad2c9726fa56bdc938f5cf67469b0af7526b95167f6a' },
      { file: 'legend-right-s5741102.webp', direction: 'right', source_png_sha256: 'd844edb612ee031e6ebdf2e5556ba41f71f870755c4035f0a1b2fd89c44d286c', sha256: 'c556f76a24009e25f1280430e0200bf33e302c88155bc170756114b9ca2342bc' },
      { file: 'legend-down-right-s5741102.webp', direction: 'down-right', source_png_sha256: '24270ee9b21abe422c0d9869679ba7c5a15dfed65498a1ec95577e265dbc3d67', sha256: 'fda1c470d7089b6b79fd1d8552db246a56b2512bb50b41eebe7a38ebf2a0403c' },
    ],
    masters: [
      { file: 'legend-master-down.png', sha256: '158b6372606ae6f46944c8939c91ac0dbafe0fd08a35adf068d3dded9ed78662' },
      { file: 'legend-master-down-left.png', sha256: 'ad22cc45f7267a18601690583cb2f8b8bf560b095a09c743e1270cbb778d0ee7' },
      { file: 'legend-master-left.png', sha256: 'ae8a854c0c7e4855f98b252c512e58b58b728d6b1707d3b4eb538241c3c73d06' },
      { file: 'legend-master-up-left.png', sha256: '1aabb81392553e4d317436799750b8f2c3ef6091e24fe24c3a9a552372daf812' },
      { file: 'legend-master-up.png', sha256: '897236279e937c86cbd046338dff24dd64b57fb160887f6678c02169e3046fe2' },
      { file: 'legend-master-up-right.png', sha256: 'f48b5d9117961c5b46d34fb5aac99344221a4e1c6995b60c30c1ccc012a66aad' },
      { file: 'legend-master-right.png', sha256: '6ea79e22797b97ae47ceeffe7350207f43aaed3af662c70ee615dada5c6266ac' },
      { file: 'legend-master-down-right.png', sha256: '3a01b52aa1945e787aca938c850a104a7188e9fc88f5fa22d1d0553bcb54efb9' },
    ],
    pack_manifest_sha256: '844973d5d4a7b59c83b9e82e43bab741158ef6c76e95bed0445518689a688ee1',
    frames_tarball_on_volume: 'ki-legends-gpu/deliveries-src/layout-legend-v6.tar (416 PNG 512x512)',
    tools: {
      checkpoint: 'animagine-xl-3.1.safetensors',
      diffusers: '0.41.0',
      torch: '2.8.0+cu128',
      rembg_model: 'isnet-anime',
      controlnet: 'xinsir/controlnet-openpose-sdxl-1.0 (Apache-2.0)',
      ip_adapter: 'h94/IP-Adapter sdxl_models (Apache-2.0)',
    },
    render: {
      KI_SAFE: 22,
      clips: 'idle8 walk8 attack8 skill8 hit4 death8 respawn8 x 8 directions = 416',
    },
    rights: 'Accepted canonical identity; local 2D mesh & alpha matting active',
  },
};

export const RACE_THEME_PRESETS: Record<HeroRace['id'], RaceDynamicTheme[]> = {
  planetary: [
    {
      id: 'planetary-canonical',
      namePl: 'Szmaragd Verdantii (Kanoniczny)',
      primaryAccent: '#10b981',
      secondaryAccent: '#14b8a6',
      auraGlow: '#34d399',
      surfaceTint: '#06281e',
      borderAccent: '#059669',
      hpBarColor: '#10b981',
      kiBarColor: '#2dd4bf',
    },
    {
      id: 'planetary-jade-canopy',
      namePl: 'Nefrytowy Korzeń Życia',
      primaryAccent: '#22c55e',
      secondaryAccent: '#84cc16',
      auraGlow: '#4ade80',
      surfaceTint: '#092614',
      borderAccent: '#16a34a',
      hpBarColor: '#22c55e',
      kiBarColor: '#a3e635',
    },
    {
      id: 'planetary-solar-bloom',
      namePl: 'Złoty Rozkwit Pradawnych',
      primaryAccent: '#059669',
      secondaryAccent: '#eab308',
      auraGlow: '#facc15',
      surfaceTint: '#112218',
      borderAccent: '#10b981',
      hpBarColor: '#10b981',
      kiBarColor: '#facc15',
    },
  ],
  sage: [
    {
      id: 'sage-canonical',
      namePl: 'Złota Pieczęć Eteru (Kanoniczny)',
      primaryAccent: '#f59e0b',
      secondaryAccent: '#eab308',
      auraGlow: '#fbbf24',
      surfaceTint: '#291a05',
      borderAccent: '#d97706',
      hpBarColor: '#f43f5e',
      kiBarColor: '#f59e0b',
    },
    {
      id: 'sage-celestial-azure',
      namePl: 'Astralny Glif Niebios',
      primaryAccent: '#eab308',
      secondaryAccent: '#38bdf8',
      auraGlow: '#fde047',
      surfaceTint: '#1f1908',
      borderAccent: '#ca8a04',
      hpBarColor: '#f43f5e',
      kiBarColor: '#38bdf8',
    },
    {
      id: 'sage-radiant-saffron',
      namePl: 'Szafranowe Sanktuarium',
      primaryAccent: '#f97316',
      secondaryAccent: '#f59e0b',
      auraGlow: '#fdba74',
      surfaceTint: '#2b1406',
      borderAccent: '#ea580c',
      hpBarColor: '#fb7185',
      kiBarColor: '#fbbf24',
    },
  ],
  android: [
    {
      id: 'android-canonical',
      namePl: 'Cyjan Rdzenia Nexus-9 (Kanoniczny)',
      primaryAccent: '#06b6d4',
      secondaryAccent: '#3b82f6',
      auraGlow: '#22d3ee',
      surfaceTint: '#06202a',
      borderAccent: '#0891b2',
      hpBarColor: '#06b6d4',
      kiBarColor: '#38bdf8',
    },
    {
      id: 'android-overdrive-ion',
      namePl: 'Przeciążenie Jonowe',
      primaryAccent: '#0ea5e9',
      secondaryAccent: '#6366f1',
      auraGlow: '#38bdf8',
      surfaceTint: '#081b2e',
      borderAccent: '#0284c7',
      hpBarColor: '#38bdf8',
      kiBarColor: '#818cf8',
    },
    {
      id: 'android-hardlight-neon',
      namePl: 'Twarde Światło Plazmy',
      primaryAccent: '#14b8a6',
      secondaryAccent: '#06b6d4',
      auraGlow: '#5eead4',
      surfaceTint: '#042424',
      borderAccent: '#0d9488',
      hpBarColor: '#2dd4bf',
      kiBarColor: '#22d3ee',
    },
  ],
  legend: [
    {
      id: 'legend-canonical',
      namePl: 'Magma Wulkanu Pyra (Kanoniczny)',
      primaryAccent: '#ef4444',
      secondaryAccent: '#f97316',
      auraGlow: '#f87171',
      surfaceTint: '#2a0909',
      borderAccent: '#dc2626',
      hpBarColor: '#ef4444',
      kiBarColor: '#f97316',
    },
    {
      id: 'legend-obsidian-wrath',
      namePl: 'Obsydianowa Furia Tytanów',
      primaryAccent: '#dc2626',
      secondaryAccent: '#fb923c',
      auraGlow: '#fb7185',
      surfaceTint: '#24070b',
      borderAccent: '#b91c1c',
      hpBarColor: '#e11d48',
      kiBarColor: '#fb923c',
    },
    {
      id: 'legend-solar-eruption',
      namePl: 'Żar Korony Bazaltowej',
      primaryAccent: '#f97316',
      secondaryAccent: '#ef4444',
      auraGlow: '#fdba74',
      surfaceTint: '#2b1106',
      borderAccent: '#ea580c',
      hpBarColor: '#ef4444',
      kiBarColor: '#facc15',
    },
  ],
};

export function createDefaultRigConfig(raceId: HeroRace['id']): RaceVisualRigConfig {
  return {
    useCleanedSprite: true,
    showAura: true,
    showFeetAnchor: false,
    showCollisionCircle: false,
    scaleMultiplier: 1.0,
    worldHeightTrialPx: 96,
    feetAnchorY: 0.91,
    collisionRadiusUnits: 12,
    hueShiftDeg: 0,
    saturationPct: 100,
    brightnessPct: 100,
    contrastPct: 100,
    fpsMultiplier: 1.0,
    strideAmplitude: 1.0,
    clothWaveIntensity: raceId === 'sage' || raceId === 'android' ? 1.15 : 1.0,
    attackLungeDistance: 1.0,
    skillLevitationHeight: 1.0,
    breathingDepth: 1.0,
    auraIntensity: 1.0,
  };
}

export function createDefaultRaceProfile(raceId: HeroRace['id']): RaceEditorProfile {
  return {
    raceId,
    theme: { ...RACE_THEME_PRESETS[raceId][0] },
    rig: createDefaultRigConfig(raceId),
    updatedAt: new Date().toISOString(),
  };
}

const STORAGE_KEY = 'ki_legends_race_editor_profiles_v1';
const ACTIVE_RACE_THEME_KEY = 'ki_legends_active_race_theme_id_v1';

const inMemoryProfiles: Record<HeroRace['id'], RaceEditorProfile> = {
  planetary: createDefaultRaceProfile('planetary'),
  sage: createDefaultRaceProfile('sage'),
  android: createDefaultRaceProfile('android'),
  legend: createDefaultRaceProfile('legend'),
};

export function loadAllRaceProfiles(): Record<HeroRace['id'], RaceEditorProfile> {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<Record<HeroRace['id'], RaceEditorProfile>>;
        for (const r of HERO_RACES) {
          if (parsed[r.id]) {
            inMemoryProfiles[r.id] = {
              raceId: r.id,
              theme: { ...RACE_THEME_PRESETS[r.id][0], ...parsed[r.id]?.theme },
              rig: { ...createDefaultRigConfig(r.id), ...parsed[r.id]?.rig },
              updatedAt: parsed[r.id]?.updatedAt || new Date().toISOString(),
            };
          }
        }
      }
    }
  } catch {
    // Fallback to in-memory defaults
  }
  return { ...inMemoryProfiles };
}

export function getRaceProfile(raceId: HeroRace['id']): RaceEditorProfile {
  const all = loadAllRaceProfiles();
  return all[raceId] || createDefaultRaceProfile(raceId);
}

export function saveRaceProfile(profile: RaceEditorProfile): void {
  inMemoryProfiles[profile.raceId] = {
    ...profile,
    updatedAt: new Date().toISOString(),
  };
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(inMemoryProfiles));
      window.dispatchEvent(
        new CustomEvent('ki-legends-race-profile-updated', { detail: inMemoryProfiles[profile.raceId] })
      );
    }
  } catch {
    // Ignore storage quota issues
  }
}

export function resetRaceProfileToCanonical(raceId: HeroRace['id']): RaceEditorProfile {
  const fresh = createDefaultRaceProfile(raceId);
  saveRaceProfile(fresh);
  return fresh;
}

export function getActiveUiThemeRaceId(): HeroRace['id'] {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const val = window.localStorage.getItem(ACTIVE_RACE_THEME_KEY) as HeroRace['id'] | null;
      if (val && ['planetary', 'sage', 'android', 'legend'].includes(val)) {
        return val;
      }
    }
  } catch {
    // ignore
  }
  return 'planetary';
}

export function setActiveUiThemeRaceId(raceId: HeroRace['id']): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(ACTIVE_RACE_THEME_KEY, raceId);
      const profile = getRaceProfile(raceId);
      applyRaceThemeToDocument(profile.theme, raceId);
      window.dispatchEvent(
        new CustomEvent('ki-legends-active-race-theme-changed', { detail: { raceId, theme: profile.theme } })
      );
    }
  } catch {
    // ignore
  }
}

export function applyRaceThemeToDocument(theme: RaceDynamicTheme, raceId: HeroRace['id']): void {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  root.style.setProperty('--race-primary', theme.primaryAccent);
  root.style.setProperty('--race-secondary', theme.secondaryAccent);
  root.style.setProperty('--race-glow', theme.auraGlow);
  root.style.setProperty('--race-surface', theme.surfaceTint);
  root.style.setProperty('--race-border', theme.borderAccent);
  root.style.setProperty('--race-hp-bar', theme.hpBarColor);
  root.style.setProperty('--race-ki-bar', theme.kiBarColor);
  root.setAttribute('data-active-race', raceId);
}

/**
 * Fetches live provenance.json from `/art/production/heroes/<race>/painted-v1/provenance.json`
 * with canonical fallback when running in headless test environments.
 */
export async function fetchRaceProvenance(raceId: HeroRace['id']): Promise<RaceProvenanceMetadata> {
  try {
    if (typeof fetch !== 'undefined') {
      const res = await fetch(`/art/production/heroes/${raceId}/painted-v1/provenance.json`);
      if (res.ok) {
        const data = (await res.json()) as RaceProvenanceMetadata;
        if (data && data.hero === raceId && Array.isArray(data.masters)) {
          return data;
        }
      }
    }
  } catch {
    // Fallback to embedded canonical provenance
  }
  return CANONICAL_RACE_PROVENANCE[raceId];
}

/**
 * Fetches live stage3-render-contract.json from `/art/pipeline/stage3-render-contract.json`
 * with canonical fallback.
 */
export async function fetchStage3RenderContract(): Promise<Stage3RenderContract> {
  try {
    if (typeof fetch !== 'undefined') {
      const res = await fetch('/art/pipeline/stage3-render-contract.json');
      if (res.ok) {
        const data = (await res.json()) as Stage3RenderContract;
        if (data && data.character && Array.isArray(data.validation)) {
          return data;
        }
      }
    }
  } catch {
    // Fallback to canonical contract
  }
  return CANONICAL_STAGE3_CONTRACT;
}

export function computeEffectiveAnimFps(state: HeroAnimState, fpsMultiplier: number): number {
  const base = HERO_ANIM_FPS[state] || 10;
  return Math.max(2, Math.min(30, Math.round(base * fpsMultiplier)));
}
