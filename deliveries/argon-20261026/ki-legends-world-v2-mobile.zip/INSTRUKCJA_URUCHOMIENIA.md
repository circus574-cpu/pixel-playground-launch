# KI LEGENDS — WORLD V2 & MOBILE EDITION
## Instrukcja Uruchomienia, Testowania i Integracji Paczki ZIP

Ta paczka zawiera kompletny kod źródłowy mechaniki **KI Legends World V2**, rozbudowany **Dziennik Misji (Quest Log)**, katalogi dialogów, przedmiotów, receptur i bossów oraz adaptację na **urządzenia mobilne i różne rozdzielczości ekranów**.

---

## 1. Zawartość Paczki ZIP

1. **`src/game/worlds/`** — Dane 4 kontynentów (`verdant`, `pyra`, `aether`, `nexus`), 16 bezpiecznych miast (`inSafeCity`), 16 Sławnych Lokacji (powiązanych z `gpu-production-targets.json`), dróg przygodowych, ukrytych sekretów i wydarzeń świata.
2. **`src/game/quests/`** — Silnik Questów V2 (`engine.ts`, `types.ts`) obsługujący 106 wieloetapowych zadań (kampanie główne, poboczne, ukryte i międzykontynentalne) oraz bezstratną migrację zapisu `Save v4 -> Save v5`.
3. **`src/game/dialogue/`** — Kompletne polskie dialogi dla wszystkich 28 NPC z 16 miast (3 powitania, 3 plotki o okolicy, kwestie `before`, `during`, `after` dla wszystkich 106 zadań) wraz z testami jednostkowymi.
4. **`src/game/items/`** — Katalog ponad 100 przedmiotów i 30+ receptur rzemieślniczych z *Księgi Przygody v1.0* (`alchemy`, `forge`, `runic`, `cyber_fabricator`).
5. **`src/game/bosses/`** — Katalog 8 bossów kontynentalnych (Ygdrasha, Thorgar, Arcykapłan Pustki, Aurelith, Arbiter Zero, Hydra-Rdzeń, Kharzul, Pyrrhax) z fazami HP, atakami i tabelami łupów.
6. **`src/components/QuestLogView.tsx` & `src/components/WorldV2Explorer.tsx`** — Nowy widok **Quest Log** śledzący postęp aktywnych misji, podświetlający ukończone cele (`UKOŃCZONO`) oraz prezentujący potencjalne nagrody (XP, monety, przedmioty kanoniczne i artefakty z Księgi Przygody).
7. **`src/components/CombatSandbox.tsx`** — Zmodernizowana Arena Walki PvE dostosowana do ekranów dotykowych (Android / iOS / Tablety / Desktop):
   - Wirtualny **Joystick Analogowy 360°** oraz przełączany **D-Pad 8-kierunkowy** pod lewy kciuk,
   - Ergonomiczny klaster przycisków **Ataku i Technik KI (Q / E / R)** pod prawy kciuk,
   - Dotykowe celowanie i atak bezpośrednio na płótnie (`Tap-to-Aim & Attack`),
   - **Domyślnie oddalona kamera (Zoom 85%)** z przełącznikiem przybliżenia (`70% / 85% / 100%`),
   - **Tryb Pełnoekranowy całej sceny wraz z HUD** (`Pełny Ekran`).
8. **`dialogue-items-bosses.patch`** — Czysta łatka Git zawierająca nowe katalogi `src/game/dialogue`, `src/game/items` oraz `src/game/bosses`.

---

## 2. Szybkie Uruchomienie Lokalne (Krok po Kroku)

### Wymagania
- **Node.js** w wersji `18.x` lub `20.x+`
- **npm** (dołączony do Node.js)

### Instrukcja w terminalu
```bash
# 1. Rozpakuj pobrane archiwum ZIP i wejdź do folderu projektu:
unzip ki-legends-world-v2-mobile.zip -d ki-legends-world-v2
cd ki-legends-world-v2

# 2. Zainstaluj zależności:
npm install

# 3. Uruchom serwer deweloperski (domyślnie na porcie 3000):
npm run dev
```

Po uruchomieniu otwórz w przeglądarce:
- Na komputerze: `http://localhost:3000`
- Na telefonie w tej samej sieci Wi-Fi: `http://<ADRES-IP-KOMPUTERA>:3000`

---

## 3. Weryfikacja Testów, Typów i Produkcyjnego Buildu

Przed wdrożeniem możesz zweryfikować pełną spójność danych i typów:

```bash
# Sprawdzenie pełnej konfiguracji TypeScript (0 błędów):
npm run typecheck

# Uruchomienie testów jednostkowych Vitest (dialogi, przedmioty, receptury, bossowie, świat, questy):
npm test

# Zbudowanie paczki produkcyjnej:
npm run build
```

---

## 4. Jak przenieść zmiany do repozytorium GitHub (`circus574-cpu/pixel-playground-launch`)

Jeżeli chcesz zaaplikować zmiany bezpośrednio na swoim lokalnym klonie repozytorium na gałęzi `feature/quests-v2`:

```bash
# Przełącz się na gałąź roboczą:
git checkout feature/quests-v2

# Skopiuj pliki z rozpakowanego archiwum ZIP do swojego repozytorium
# LUB nałóż załączoną łatkę katalogów gry:
git apply dialogue-items-bosses.patch

# Sprawdź status i zatwierdź zmiany:
git status
git add src/
git commit -m "Feat: World V2 Quest Log, mobile touch HUD, dialogues, items and bosses"
git push origin feature/quests-v2
```

---

## 5. Sterowanie na Urządzeniach Mobilnych i Różnych Ekranach

- **Smartfony i Tablety (Ekran dotykowy)**:
  - W zakładce **Arena Walki** włącz przycisk **Pełny Ekran**, aby rozciągnąć scenę na cały wyświetlacz telefonu wraz z nakładką HUD.
  - **Lewy kciuk**: Płynny ruch w 360 stopniach za pomocą wirtualnego joysticka lub precyzyjny ruch 8-kierunkowy po przełączeniu na `Tryb: D-Pad 8-Kier.`.
  - **Prawy kciuk**: Duży przycisk `ATAK` oraz trzy przyciski umiejętności KI (`Q`, `E`, `R`) z licznikami czasu odnowienia i kosztu KI.
  - **Dotknięcie areny**: Postać automatycznie obraca się w stronę dotkniętego punktu i wystrzeliwuje pocisk w tym kierunku.
- **Komputery (Klawiatura + Mysz)**:
  - Ruch: `W, A, S, D` lub `Strzałki`
  - Atak podstawowy: `Spacja` lub kliknięcie w wybranym punkcie areny
  - Umiejętności KI: klawisze `Q`, `E`, `R`
