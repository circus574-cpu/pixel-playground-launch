KI Legends – wstępnie wyselekcjonowane efekty Planetarnych
Źródło: grafika 11436.jpg przekazana w rozmowie.
6 odrębnych kafli PNG RGBA, wyodrębnionych z JPG o szarym tle.
To pliki QA, nie zatwierdzone atlasy produkcyjne. Kanał alfa odtworzono
heurystycznie i wymaga kontroli halo, krawędzi oraz poprawności maski.
Brak animacji i weryfikacji licencji. Bez zmian w mechanice gry.
