// scripts/worldgen/check-navigation.ts
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

// src/game/geometry.ts
var FOOT_RADIUS = 12;
var WORLD_EDGE_MARGIN = 16;

// src/game/movement.ts
function blockedAt(x, y, obstacles, radius = FOOT_RADIUS) {
  return obstacles.some((b) => {
    const dx = x - Math.max(b.x, Math.min(x, b.x + b.width));
    const dy = y - Math.max(b.y, Math.min(y, b.y + b.height));
    return dx * dx + dy * dy <= radius * radius;
  });
}
function clearSight(ax, ay, bx, by, obstacles) {
  const steps = Math.max(1, Math.ceil(Math.hypot(bx - ax, by - ay) / 4));
  for (let i = 0; i <= steps; i++) {
    if (blockedAt(ax + (bx - ax) * i / steps, ay + (by - ay) * i / steps, obstacles, 1))
      return false;
  }
  return true;
}

// src/game/navigation.ts
var distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
var Navigation = class {
  constructor(width, height, obstacles, field) {
    this.width = width;
    this.height = height;
    this.obstacles = obstacles;
    this.field = field;
    this.cell = field?.cell ?? 24;
    this.cols = Math.ceil(width / this.cell);
    this.rows = Math.ceil(height / this.cell);
    if (field) {
      if (field.blocked.length !== this.cols * this.rows)
        throw new Error("Invalid navigation field size");
      this.blocked = field.blocked;
      return;
    }
    this.blocked = new Uint8Array(this.cols * this.rows);
    for (let i = 0; i < this.blocked.length; i++) {
      const p = this.point(i);
      this.blocked[i] = this.walkable(p) ? 0 : 1;
    }
  }
  width;
  height;
  obstacles;
  field;
  cell;
  cols;
  rows;
  blocked;
  walkable(p) {
    if (this.field)
      return Number.isFinite(p.x) && Number.isFinite(p.y) && p.x >= WORLD_EDGE_MARGIN && p.y >= WORLD_EDGE_MARGIN && p.x <= this.width - WORLD_EDGE_MARGIN && p.y <= this.height - WORLD_EDGE_MARGIN && this.field.walkable(p);
    return p.x >= WORLD_EDGE_MARGIN && p.y >= WORLD_EDGE_MARGIN && p.x <= this.width - WORLD_EDGE_MARGIN && p.y <= this.height - WORLD_EDGE_MARGIN && !blockedAt(p.x, p.y, this.obstacles, FOOT_RADIUS);
  }
  visible(a, b) {
    return this.field ? this.segment(a, b) : clearSight(a.x, a.y, b.x, b.y, this.obstacles);
  }
  segment(a, b) {
    const steps = Math.max(1, Math.ceil(distance(a, b) / 8));
    for (let i = 1; i <= steps; i++)
      if (!this.walkable({ x: a.x + (b.x - a.x) * i / steps, y: a.y + (b.y - a.y) * i / steps }))
        return false;
    return true;
  }
  index(p) {
    return Math.max(0, Math.min(this.rows - 1, Math.floor(p.y / this.cell))) * this.cols + Math.max(0, Math.min(this.cols - 1, Math.floor(p.x / this.cell)));
  }
  point(i) {
    return {
      x: (i % this.cols + 0.5) * this.cell,
      y: (Math.floor(i / this.cols) + 0.5) * this.cell
    };
  }
  accessibleCell(p) {
    const at = this.index(p), cx = at % this.cols, cy = Math.floor(at / this.cols);
    let best = -1, nearest = Infinity;
    for (let dy = -2; dy <= 2; dy++)
      for (let dx = -2; dx <= 2; dx++) {
        const x = cx + dx, y = cy + dy, i = y * this.cols + x;
        if (x < 0 || y < 0 || x >= this.cols || y >= this.rows || this.blocked[i]) continue;
        const point = this.point(i), d = distance(p, point);
        if (d < nearest && this.segment(p, point)) {
          best = i;
          nearest = d;
        }
      }
    return best;
  }
  safe(p) {
    if (this.walkable(p)) return { ...p };
    const start2 = this.point(this.index(p));
    for (let r = this.cell; r < 600; r += this.cell)
      for (let angle = 0; angle < 16; angle++) {
        const q = {
          x: start2.x + Math.cos(angle * Math.PI / 8) * r,
          y: start2.y + Math.sin(angle * Math.PI / 8) * r
        };
        if (this.walkable(q)) return q;
      }
    throw new Error("Brak bezpiecznego punktu na mapie.");
  }
  path(from, requested) {
    const to = this.safe(requested);
    if (this.segment(from, to)) return [to];
    const start2 = this.accessibleCell(from), goal = this.accessibleCell(to);
    if (start2 < 0 || goal < 0) return [];
    if (this.field) return this.fieldPath(start2, goal, to);
    const open = /* @__PURE__ */ new Set([start2]), closed = /* @__PURE__ */ new Set();
    const parent = /* @__PURE__ */ new Map(), cost = /* @__PURE__ */ new Map([[start2, 0]]);
    const score = (i) => (cost.get(i) ?? Infinity) + distance(this.point(i), to);
    for (let attempts = 0; open.size && attempts < this.blocked.length; attempts++) {
      let cur = -1, best = Infinity;
      for (const i of open) {
        const s = score(i);
        if (s < best) {
          best = s;
          cur = i;
        }
      }
      if (cur === goal) {
        const result = [to];
        let at = cur;
        while (at !== start2) {
          result.unshift(this.point(at));
          at = parent.get(at);
        }
        result.unshift(this.point(start2));
        return result;
      }
      open.delete(cur);
      closed.add(cur);
      const cx = cur % this.cols, cy = Math.floor(cur / this.cols);
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue;
          const x = cx + dx, y = cy + dy, n = y * this.cols + x;
          if (x < 0 || y < 0 || x >= this.cols || y >= this.rows || this.blocked[n] || closed.has(n))
            continue;
          if (dx && dy && (this.blocked[cy * this.cols + x] || this.blocked[y * this.cols + cx]))
            continue;
          const c = (cost.get(cur) ?? Infinity) + this.cell * Math.hypot(dx, dy);
          if (c < (cost.get(n) ?? Infinity)) {
            cost.set(n, c);
            parent.set(n, cur);
            open.add(n);
          }
        }
    }
    return [];
  }
  fieldPath(start2, goal, to) {
    const queue = [];
    const push = (item) => {
      let i = queue.length;
      queue.push(item);
      while (i > 0) {
        const p = i - 1 >> 1;
        if (queue[p].score <= item.score) break;
        queue[i] = queue[p];
        i = p;
      }
      queue[i] = item;
    };
    const pop = () => {
      const first = queue[0], last = queue.pop();
      if (queue.length) {
        let i = 0;
        while (i * 2 + 1 < queue.length) {
          let child = i * 2 + 1;
          if (child + 1 < queue.length && queue[child + 1].score < queue[child].score) child++;
          if (queue[child].score >= last.score) break;
          queue[i] = queue[child];
          i = child;
        }
        queue[i] = last;
      }
      return first;
    };
    const costs = /* @__PURE__ */ new Map([[start2, 0]]), parents = /* @__PURE__ */ new Map();
    const closed = /* @__PURE__ */ new Set();
    push({ id: start2, cost: 0, score: distance(this.point(start2), to) });
    while (queue.length && closed.size < 1e6) {
      const current = pop(), at = current.id;
      if (closed.has(at)) continue;
      if (at === goal) {
        const path = [to];
        let v = at;
        while (v !== start2) {
          path.push(this.point(v));
          v = parents.get(v);
        }
        path.push(this.point(start2));
        return path.reverse();
      }
      closed.add(at);
      const x = at % this.cols, y = Math.floor(at / this.cols);
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue;
          const nx = x + dx, ny = y + dy, next = ny * this.cols + nx;
          if (nx < 0 || ny < 0 || nx >= this.cols || ny >= this.rows || this.blocked[next] || closed.has(next))
            continue;
          if (dx && dy && (this.blocked[y * this.cols + nx] || this.blocked[ny * this.cols + x]))
            continue;
          const cost = current.cost + Math.hypot(dx, dy) * this.cell;
          if (cost >= (costs.get(next) ?? Infinity)) continue;
          costs.set(next, cost);
          parents.set(next, at);
          push({ id: next, cost, score: cost + distance(this.point(next), to) });
        }
    }
    return [];
  }
  step(p, to, amount) {
    const d = distance(p, to);
    if (d < 0.01) return p;
    const step = Math.min(amount, d);
    const next = { x: p.x + (to.x - p.x) / d * step, y: p.y + (to.y - p.y) / d * step };
    if (this.walkable(next) && (!this.field || this.segment(p, next))) return next;
    if (this.walkable({ x: next.x, y: p.y }) && (!this.field || this.segment(p, { x: next.x, y: p.y })))
      return { x: next.x, y: p.y };
    if (this.walkable({ x: p.x, y: next.y }) && (!this.field || this.segment(p, { x: p.x, y: next.y })))
      return { x: p.x, y: next.y };
    return p;
  }
};

// src/game/world/generated/browserTerrain.ts
function decodeRuns(input, count) {
  if (!Number.isSafeInteger(count) || count < 1 || count > 16e6 || !Array.isArray(input))
    throw new Error("Invalid CPU grid size");
  const result = new Uint8Array(count);
  let at = 0;
  for (const run of input) {
    if (!Array.isArray(run) || run.length !== 2 || !Number.isInteger(run[0]) || run[0] < 0 || run[0] > 255 || !Number.isSafeInteger(run[1]) || run[1] < 1 || at + run[1] > count)
      throw new Error("Invalid CPU grid run");
    result.fill(run[0], at, at + run[1]);
    at += run[1];
  }
  if (at !== count) throw new Error("Incomplete CPU grid");
  return result;
}
function browserNavigation(width, height, navigation, terrain, colliders) {
  if (navigation.cell !== 16 || terrain.cell !== 32 || navigation.width * 16 !== width || navigation.height * 16 !== height || terrain.width * 32 !== width || terrain.height * 32 !== height)
    throw new Error("CPU grid geometry mismatch");
  const blocked = decodeRuns(navigation.blocked, navigation.width * navigation.height), flags = decodeRuns(terrain.flags, terrain.width * terrain.height);
  if (blocked.some((v) => v > 1)) throw new Error("Invalid CPU navigation occupancy");
  const index = /* @__PURE__ */ new Map();
  for (const r of colliders) {
    if (![r.x, r.y, r.width, r.height].every(Number.isFinite) || r.width <= 0 || r.height <= 0 || r.x < 0 || r.y < 0 || r.x + r.width > width + 1 || r.y + r.height > height + 1)
      throw new Error("Invalid CPU collider");
    for (let y = Math.floor(r.y / 256); y <= Math.floor((r.y + r.height) / 256); y++)
      for (let x = Math.floor(r.x / 256); x <= Math.floor((r.x + r.width) / 256); x++) {
        const key = x + ":" + y;
        const list = index.get(key) ?? [];
        list.push(r);
        index.set(key, list);
      }
  }
  const walkable = (p) => {
    if (!Number.isFinite(p.x) || !Number.isFinite(p.y) || p.x < WORLD_EDGE_MARGIN || p.y < WORLD_EDGE_MARGIN || p.x > width - WORLD_EDGE_MARGIN || p.y > height - WORLD_EDGE_MARGIN)
      return false;
    for (let y = Math.max(0, Math.floor((p.y - FOOT_RADIUS) / 32)); y <= Math.min(terrain.height - 1, Math.floor((p.y + FOOT_RADIUS) / 32)); y++)
      for (let x = Math.max(0, Math.floor((p.x - FOOT_RADIUS) / 32)); x <= Math.min(terrain.width - 1, Math.floor((p.x + FOOT_RADIUS) / 32)); x++)
        if (!(flags[y * terrain.width + x] & 1) && blockedAt(p.x, p.y, [{ x: x * 32, y: y * 32, width: 32, height: 32 }]))
          return false;
    for (let y = Math.floor((p.y - FOOT_RADIUS) / 256); y <= Math.floor((p.y + FOOT_RADIUS) / 256); y++)
      for (let x = Math.floor((p.x - FOOT_RADIUS) / 256); x <= Math.floor((p.x + FOOT_RADIUS) / 256); x++)
        if (blockedAt(p.x, p.y, index.get(x + ":" + y) ?? [])) return false;
    return true;
  };
  return new Navigation(width, height, [], { cell: 16, blocked, walkable });
}

// scripts/worldgen/check-navigation.ts
var root = process.argv[2];
var feature = process.argv[3];
if (!root || !feature) throw Error("Usage: check-navigation ROOT FEATURE [REPORT]");
var read = (name) => JSON.parse(readFileSync(join(root, feature, name), "utf8"));
var world = read("world.json");
var fixtures = read("collision-fixtures.json");
var nav = browserNavigation(
  world.geometry.width,
  world.geometry.height,
  read("navigation.json"),
  read("terrain.json"),
  read("collision.json")
);
var collisionChecks = 0;
for (const fixture of fixtures) {
  if (nav.walkable(fixture) !== fixture.walkable)
    throw Error("Python/TypeScript collision mismatch " + JSON.stringify(fixture));
  collisionChecks++;
}
var anchors = read("navigation-anchors.json");
var selected = [
  ...anchors.slice(0, 8),
  ...anchors.filter((a) => a.id.startsWith("accepted-")),
  ...anchors.slice(-4)
];
var start = anchors[0].point;
var paths = 0;
var segments = 0;
var started = performance.now();
for (const target of selected) {
  const path = nav.path(start, target.point);
  if (!path.length) throw Error("Game Navigation found no path: " + target.id);
  let from = start;
  for (const to of path) {
    const steps = Math.max(1, Math.ceil(distance(from, to) / 4));
    for (let i = 0; i <= steps; i++) {
      const p = {
        x: from.x + (to.x - from.x) * i / steps,
        y: from.y + (to.y - from.y) * i / steps
      };
      if (!nav.walkable(p)) throw Error("Engine route intersects collider: " + target.id);
    }
    from = to;
    segments++;
  }
  paths++;
}
var report = {
  feature,
  passed: true,
  engine: "src/game/navigation.ts",
  collisionChecks,
  paths,
  segments,
  seconds: Math.round((performance.now() - started) / 10) / 100,
  footRadius: 12
};
if (process.argv[4]) writeFileSync(process.argv[4], JSON.stringify(report, null, 2));
console.log(JSON.stringify(report));
