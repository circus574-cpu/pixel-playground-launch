var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// scripts/worldgen/simulate-balance.ts
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";

// src/game/nickname.ts
var NICK_MIN = 3;
var NICK_MAX = 16;
var ALLOWED = /^[\p{L}\p{N}][\p{L}\p{N} _'-]*$/u;
var normalizeNick = (raw) => raw.trim().replace(/\s+/g, " ");
function nickError(raw) {
  const nick = normalizeNick(raw);
  if (!nick) return "";
  if ([...nick].length < NICK_MIN) return `Nick ma co najmniej ${NICK_MIN} znaki.`;
  if ([...nick].length > NICK_MAX) return `Nick ma najwy\u017Cej ${NICK_MAX} znak\xF3w.`;
  if (!ALLOWED.test(nick))
    return "Dozwolone s\u0105 litery, cyfry, spacja oraz znaki _ - ' (zacznij od litery lub cyfry).";
  return "";
}
var isValidNick = (nick) => nick === normalizeNick(nick) && nickError(nick) === "" && nick !== "";

// node_modules/zod/v3/external.js
var external_exports = {};
__export(external_exports, {
  BRAND: () => BRAND,
  DIRTY: () => DIRTY,
  EMPTY_PATH: () => EMPTY_PATH,
  INVALID: () => INVALID,
  NEVER: () => NEVER,
  OK: () => OK,
  ParseStatus: () => ParseStatus,
  Schema: () => ZodType,
  ZodAny: () => ZodAny,
  ZodArray: () => ZodArray,
  ZodBigInt: () => ZodBigInt,
  ZodBoolean: () => ZodBoolean,
  ZodBranded: () => ZodBranded,
  ZodCatch: () => ZodCatch,
  ZodDate: () => ZodDate,
  ZodDefault: () => ZodDefault,
  ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
  ZodEffects: () => ZodEffects,
  ZodEnum: () => ZodEnum,
  ZodError: () => ZodError,
  ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
  ZodFunction: () => ZodFunction,
  ZodIntersection: () => ZodIntersection,
  ZodIssueCode: () => ZodIssueCode,
  ZodLazy: () => ZodLazy,
  ZodLiteral: () => ZodLiteral,
  ZodMap: () => ZodMap,
  ZodNaN: () => ZodNaN,
  ZodNativeEnum: () => ZodNativeEnum,
  ZodNever: () => ZodNever,
  ZodNull: () => ZodNull,
  ZodNullable: () => ZodNullable,
  ZodNumber: () => ZodNumber,
  ZodObject: () => ZodObject,
  ZodOptional: () => ZodOptional,
  ZodParsedType: () => ZodParsedType,
  ZodPipeline: () => ZodPipeline,
  ZodPromise: () => ZodPromise,
  ZodReadonly: () => ZodReadonly,
  ZodRecord: () => ZodRecord,
  ZodSchema: () => ZodType,
  ZodSet: () => ZodSet,
  ZodString: () => ZodString,
  ZodSymbol: () => ZodSymbol,
  ZodTransformer: () => ZodEffects,
  ZodTuple: () => ZodTuple,
  ZodType: () => ZodType,
  ZodUndefined: () => ZodUndefined,
  ZodUnion: () => ZodUnion,
  ZodUnknown: () => ZodUnknown,
  ZodVoid: () => ZodVoid,
  addIssueToContext: () => addIssueToContext,
  any: () => anyType,
  array: () => arrayType,
  bigint: () => bigIntType,
  boolean: () => booleanType,
  coerce: () => coerce,
  custom: () => custom,
  date: () => dateType,
  datetimeRegex: () => datetimeRegex,
  defaultErrorMap: () => en_default,
  discriminatedUnion: () => discriminatedUnionType,
  effect: () => effectsType,
  enum: () => enumType,
  function: () => functionType,
  getErrorMap: () => getErrorMap,
  getParsedType: () => getParsedType,
  instanceof: () => instanceOfType,
  intersection: () => intersectionType,
  isAborted: () => isAborted,
  isAsync: () => isAsync,
  isDirty: () => isDirty,
  isValid: () => isValid,
  late: () => late,
  lazy: () => lazyType,
  literal: () => literalType,
  makeIssue: () => makeIssue,
  map: () => mapType,
  nan: () => nanType,
  nativeEnum: () => nativeEnumType,
  never: () => neverType,
  null: () => nullType,
  nullable: () => nullableType,
  number: () => numberType,
  object: () => objectType,
  objectUtil: () => objectUtil,
  oboolean: () => oboolean,
  onumber: () => onumber,
  optional: () => optionalType,
  ostring: () => ostring,
  pipeline: () => pipelineType,
  preprocess: () => preprocessType,
  promise: () => promiseType,
  quotelessJson: () => quotelessJson,
  record: () => recordType,
  set: () => setType,
  setErrorMap: () => setErrorMap,
  strictObject: () => strictObjectType,
  string: () => stringType,
  symbol: () => symbolType,
  transformer: () => effectsType,
  tuple: () => tupleType,
  undefined: () => undefinedType,
  union: () => unionType,
  unknown: () => unknownType,
  util: () => util,
  void: () => voidType
});

// node_modules/zod/v3/helpers/util.js
var util;
(function(util2) {
  util2.assertEqual = (_) => {
  };
  function assertIs(_arg) {
  }
  util2.assertIs = assertIs;
  function assertNever(_x) {
    throw new Error();
  }
  util2.assertNever = assertNever;
  util2.arrayToEnum = (items) => {
    const obj = {};
    for (const item of items) {
      obj[item] = item;
    }
    return obj;
  };
  util2.getValidEnumValues = (obj) => {
    const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
    const filtered = {};
    for (const k of validKeys) {
      filtered[k] = obj[k];
    }
    return util2.objectValues(filtered);
  };
  util2.objectValues = (obj) => {
    return util2.objectKeys(obj).map(function(e) {
      return obj[e];
    });
  };
  util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
    const keys = [];
    for (const key in object) {
      if (Object.prototype.hasOwnProperty.call(object, key)) {
        keys.push(key);
      }
    }
    return keys;
  };
  util2.find = (arr, checker) => {
    for (const item of arr) {
      if (checker(item))
        return item;
    }
    return void 0;
  };
  util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
  function joinValues(array, separator = " | ") {
    return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
  }
  util2.joinValues = joinValues;
  util2.jsonStringifyReplacer = (_, value) => {
    if (typeof value === "bigint") {
      return value.toString();
    }
    return value;
  };
})(util || (util = {}));
var objectUtil;
(function(objectUtil2) {
  objectUtil2.mergeShapes = (first, second) => {
    return {
      ...first,
      ...second
      // second overwrites first
    };
  };
})(objectUtil || (objectUtil = {}));
var ZodParsedType = util.arrayToEnum([
  "string",
  "nan",
  "number",
  "integer",
  "float",
  "boolean",
  "date",
  "bigint",
  "symbol",
  "function",
  "undefined",
  "null",
  "array",
  "object",
  "unknown",
  "promise",
  "void",
  "never",
  "map",
  "set"
]);
var getParsedType = (data) => {
  const t = typeof data;
  switch (t) {
    case "undefined":
      return ZodParsedType.undefined;
    case "string":
      return ZodParsedType.string;
    case "number":
      return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
    case "boolean":
      return ZodParsedType.boolean;
    case "function":
      return ZodParsedType.function;
    case "bigint":
      return ZodParsedType.bigint;
    case "symbol":
      return ZodParsedType.symbol;
    case "object":
      if (Array.isArray(data)) {
        return ZodParsedType.array;
      }
      if (data === null) {
        return ZodParsedType.null;
      }
      if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
        return ZodParsedType.promise;
      }
      if (typeof Map !== "undefined" && data instanceof Map) {
        return ZodParsedType.map;
      }
      if (typeof Set !== "undefined" && data instanceof Set) {
        return ZodParsedType.set;
      }
      if (typeof Date !== "undefined" && data instanceof Date) {
        return ZodParsedType.date;
      }
      return ZodParsedType.object;
    default:
      return ZodParsedType.unknown;
  }
};

// node_modules/zod/v3/ZodError.js
var ZodIssueCode = util.arrayToEnum([
  "invalid_type",
  "invalid_literal",
  "custom",
  "invalid_union",
  "invalid_union_discriminator",
  "invalid_enum_value",
  "unrecognized_keys",
  "invalid_arguments",
  "invalid_return_type",
  "invalid_date",
  "invalid_string",
  "too_small",
  "too_big",
  "invalid_intersection_types",
  "not_multiple_of",
  "not_finite"
]);
var quotelessJson = (obj) => {
  const json = JSON.stringify(obj, null, 2);
  return json.replace(/"([^"]+)":/g, "$1:");
};
var ZodError = class _ZodError extends Error {
  get errors() {
    return this.issues;
  }
  constructor(issues) {
    super();
    this.issues = [];
    this.addIssue = (sub) => {
      this.issues = [...this.issues, sub];
    };
    this.addIssues = (subs = []) => {
      this.issues = [...this.issues, ...subs];
    };
    const actualProto = new.target.prototype;
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(this, actualProto);
    } else {
      this.__proto__ = actualProto;
    }
    this.name = "ZodError";
    this.issues = issues;
  }
  format(_mapper) {
    const mapper = _mapper || function(issue) {
      return issue.message;
    };
    const fieldErrors = { _errors: [] };
    const processError = (error) => {
      for (const issue of error.issues) {
        if (issue.code === "invalid_union") {
          issue.unionErrors.map(processError);
        } else if (issue.code === "invalid_return_type") {
          processError(issue.returnTypeError);
        } else if (issue.code === "invalid_arguments") {
          processError(issue.argumentsError);
        } else if (issue.path.length === 0) {
          fieldErrors._errors.push(mapper(issue));
        } else {
          let curr = fieldErrors;
          let i = 0;
          while (i < issue.path.length) {
            const el = issue.path[i];
            const terminal = i === issue.path.length - 1;
            if (!terminal) {
              curr[el] = curr[el] || { _errors: [] };
            } else {
              curr[el] = curr[el] || { _errors: [] };
              curr[el]._errors.push(mapper(issue));
            }
            curr = curr[el];
            i++;
          }
        }
      }
    };
    processError(this);
    return fieldErrors;
  }
  static assert(value) {
    if (!(value instanceof _ZodError)) {
      throw new Error(`Not a ZodError: ${value}`);
    }
  }
  toString() {
    return this.message;
  }
  get message() {
    return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
  }
  get isEmpty() {
    return this.issues.length === 0;
  }
  flatten(mapper = (issue) => issue.message) {
    const fieldErrors = {};
    const formErrors = [];
    for (const sub of this.issues) {
      if (sub.path.length > 0) {
        const firstEl = sub.path[0];
        fieldErrors[firstEl] = fieldErrors[firstEl] || [];
        fieldErrors[firstEl].push(mapper(sub));
      } else {
        formErrors.push(mapper(sub));
      }
    }
    return { formErrors, fieldErrors };
  }
  get formErrors() {
    return this.flatten();
  }
};
ZodError.create = (issues) => {
  const error = new ZodError(issues);
  return error;
};

// node_modules/zod/v3/locales/en.js
var errorMap = (issue, _ctx) => {
  let message;
  switch (issue.code) {
    case ZodIssueCode.invalid_type:
      if (issue.received === ZodParsedType.undefined) {
        message = "Required";
      } else {
        message = `Expected ${issue.expected}, received ${issue.received}`;
      }
      break;
    case ZodIssueCode.invalid_literal:
      message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
      break;
    case ZodIssueCode.unrecognized_keys:
      message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
      break;
    case ZodIssueCode.invalid_union:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_union_discriminator:
      message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
      break;
    case ZodIssueCode.invalid_enum_value:
      message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
      break;
    case ZodIssueCode.invalid_arguments:
      message = `Invalid function arguments`;
      break;
    case ZodIssueCode.invalid_return_type:
      message = `Invalid function return type`;
      break;
    case ZodIssueCode.invalid_date:
      message = `Invalid date`;
      break;
    case ZodIssueCode.invalid_string:
      if (typeof issue.validation === "object") {
        if ("includes" in issue.validation) {
          message = `Invalid input: must include "${issue.validation.includes}"`;
          if (typeof issue.validation.position === "number") {
            message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
          }
        } else if ("startsWith" in issue.validation) {
          message = `Invalid input: must start with "${issue.validation.startsWith}"`;
        } else if ("endsWith" in issue.validation) {
          message = `Invalid input: must end with "${issue.validation.endsWith}"`;
        } else {
          util.assertNever(issue.validation);
        }
      } else if (issue.validation !== "regex") {
        message = `Invalid ${issue.validation}`;
      } else {
        message = "Invalid";
      }
      break;
    case ZodIssueCode.too_small:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "bigint")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.too_big:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "bigint")
        message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.custom:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_intersection_types:
      message = `Intersection results could not be merged`;
      break;
    case ZodIssueCode.not_multiple_of:
      message = `Number must be a multiple of ${issue.multipleOf}`;
      break;
    case ZodIssueCode.not_finite:
      message = "Number must be finite";
      break;
    default:
      message = _ctx.defaultError;
      util.assertNever(issue);
  }
  return { message };
};
var en_default = errorMap;

// node_modules/zod/v3/errors.js
var overrideErrorMap = en_default;
function setErrorMap(map) {
  overrideErrorMap = map;
}
function getErrorMap() {
  return overrideErrorMap;
}

// node_modules/zod/v3/helpers/parseUtil.js
var makeIssue = (params) => {
  const { data, path, errorMaps, issueData } = params;
  const fullPath = [...path, ...issueData.path || []];
  const fullIssue = {
    ...issueData,
    path: fullPath
  };
  if (issueData.message !== void 0) {
    return {
      ...issueData,
      path: fullPath,
      message: issueData.message
    };
  }
  let errorMessage = "";
  const maps = errorMaps.filter((m) => !!m).slice().reverse();
  for (const map of maps) {
    errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
  }
  return {
    ...issueData,
    path: fullPath,
    message: errorMessage
  };
};
var EMPTY_PATH = [];
function addIssueToContext(ctx, issueData) {
  const overrideMap = getErrorMap();
  const issue = makeIssue({
    issueData,
    data: ctx.data,
    path: ctx.path,
    errorMaps: [
      ctx.common.contextualErrorMap,
      // contextual error map is first priority
      ctx.schemaErrorMap,
      // then schema-bound map if available
      overrideMap,
      // then global override map
      overrideMap === en_default ? void 0 : en_default
      // then global default map
    ].filter((x) => !!x)
  });
  ctx.common.issues.push(issue);
}
var ParseStatus = class _ParseStatus {
  constructor() {
    this.value = "valid";
  }
  dirty() {
    if (this.value === "valid")
      this.value = "dirty";
  }
  abort() {
    if (this.value !== "aborted")
      this.value = "aborted";
  }
  static mergeArray(status2, results2) {
    const arrayValue = [];
    for (const s of results2) {
      if (s.status === "aborted")
        return INVALID;
      if (s.status === "dirty")
        status2.dirty();
      arrayValue.push(s.value);
    }
    return { status: status2.value, value: arrayValue };
  }
  static async mergeObjectAsync(status2, pairs) {
    const syncPairs = [];
    for (const pair of pairs) {
      const key = await pair.key;
      const value = await pair.value;
      syncPairs.push({
        key,
        value
      });
    }
    return _ParseStatus.mergeObjectSync(status2, syncPairs);
  }
  static mergeObjectSync(status2, pairs) {
    const finalObject = {};
    for (const pair of pairs) {
      const { key, value } = pair;
      if (key.status === "aborted")
        return INVALID;
      if (value.status === "aborted")
        return INVALID;
      if (key.status === "dirty")
        status2.dirty();
      if (value.status === "dirty")
        status2.dirty();
      if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
        finalObject[key.value] = value.value;
      }
    }
    return { status: status2.value, value: finalObject };
  }
};
var INVALID = Object.freeze({
  status: "aborted"
});
var DIRTY = (value) => ({ status: "dirty", value });
var OK = (value) => ({ status: "valid", value });
var isAborted = (x) => x.status === "aborted";
var isDirty = (x) => x.status === "dirty";
var isValid = (x) => x.status === "valid";
var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

// node_modules/zod/v3/helpers/errorUtil.js
var errorUtil;
(function(errorUtil2) {
  errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
  errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
})(errorUtil || (errorUtil = {}));

// node_modules/zod/v3/types.js
var ParseInputLazyPath = class {
  constructor(parent, value, path, key) {
    this._cachedPath = [];
    this.parent = parent;
    this.data = value;
    this._path = path;
    this._key = key;
  }
  get path() {
    if (!this._cachedPath.length) {
      if (Array.isArray(this._key)) {
        this._cachedPath.push(...this._path, ...this._key);
      } else {
        this._cachedPath.push(...this._path, this._key);
      }
    }
    return this._cachedPath;
  }
};
var handleResult = (ctx, result) => {
  if (isValid(result)) {
    return { success: true, data: result.value };
  } else {
    if (!ctx.common.issues.length) {
      throw new Error("Validation failed but no issues detected.");
    }
    return {
      success: false,
      get error() {
        if (this._error)
          return this._error;
        const error = new ZodError(ctx.common.issues);
        this._error = error;
        return this._error;
      }
    };
  }
};
function processCreateParams(params) {
  if (!params)
    return {};
  const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
  if (errorMap2 && (invalid_type_error || required_error)) {
    throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
  }
  if (errorMap2)
    return { errorMap: errorMap2, description };
  const customMap = (iss, ctx) => {
    const { message } = params;
    if (iss.code === "invalid_enum_value") {
      return { message: message ?? ctx.defaultError };
    }
    if (typeof ctx.data === "undefined") {
      return { message: message ?? required_error ?? ctx.defaultError };
    }
    if (iss.code !== "invalid_type")
      return { message: ctx.defaultError };
    return { message: message ?? invalid_type_error ?? ctx.defaultError };
  };
  return { errorMap: customMap, description };
}
var ZodType = class {
  get description() {
    return this._def.description;
  }
  _getType(input) {
    return getParsedType(input.data);
  }
  _getOrReturnCtx(input, ctx) {
    return ctx || {
      common: input.parent.common,
      data: input.data,
      parsedType: getParsedType(input.data),
      schemaErrorMap: this._def.errorMap,
      path: input.path,
      parent: input.parent
    };
  }
  _processInputParams(input) {
    return {
      status: new ParseStatus(),
      ctx: {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      }
    };
  }
  _parseSync(input) {
    const result = this._parse(input);
    if (isAsync(result)) {
      throw new Error("Synchronous parse encountered promise.");
    }
    return result;
  }
  _parseAsync(input) {
    const result = this._parse(input);
    return Promise.resolve(result);
  }
  parse(data, params) {
    const result = this.safeParse(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  safeParse(data, params) {
    const ctx = {
      common: {
        issues: [],
        async: params?.async ?? false,
        contextualErrorMap: params?.errorMap
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const result = this._parseSync({ data, path: ctx.path, parent: ctx });
    return handleResult(ctx, result);
  }
  "~validate"(data) {
    const ctx = {
      common: {
        issues: [],
        async: !!this["~standard"].async
      },
      path: [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    if (!this["~standard"].async) {
      try {
        const result = this._parseSync({ data, path: [], parent: ctx });
        return isValid(result) ? {
          value: result.value
        } : {
          issues: ctx.common.issues
        };
      } catch (err) {
        if (err?.message?.toLowerCase()?.includes("encountered")) {
          this["~standard"].async = true;
        }
        ctx.common = {
          issues: [],
          async: true
        };
      }
    }
    return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
      value: result.value
    } : {
      issues: ctx.common.issues
    });
  }
  async parseAsync(data, params) {
    const result = await this.safeParseAsync(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  async safeParseAsync(data, params) {
    const ctx = {
      common: {
        issues: [],
        contextualErrorMap: params?.errorMap,
        async: true
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
    const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
    return handleResult(ctx, result);
  }
  refine(check, message) {
    const getIssueProperties = (val) => {
      if (typeof message === "string" || typeof message === "undefined") {
        return { message };
      } else if (typeof message === "function") {
        return message(val);
      } else {
        return message;
      }
    };
    return this._refinement((val, ctx) => {
      const result = check(val);
      const setError = () => ctx.addIssue({
        code: ZodIssueCode.custom,
        ...getIssueProperties(val)
      });
      if (typeof Promise !== "undefined" && result instanceof Promise) {
        return result.then((data) => {
          if (!data) {
            setError();
            return false;
          } else {
            return true;
          }
        });
      }
      if (!result) {
        setError();
        return false;
      } else {
        return true;
      }
    });
  }
  refinement(check, refinementData) {
    return this._refinement((val, ctx) => {
      if (!check(val)) {
        ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
        return false;
      } else {
        return true;
      }
    });
  }
  _refinement(refinement) {
    return new ZodEffects({
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "refinement", refinement }
    });
  }
  superRefine(refinement) {
    return this._refinement(refinement);
  }
  constructor(def) {
    this.spa = this.safeParseAsync;
    this._def = def;
    this.parse = this.parse.bind(this);
    this.safeParse = this.safeParse.bind(this);
    this.parseAsync = this.parseAsync.bind(this);
    this.safeParseAsync = this.safeParseAsync.bind(this);
    this.spa = this.spa.bind(this);
    this.refine = this.refine.bind(this);
    this.refinement = this.refinement.bind(this);
    this.superRefine = this.superRefine.bind(this);
    this.optional = this.optional.bind(this);
    this.nullable = this.nullable.bind(this);
    this.nullish = this.nullish.bind(this);
    this.array = this.array.bind(this);
    this.promise = this.promise.bind(this);
    this.or = this.or.bind(this);
    this.and = this.and.bind(this);
    this.transform = this.transform.bind(this);
    this.brand = this.brand.bind(this);
    this.default = this.default.bind(this);
    this.catch = this.catch.bind(this);
    this.describe = this.describe.bind(this);
    this.pipe = this.pipe.bind(this);
    this.readonly = this.readonly.bind(this);
    this.isNullable = this.isNullable.bind(this);
    this.isOptional = this.isOptional.bind(this);
    this["~standard"] = {
      version: 1,
      vendor: "zod",
      validate: (data) => this["~validate"](data)
    };
  }
  optional() {
    return ZodOptional.create(this, this._def);
  }
  nullable() {
    return ZodNullable.create(this, this._def);
  }
  nullish() {
    return this.nullable().optional();
  }
  array() {
    return ZodArray.create(this);
  }
  promise() {
    return ZodPromise.create(this, this._def);
  }
  or(option) {
    return ZodUnion.create([this, option], this._def);
  }
  and(incoming) {
    return ZodIntersection.create(this, incoming, this._def);
  }
  transform(transform) {
    return new ZodEffects({
      ...processCreateParams(this._def),
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "transform", transform }
    });
  }
  default(def) {
    const defaultValueFunc = typeof def === "function" ? def : () => def;
    return new ZodDefault({
      ...processCreateParams(this._def),
      innerType: this,
      defaultValue: defaultValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodDefault
    });
  }
  brand() {
    return new ZodBranded({
      typeName: ZodFirstPartyTypeKind.ZodBranded,
      type: this,
      ...processCreateParams(this._def)
    });
  }
  catch(def) {
    const catchValueFunc = typeof def === "function" ? def : () => def;
    return new ZodCatch({
      ...processCreateParams(this._def),
      innerType: this,
      catchValue: catchValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodCatch
    });
  }
  describe(description) {
    const This = this.constructor;
    return new This({
      ...this._def,
      description
    });
  }
  pipe(target) {
    return ZodPipeline.create(this, target);
  }
  readonly() {
    return ZodReadonly.create(this);
  }
  isOptional() {
    return this.safeParse(void 0).success;
  }
  isNullable() {
    return this.safeParse(null).success;
  }
};
var cuidRegex = /^c[^\s-]{8,}$/i;
var cuid2Regex = /^[0-9a-z]+$/;
var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
var nanoidRegex = /^[a-z0-9_-]{21}$/i;
var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
var emojiRegex;
var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
var dateRegex = new RegExp(`^${dateRegexSource}$`);
function timeRegexSource(args) {
  let secondsRegexSource = `[0-5]\\d`;
  if (args.precision) {
    secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
  } else if (args.precision == null) {
    secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
  }
  const secondsQuantifier = args.precision ? "+" : "?";
  return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
}
function timeRegex(args) {
  return new RegExp(`^${timeRegexSource(args)}$`);
}
function datetimeRegex(args) {
  let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
  const opts = [];
  opts.push(args.local ? `Z?` : `Z`);
  if (args.offset)
    opts.push(`([+-]\\d{2}:?\\d{2})`);
  regex = `${regex}(${opts.join("|")})`;
  return new RegExp(`^${regex}$`);
}
function isValidIP(ip, version) {
  if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
    return true;
  }
  return false;
}
function isValidJWT(jwt, alg) {
  if (!jwtRegex.test(jwt))
    return false;
  try {
    const [header] = jwt.split(".");
    if (!header)
      return false;
    const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
    const decoded = JSON.parse(atob(base64));
    if (typeof decoded !== "object" || decoded === null)
      return false;
    if ("typ" in decoded && decoded?.typ !== "JWT")
      return false;
    if (!decoded.alg)
      return false;
    if (alg && decoded.alg !== alg)
      return false;
    return true;
  } catch {
    return false;
  }
}
function isValidCidr(ip, version) {
  if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
    return true;
  }
  return false;
}
var ZodString = class _ZodString extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = String(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.string) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.string,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const status2 = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.length < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.length > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "length") {
        const tooBig = input.data.length > check.value;
        const tooSmall = input.data.length < check.value;
        if (tooBig || tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          if (tooBig) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          } else if (tooSmall) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          }
          status2.dirty();
        }
      } else if (check.kind === "email") {
        if (!emailRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "email",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "emoji") {
        if (!emojiRegex) {
          emojiRegex = new RegExp(_emojiRegex, "u");
        }
        if (!emojiRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "emoji",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "uuid") {
        if (!uuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "uuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "nanoid") {
        if (!nanoidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "nanoid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "cuid") {
        if (!cuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "cuid2") {
        if (!cuid2Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid2",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "ulid") {
        if (!ulidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ulid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "url") {
        try {
          new URL(input.data);
        } catch {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "regex") {
        check.regex.lastIndex = 0;
        const testResult = check.regex.test(input.data);
        if (!testResult) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "regex",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "trim") {
        input.data = input.data.trim();
      } else if (check.kind === "includes") {
        if (!input.data.includes(check.value, check.position)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { includes: check.value, position: check.position },
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "toLowerCase") {
        input.data = input.data.toLowerCase();
      } else if (check.kind === "toUpperCase") {
        input.data = input.data.toUpperCase();
      } else if (check.kind === "startsWith") {
        if (!input.data.startsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { startsWith: check.value },
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "endsWith") {
        if (!input.data.endsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { endsWith: check.value },
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "datetime") {
        const regex = datetimeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "datetime",
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "date") {
        const regex = dateRegex;
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "date",
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "time") {
        const regex = timeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "time",
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "duration") {
        if (!durationRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "duration",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "ip") {
        if (!isValidIP(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ip",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "jwt") {
        if (!isValidJWT(input.data, check.alg)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "jwt",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "cidr") {
        if (!isValidCidr(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cidr",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "base64") {
        if (!base64Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "base64url") {
        if (!base64urlRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status2.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status2.value, value: input.data };
  }
  _regex(regex, validation, message) {
    return this.refinement((data) => regex.test(data), {
      validation,
      code: ZodIssueCode.invalid_string,
      ...errorUtil.errToObj(message)
    });
  }
  _addCheck(check) {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  email(message) {
    return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
  }
  url(message) {
    return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
  }
  emoji(message) {
    return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
  }
  uuid(message) {
    return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
  }
  nanoid(message) {
    return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
  }
  cuid(message) {
    return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
  }
  cuid2(message) {
    return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
  }
  ulid(message) {
    return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
  }
  base64(message) {
    return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
  }
  base64url(message) {
    return this._addCheck({
      kind: "base64url",
      ...errorUtil.errToObj(message)
    });
  }
  jwt(options) {
    return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
  }
  ip(options) {
    return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
  }
  cidr(options) {
    return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
  }
  datetime(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "datetime",
        precision: null,
        offset: false,
        local: false,
        message: options
      });
    }
    return this._addCheck({
      kind: "datetime",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      offset: options?.offset ?? false,
      local: options?.local ?? false,
      ...errorUtil.errToObj(options?.message)
    });
  }
  date(message) {
    return this._addCheck({ kind: "date", message });
  }
  time(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "time",
        precision: null,
        message: options
      });
    }
    return this._addCheck({
      kind: "time",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      ...errorUtil.errToObj(options?.message)
    });
  }
  duration(message) {
    return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
  }
  regex(regex, message) {
    return this._addCheck({
      kind: "regex",
      regex,
      ...errorUtil.errToObj(message)
    });
  }
  includes(value, options) {
    return this._addCheck({
      kind: "includes",
      value,
      position: options?.position,
      ...errorUtil.errToObj(options?.message)
    });
  }
  startsWith(value, message) {
    return this._addCheck({
      kind: "startsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  endsWith(value, message) {
    return this._addCheck({
      kind: "endsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  min(minLength, message) {
    return this._addCheck({
      kind: "min",
      value: minLength,
      ...errorUtil.errToObj(message)
    });
  }
  max(maxLength, message) {
    return this._addCheck({
      kind: "max",
      value: maxLength,
      ...errorUtil.errToObj(message)
    });
  }
  length(len, message) {
    return this._addCheck({
      kind: "length",
      value: len,
      ...errorUtil.errToObj(message)
    });
  }
  /**
   * Equivalent to `.min(1)`
   */
  nonempty(message) {
    return this.min(1, errorUtil.errToObj(message));
  }
  trim() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "trim" }]
    });
  }
  toLowerCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toLowerCase" }]
    });
  }
  toUpperCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toUpperCase" }]
    });
  }
  get isDatetime() {
    return !!this._def.checks.find((ch) => ch.kind === "datetime");
  }
  get isDate() {
    return !!this._def.checks.find((ch) => ch.kind === "date");
  }
  get isTime() {
    return !!this._def.checks.find((ch) => ch.kind === "time");
  }
  get isDuration() {
    return !!this._def.checks.find((ch) => ch.kind === "duration");
  }
  get isEmail() {
    return !!this._def.checks.find((ch) => ch.kind === "email");
  }
  get isURL() {
    return !!this._def.checks.find((ch) => ch.kind === "url");
  }
  get isEmoji() {
    return !!this._def.checks.find((ch) => ch.kind === "emoji");
  }
  get isUUID() {
    return !!this._def.checks.find((ch) => ch.kind === "uuid");
  }
  get isNANOID() {
    return !!this._def.checks.find((ch) => ch.kind === "nanoid");
  }
  get isCUID() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid");
  }
  get isCUID2() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid2");
  }
  get isULID() {
    return !!this._def.checks.find((ch) => ch.kind === "ulid");
  }
  get isIP() {
    return !!this._def.checks.find((ch) => ch.kind === "ip");
  }
  get isCIDR() {
    return !!this._def.checks.find((ch) => ch.kind === "cidr");
  }
  get isBase64() {
    return !!this._def.checks.find((ch) => ch.kind === "base64");
  }
  get isBase64url() {
    return !!this._def.checks.find((ch) => ch.kind === "base64url");
  }
  get minLength() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxLength() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodString.create = (params) => {
  return new ZodString({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodString,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
function floatSafeRemainder(val, step) {
  const valDecCount = (val.toString().split(".")[1] || "").length;
  const stepDecCount = (step.toString().split(".")[1] || "").length;
  const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
  const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
  const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
  return valInt % stepInt / 10 ** decCount;
}
var ZodNumber = class _ZodNumber extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
    this.step = this.multipleOf;
  }
  _parse(input) {
    if (this._def.coerce) {
      input.data = Number(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.number) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.number,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    let ctx = void 0;
    const status2 = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "int") {
        if (!util.isInteger(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: "integer",
            received: "float",
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (floatSafeRemainder(input.data, check.value) !== 0) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "finite") {
        if (!Number.isFinite(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_finite,
            message: check.message
          });
          status2.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status2.value, value: input.data };
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodNumber({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodNumber({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  int(message) {
    return this._addCheck({
      kind: "int",
      message: errorUtil.toString(message)
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  finite(message) {
    return this._addCheck({
      kind: "finite",
      message: errorUtil.toString(message)
    });
  }
  safe(message) {
    return this._addCheck({
      kind: "min",
      inclusive: true,
      value: Number.MIN_SAFE_INTEGER,
      message: errorUtil.toString(message)
    })._addCheck({
      kind: "max",
      inclusive: true,
      value: Number.MAX_SAFE_INTEGER,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
  get isInt() {
    return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
  }
  get isFinite() {
    let max = null;
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
        return true;
      } else if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      } else if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return Number.isFinite(min) && Number.isFinite(max);
  }
};
ZodNumber.create = (params) => {
  return new ZodNumber({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodNumber,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodBigInt = class _ZodBigInt extends ZodType {
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
  }
  _parse(input) {
    if (this._def.coerce) {
      try {
        input.data = BigInt(input.data);
      } catch {
        return this._getInvalidInput(input);
      }
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.bigint) {
      return this._getInvalidInput(input);
    }
    let ctx = void 0;
    const status2 = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            type: "bigint",
            minimum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            type: "bigint",
            maximum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status2.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (input.data % check.value !== BigInt(0)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status2.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status2.value, value: input.data };
  }
  _getInvalidInput(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.bigint,
      received: ctx.parsedType
    });
    return INVALID;
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodBigInt({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodBigInt({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodBigInt.create = (params) => {
  return new ZodBigInt({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodBigInt,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
var ZodBoolean = class extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = Boolean(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.boolean) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.boolean,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodBoolean.create = (params) => {
  return new ZodBoolean({
    typeName: ZodFirstPartyTypeKind.ZodBoolean,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodDate = class _ZodDate extends ZodType {
  _parse(input) {
    if (this._def.coerce) {
      input.data = new Date(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.date) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.date,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    if (Number.isNaN(input.data.getTime())) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_date
      });
      return INVALID;
    }
    const status2 = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.getTime() < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            message: check.message,
            inclusive: true,
            exact: false,
            minimum: check.value,
            type: "date"
          });
          status2.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.getTime() > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            message: check.message,
            inclusive: true,
            exact: false,
            maximum: check.value,
            type: "date"
          });
          status2.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return {
      status: status2.value,
      value: new Date(input.data.getTime())
    };
  }
  _addCheck(check) {
    return new _ZodDate({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  min(minDate, message) {
    return this._addCheck({
      kind: "min",
      value: minDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  max(maxDate, message) {
    return this._addCheck({
      kind: "max",
      value: maxDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  get minDate() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min != null ? new Date(min) : null;
  }
  get maxDate() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max != null ? new Date(max) : null;
  }
};
ZodDate.create = (params) => {
  return new ZodDate({
    checks: [],
    coerce: params?.coerce || false,
    typeName: ZodFirstPartyTypeKind.ZodDate,
    ...processCreateParams(params)
  });
};
var ZodSymbol = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.symbol) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.symbol,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodSymbol.create = (params) => {
  return new ZodSymbol({
    typeName: ZodFirstPartyTypeKind.ZodSymbol,
    ...processCreateParams(params)
  });
};
var ZodUndefined = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.undefined,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodUndefined.create = (params) => {
  return new ZodUndefined({
    typeName: ZodFirstPartyTypeKind.ZodUndefined,
    ...processCreateParams(params)
  });
};
var ZodNull = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.null) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.null,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodNull.create = (params) => {
  return new ZodNull({
    typeName: ZodFirstPartyTypeKind.ZodNull,
    ...processCreateParams(params)
  });
};
var ZodAny = class extends ZodType {
  constructor() {
    super(...arguments);
    this._any = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodAny.create = (params) => {
  return new ZodAny({
    typeName: ZodFirstPartyTypeKind.ZodAny,
    ...processCreateParams(params)
  });
};
var ZodUnknown = class extends ZodType {
  constructor() {
    super(...arguments);
    this._unknown = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodUnknown.create = (params) => {
  return new ZodUnknown({
    typeName: ZodFirstPartyTypeKind.ZodUnknown,
    ...processCreateParams(params)
  });
};
var ZodNever = class extends ZodType {
  _parse(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.never,
      received: ctx.parsedType
    });
    return INVALID;
  }
};
ZodNever.create = (params) => {
  return new ZodNever({
    typeName: ZodFirstPartyTypeKind.ZodNever,
    ...processCreateParams(params)
  });
};
var ZodVoid = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.void,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodVoid.create = (params) => {
  return new ZodVoid({
    typeName: ZodFirstPartyTypeKind.ZodVoid,
    ...processCreateParams(params)
  });
};
var ZodArray = class _ZodArray extends ZodType {
  _parse(input) {
    const { ctx, status: status2 } = this._processInputParams(input);
    const def = this._def;
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (def.exactLength !== null) {
      const tooBig = ctx.data.length > def.exactLength.value;
      const tooSmall = ctx.data.length < def.exactLength.value;
      if (tooBig || tooSmall) {
        addIssueToContext(ctx, {
          code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
          minimum: tooSmall ? def.exactLength.value : void 0,
          maximum: tooBig ? def.exactLength.value : void 0,
          type: "array",
          inclusive: true,
          exact: true,
          message: def.exactLength.message
        });
        status2.dirty();
      }
    }
    if (def.minLength !== null) {
      if (ctx.data.length < def.minLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.minLength.message
        });
        status2.dirty();
      }
    }
    if (def.maxLength !== null) {
      if (ctx.data.length > def.maxLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.maxLength.message
        });
        status2.dirty();
      }
    }
    if (ctx.common.async) {
      return Promise.all([...ctx.data].map((item, i) => {
        return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      })).then((result2) => {
        return ParseStatus.mergeArray(status2, result2);
      });
    }
    const result = [...ctx.data].map((item, i) => {
      return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
    });
    return ParseStatus.mergeArray(status2, result);
  }
  get element() {
    return this._def.type;
  }
  min(minLength, message) {
    return new _ZodArray({
      ...this._def,
      minLength: { value: minLength, message: errorUtil.toString(message) }
    });
  }
  max(maxLength, message) {
    return new _ZodArray({
      ...this._def,
      maxLength: { value: maxLength, message: errorUtil.toString(message) }
    });
  }
  length(len, message) {
    return new _ZodArray({
      ...this._def,
      exactLength: { value: len, message: errorUtil.toString(message) }
    });
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodArray.create = (schema, params) => {
  return new ZodArray({
    type: schema,
    minLength: null,
    maxLength: null,
    exactLength: null,
    typeName: ZodFirstPartyTypeKind.ZodArray,
    ...processCreateParams(params)
  });
};
function deepPartialify(schema) {
  if (schema instanceof ZodObject) {
    const newShape = {};
    for (const key in schema.shape) {
      const fieldSchema = schema.shape[key];
      newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
    }
    return new ZodObject({
      ...schema._def,
      shape: () => newShape
    });
  } else if (schema instanceof ZodArray) {
    return new ZodArray({
      ...schema._def,
      type: deepPartialify(schema.element)
    });
  } else if (schema instanceof ZodOptional) {
    return ZodOptional.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodNullable) {
    return ZodNullable.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodTuple) {
    return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
  } else {
    return schema;
  }
}
var ZodObject = class _ZodObject extends ZodType {
  constructor() {
    super(...arguments);
    this._cached = null;
    this.nonstrict = this.passthrough;
    this.augment = this.extend;
  }
  _getCached() {
    if (this._cached !== null)
      return this._cached;
    const shape = this._def.shape();
    const keys = util.objectKeys(shape);
    this._cached = { shape, keys };
    return this._cached;
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.object) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const { status: status2, ctx } = this._processInputParams(input);
    const { shape, keys: shapeKeys } = this._getCached();
    const extraKeys = [];
    if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
      for (const key in ctx.data) {
        if (!shapeKeys.includes(key)) {
          extraKeys.push(key);
        }
      }
    }
    const pairs = [];
    for (const key of shapeKeys) {
      const keyValidator = shape[key];
      const value = ctx.data[key];
      pairs.push({
        key: { status: "valid", value: key },
        value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (this._def.catchall instanceof ZodNever) {
      const unknownKeys = this._def.unknownKeys;
      if (unknownKeys === "passthrough") {
        for (const key of extraKeys) {
          pairs.push({
            key: { status: "valid", value: key },
            value: { status: "valid", value: ctx.data[key] }
          });
        }
      } else if (unknownKeys === "strict") {
        if (extraKeys.length > 0) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.unrecognized_keys,
            keys: extraKeys
          });
          status2.dirty();
        }
      } else if (unknownKeys === "strip") {
      } else {
        throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
      }
    } else {
      const catchall = this._def.catchall;
      for (const key of extraKeys) {
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: catchall._parse(
            new ParseInputLazyPath(ctx, value, ctx.path, key)
            //, ctx.child(key), value, getParsedType(value)
          ),
          alwaysSet: key in ctx.data
        });
      }
    }
    if (ctx.common.async) {
      return Promise.resolve().then(async () => {
        const syncPairs = [];
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          syncPairs.push({
            key,
            value,
            alwaysSet: pair.alwaysSet
          });
        }
        return syncPairs;
      }).then((syncPairs) => {
        return ParseStatus.mergeObjectSync(status2, syncPairs);
      });
    } else {
      return ParseStatus.mergeObjectSync(status2, pairs);
    }
  }
  get shape() {
    return this._def.shape();
  }
  strict(message) {
    errorUtil.errToObj;
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strict",
      ...message !== void 0 ? {
        errorMap: (issue, ctx) => {
          const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
          if (issue.code === "unrecognized_keys")
            return {
              message: errorUtil.errToObj(message).message ?? defaultError
            };
          return {
            message: defaultError
          };
        }
      } : {}
    });
  }
  strip() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strip"
    });
  }
  passthrough() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "passthrough"
    });
  }
  // const AugmentFactory =
  //   <Def extends ZodObjectDef>(def: Def) =>
  //   <Augmentation extends ZodRawShape>(
  //     augmentation: Augmentation
  //   ): ZodObject<
  //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
  //     Def["unknownKeys"],
  //     Def["catchall"]
  //   > => {
  //     return new ZodObject({
  //       ...def,
  //       shape: () => ({
  //         ...def.shape(),
  //         ...augmentation,
  //       }),
  //     }) as any;
  //   };
  extend(augmentation) {
    return new _ZodObject({
      ...this._def,
      shape: () => ({
        ...this._def.shape(),
        ...augmentation
      })
    });
  }
  /**
   * Prior to zod@1.0.12 there was a bug in the
   * inferred type of merged objects. Please
   * upgrade if you are experiencing issues.
   */
  merge(merging) {
    const merged = new _ZodObject({
      unknownKeys: merging._def.unknownKeys,
      catchall: merging._def.catchall,
      shape: () => ({
        ...this._def.shape(),
        ...merging._def.shape()
      }),
      typeName: ZodFirstPartyTypeKind.ZodObject
    });
    return merged;
  }
  // merge<
  //   Incoming extends AnyZodObject,
  //   Augmentation extends Incoming["shape"],
  //   NewOutput extends {
  //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
  //       ? Augmentation[k]["_output"]
  //       : k extends keyof Output
  //       ? Output[k]
  //       : never;
  //   },
  //   NewInput extends {
  //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
  //       ? Augmentation[k]["_input"]
  //       : k extends keyof Input
  //       ? Input[k]
  //       : never;
  //   }
  // >(
  //   merging: Incoming
  // ): ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"],
  //   NewOutput,
  //   NewInput
  // > {
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  setKey(key, schema) {
    return this.augment({ [key]: schema });
  }
  // merge<Incoming extends AnyZodObject>(
  //   merging: Incoming
  // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
  // ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"]
  // > {
  //   // const mergedShape = objectUtil.mergeShapes(
  //   //   this._def.shape(),
  //   //   merging._def.shape()
  //   // );
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  catchall(index) {
    return new _ZodObject({
      ...this._def,
      catchall: index
    });
  }
  pick(mask) {
    const shape = {};
    for (const key of util.objectKeys(mask)) {
      if (mask[key] && this.shape[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  omit(mask) {
    const shape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (!mask[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => shape
    });
  }
  /**
   * @deprecated
   */
  deepPartial() {
    return deepPartialify(this);
  }
  partial(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      const fieldSchema = this.shape[key];
      if (mask && !mask[key]) {
        newShape[key] = fieldSchema;
      } else {
        newShape[key] = fieldSchema.optional();
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  required(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (mask && !mask[key]) {
        newShape[key] = this.shape[key];
      } else {
        const fieldSchema = this.shape[key];
        let newField = fieldSchema;
        while (newField instanceof ZodOptional) {
          newField = newField._def.innerType;
        }
        newShape[key] = newField;
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: () => newShape
    });
  }
  keyof() {
    return createZodEnum(util.objectKeys(this.shape));
  }
};
ZodObject.create = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.strictCreate = (shape, params) => {
  return new ZodObject({
    shape: () => shape,
    unknownKeys: "strict",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.lazycreate = (shape, params) => {
  return new ZodObject({
    shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
var ZodUnion = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const options = this._def.options;
    function handleResults(results2) {
      for (const result of results2) {
        if (result.result.status === "valid") {
          return result.result;
        }
      }
      for (const result of results2) {
        if (result.result.status === "dirty") {
          ctx.common.issues.push(...result.ctx.common.issues);
          return result.result;
        }
      }
      const unionErrors = results2.map((result) => new ZodError(result.ctx.common.issues));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return Promise.all(options.map(async (option) => {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        return {
          result: await option._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          }),
          ctx: childCtx
        };
      })).then(handleResults);
    } else {
      let dirty = void 0;
      const issues = [];
      for (const option of options) {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        const result = option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: childCtx
        });
        if (result.status === "valid") {
          return result;
        } else if (result.status === "dirty" && !dirty) {
          dirty = { result, ctx: childCtx };
        }
        if (childCtx.common.issues.length) {
          issues.push(childCtx.common.issues);
        }
      }
      if (dirty) {
        ctx.common.issues.push(...dirty.ctx.common.issues);
        return dirty.result;
      }
      const unionErrors = issues.map((issues2) => new ZodError(issues2));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
  }
  get options() {
    return this._def.options;
  }
};
ZodUnion.create = (types, params) => {
  return new ZodUnion({
    options: types,
    typeName: ZodFirstPartyTypeKind.ZodUnion,
    ...processCreateParams(params)
  });
};
var getDiscriminator = (type) => {
  if (type instanceof ZodLazy) {
    return getDiscriminator(type.schema);
  } else if (type instanceof ZodEffects) {
    return getDiscriminator(type.innerType());
  } else if (type instanceof ZodLiteral) {
    return [type.value];
  } else if (type instanceof ZodEnum) {
    return type.options;
  } else if (type instanceof ZodNativeEnum) {
    return util.objectValues(type.enum);
  } else if (type instanceof ZodDefault) {
    return getDiscriminator(type._def.innerType);
  } else if (type instanceof ZodUndefined) {
    return [void 0];
  } else if (type instanceof ZodNull) {
    return [null];
  } else if (type instanceof ZodOptional) {
    return [void 0, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodNullable) {
    return [null, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodBranded) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodReadonly) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodCatch) {
    return getDiscriminator(type._def.innerType);
  } else {
    return [];
  }
};
var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const discriminator = this.discriminator;
    const discriminatorValue = ctx.data[discriminator];
    const option = this.optionsMap.get(discriminatorValue);
    if (!option) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union_discriminator,
        options: Array.from(this.optionsMap.keys()),
        path: [discriminator]
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return option._parseAsync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    } else {
      return option._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    }
  }
  get discriminator() {
    return this._def.discriminator;
  }
  get options() {
    return this._def.options;
  }
  get optionsMap() {
    return this._def.optionsMap;
  }
  /**
   * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
   * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
   * have a different value for each object in the union.
   * @param discriminator the name of the discriminator property
   * @param types an array of object schemas
   * @param params
   */
  static create(discriminator, options, params) {
    const optionsMap = /* @__PURE__ */ new Map();
    for (const type of options) {
      const discriminatorValues = getDiscriminator(type.shape[discriminator]);
      if (!discriminatorValues.length) {
        throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
      }
      for (const value of discriminatorValues) {
        if (optionsMap.has(value)) {
          throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
        }
        optionsMap.set(value, type);
      }
    }
    return new _ZodDiscriminatedUnion({
      typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
      discriminator,
      options,
      optionsMap,
      ...processCreateParams(params)
    });
  }
};
function mergeValues(a, b) {
  const aType = getParsedType(a);
  const bType = getParsedType(b);
  if (a === b) {
    return { valid: true, data: a };
  } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
    const bKeys = util.objectKeys(b);
    const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
    const newObj = { ...a, ...b };
    for (const key of sharedKeys) {
      const sharedValue = mergeValues(a[key], b[key]);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newObj[key] = sharedValue.data;
    }
    return { valid: true, data: newObj };
  } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
    if (a.length !== b.length) {
      return { valid: false };
    }
    const newArray = [];
    for (let index = 0; index < a.length; index++) {
      const itemA = a[index];
      const itemB = b[index];
      const sharedValue = mergeValues(itemA, itemB);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newArray.push(sharedValue.data);
    }
    return { valid: true, data: newArray };
  } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
    return { valid: true, data: a };
  } else {
    return { valid: false };
  }
}
var ZodIntersection = class extends ZodType {
  _parse(input) {
    const { status: status2, ctx } = this._processInputParams(input);
    const handleParsed = (parsedLeft, parsedRight) => {
      if (isAborted(parsedLeft) || isAborted(parsedRight)) {
        return INVALID;
      }
      const merged = mergeValues(parsedLeft.value, parsedRight.value);
      if (!merged.valid) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_intersection_types
        });
        return INVALID;
      }
      if (isDirty(parsedLeft) || isDirty(parsedRight)) {
        status2.dirty();
      }
      return { status: status2.value, value: merged.data };
    };
    if (ctx.common.async) {
      return Promise.all([
        this._def.left._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }),
        this._def.right._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        })
      ]).then(([left, right]) => handleParsed(left, right));
    } else {
      return handleParsed(this._def.left._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }), this._def.right._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }));
    }
  }
};
ZodIntersection.create = (left, right, params) => {
  return new ZodIntersection({
    left,
    right,
    typeName: ZodFirstPartyTypeKind.ZodIntersection,
    ...processCreateParams(params)
  });
};
var ZodTuple = class _ZodTuple extends ZodType {
  _parse(input) {
    const { status: status2, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (ctx.data.length < this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_small,
        minimum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      return INVALID;
    }
    const rest = this._def.rest;
    if (!rest && ctx.data.length > this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_big,
        maximum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      status2.dirty();
    }
    const items = [...ctx.data].map((item, itemIndex) => {
      const schema = this._def.items[itemIndex] || this._def.rest;
      if (!schema)
        return null;
      return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
    }).filter((x) => !!x);
    if (ctx.common.async) {
      return Promise.all(items).then((results2) => {
        return ParseStatus.mergeArray(status2, results2);
      });
    } else {
      return ParseStatus.mergeArray(status2, items);
    }
  }
  get items() {
    return this._def.items;
  }
  rest(rest) {
    return new _ZodTuple({
      ...this._def,
      rest
    });
  }
};
ZodTuple.create = (schemas, params) => {
  if (!Array.isArray(schemas)) {
    throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
  }
  return new ZodTuple({
    items: schemas,
    typeName: ZodFirstPartyTypeKind.ZodTuple,
    rest: null,
    ...processCreateParams(params)
  });
};
var ZodRecord = class _ZodRecord extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status: status2, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const pairs = [];
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    for (const key in ctx.data) {
      pairs.push({
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
        value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (ctx.common.async) {
      return ParseStatus.mergeObjectAsync(status2, pairs);
    } else {
      return ParseStatus.mergeObjectSync(status2, pairs);
    }
  }
  get element() {
    return this._def.valueType;
  }
  static create(first, second, third) {
    if (second instanceof ZodType) {
      return new _ZodRecord({
        keyType: first,
        valueType: second,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(third)
      });
    }
    return new _ZodRecord({
      keyType: ZodString.create(),
      valueType: first,
      typeName: ZodFirstPartyTypeKind.ZodRecord,
      ...processCreateParams(second)
    });
  }
};
var ZodMap = class extends ZodType {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status: status2, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.map) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.map,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    const pairs = [...ctx.data.entries()].map(([key, value], index) => {
      return {
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
        value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
      };
    });
    if (ctx.common.async) {
      const finalMap = /* @__PURE__ */ new Map();
      return Promise.resolve().then(async () => {
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status2.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status2.value, value: finalMap };
      });
    } else {
      const finalMap = /* @__PURE__ */ new Map();
      for (const pair of pairs) {
        const key = pair.key;
        const value = pair.value;
        if (key.status === "aborted" || value.status === "aborted") {
          return INVALID;
        }
        if (key.status === "dirty" || value.status === "dirty") {
          status2.dirty();
        }
        finalMap.set(key.value, value.value);
      }
      return { status: status2.value, value: finalMap };
    }
  }
};
ZodMap.create = (keyType, valueType, params) => {
  return new ZodMap({
    valueType,
    keyType,
    typeName: ZodFirstPartyTypeKind.ZodMap,
    ...processCreateParams(params)
  });
};
var ZodSet = class _ZodSet extends ZodType {
  _parse(input) {
    const { status: status2, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.set) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.set,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const def = this._def;
    if (def.minSize !== null) {
      if (ctx.data.size < def.minSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.minSize.message
        });
        status2.dirty();
      }
    }
    if (def.maxSize !== null) {
      if (ctx.data.size > def.maxSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.maxSize.message
        });
        status2.dirty();
      }
    }
    const valueType = this._def.valueType;
    function finalizeSet(elements2) {
      const parsedSet = /* @__PURE__ */ new Set();
      for (const element of elements2) {
        if (element.status === "aborted")
          return INVALID;
        if (element.status === "dirty")
          status2.dirty();
        parsedSet.add(element.value);
      }
      return { status: status2.value, value: parsedSet };
    }
    const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
    if (ctx.common.async) {
      return Promise.all(elements).then((elements2) => finalizeSet(elements2));
    } else {
      return finalizeSet(elements);
    }
  }
  min(minSize, message) {
    return new _ZodSet({
      ...this._def,
      minSize: { value: minSize, message: errorUtil.toString(message) }
    });
  }
  max(maxSize, message) {
    return new _ZodSet({
      ...this._def,
      maxSize: { value: maxSize, message: errorUtil.toString(message) }
    });
  }
  size(size, message) {
    return this.min(size, message).max(size, message);
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodSet.create = (valueType, params) => {
  return new ZodSet({
    valueType,
    minSize: null,
    maxSize: null,
    typeName: ZodFirstPartyTypeKind.ZodSet,
    ...processCreateParams(params)
  });
};
var ZodFunction = class _ZodFunction extends ZodType {
  constructor() {
    super(...arguments);
    this.validate = this.implement;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.function) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.function,
        received: ctx.parsedType
      });
      return INVALID;
    }
    function makeArgsIssue(args, error) {
      return makeIssue({
        data: args,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_arguments,
          argumentsError: error
        }
      });
    }
    function makeReturnsIssue(returns, error) {
      return makeIssue({
        data: returns,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_return_type,
          returnTypeError: error
        }
      });
    }
    const params = { errorMap: ctx.common.contextualErrorMap };
    const fn = ctx.data;
    if (this._def.returns instanceof ZodPromise) {
      const me = this;
      return OK(async function(...args) {
        const error = new ZodError([]);
        const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
          error.addIssue(makeArgsIssue(args, e));
          throw error;
        });
        const result = await Reflect.apply(fn, this, parsedArgs);
        const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
          error.addIssue(makeReturnsIssue(result, e));
          throw error;
        });
        return parsedReturns;
      });
    } else {
      const me = this;
      return OK(function(...args) {
        const parsedArgs = me._def.args.safeParse(args, params);
        if (!parsedArgs.success) {
          throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
        }
        const result = Reflect.apply(fn, this, parsedArgs.data);
        const parsedReturns = me._def.returns.safeParse(result, params);
        if (!parsedReturns.success) {
          throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
        }
        return parsedReturns.data;
      });
    }
  }
  parameters() {
    return this._def.args;
  }
  returnType() {
    return this._def.returns;
  }
  args(...items) {
    return new _ZodFunction({
      ...this._def,
      args: ZodTuple.create(items).rest(ZodUnknown.create())
    });
  }
  returns(returnType) {
    return new _ZodFunction({
      ...this._def,
      returns: returnType
    });
  }
  implement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  strictImplement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  static create(args, returns, params) {
    return new _ZodFunction({
      args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
      returns: returns || ZodUnknown.create(),
      typeName: ZodFirstPartyTypeKind.ZodFunction,
      ...processCreateParams(params)
    });
  }
};
var ZodLazy = class extends ZodType {
  get schema() {
    return this._def.getter();
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const lazySchema = this._def.getter();
    return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
  }
};
ZodLazy.create = (getter, params) => {
  return new ZodLazy({
    getter,
    typeName: ZodFirstPartyTypeKind.ZodLazy,
    ...processCreateParams(params)
  });
};
var ZodLiteral = class extends ZodType {
  _parse(input) {
    if (input.data !== this._def.value) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_literal,
        expected: this._def.value
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
  get value() {
    return this._def.value;
  }
};
ZodLiteral.create = (value, params) => {
  return new ZodLiteral({
    value,
    typeName: ZodFirstPartyTypeKind.ZodLiteral,
    ...processCreateParams(params)
  });
};
function createZodEnum(values, params) {
  return new ZodEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodEnum,
    ...processCreateParams(params)
  });
}
var ZodEnum = class _ZodEnum extends ZodType {
  _parse(input) {
    if (typeof input.data !== "string") {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(this._def.values);
    }
    if (!this._cache.has(input.data)) {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get options() {
    return this._def.values;
  }
  get enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Values() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  extract(values, newDef = this._def) {
    return _ZodEnum.create(values, {
      ...this._def,
      ...newDef
    });
  }
  exclude(values, newDef = this._def) {
    return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
      ...this._def,
      ...newDef
    });
  }
};
ZodEnum.create = createZodEnum;
var ZodNativeEnum = class extends ZodType {
  _parse(input) {
    const nativeEnumValues = util.getValidEnumValues(this._def.values);
    const ctx = this._getOrReturnCtx(input);
    if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(util.getValidEnumValues(this._def.values));
    }
    if (!this._cache.has(input.data)) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get enum() {
    return this._def.values;
  }
};
ZodNativeEnum.create = (values, params) => {
  return new ZodNativeEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
    ...processCreateParams(params)
  });
};
var ZodPromise = class extends ZodType {
  unwrap() {
    return this._def.type;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.promise,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
    return OK(promisified.then((data) => {
      return this._def.type.parseAsync(data, {
        path: ctx.path,
        errorMap: ctx.common.contextualErrorMap
      });
    }));
  }
};
ZodPromise.create = (schema, params) => {
  return new ZodPromise({
    type: schema,
    typeName: ZodFirstPartyTypeKind.ZodPromise,
    ...processCreateParams(params)
  });
};
var ZodEffects = class extends ZodType {
  innerType() {
    return this._def.schema;
  }
  sourceType() {
    return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
  }
  _parse(input) {
    const { status: status2, ctx } = this._processInputParams(input);
    const effect = this._def.effect || null;
    const checkCtx = {
      addIssue: (arg2) => {
        addIssueToContext(ctx, arg2);
        if (arg2.fatal) {
          status2.abort();
        } else {
          status2.dirty();
        }
      },
      get path() {
        return ctx.path;
      }
    };
    checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
    if (effect.type === "preprocess") {
      const processed = effect.transform(ctx.data, checkCtx);
      if (ctx.common.async) {
        return Promise.resolve(processed).then(async (processed2) => {
          if (status2.value === "aborted")
            return INVALID;
          const result = await this._def.schema._parseAsync({
            data: processed2,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status2.value === "dirty")
            return DIRTY(result.value);
          return result;
        });
      } else {
        if (status2.value === "aborted")
          return INVALID;
        const result = this._def.schema._parseSync({
          data: processed,
          path: ctx.path,
          parent: ctx
        });
        if (result.status === "aborted")
          return INVALID;
        if (result.status === "dirty")
          return DIRTY(result.value);
        if (status2.value === "dirty")
          return DIRTY(result.value);
        return result;
      }
    }
    if (effect.type === "refinement") {
      const executeRefinement = (acc) => {
        const result = effect.refinement(acc, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(result);
        }
        if (result instanceof Promise) {
          throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
        }
        return acc;
      };
      if (ctx.common.async === false) {
        const inner = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inner.status === "aborted")
          return INVALID;
        if (inner.status === "dirty")
          status2.dirty();
        executeRefinement(inner.value);
        return { status: status2.value, value: inner.value };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status2.dirty();
          return executeRefinement(inner.value).then(() => {
            return { status: status2.value, value: inner.value };
          });
        });
      }
    }
    if (effect.type === "transform") {
      if (ctx.common.async === false) {
        const base = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (!isValid(base))
          return INVALID;
        const result = effect.transform(base.value, checkCtx);
        if (result instanceof Promise) {
          throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
        }
        return { status: status2.value, value: result };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
          if (!isValid(base))
            return INVALID;
          return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
            status: status2.value,
            value: result
          }));
        });
      }
    }
    util.assertNever(effect);
  }
};
ZodEffects.create = (schema, effect, params) => {
  return new ZodEffects({
    schema,
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    effect,
    ...processCreateParams(params)
  });
};
ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
  return new ZodEffects({
    schema,
    effect: { type: "preprocess", transform: preprocess },
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    ...processCreateParams(params)
  });
};
var ZodOptional = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.undefined) {
      return OK(void 0);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodOptional.create = (type, params) => {
  return new ZodOptional({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodOptional,
    ...processCreateParams(params)
  });
};
var ZodNullable = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.null) {
      return OK(null);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodNullable.create = (type, params) => {
  return new ZodNullable({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodNullable,
    ...processCreateParams(params)
  });
};
var ZodDefault = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    let data = ctx.data;
    if (ctx.parsedType === ZodParsedType.undefined) {
      data = this._def.defaultValue();
    }
    return this._def.innerType._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  removeDefault() {
    return this._def.innerType;
  }
};
ZodDefault.create = (type, params) => {
  return new ZodDefault({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodDefault,
    defaultValue: typeof params.default === "function" ? params.default : () => params.default,
    ...processCreateParams(params)
  });
};
var ZodCatch = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const newCtx = {
      ...ctx,
      common: {
        ...ctx.common,
        issues: []
      }
    };
    const result = this._def.innerType._parse({
      data: newCtx.data,
      path: newCtx.path,
      parent: {
        ...newCtx
      }
    });
    if (isAsync(result)) {
      return result.then((result2) => {
        return {
          status: "valid",
          value: result2.status === "valid" ? result2.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      });
    } else {
      return {
        status: "valid",
        value: result.status === "valid" ? result.value : this._def.catchValue({
          get error() {
            return new ZodError(newCtx.common.issues);
          },
          input: newCtx.data
        })
      };
    }
  }
  removeCatch() {
    return this._def.innerType;
  }
};
ZodCatch.create = (type, params) => {
  return new ZodCatch({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodCatch,
    catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
    ...processCreateParams(params)
  });
};
var ZodNaN = class extends ZodType {
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.nan) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.nan,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
};
ZodNaN.create = (params) => {
  return new ZodNaN({
    typeName: ZodFirstPartyTypeKind.ZodNaN,
    ...processCreateParams(params)
  });
};
var BRAND = /* @__PURE__ */ Symbol("zod_brand");
var ZodBranded = class extends ZodType {
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const data = ctx.data;
    return this._def.type._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  unwrap() {
    return this._def.type;
  }
};
var ZodPipeline = class _ZodPipeline extends ZodType {
  _parse(input) {
    const { status: status2, ctx } = this._processInputParams(input);
    if (ctx.common.async) {
      const handleAsync = async () => {
        const inResult = await this._def.in._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status2.dirty();
          return DIRTY(inResult.value);
        } else {
          return this._def.out._parseAsync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      };
      return handleAsync();
    } else {
      const inResult = this._def.in._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
      if (inResult.status === "aborted")
        return INVALID;
      if (inResult.status === "dirty") {
        status2.dirty();
        return {
          status: "dirty",
          value: inResult.value
        };
      } else {
        return this._def.out._parseSync({
          data: inResult.value,
          path: ctx.path,
          parent: ctx
        });
      }
    }
  }
  static create(a, b) {
    return new _ZodPipeline({
      in: a,
      out: b,
      typeName: ZodFirstPartyTypeKind.ZodPipeline
    });
  }
};
var ZodReadonly = class extends ZodType {
  _parse(input) {
    const result = this._def.innerType._parse(input);
    const freeze = (data) => {
      if (isValid(data)) {
        data.value = Object.freeze(data.value);
      }
      return data;
    };
    return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodReadonly.create = (type, params) => {
  return new ZodReadonly({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodReadonly,
    ...processCreateParams(params)
  });
};
function cleanParams(params, data) {
  const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
  const p2 = typeof p === "string" ? { message: p } : p;
  return p2;
}
function custom(check, _params = {}, fatal) {
  if (check)
    return ZodAny.create().superRefine((data, ctx) => {
      const r = check(data);
      if (r instanceof Promise) {
        return r.then((r2) => {
          if (!r2) {
            const params = cleanParams(_params, data);
            const _fatal = params.fatal ?? fatal ?? true;
            ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
          }
        });
      }
      if (!r) {
        const params = cleanParams(_params, data);
        const _fatal = params.fatal ?? fatal ?? true;
        ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
      }
      return;
    });
  return ZodAny.create();
}
var late = {
  object: ZodObject.lazycreate
};
var ZodFirstPartyTypeKind;
(function(ZodFirstPartyTypeKind2) {
  ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
  ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
  ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
  ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
  ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
  ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
  ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
  ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
  ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
  ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
  ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
  ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
  ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
  ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
  ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
  ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
  ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
  ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
  ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
  ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
  ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
  ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
  ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
  ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
  ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
  ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
  ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
  ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
  ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
  ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
  ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
  ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
  ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
  ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
  ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
  ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
})(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
var instanceOfType = (cls, params = {
  message: `Input not instance of ${cls.name}`
}) => custom((data) => data instanceof cls, params);
var stringType = ZodString.create;
var numberType = ZodNumber.create;
var nanType = ZodNaN.create;
var bigIntType = ZodBigInt.create;
var booleanType = ZodBoolean.create;
var dateType = ZodDate.create;
var symbolType = ZodSymbol.create;
var undefinedType = ZodUndefined.create;
var nullType = ZodNull.create;
var anyType = ZodAny.create;
var unknownType = ZodUnknown.create;
var neverType = ZodNever.create;
var voidType = ZodVoid.create;
var arrayType = ZodArray.create;
var objectType = ZodObject.create;
var strictObjectType = ZodObject.strictCreate;
var unionType = ZodUnion.create;
var discriminatedUnionType = ZodDiscriminatedUnion.create;
var intersectionType = ZodIntersection.create;
var tupleType = ZodTuple.create;
var recordType = ZodRecord.create;
var mapType = ZodMap.create;
var setType = ZodSet.create;
var functionType = ZodFunction.create;
var lazyType = ZodLazy.create;
var literalType = ZodLiteral.create;
var enumType = ZodEnum.create;
var nativeEnumType = ZodNativeEnum.create;
var promiseType = ZodPromise.create;
var effectsType = ZodEffects.create;
var optionalType = ZodOptional.create;
var nullableType = ZodNullable.create;
var preprocessType = ZodEffects.createWithPreprocess;
var pipelineType = ZodPipeline.create;
var ostring = () => stringType().optional();
var onumber = () => numberType().optional();
var oboolean = () => booleanType().optional();
var coerce = {
  string: ((arg2) => ZodString.create({ ...arg2, coerce: true })),
  number: ((arg2) => ZodNumber.create({ ...arg2, coerce: true })),
  boolean: ((arg2) => ZodBoolean.create({
    ...arg2,
    coerce: true
  })),
  bigint: ((arg2) => ZodBigInt.create({ ...arg2, coerce: true })),
  date: ((arg2) => ZodDate.create({ ...arg2, coerce: true }))
};
var NEVER = INVALID;

// src/game/world/forest-map.json
var forest_map_default = {
  version: 4,
  width: 3072,
  height: 2048,
  tileSize: 32,
  textureTileSize: 64,
  cols: 96,
  rows: 64,
  vertices: [
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      2,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      2,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      1,
      1,
      1,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      1,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      1,
      1,
      1,
      2,
      2,
      2,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2
    ],
    [
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1
    ],
    [
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      1,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      2,
      2,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      2,
      2,
      2,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      1,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      3,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ]
  ],
  layers: [
    [
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ],
      [
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3,
        0,
        1,
        2,
        3
      ],
      [
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7,
        4,
        5,
        6,
        7
      ],
      [
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11,
        8,
        9,
        10,
        11
      ],
      [
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15,
        12,
        13,
        14,
        15
      ]
    ],
    [
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        22,
        47,
        63,
        79,
        31,
        41,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        22,
        47,
        57,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        34,
        55,
        77,
        24,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        86,
        111,
        127,
        143,
        91,
        97,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        82,
        103,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        118,
        143,
        89,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        150,
        175,
        191,
        207,
        153,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        166,
        189,
        200,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        182,
        207,
        153,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        260,
        222,
        239,
        255,
        271,
        217,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        230,
        255,
        265,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        271,
        217,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        70,
        31,
        47,
        63,
        79,
        25,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        38,
        63,
        73,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        50,
        71,
        25,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        95,
        111,
        127,
        139,
        81,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        102,
        127,
        137,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        93,
        104,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        198,
        159,
        175,
        191,
        201,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        162,
        183,
        201,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        198,
        159,
        169,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        244,
        270,
        223,
        239,
        255,
        265,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        269,
        216,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        262,
        223,
        233,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        54,
        79,
        31,
        47,
        63,
        73,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        54,
        79,
        25,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        70,
        31,
        41,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        118,
        143,
        95,
        111,
        127,
        137,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        118,
        143,
        89,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        130,
        87,
        105,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        182,
        207,
        159,
        175,
        187,
        193,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        182,
        207,
        153,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        150,
        169,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        271,
        223,
        239,
        249,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        271,
        217,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        214,
        233,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        54,
        79,
        31,
        47,
        57,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        54,
        79,
        25,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        22,
        41,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        100,
        126,
        143,
        95,
        111,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        118,
        143,
        89,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        86,
        105,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        166,
        191,
        207,
        159,
        175,
        185,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        182,
        207,
        153,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        150,
        169,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        230,
        255,
        271,
        223,
        239,
        249,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        271,
        217,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        214,
        233,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        38,
        63,
        79,
        31,
        47,
        57,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        54,
        79,
        25,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        68,
        30,
        41,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        102,
        127,
        143,
        95,
        111,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        118,
        143,
        89,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        95,
        105,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        166,
        191,
        207,
        159,
        175,
        185,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        182,
        203,
        145,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        198,
        159,
        169,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        230,
        255,
        271,
        223,
        239,
        249,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        265,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        262,
        223,
        233,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        38,
        63,
        79,
        31,
        47,
        57,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        36,
        62,
        73,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        70,
        31,
        41,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        98,
        119,
        143,
        95,
        111,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        102,
        127,
        137,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        91,
        97,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        182,
        207,
        159,
        175,
        185,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        166,
        191,
        201,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        180,
        206,
        153,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        271,
        223,
        239,
        249,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        260,
        220,
        232,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        230,
        251,
        257,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        271,
        217,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        68,
        28,
        40,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        54,
        79,
        31,
        47,
        61,
        76,
        28,
        40,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        70,
        31,
        41,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        20,
        46,
        57,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        54,
        79,
        25,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        95,
        105,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        84,
        108,
        126,
        143,
        95,
        111,
        127,
        143,
        95,
        109,
        124,
        136,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        95,
        105,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        86,
        111,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        118,
        139,
        81,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        198,
        159,
        169,
        -1,
        -1,
        -1,
        -1,
        -1,
        196,
        158,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        205,
        156,
        168,
        -1,
        -1,
        -1,
        -1,
        -1,
        198,
        159,
        169,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        150,
        175,
        185,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        164,
        190,
        201,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        262,
        223,
        233,
        -1,
        -1,
        -1,
        -1,
        244,
        270,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        237,
        248,
        -1,
        -1,
        -1,
        -1,
        262,
        223,
        233,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        214,
        235,
        241,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        230,
        255,
        265,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        70,
        31,
        41,
        -1,
        -1,
        -1,
        36,
        62,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        57,
        -1,
        -1,
        -1,
        -1,
        70,
        31,
        41,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        68,
        30,
        41,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        38,
        63,
        73,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        95,
        105,
        -1,
        -1,
        -1,
        102,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        121,
        -1,
        -1,
        -1,
        -1,
        134,
        95,
        105,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        95,
        105,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        102,
        127,
        141,
        92,
        108,
        124,
        140,
        92,
        108,
        124,
        140,
        92,
        108,
        124,
        140
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        198,
        159,
        169,
        180,
        204,
        156,
        174,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        189,
        200,
        -1,
        -1,
        -1,
        198,
        159,
        169,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        180,
        206,
        159,
        169,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        148,
        174,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        260,
        220,
        236,
        252,
        270,
        223,
        237,
        254,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        269,
        220,
        236,
        252,
        270,
        223,
        233,
        -1,
        260,
        220,
        236,
        252,
        268,
        220,
        236,
        254,
        271,
        219,
        225,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        214,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271
      ],
      [
        28,
        44,
        60,
        72,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        68,
        28,
        44,
        60,
        76,
        28,
        44,
        60,
        76,
        28,
        44,
        60,
        78,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        45,
        60,
        78,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        25,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        22,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79
      ],
      [
        95,
        111,
        127,
        141,
        92,
        108,
        124,
        140,
        92,
        108,
        124,
        140,
        92,
        108,
        124,
        142,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        95,
        111,
        127,
        143,
        89,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        86,
        111,
        123,
        131,
        83,
        99,
        115,
        131,
        83,
        99,
        115,
        131,
        83,
        99,
        115,
        131
      ],
      [
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        155,
        163,
        183,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        159,
        175,
        191,
        207,
        153,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        150,
        171,
        177,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        251,
        263,
        223,
        239,
        251,
        259,
        209,
        -1,
        242,
        259,
        215,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        219,
        227,
        243,
        259,
        215,
        239,
        255,
        271,
        223,
        239,
        255,
        271,
        223,
        239,
        251,
        259,
        211,
        227,
        247,
        271,
        217,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        214,
        233,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        43,
        51,
        67,
        19,
        35,
        51,
        67,
        19,
        35,
        49,
        70,
        31,
        47,
        57,
        -1,
        -1,
        -1,
        -1,
        -1,
        18,
        39,
        63,
        79,
        31,
        47,
        63,
        79,
        31,
        47,
        59,
        67,
        17,
        -1,
        -1,
        -1,
        18,
        35,
        51,
        67,
        23,
        47,
        59,
        67,
        19,
        35,
        49,
        -1,
        -1,
        -1,
        54,
        79,
        25,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        68,
        30,
        41,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        83,
        99,
        115,
        131,
        83,
        99,
        115,
        131,
        83,
        99,
        115,
        131,
        83,
        99,
        115,
        131,
        83,
        99,
        115,
        131,
        83,
        97,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        95,
        111,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        98,
        115,
        131,
        83,
        103,
        127,
        143,
        95,
        111,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        86,
        111,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        118,
        143,
        89,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        95,
        105,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        198,
        159,
        175,
        185,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        166,
        191,
        207,
        159,
        175,
        185,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        150,
        175,
        185,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        182,
        207,
        153,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        198,
        159,
        169,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        262,
        223,
        239,
        249,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        230,
        255,
        271,
        223,
        239,
        249,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        214,
        239,
        249,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        271,
        217,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        262,
        223,
        233,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        70,
        31,
        47,
        57,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        38,
        63,
        79,
        31,
        47,
        57,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        22,
        47,
        57,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        54,
        79,
        25,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        70,
        31,
        41,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        130,
        83,
        99,
        113,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        98,
        119,
        143,
        95,
        111,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        86,
        111,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        118,
        143,
        89,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        95,
        105,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        182,
        207,
        159,
        175,
        185,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        146,
        163,
        177,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        182,
        207,
        153,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        198,
        159,
        169,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        271,
        223,
        239,
        249,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        271,
        217,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        258,
        215,
        233,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        54,
        79,
        31,
        47,
        57,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        54,
        79,
        25,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        22,
        41,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        118,
        143,
        95,
        111,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        118,
        143,
        89,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        86,
        109,
        120,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        182,
        207,
        159,
        175,
        185,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        178,
        199,
        153,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        150,
        175,
        185,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        271,
        223,
        239,
        249,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        262,
        221,
        232,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        214,
        239,
        249,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        36,
        62,
        79,
        31,
        47,
        57,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        70,
        31,
        41,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        22,
        47,
        57,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        102,
        127,
        143,
        95,
        111,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        95,
        105,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        82,
        103,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        166,
        191,
        207,
        159,
        175,
        185,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        198,
        159,
        169,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        166,
        189,
        200,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        230,
        255,
        271,
        223,
        239,
        249,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        258,
        215,
        233,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        230,
        255,
        265,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        38,
        63,
        79,
        31,
        43,
        49,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        22,
        45,
        56,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        38,
        63,
        73,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        102,
        127,
        143,
        95,
        105,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        86,
        111,
        121,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        98,
        119,
        141,
        88,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        148,
        174,
        191,
        207,
        159,
        169,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        146,
        167,
        185,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        182,
        207,
        153,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        214,
        239,
        255,
        271,
        223,
        233,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        230,
        253,
        264,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        271,
        217,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        22,
        47,
        63,
        79,
        27,
        33,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        38,
        63,
        73,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        54,
        79,
        25,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        86,
        111,
        127,
        143,
        89,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        102,
        127,
        137,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        114,
        135,
        89,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        196,
        158,
        175,
        191,
        207,
        153,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        166,
        191,
        201,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        198,
        157,
        168,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        262,
        223,
        239,
        255,
        271,
        217,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        226,
        247,
        265,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        262,
        223,
        233,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        70,
        31,
        47,
        63,
        75,
        17,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        54,
        77,
        24,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        70,
        31,
        41,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        95,
        111,
        127,
        137,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        118,
        143,
        89,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        134,
        95,
        105,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        180,
        206,
        159,
        175,
        191,
        201,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        182,
        207,
        153,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        194,
        151,
        169,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        271,
        223,
        239,
        255,
        265,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        246,
        271,
        217,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        214,
        233,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ]
    ],
    [
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        294,
        319,
        335,
        281,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        358,
        383,
        399,
        345,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        404,
        430,
        447,
        459,
        401,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        470,
        495,
        511,
        521,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        278,
        303,
        319,
        329,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        342,
        367,
        383,
        393,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        452,
        414,
        431,
        443,
        449,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        518,
        479,
        495,
        505,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        326,
        287,
        303,
        313,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        390,
        351,
        367,
        377,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        454,
        415,
        431,
        441,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        500,
        526,
        479,
        495,
        505,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        310,
        335,
        287,
        299,
        305,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        374,
        399,
        351,
        361,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        438,
        463,
        415,
        425,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        502,
        527,
        479,
        489,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        310,
        335,
        287,
        297,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        374,
        399,
        351,
        361,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        438,
        463,
        415,
        425,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        502,
        527,
        479,
        489,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        310,
        335,
        287,
        297,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        374,
        399,
        351,
        361,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        438,
        463,
        415,
        429,
        440,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        498,
        519,
        479,
        495,
        505,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        326,
        287,
        303,
        313,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        372,
        398,
        351,
        367,
        381,
        396,
        348,
        360,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        404,
        428,
        446,
        463,
        415,
        431,
        447,
        463,
        415,
        429,
        444,
        456,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        516,
        478,
        495,
        511,
        527,
        479,
        495,
        511,
        527,
        479,
        495,
        511,
        525,
        472,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        308,
        334,
        287,
        303,
        319,
        335,
        287,
        303,
        319,
        335,
        287,
        303,
        319,
        335,
        285,
        296,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        374,
        399,
        351,
        367,
        383,
        399,
        351,
        367,
        383,
        399,
        351,
        367,
        383,
        399,
        351,
        365,
        376,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        372,
        396,
        348,
        364,
        380,
        396,
        348,
        364,
        380,
        396,
        348,
        364,
        380,
        396
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        438,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        441,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        438,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        468,
        492,
        508,
        524,
        476,
        492,
        510,
        527,
        479,
        495,
        511,
        527,
        479,
        495,
        511,
        527,
        479,
        495,
        511,
        527,
        479,
        495,
        505,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        468,
        492,
        508,
        520,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        502,
        527,
        479,
        495,
        511,
        527,
        479,
        495,
        511,
        527,
        479,
        495,
        511,
        527
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        292,
        316,
        332,
        284,
        300,
        316,
        332,
        286,
        303,
        319,
        335,
        287,
        303,
        319,
        335,
        287,
        303,
        319,
        335,
        287,
        303,
        319,
        335,
        287,
        303,
        319,
        335,
        287,
        303,
        317,
        332,
        284,
        300,
        316,
        332,
        284,
        300,
        316,
        332,
        284,
        300,
        316,
        332,
        286,
        303,
        315,
        321,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        306,
        323,
        275,
        291,
        307,
        323,
        275,
        291,
        307,
        323,
        275,
        291,
        307,
        323
      ],
      [
        348,
        364,
        380,
        396,
        348,
        364,
        380,
        396,
        348,
        364,
        380,
        396,
        348,
        364,
        380,
        396,
        348,
        364,
        380,
        396,
        348,
        364,
        380,
        396,
        348,
        366,
        383,
        399,
        351,
        367,
        383,
        399,
        351,
        367,
        383,
        399,
        351,
        367,
        379,
        391,
        351,
        367,
        383,
        399,
        351,
        367,
        383,
        399,
        351,
        367,
        383,
        399,
        351,
        367,
        383,
        399,
        351,
        367,
        383,
        399,
        351,
        367,
        383,
        399,
        351,
        367,
        383,
        399,
        351,
        367,
        377,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        411,
        419,
        435,
        451,
        403,
        419,
        433,
        450,
        407,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        411,
        419,
        439,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        415,
        431,
        447,
        463,
        411,
        419,
        433,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        479,
        495,
        511,
        527,
        479,
        495,
        511,
        527,
        479,
        495,
        511,
        527,
        479,
        495,
        511,
        527,
        479,
        495,
        511,
        527,
        479,
        495,
        511,
        523,
        467,
        483,
        499,
        515,
        467,
        483,
        499,
        515,
        465,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        466,
        487,
        511,
        527,
        479,
        495,
        511,
        527,
        479,
        495,
        511,
        523,
        465,
        -1,
        498,
        515,
        467,
        483,
        499,
        515,
        467,
        483,
        499,
        515,
        467,
        483,
        499,
        515,
        465,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        275,
        291,
        307,
        323,
        275,
        291,
        307,
        323,
        275,
        291,
        307,
        323,
        275,
        291,
        307,
        323,
        275,
        291,
        307,
        323,
        275,
        291,
        307,
        321,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        290,
        307,
        323,
        279,
        303,
        319,
        335,
        287,
        299,
        307,
        321,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        338,
        355,
        375,
        399,
        351,
        361,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        438,
        463,
        415,
        425,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        502,
        527,
        479,
        489,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        310,
        335,
        287,
        297,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        374,
        399,
        351,
        361,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        438,
        463,
        415,
        425,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        502,
        527,
        479,
        489,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        310,
        335,
        287,
        297,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        374,
        399,
        351,
        361,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        438,
        463,
        415,
        425,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        502,
        527,
        479,
        489,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        310,
        335,
        287,
        297,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        374,
        399,
        351,
        361,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        438,
        463,
        415,
        425,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        502,
        527,
        479,
        489,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        310,
        335,
        287,
        297,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        356,
        382,
        399,
        347,
        353,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        422,
        447,
        463,
        409,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        486,
        511,
        527,
        473,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        294,
        319,
        335,
        281,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        340,
        366,
        383,
        395,
        337,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        406,
        431,
        447,
        457,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        470,
        495,
        511,
        521,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        278,
        303,
        319,
        329,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        388,
        350,
        367,
        379,
        385,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        454,
        415,
        431,
        441,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        518,
        479,
        495,
        505,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ]
    ],
    [
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        566,
        591,
        543,
        559,
        575,
        591,
        543,
        557,
        568,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        630,
        655,
        607,
        623,
        639,
        655,
        607,
        623,
        633,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        690,
        711,
        671,
        687,
        703,
        719,
        671,
        687,
        697,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        774,
        735,
        751,
        767,
        783,
        735,
        751,
        761,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        582,
        543,
        559,
        575,
        591,
        543,
        559,
        573,
        584,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        646,
        607,
        623,
        639,
        655,
        607,
        623,
        639,
        649,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        710,
        671,
        687,
        703,
        719,
        671,
        687,
        703,
        713,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        770,
        727,
        751,
        767,
        783,
        735,
        751,
        767,
        777,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        534,
        559,
        575,
        591,
        543,
        559,
        575,
        585,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        598,
        623,
        639,
        655,
        607,
        623,
        639,
        653,
        600,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        662,
        687,
        703,
        719,
        671,
        687,
        703,
        719,
        665,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        726,
        751,
        767,
        783,
        735,
        751,
        767,
        783,
        729,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        534,
        559,
        575,
        591,
        543,
        559,
        575,
        591,
        537,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        598,
        623,
        639,
        655,
        607,
        623,
        639,
        655,
        601,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        662,
        687,
        703,
        719,
        671,
        687,
        703,
        719,
        665,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        726,
        751,
        767,
        783,
        735,
        751,
        767,
        783,
        729,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        534,
        559,
        575,
        591,
        543,
        559,
        575,
        587,
        529,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        598,
        623,
        639,
        655,
        607,
        623,
        639,
        649,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        708,
        670,
        687,
        703,
        719,
        671,
        687,
        703,
        713,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        774,
        735,
        751,
        767,
        783,
        735,
        751,
        767,
        777,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        582,
        543,
        559,
        575,
        591,
        543,
        559,
        575,
        585,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        646,
        607,
        623,
        639,
        655,
        607,
        623,
        639,
        649,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        710,
        671,
        687,
        703,
        719,
        671,
        687,
        699,
        705,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        756,
        782,
        735,
        751,
        767,
        783,
        735,
        751,
        761,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        566,
        591,
        543,
        559,
        575,
        591,
        543,
        559,
        569,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        630,
        655,
        607,
        623,
        639,
        655,
        607,
        623,
        633,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        694,
        719,
        671,
        687,
        703,
        719,
        671,
        683,
        689,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        740,
        766,
        783,
        735,
        751,
        767,
        783,
        735,
        745,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        550,
        575,
        591,
        543,
        559,
        575,
        591,
        543,
        553,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        614,
        639,
        655,
        607,
        623,
        639,
        655,
        607,
        617,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        678,
        703,
        719,
        671,
        687,
        703,
        719,
        667,
        673,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        724,
        750,
        767,
        783,
        735,
        751,
        767,
        783,
        729,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        534,
        559,
        575,
        591,
        543,
        559,
        575,
        591,
        537,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        598,
        623,
        639,
        655,
        607,
        623,
        639,
        655,
        601,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        662,
        687,
        703,
        719,
        671,
        687,
        703,
        719,
        665,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        726,
        751,
        767,
        783,
        735,
        751,
        767,
        783,
        729,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        534,
        559,
        575,
        591,
        543,
        559,
        575,
        587,
        529,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        598,
        623,
        639,
        655,
        607,
        623,
        639,
        649,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        662,
        687,
        703,
        719,
        671,
        687,
        703,
        713,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        726,
        751,
        767,
        783,
        735,
        751,
        767,
        777,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        534,
        559,
        575,
        591,
        543,
        559,
        575,
        585,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        598,
        623,
        639,
        655,
        607,
        623,
        639,
        649,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        662,
        687,
        703,
        719,
        671,
        687,
        703,
        713,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        726,
        751,
        767,
        783,
        735,
        751,
        767,
        781,
        728,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        534,
        559,
        575,
        591,
        543,
        559,
        575,
        591,
        537,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        598,
        623,
        639,
        655,
        607,
        623,
        639,
        655,
        601,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        662,
        687,
        703,
        719,
        671,
        687,
        703,
        719,
        665,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        722,
        743,
        767,
        783,
        735,
        751,
        767,
        783,
        729,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        550,
        575,
        591,
        543,
        559,
        575,
        591,
        537,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        614,
        639,
        655,
        607,
        623,
        639,
        655,
        605,
        616,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        678,
        703,
        719,
        671,
        687,
        703,
        719,
        671,
        681,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        742,
        767,
        783,
        735,
        751,
        767,
        783,
        735,
        745,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        546,
        567,
        591,
        543,
        559,
        575,
        591,
        543,
        553,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        630,
        655,
        607,
        623,
        639,
        655,
        607,
        621,
        632,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        694,
        719,
        671,
        687,
        703,
        719,
        671,
        687,
        697,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        754,
        775,
        735,
        751,
        767,
        783,
        735,
        751,
        761,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        582,
        543,
        559,
        575,
        591,
        543,
        559,
        569,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        646,
        607,
        623,
        639,
        655,
        607,
        623,
        637,
        648,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        710,
        671,
        687,
        703,
        719,
        671,
        687,
        703,
        713,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        774,
        735,
        751,
        767,
        783,
        735,
        751,
        767,
        777,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        578,
        535,
        559,
        575,
        591,
        543,
        559,
        575,
        585,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        598,
        623,
        639,
        655,
        607,
        623,
        639,
        649,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        662,
        687,
        703,
        719,
        671,
        687,
        703,
        717,
        664,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ],
      [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        726,
        751,
        767,
        783,
        735,
        751,
        767,
        783,
        729,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ]
    ]
  ],
  objects: [
    {
      id: "cottage-0",
      kind: "cottage",
      x: 1040,
      y: 610,
      width: 500,
      height: 471,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 360, height: 113, offsetY: -28 }
    },
    {
      id: "inn-1",
      kind: "inn",
      x: 1940,
      y: 570,
      width: 570,
      height: 491,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 410, height: 118, offsetY: -29 }
    },
    {
      id: "forge-2",
      kind: "forge",
      x: 1050,
      y: 1510,
      width: 520,
      height: 511,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 374, height: 123, offsetY: -31 }
    },
    {
      id: "cottage-3",
      kind: "cottage",
      x: 1950,
      y: 1500,
      width: 500,
      height: 471,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 360, height: 113, offsetY: -28 }
    },
    {
      id: "market-4",
      kind: "market",
      x: 1190,
      y: 1020,
      width: 210,
      height: 201,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 151, height: 48, offsetY: -12 }
    },
    {
      id: "fountain-5",
      kind: "fountain",
      x: 1480,
      y: 1e3,
      width: 145,
      height: 149,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 147, height: 122 }
    },
    {
      id: "bridge-6",
      kind: "bridge",
      x: 2463,
      y: 1e3,
      width: 420,
      height: 88,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "lamp-7",
      kind: "lamp",
      x: 1340,
      y: 750,
      width: 40,
      height: 122,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 12, height: 12, offsetY: 0 }
    },
    {
      id: "lamp-8",
      kind: "lamp",
      x: 1640,
      y: 750,
      width: 40,
      height: 122,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 12, height: 12, offsetY: 0 }
    },
    {
      id: "lamp-9",
      kind: "lamp",
      x: 1340,
      y: 1240,
      width: 40,
      height: 122,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 12, height: 12, offsetY: 0 }
    },
    {
      id: "lamp-10",
      kind: "lamp",
      x: 1640,
      y: 1240,
      width: 40,
      height: 122,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 12, height: 12, offsetY: 0 }
    },
    {
      id: "lamp-11",
      kind: "lamp",
      x: 900,
      y: 1040,
      width: 40,
      height: 122,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 12, height: 12, offsetY: 0 }
    },
    {
      id: "lamp-12",
      kind: "lamp",
      x: 2070,
      y: 1040,
      width: 40,
      height: 122,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 12, height: 12, offsetY: 0 }
    },
    {
      id: "lamp-13",
      kind: "lamp",
      x: 2260,
      y: 890,
      width: 40,
      height: 122,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 12, height: 12, offsetY: 0 }
    },
    {
      id: "lamp-14",
      kind: "lamp",
      x: 2250,
      y: 1120,
      width: 40,
      height: 122,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 12, height: 12, offsetY: 0 }
    },
    {
      id: "fir-15",
      kind: "fir",
      x: 8,
      y: 12,
      width: 250,
      height: 284,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-16",
      kind: "oak",
      x: 211,
      y: 55,
      width: 257,
      height: 204,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-17",
      kind: "oak",
      x: 339,
      y: 31,
      width: 259,
      height: 205,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-18",
      kind: "oak",
      x: 467,
      y: 74,
      width: 304,
      height: 241,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-19",
      kind: "fir",
      x: 595,
      y: 50,
      width: 266,
      height: 302,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-20",
      kind: "oak",
      x: 723,
      y: 26,
      width: 305,
      height: 242,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-21",
      kind: "oak",
      x: 851,
      y: 69,
      width: 284,
      height: 225,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-22",
      kind: "oak",
      x: 979,
      y: 45,
      width: 260,
      height: 206,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-23",
      kind: "fir",
      x: 1107,
      y: 21,
      width: 302,
      height: 343,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-24",
      kind: "oak",
      x: 1235,
      y: 64,
      width: 269,
      height: 213,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-25",
      kind: "oak",
      x: 1363,
      y: 40,
      width: 261,
      height: 207,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-26",
      kind: "fir",
      x: 1619,
      y: 59,
      width: 248,
      height: 281,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-27",
      kind: "oak",
      x: 1747,
      y: 35,
      width: 298,
      height: 236,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-28",
      kind: "oak",
      x: 1875,
      y: 78,
      width: 319,
      height: 253,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-29",
      kind: "oak",
      x: 2003,
      y: 54,
      width: 307,
      height: 243,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-30",
      kind: "fir",
      x: 2131,
      y: 30,
      width: 291,
      height: 330,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-31",
      kind: "oak",
      x: 2259,
      y: 73,
      width: 273,
      height: 216,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-32",
      kind: "oak",
      x: 49,
      y: 152,
      width: 303,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-33",
      kind: "oak",
      x: 177,
      y: 195,
      width: 318,
      height: 252,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-34",
      kind: "oak",
      x: 305,
      y: 171,
      width: 288,
      height: 228,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-35",
      kind: "fir",
      x: 433,
      y: 147,
      width: 301,
      height: 342,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-36",
      kind: "oak",
      x: 561,
      y: 190,
      width: 314,
      height: 249,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-37",
      kind: "oak",
      x: 689,
      y: 166,
      width: 301,
      height: 238,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-38",
      kind: "oak",
      x: 817,
      y: 142,
      width: 271,
      height: 215,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-39",
      kind: "fir",
      x: 945,
      y: 185,
      width: 266,
      height: 302,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-40",
      kind: "oak",
      x: 1073,
      y: 161,
      width: 297,
      height: 235,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-41",
      kind: "oak",
      x: 1201,
      y: 204,
      width: 261,
      height: 207,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-42",
      kind: "oak",
      x: 1329,
      y: 180,
      width: 285,
      height: 226,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-43",
      kind: "oak",
      x: 1585,
      y: 199,
      width: 292,
      height: 231,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-44",
      kind: "oak",
      x: 1713,
      y: 175,
      width: 298,
      height: 236,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-45",
      kind: "oak",
      x: 1841,
      y: 151,
      width: 307,
      height: 243,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-46",
      kind: "fir",
      x: 1969,
      y: 194,
      width: 313,
      height: 355,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-47",
      kind: "oak",
      x: 2097,
      y: 170,
      width: 294,
      height: 233,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-48",
      kind: "oak",
      x: 2225,
      y: 146,
      width: 259,
      height: 205,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-49",
      kind: "oak",
      x: 2353,
      y: 189,
      width: 265,
      height: 210,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-50",
      kind: "oak",
      x: 15,
      y: 292,
      width: 291,
      height: 231,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-51",
      kind: "oak",
      x: 143,
      y: 268,
      width: 308,
      height: 244,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-52",
      kind: "fir",
      x: 271,
      y: 311,
      width: 272,
      height: 309,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-53",
      kind: "oak",
      x: 399,
      y: 287,
      width: 252,
      height: 200,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-54",
      kind: "oak",
      x: 602,
      y: 330,
      width: 259,
      height: 205,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-55",
      kind: "oak",
      x: 730,
      y: 306,
      width: 261,
      height: 207,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-56",
      kind: "fir",
      x: 858,
      y: 282,
      width: 296,
      height: 336,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-57",
      kind: "oak",
      x: 986,
      y: 325,
      width: 287,
      height: 227,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-58",
      kind: "oak",
      x: 1114,
      y: 301,
      width: 270,
      height: 214,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-59",
      kind: "oak",
      x: 1242,
      y: 277,
      width: 285,
      height: 226,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-60",
      kind: "oak",
      x: 1626,
      y: 272,
      width: 250,
      height: 198,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-61",
      kind: "oak",
      x: 1754,
      y: 315,
      width: 264,
      height: 209,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-62",
      kind: "fir",
      x: 1882,
      y: 291,
      width: 316,
      height: 359,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-63",
      kind: "oak",
      x: 2010,
      y: 334,
      width: 283,
      height: 224,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-64",
      kind: "oak",
      x: 2138,
      y: 310,
      width: 299,
      height: 237,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-65",
      kind: "oak",
      x: 2266,
      y: 286,
      width: 245,
      height: 194,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-66",
      kind: "oak",
      x: 56,
      y: 432,
      width: 297,
      height: 235,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-67",
      kind: "fir",
      x: 184,
      y: 408,
      width: 260,
      height: 295,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-68",
      kind: "oak",
      x: 312,
      y: 451,
      width: 311,
      height: 246,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-69",
      kind: "oak",
      x: 440,
      y: 427,
      width: 318,
      height: 252,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-70",
      kind: "oak",
      x: 568,
      y: 403,
      width: 258,
      height: 204,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-71",
      kind: "fir",
      x: 696,
      y: 446,
      width: 298,
      height: 338,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-72",
      kind: "oak",
      x: 824,
      y: 422,
      width: 280,
      height: 222,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-73",
      kind: "oak",
      x: 952,
      y: 398,
      width: 276,
      height: 219,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-74",
      kind: "oak",
      x: 1976,
      y: 407,
      width: 284,
      height: 225,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-75",
      kind: "oak",
      x: 2104,
      y: 450,
      width: 253,
      height: 200,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-76",
      kind: "fir",
      x: 2232,
      y: 426,
      width: 268,
      height: 304,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-77",
      kind: "oak",
      x: 2360,
      y: 402,
      width: 245,
      height: 194,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-78",
      kind: "fir",
      x: 22,
      y: 572,
      width: 301,
      height: 342,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-79",
      kind: "oak",
      x: 150,
      y: 548,
      width: 291,
      height: 231,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-80",
      kind: "oak",
      x: 278,
      y: 524,
      width: 297,
      height: 235,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-81",
      kind: "oak",
      x: 406,
      y: 567,
      width: 258,
      height: 204,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-82",
      kind: "fir",
      x: 534,
      y: 543,
      width: 312,
      height: 354,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-83",
      kind: "oak",
      x: 662,
      y: 586,
      width: 309,
      height: 245,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-84",
      kind: "oak",
      x: 790,
      y: 562,
      width: 265,
      height: 210,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-85",
      kind: "oak",
      x: 2273,
      y: 566,
      width: 256,
      height: 203,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-86",
      kind: "oak",
      x: 63,
      y: 712,
      width: 267,
      height: 212,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-87",
      kind: "oak",
      x: 191,
      y: 688,
      width: 250,
      height: 198,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-88",
      kind: "oak",
      x: 319,
      y: 664,
      width: 261,
      height: 207,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-89",
      kind: "fir",
      x: 447,
      y: 707,
      width: 311,
      height: 353,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-90",
      kind: "oak",
      x: 575,
      y: 683,
      width: 298,
      height: 236,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-91",
      kind: "oak",
      x: 703,
      y: 659,
      width: 308,
      height: 244,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-92",
      kind: "oak",
      x: 29,
      y: 785,
      width: 282,
      height: 223,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-93",
      kind: "oak",
      x: 157,
      y: 828,
      width: 303,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-94",
      kind: "fir",
      x: 285,
      y: 804,
      width: 285,
      height: 323,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-95",
      kind: "oak",
      x: 413,
      y: 780,
      width: 308,
      height: 244,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-96",
      kind: "oak",
      x: 541,
      y: 823,
      width: 249,
      height: 197,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-97",
      kind: "oak",
      x: 70,
      y: 925,
      width: 275,
      height: 218,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-98",
      kind: "fir",
      x: 198,
      y: 968,
      width: 294,
      height: 334,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-99",
      kind: "oak",
      x: 326,
      y: 944,
      width: 290,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-100",
      kind: "oak",
      x: 454,
      y: 920,
      width: 269,
      height: 213,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-101",
      kind: "oak",
      x: 582,
      y: 963,
      width: 283,
      height: 224,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-102",
      kind: "oak",
      x: 164,
      y: 1041,
      width: 255,
      height: 202,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-103",
      kind: "fir",
      x: 548,
      y: 1036,
      width: 274,
      height: 311,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-104",
      kind: "oak",
      x: 77,
      y: 1205,
      width: 269,
      height: 213,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-105",
      kind: "oak",
      x: 333,
      y: 1224,
      width: 317,
      height: 251,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-106",
      kind: "fir",
      x: 461,
      y: 1200,
      width: 287,
      height: 326,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-107",
      kind: "oak",
      x: 43,
      y: 1345,
      width: 291,
      height: 231,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-108",
      kind: "oak",
      x: 171,
      y: 1321,
      width: 278,
      height: 220,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-109",
      kind: "fir",
      x: 299,
      y: 1297,
      width: 245,
      height: 278,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-110",
      kind: "oak",
      x: 427,
      y: 1340,
      width: 300,
      height: 238,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-111",
      kind: "oak",
      x: 555,
      y: 1316,
      width: 319,
      height: 253,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-112",
      kind: "oak",
      x: 9,
      y: 1485,
      width: 292,
      height: 231,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-113",
      kind: "fir",
      x: 212,
      y: 1461,
      width: 318,
      height: 361,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-114",
      kind: "oak",
      x: 340,
      y: 1437,
      width: 254,
      height: 201,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-115",
      kind: "oak",
      x: 468,
      y: 1480,
      width: 250,
      height: 198,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-116",
      kind: "oak",
      x: 596,
      y: 1456,
      width: 278,
      height: 220,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-117",
      kind: "fir",
      x: 724,
      y: 1432,
      width: 294,
      height: 334,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-118",
      kind: "fir",
      x: 2260,
      y: 1479,
      width: 277,
      height: 314,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-119",
      kind: "fir",
      x: 50,
      y: 1558,
      width: 260,
      height: 295,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-120",
      kind: "oak",
      x: 178,
      y: 1601,
      width: 291,
      height: 231,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-121",
      kind: "oak",
      x: 306,
      y: 1577,
      width: 306,
      height: 242,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-122",
      kind: "oak",
      x: 434,
      y: 1553,
      width: 265,
      height: 210,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-123",
      kind: "fir",
      x: 562,
      y: 1596,
      width: 284,
      height: 322,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-124",
      kind: "oak",
      x: 690,
      y: 1572,
      width: 258,
      height: 204,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-125",
      kind: "oak",
      x: 818,
      y: 1548,
      width: 278,
      height: 220,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-126",
      kind: "oak",
      x: 946,
      y: 1591,
      width: 257,
      height: 204,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-127",
      kind: "fir",
      x: 2098,
      y: 1576,
      width: 276,
      height: 313,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-128",
      kind: "oak",
      x: 2226,
      y: 1552,
      width: 272,
      height: 216,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-129",
      kind: "oak",
      x: 16,
      y: 1698,
      width: 279,
      height: 221,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-130",
      kind: "oak",
      x: 144,
      y: 1741,
      width: 253,
      height: 200,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-131",
      kind: "oak",
      x: 272,
      y: 1717,
      width: 271,
      height: 215,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-132",
      kind: "fir",
      x: 400,
      y: 1693,
      width: 304,
      height: 345,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-133",
      kind: "oak",
      x: 528,
      y: 1736,
      width: 253,
      height: 200,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-134",
      kind: "oak",
      x: 731,
      y: 1712,
      width: 310,
      height: 246,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-135",
      kind: "oak",
      x: 859,
      y: 1688,
      width: 289,
      height: 229,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-136",
      kind: "fir",
      x: 987,
      y: 1731,
      width: 245,
      height: 278,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-137",
      kind: "oak",
      x: 1115,
      y: 1707,
      width: 268,
      height: 212,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-138",
      kind: "oak",
      x: 1755,
      y: 1721,
      width: 266,
      height: 211,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-139",
      kind: "oak",
      x: 1883,
      y: 1697,
      width: 246,
      height: 195,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-140",
      kind: "fir",
      x: 2011,
      y: 1740,
      width: 254,
      height: 288,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-141",
      kind: "oak",
      x: 2139,
      y: 1716,
      width: 300,
      height: 238,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-142",
      kind: "oak",
      x: 2267,
      y: 1692,
      width: 281,
      height: 223,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-143",
      kind: "oak",
      x: 57,
      y: 1838,
      width: 272,
      height: 216,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-144",
      kind: "oak",
      x: 185,
      y: 1814,
      width: 258,
      height: 204,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-145",
      kind: "fir",
      x: 313,
      y: 1857,
      width: 295,
      height: 335,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-146",
      kind: "oak",
      x: 441,
      y: 1833,
      width: 311,
      height: 246,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-147",
      kind: "oak",
      x: 569,
      y: 1809,
      width: 280,
      height: 222,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-148",
      kind: "oak",
      x: 697,
      y: 1852,
      width: 276,
      height: 219,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-149",
      kind: "fir",
      x: 825,
      y: 1828,
      width: 278,
      height: 316,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-150",
      kind: "oak",
      x: 953,
      y: 1804,
      width: 250,
      height: 198,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-151",
      kind: "oak",
      x: 1081,
      y: 1847,
      width: 267,
      height: 212,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-152",
      kind: "oak",
      x: 1209,
      y: 1823,
      width: 318,
      height: 252,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-153",
      kind: "fir",
      x: 1337,
      y: 1866,
      width: 305,
      height: 346,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-154",
      kind: "oak",
      x: 1593,
      y: 1818,
      width: 312,
      height: 247,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-155",
      kind: "oak",
      x: 1721,
      y: 1861,
      width: 267,
      height: 212,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-156",
      kind: "fir",
      x: 1849,
      y: 1837,
      width: 250,
      height: 284,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-157",
      kind: "oak",
      x: 1977,
      y: 1813,
      width: 307,
      height: 243,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-158",
      kind: "oak",
      x: 2105,
      y: 1856,
      width: 252,
      height: 200,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-159",
      kind: "oak",
      x: 2233,
      y: 1832,
      width: 315,
      height: 250,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-160",
      kind: "oak",
      x: 23,
      y: 1978,
      width: 302,
      height: 239,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-161",
      kind: "fir",
      x: 151,
      y: 1954,
      width: 294,
      height: 334,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-162",
      kind: "oak",
      x: 279,
      y: 1997,
      width: 252,
      height: 200,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-163",
      kind: "oak",
      x: 407,
      y: 1973,
      width: 286,
      height: 227,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-164",
      kind: "oak",
      x: 535,
      y: 1949,
      width: 317,
      height: 251,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-165",
      kind: "fir",
      x: 663,
      y: 1992,
      width: 310,
      height: 352,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-166",
      kind: "oak",
      x: 791,
      y: 1968,
      width: 266,
      height: 211,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-167",
      kind: "oak",
      x: 919,
      y: 1944,
      width: 259,
      height: 205,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-168",
      kind: "oak",
      x: 1122,
      y: 1987,
      width: 261,
      height: 207,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-169",
      kind: "fir",
      x: 1250,
      y: 1963,
      width: 279,
      height: 317,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-170",
      kind: "oak",
      x: 1378,
      y: 1939,
      width: 282,
      height: 223,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-171",
      kind: "oak",
      x: 1634,
      y: 1958,
      width: 312,
      height: 247,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-172",
      kind: "fir",
      x: 1762,
      y: 1934,
      width: 303,
      height: 344,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-173",
      kind: "oak",
      x: 1890,
      y: 1977,
      width: 292,
      height: 231,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-174",
      kind: "oak",
      x: 2018,
      y: 1953,
      width: 261,
      height: 207,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-175",
      kind: "oak",
      x: 2146,
      y: 1996,
      width: 267,
      height: 212,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "fir-176",
      kind: "fir",
      x: 2274,
      y: 1972,
      width: 288,
      height: 327,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-177",
      kind: "oak",
      x: 740,
      y: 600,
      width: 302,
      height: 239,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-178",
      kind: "oak",
      x: 820,
      y: 1350,
      width: 248,
      height: 196,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-179",
      kind: "oak",
      x: 2110,
      y: 1300,
      width: 276,
      height: 219,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-180",
      kind: "oak",
      x: 1720,
      y: 670,
      width: 297,
      height: 235,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-181",
      kind: "oak",
      x: 1200,
      y: 710,
      width: 249,
      height: 197,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-182",
      kind: "oak",
      x: 1760,
      y: 1380,
      width: 287,
      height: 227,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-183",
      kind: "oak",
      x: 1250,
      y: 1390,
      width: 270,
      height: 214,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-184",
      kind: "oak",
      x: 2100,
      y: 940,
      width: 315,
      height: 250,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-185",
      kind: "oak",
      x: 2160,
      y: 650,
      width: 296,
      height: 235,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-186",
      kind: "oak",
      x: 2240,
      y: 1480,
      width: 248,
      height: 196,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-187",
      kind: "oak",
      x: 710,
      y: 1550,
      width: 289,
      height: 229,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-188",
      kind: "oak",
      x: 920,
      y: 450,
      width: 246,
      height: 195,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "oak-189",
      kind: "oak",
      x: 2100,
      y: 425,
      width: 306,
      height: 242,
      anchorX: 0.5,
      anchorY: 0.94,
      solid: true,
      footprint: { width: 24, height: 24, offsetY: 0 }
    },
    {
      id: "rock-190",
      kind: "rock",
      x: 170,
      y: 200,
      width: 74,
      height: 66,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 48, height: 41 }
    },
    {
      id: "bush-191",
      kind: "bush",
      x: 507,
      y: 463,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-192",
      kind: "bush",
      x: 844,
      y: 726,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-193",
      kind: "bush",
      x: 2192,
      y: 1778,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-194",
      kind: "bush",
      x: 206,
      y: 644,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-195",
      kind: "bush",
      x: 543,
      y: 907,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-196",
      kind: "bush",
      x: 880,
      y: 1170,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-197",
      kind: "bush",
      x: 1891,
      y: 299,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "rock-198",
      kind: "rock",
      x: 2228,
      y: 562,
      width: 74,
      height: 66,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 48, height: 41 }
    },
    {
      id: "bush-199",
      kind: "bush",
      x: 579,
      y: 1351,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-200",
      kind: "bush",
      x: 1253,
      y: 217,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-201",
      kind: "bush",
      x: 1590,
      y: 480,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "rock-202",
      kind: "rock",
      x: 1927,
      y: 743,
      width: 74,
      height: 66,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 48, height: 41 }
    },
    {
      id: "bush-203",
      kind: "bush",
      x: 278,
      y: 1532,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-204",
      kind: "bush",
      x: 615,
      y: 1795,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-205",
      kind: "bush",
      x: 952,
      y: 398,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-206",
      kind: "bush",
      x: 1289,
      y: 661,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-207",
      kind: "bush",
      x: 314,
      y: 316,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-208",
      kind: "bush",
      x: 651,
      y: 579,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-209",
      kind: "bush",
      x: 988,
      y: 842,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-210",
      kind: "bush",
      x: 1662,
      y: 1368,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-211",
      kind: "bush",
      x: 2336,
      y: 234,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-212",
      kind: "bush",
      x: 350,
      y: 760,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-213",
      kind: "bush",
      x: 687,
      y: 1023,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-214",
      kind: "bush",
      x: 1361,
      y: 1549,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-215",
      kind: "bush",
      x: 1698,
      y: 1812,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-216",
      kind: "bush",
      x: 386,
      y: 1204,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "rock-217",
      kind: "rock",
      x: 723,
      y: 1467,
      width: 74,
      height: 66,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 48, height: 41 }
    },
    {
      id: "bush-218",
      kind: "bush",
      x: 1060,
      y: 1730,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-219",
      kind: "bush",
      x: 1734,
      y: 596,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-220",
      kind: "bush",
      x: 2071,
      y: 859,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-221",
      kind: "bush",
      x: 2745,
      y: 1385,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "rock-222",
      kind: "rock",
      x: 422,
      y: 1648,
      width: 74,
      height: 66,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 48, height: 41 }
    },
    {
      id: "bush-223",
      kind: "bush",
      x: 759,
      y: 251,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-224",
      kind: "bush",
      x: 2107,
      y: 1303,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "rock-225",
      kind: "rock",
      x: 2781,
      y: 1829,
      width: 74,
      height: 66,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 48, height: 41 }
    },
    {
      id: "bush-226",
      kind: "bush",
      x: 458,
      y: 432,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-227",
      kind: "bush",
      x: 795,
      y: 695,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-228",
      kind: "bush",
      x: 1806,
      y: 1484,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-229",
      kind: "bush",
      x: 2143,
      y: 1747,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-230",
      kind: "bush",
      x: 2817,
      y: 613,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-231",
      kind: "bush",
      x: 494,
      y: 876,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-232",
      kind: "bush",
      x: 1842,
      y: 268,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "rock-233",
      kind: "rock",
      x: 2179,
      y: 531,
      width: 74,
      height: 66,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 48, height: 41 }
    },
    {
      id: "bush-234",
      kind: "bush",
      x: 193,
      y: 1057,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-235",
      kind: "bush",
      x: 530,
      y: 1320,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-236",
      kind: "bush",
      x: 867,
      y: 1583,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-237",
      kind: "bush",
      x: 1204,
      y: 1846,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-238",
      kind: "bush",
      x: 1541,
      y: 449,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-239",
      kind: "bush",
      x: 2215,
      y: 975,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-240",
      kind: "bush",
      x: 229,
      y: 1501,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-241",
      kind: "bush",
      x: 566,
      y: 1764,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-242",
      kind: "bush",
      x: 903,
      y: 367,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-243",
      kind: "bush",
      x: 1240,
      y: 630,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-244",
      kind: "bush",
      x: 265,
      y: 285,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-245",
      kind: "bush",
      x: 602,
      y: 548,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-246",
      kind: "bush",
      x: 939,
      y: 811,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-247",
      kind: "bush",
      x: 2287,
      y: 203,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-248",
      kind: "bush",
      x: 301,
      y: 729,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-249",
      kind: "bush",
      x: 638,
      y: 992,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "rock-250",
      kind: "rock",
      x: 975,
      y: 1255,
      width: 74,
      height: 66,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 48, height: 41 }
    },
    {
      id: "bush-251",
      kind: "bush",
      x: 1312,
      y: 1518,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-252",
      kind: "bush",
      x: 1649,
      y: 1781,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-253",
      kind: "bush",
      x: 1986,
      y: 384,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-254",
      kind: "bush",
      x: 2323,
      y: 647,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "rock-255",
      kind: "rock",
      x: 674,
      y: 1436,
      width: 74,
      height: 66,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 48, height: 41 }
    },
    {
      id: "bush-256",
      kind: "bush",
      x: 1011,
      y: 1699,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-257",
      kind: "bush",
      x: 1348,
      y: 302,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-258",
      kind: "bush",
      x: 1685,
      y: 565,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-259",
      kind: "bush",
      x: 2022,
      y: 828,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-260",
      kind: "bush",
      x: 2696,
      y: 1354,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "rock-261",
      kind: "rock",
      x: 373,
      y: 1617,
      width: 74,
      height: 66,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 48, height: 41 }
    },
    {
      id: "bush-262",
      kind: "bush",
      x: 710,
      y: 220,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-263",
      kind: "bush",
      x: 2058,
      y: 1272,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "rock-264",
      kind: "rock",
      x: 2732,
      y: 1798,
      width: 74,
      height: 66,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 48, height: 41 }
    },
    {
      id: "bush-265",
      kind: "bush",
      x: 409,
      y: 401,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-266",
      kind: "bush",
      x: 746,
      y: 664,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-267",
      kind: "bush",
      x: 1083,
      y: 927,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-268",
      kind: "bush",
      x: 1757,
      y: 1453,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-269",
      kind: "bush",
      x: 2094,
      y: 1716,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-270",
      kind: "bush",
      x: 2768,
      y: 582,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-271",
      kind: "bush",
      x: 445,
      y: 845,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-272",
      kind: "bush",
      x: 1456,
      y: 1634,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-273",
      kind: "bush",
      x: 1793,
      y: 237,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-274",
      kind: "bush",
      x: 481,
      y: 1289,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-275",
      kind: "bush",
      x: 818,
      y: 1552,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-276",
      kind: "bush",
      x: 1155,
      y: 1815,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-277",
      kind: "bush",
      x: 1492,
      y: 418,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-278",
      kind: "bush",
      x: 2166,
      y: 944,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-279",
      kind: "bush",
      x: 180,
      y: 1470,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-280",
      kind: "bush",
      x: 517,
      y: 1733,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-281",
      kind: "bush",
      x: 854,
      y: 336,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-282",
      kind: "bush",
      x: 1191,
      y: 599,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-283",
      kind: "bush",
      x: 2202,
      y: 1388,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-284",
      kind: "bush",
      x: 216,
      y: 254,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "bush-285",
      kind: "bush",
      x: 553,
      y: 517,
      width: 68,
      height: 61,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: false
    },
    {
      id: "fence-286",
      kind: "fence",
      x: 840,
      y: 1490,
      width: 145,
      height: 38,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 130, height: 12 }
    },
    {
      id: "fence-287",
      kind: "fence",
      x: 850,
      y: 1580,
      width: 145,
      height: 38,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 130, height: 12 }
    },
    {
      id: "fence-288",
      kind: "fence",
      x: 1180,
      y: 1670,
      width: 145,
      height: 38,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 130, height: 12 }
    },
    {
      id: "fence-289",
      kind: "fence",
      x: 1860,
      y: 1700,
      width: 145,
      height: 38,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 130, height: 12 }
    },
    {
      id: "fence-290",
      kind: "fence",
      x: 2090,
      y: 1550,
      width: 145,
      height: 38,
      anchorX: 0.5,
      anchorY: 0.5,
      solid: true,
      footprint: { width: 130, height: 12 }
    }
  ],
  spawn: { x: 1495, y: 1260 },
  enemies: [
    { x: 2050, y: 1030 },
    { x: 2100, y: 1620 },
    { x: 1850, y: 1800 },
    { x: 750, y: 1e3 }
  ],
  bridge: { x: 2462.6918472322996, y: 1e3, halfHeight: 34 },
  riverRows: [
    { x: 2376, y: 0, width: 248, height: 32 },
    { x: 2384, y: 32, width: 248, height: 32 },
    { x: 2392, y: 64, width: 248, height: 32 },
    { x: 2400, y: 96, width: 248, height: 32 },
    { x: 2408, y: 128, width: 248, height: 32 },
    { x: 2415, y: 160, width: 248, height: 32 },
    { x: 2422, y: 192, width: 248, height: 32 },
    { x: 2428, y: 224, width: 248, height: 32 },
    { x: 2433, y: 256, width: 248, height: 32 },
    { x: 2437, y: 288, width: 248, height: 32 },
    { x: 2441, y: 320, width: 248, height: 32 },
    { x: 2444, y: 352, width: 248, height: 32 },
    { x: 2445, y: 384, width: 248, height: 32 },
    { x: 2446, y: 416, width: 248, height: 32 },
    { x: 2446, y: 448, width: 248, height: 32 },
    { x: 2445, y: 480, width: 248, height: 32 },
    { x: 2442, y: 512, width: 248, height: 32 },
    { x: 2439, y: 544, width: 248, height: 32 },
    { x: 2435, y: 576, width: 248, height: 32 },
    { x: 2430, y: 608, width: 248, height: 32 },
    { x: 2425, y: 640, width: 248, height: 32 },
    { x: 2419, y: 672, width: 248, height: 32 },
    { x: 2412, y: 704, width: 248, height: 32 },
    { x: 2404, y: 736, width: 248, height: 32 },
    { x: 2396, y: 768, width: 248, height: 32 },
    { x: 2388, y: 800, width: 248, height: 32 },
    { x: 2380, y: 832, width: 248, height: 32 },
    { x: 2372, y: 864, width: 248, height: 32 },
    { x: 2364, y: 896, width: 248, height: 32 },
    { x: 2356, y: 928, width: 248, height: 32 },
    { x: 2348, y: 960, width: 248, height: 6 },
    { x: 2334, y: 1034, width: 248, height: 22 },
    { x: 2327, y: 1056, width: 248, height: 32 },
    { x: 2322, y: 1088, width: 248, height: 32 },
    { x: 2317, y: 1120, width: 248, height: 32 },
    { x: 2313, y: 1152, width: 248, height: 32 },
    { x: 2310, y: 1184, width: 248, height: 32 },
    { x: 2308, y: 1216, width: 248, height: 32 },
    { x: 2306, y: 1248, width: 248, height: 32 },
    { x: 2306, y: 1280, width: 248, height: 32 },
    { x: 2307, y: 1312, width: 248, height: 32 },
    { x: 2308, y: 1344, width: 248, height: 32 },
    { x: 2311, y: 1376, width: 248, height: 32 },
    { x: 2315, y: 1408, width: 248, height: 32 },
    { x: 2319, y: 1440, width: 248, height: 32 },
    { x: 2324, y: 1472, width: 248, height: 32 },
    { x: 2330, y: 1504, width: 248, height: 32 },
    { x: 2337, y: 1536, width: 248, height: 32 },
    { x: 2344, y: 1568, width: 248, height: 32 },
    { x: 2352, y: 1600, width: 248, height: 32 },
    { x: 2359, y: 1632, width: 248, height: 32 },
    { x: 2368, y: 1664, width: 248, height: 32 },
    { x: 2376, y: 1696, width: 248, height: 32 },
    { x: 2384, y: 1728, width: 248, height: 32 },
    { x: 2392, y: 1760, width: 248, height: 32 },
    { x: 2400, y: 1792, width: 248, height: 32 },
    { x: 2408, y: 1824, width: 248, height: 32 },
    { x: 2415, y: 1856, width: 248, height: 32 },
    { x: 2422, y: 1888, width: 248, height: 32 },
    { x: 2428, y: 1920, width: 248, height: 32 },
    { x: 2433, y: 1952, width: 248, height: 32 },
    { x: 2437, y: 1984, width: 248, height: 32 },
    { x: 2441, y: 2016, width: 248, height: 32 }
  ],
  terrainFrameCount: 784
};

// src/game/world/forest.ts
var FOREST = forest_map_default;
var WORLD_WIDTH = FOREST.width;
var WORLD_HEIGHT = FOREST.height;
var FOREST_OBJECTS = FOREST.objects;

// src/game/tutorial.ts
var TUTORIAL_MARKET = {
  x: 1480,
  y: 800,
  radius: 85,
  label: "Rynek",
  instruction: "Odwied\u017A oznaczony Rynek na p\xF3\u0142noc od fontanny"
};

// src/game/world/regions/aether.json
var aether_default = {
  id: "aether",
  race: "sage",
  name: "Aetheria",
  settlement: "Sanktuarium Tysi\u0105ca \u0179r\xF3de\u0142",
  description: "G\xF3rskie tarasy, magiczne \u017Ar\xF3d\u0142a i ogrody pod opiek\u0105 wiekowych drzew.",
  architecture: "Szmaragdowe \u015Bwi\u0105tynie, biblioteki i bia\u0142e kamienne dziedzi\u0144ce.",
  width: 6e3,
  height: 4360,
  spawn: {
    x: 2350,
    y: 2030
  },
  background: "#193c42",
  minimap: "/game/assets/stage3/aether-minimap.webp",
  market: {
    x: 2400,
    y: 1550,
    radius: 85,
    label: "\u0179r\xF3d\u0142o Pami\u0119ci",
    instruction: "Odwied\u017A oznaczony punkt: \u0179r\xF3d\u0142o Pami\u0119ci",
    action: "Podejd\u017A: \u0179r\xF3d\u0142o Pami\u0119ci"
  },
  npcs: [
    {
      id: "guide",
      name: "Sora",
      role: "Opiekunka \u017Ar\xF3de\u0142",
      x: 2440,
      y: 2030,
      tint: 11071695,
      dialogue: "Zanim otworzysz ksi\u0119g\u0119, naucz si\u0119 s\u0142ucha\u0107. Odwied\u017A \u0179r\xF3d\u0142o Pami\u0119ci i wr\xF3\u0107. Jego cisza jest pierwsz\u0105 lekcj\u0105 KI."
    },
    {
      id: "hunter",
      name: "Ishin",
      role: "Stra\u017Cnik ogrod\xF3w",
      x: 2660,
      y: 1650,
      tint: 16762788,
      dialogue: "Zdzicza\u0142e bestie niszcz\u0105 korzenie \u015Bwi\u0119tego gaju. Uspok\xF3j trzy, a powierz ci ostrze stra\u017Cnika."
    },
    {
      id: "steward",
      name: "Hoshi",
      role: "Zarz\u0105dca Sali Rady",
      x: 2400,
      y: 1460,
      tint: 15390133,
      dialogue: "Sala Rady stoi otworem. Ka\u017Cda historia w Sanktuarium zaczyna si\u0119 od pytania, nie od odpowiedzi.",
      building: "hall"
    },
    {
      id: "merchant",
      name: "Mei",
      role: "Archiwistka wymiany",
      x: 3250,
      y: 1880,
      tint: 14070783,
      dialogue: "Wiedza kr\u0105\u017Cy tak jak towary. Wymie\u0144 k\u0142y na mikstury i wyposa\u017Cenie.",
      building: "shop"
    },
    {
      id: "trainer",
      name: "Raku",
      role: "Mistrz skupienia",
      x: 3980,
      y: 1780,
      tint: 16755370,
      dialogue: "Manekin nie oddaje cios\xF3w, wi\u0119c nie masz wym\xF3wki. U\u017Cyj ka\u017Cdej zdolno\u015Bci i obserwuj, jak dzia\u0142a.",
      building: "arena"
    },
    {
      id: "keeper",
      name: "Kaede",
      role: "Stra\u017Cniczka zwoj\xF3w",
      x: 1850,
      y: 2277,
      tint: 12116191,
      dialogue: "Twoje rzeczy le\u017C\u0105 tu bezpieczniej ni\u017C w jakiejkolwiek sakwie. Skrzynia nale\u017Cy tylko do ciebie.",
      building: "depot"
    },
    {
      id: "smith",
      name: "Enso",
      role: "Rzemie\u015Blnik piecz\u0119ci",
      x: 3360,
      y: 3002,
      tint: 10802687,
      dialogue: "Dobre ostrze wymaga skupienia. Za\u0142\xF3\u017C je i wr\xF3\u0107; wzmocni\u0119 jego piecz\u0119\u0107 za 15 monet.",
      building: "smithy"
    },
    {
      id: "innkeeper",
      name: "Yuna",
      role: "Mistrzyni herbaty",
      x: 1850,
      y: 2990,
      tint: 16766139,
      dialogue: "Usi\u0105d\u017A. Herbata z wiosennego \u017Ar\xF3d\u0142a leczy wi\u0119cej, ni\u017C si\u0119 wydaje.",
      building: "inn"
    }
  ],
  enemies: [
    {
      x: 4101,
      y: 368
    },
    {
      x: 5581,
      y: 694
    },
    {
      x: 3017,
      y: 602
    },
    {
      x: 2880,
      y: 508
    },
    {
      x: 768,
      y: 376
    },
    {
      x: 2425,
      y: 3956
    },
    {
      x: 5061,
      y: 4011
    },
    {
      x: 4484,
      y: 3749
    },
    {
      x: 3215,
      y: 3773
    },
    {
      x: 2297,
      y: 3735
    },
    {
      x: 5317,
      y: 2685
    },
    {
      x: 5376,
      y: 2934
    },
    {
      x: 5209,
      y: 2031
    },
    {
      x: 5609,
      y: 2343
    },
    {
      x: 5510,
      y: 2789
    },
    {
      x: 674,
      y: 2421
    },
    {
      x: 640,
      y: 2705
    },
    {
      x: 732,
      y: 1850
    },
    {
      x: 940,
      y: 2948
    },
    {
      x: 690,
      y: 3281
    }
  ],
  enemyName: "Dzik z mglistych ogrod\xF3w",
  huntName: "R\xF3wnowaga ogrod\xF3w",
  landmarks: [
    {
      x: 2400,
      y: 2020,
      label: "Sanktuarium",
      kind: "settlement"
    },
    {
      x: 2400,
      y: 1550,
      label: "\u0179r\xF3d\u0142o Pami\u0119ci",
      kind: "energy"
    },
    {
      x: 3100,
      y: 2420,
      label: "Dziki gaj",
      kind: "danger"
    },
    {
      x: 4080,
      y: 1850,
      label: "Ogr\xF3d Pag\xF3d",
      kind: "settlement"
    },
    {
      x: 2100,
      y: 3070,
      label: "Staw Koi",
      kind: "energy"
    },
    {
      x: 4250,
      y: 2980,
      label: "Dzikie wzg\xF3rza",
      kind: "danger"
    },
    {
      x: 3e3,
      y: 515,
      label: "Lodowe Szczyty",
      kind: "danger"
    },
    {
      x: 3e3,
      y: 3845,
      label: "Dolina Strumieni",
      kind: "danger"
    },
    {
      x: 5335,
      y: 2180,
      label: "Lodowce Wschodu",
      kind: "danger"
    },
    {
      x: 665,
      y: 2180,
      label: "Ska\u0142y Zachodu",
      kind: "danger"
    },
    {
      x: 2400,
      y: 1460,
      label: "Sala Rady \u0179r\xF3de\u0142",
      kind: "settlement",
      city: true
    },
    {
      x: 3250,
      y: 1880,
      label: "Pawilon Wymiany",
      kind: "settlement",
      city: true
    },
    {
      x: 3980,
      y: 1780,
      label: "Dziedziniec Skupienia",
      kind: "settlement",
      city: true
    },
    {
      x: 1850,
      y: 2277,
      label: "Skarbiec Zwoj\xF3w",
      kind: "settlement",
      city: true
    },
    {
      x: 3360,
      y: 3002,
      label: "Warsztat Piecz\u0119ci",
      kind: "settlement",
      city: true
    },
    {
      x: 1850,
      y: 2990,
      label: "Herbaciarnia Cichych W\xF3d",
      kind: "settlement",
      city: true
    }
  ],
  objects: [
    {
      id: "sanctum-0",
      kind: "sanctum",
      asset: "sanctum",
      x: 2400,
      y: 1330,
      width: 470,
      height: 390,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 370,
        height: 150
      }
    },
    {
      id: "archive-1",
      kind: "archive",
      asset: "archive",
      x: 1850,
      y: 2150,
      width: 370,
      height: 330,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 280,
        height: 145
      }
    },
    {
      id: "archive-2",
      kind: "archive",
      asset: "archive",
      x: 3250,
      y: 1760,
      width: 360,
      height: 320,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 265,
        height: 130
      }
    },
    {
      id: "ki-source-3",
      kind: "ki-source",
      asset: "ki-source",
      x: 2400,
      y: 1635,
      width: 170,
      height: 160,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 105,
        height: 55
      }
    },
    {
      id: "ki-tree-5",
      kind: "ki-tree",
      asset: "ki-tree",
      x: 3e3,
      y: 2290,
      width: 310,
      height: 350,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 85,
        height: 65
      }
    },
    {
      id: "ki-tree-6",
      kind: "ki-tree",
      asset: "ki-tree",
      x: 1630,
      y: 1400,
      width: 260,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 70,
        height: 60
      }
    },
    {
      id: "ki-tree-7",
      kind: "ki-tree",
      asset: "ki-tree",
      x: 3150,
      y: 1320,
      width: 270,
      height: 310,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 80,
        height: 60
      }
    },
    {
      id: "detail-cloud-peak-8",
      kind: "cloud-peak",
      asset: "cloud-peak",
      x: 1530,
      y: 1140,
      width: 420,
      height: 270,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-cloud-peak-9",
      kind: "cloud-peak",
      asset: "cloud-peak",
      x: 1980,
      y: 1140,
      width: 420,
      height: 270,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-cloud-peak-10",
      kind: "cloud-peak",
      asset: "cloud-peak",
      x: 2860,
      y: 1140,
      width: 420,
      height: 270,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-cloud-peak-11",
      kind: "cloud-peak",
      asset: "cloud-peak",
      x: 3310,
      y: 1140,
      width: 420,
      height: 270,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-garden-12",
      kind: "garden",
      asset: "garden",
      x: 2150,
      y: 1770,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-garden-13",
      kind: "garden",
      asset: "garden",
      x: 2630,
      y: 1780,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-garden-14",
      kind: "garden",
      asset: "garden",
      x: 2010,
      y: 2170,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-garden-15",
      kind: "garden",
      asset: "garden",
      x: 2700,
      y: 2220,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-garden-16",
      kind: "garden",
      asset: "garden",
      x: 1580,
      y: 2080,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-garden-17",
      kind: "garden",
      asset: "garden",
      x: 3220,
      y: 2070,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-garden-18",
      kind: "garden",
      asset: "garden",
      x: 1880,
      y: 1550,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-garden-19",
      kind: "garden",
      asset: "garden",
      x: 2980,
      y: 1530,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-garden-20",
      kind: "garden",
      asset: "garden",
      x: 2230,
      y: 2450,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-garden-21",
      kind: "garden",
      asset: "garden",
      x: 2510,
      y: 2430,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "x-pagoda-0",
      kind: "pagoda",
      asset: "pagoda",
      x: 3980,
      y: 1670,
      width: 380,
      height: 457,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 250,
        height: 110
      }
    },
    {
      id: "x-pagoda-1",
      kind: "pagoda",
      asset: "pagoda",
      x: 1850,
      y: 2880,
      width: 380,
      height: 457,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 250,
        height: 110
      }
    },
    {
      id: "x-archive-2",
      kind: "archive",
      asset: "archive",
      x: 3360,
      y: 2875,
      width: 370,
      height: 330,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 280,
        height: 145
      }
    },
    {
      id: "x-koi-pond-3",
      kind: "koi-pond",
      asset: "koi-pond",
      x: 3720,
      y: 1290,
      width: 380,
      height: 248,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 300,
        height: 110
      }
    },
    {
      id: "x-koi-pond-4",
      kind: "koi-pond",
      asset: "koi-pond",
      x: 2150,
      y: 3230,
      width: 380,
      height: 248,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 300,
        height: 110
      }
    },
    {
      id: "x-spirit-gate-5",
      kind: "spirit-gate",
      asset: "spirit-gate",
      x: 3250,
      y: 2070,
      width: 260,
      height: 306,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "x-spirit-gate-6",
      kind: "spirit-gate",
      asset: "spirit-gate",
      x: 2472,
      y: 2600,
      width: 260,
      height: 306,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "x-spirit-gate-7",
      kind: "spirit-gate",
      asset: "spirit-gate",
      x: 3900,
      y: 1865,
      width: 260,
      height: 306,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "x-stone-lantern-8",
      kind: "stone-lantern",
      asset: "stone-lantern",
      x: 2260,
      y: 2420,
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      }
    },
    {
      id: "x-stone-lantern-9",
      kind: "stone-lantern",
      asset: "stone-lantern",
      x: 2630,
      y: 2420,
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      }
    },
    {
      id: "x-stone-lantern-10",
      kind: "stone-lantern",
      asset: "stone-lantern",
      x: 2280,
      y: 2980,
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      }
    },
    {
      id: "x-stone-lantern-11",
      kind: "stone-lantern",
      asset: "stone-lantern",
      x: 2550,
      y: 2890,
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      }
    },
    {
      id: "x-stone-lantern-12",
      kind: "stone-lantern",
      asset: "stone-lantern",
      x: 3780,
      y: 2010,
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      }
    },
    {
      id: "x-stone-lantern-14",
      kind: "stone-lantern",
      asset: "stone-lantern",
      x: 3840,
      y: 2330,
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      }
    },
    {
      id: "x-stone-lantern-15",
      kind: "stone-lantern",
      asset: "stone-lantern",
      x: 3630,
      y: 2500,
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      }
    },
    {
      id: "x-stone-lantern-16",
      kind: "stone-lantern",
      asset: "stone-lantern",
      x: 3180,
      y: 2190,
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      }
    },
    {
      id: "x-stone-lantern-17",
      kind: "stone-lantern",
      asset: "stone-lantern",
      x: 4190,
      y: 1980,
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      }
    },
    {
      id: "x-cherry-tree-18",
      kind: "cherry-tree",
      asset: "cherry-tree",
      x: 3500,
      y: 1600,
      width: 300,
      height: 294,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 60,
        height: 46
      }
    },
    {
      id: "x-cherry-tree-19",
      kind: "cherry-tree",
      asset: "cherry-tree",
      x: 4400,
      y: 2010,
      width: 300,
      height: 294,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 60,
        height: 46
      }
    },
    {
      id: "x-cherry-tree-20",
      kind: "cherry-tree",
      asset: "cherry-tree",
      x: 4450,
      y: 2430,
      width: 300,
      height: 294,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 60,
        height: 46
      }
    },
    {
      id: "x-cherry-tree-21",
      kind: "cherry-tree",
      asset: "cherry-tree",
      x: 2800,
      y: 2880,
      width: 300,
      height: 294,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 60,
        height: 46
      }
    },
    {
      id: "x-cherry-tree-22",
      kind: "cherry-tree",
      asset: "cherry-tree",
      x: 2080,
      y: 2750,
      width: 300,
      height: 294,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 60,
        height: 46
      }
    },
    {
      id: "x-cherry-tree-23",
      kind: "cherry-tree",
      asset: "cherry-tree",
      x: 3900,
      y: 3200,
      width: 300,
      height: 294,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 60,
        height: 46
      }
    },
    {
      id: "x-cherry-tree-24",
      kind: "cherry-tree",
      asset: "cherry-tree",
      x: 4450,
      y: 3200,
      width: 300,
      height: 294,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 60,
        height: 46
      }
    },
    {
      id: "x-cherry-tree-25",
      kind: "cherry-tree",
      asset: "cherry-tree",
      x: 3150,
      y: 3300,
      width: 300,
      height: 294,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 60,
        height: 46
      }
    },
    {
      id: "x-cherry-tree-26",
      kind: "cherry-tree",
      asset: "cherry-tree",
      x: 4400,
      y: 1700,
      width: 300,
      height: 294,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 60,
        height: 46
      }
    },
    {
      id: "x-cherry-tree-27",
      kind: "cherry-tree",
      asset: "cherry-tree",
      x: 2850,
      y: 2350,
      width: 300,
      height: 294,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 60,
        height: 46
      }
    },
    {
      id: "x-ki-tree-28",
      kind: "ki-tree",
      asset: "ki-tree",
      x: 4150,
      y: 2480,
      width: 290,
      height: 330,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 75,
        height: 60
      }
    },
    {
      id: "x-ki-tree-29",
      kind: "ki-tree",
      asset: "ki-tree",
      x: 4500,
      y: 2850,
      width: 290,
      height: 330,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 75,
        height: 60
      }
    },
    {
      id: "x-ki-tree-30",
      kind: "ki-tree",
      asset: "ki-tree",
      x: 3620,
      y: 3230,
      width: 290,
      height: 330,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 75,
        height: 60
      }
    },
    {
      id: "x-ki-tree-31",
      kind: "ki-tree",
      asset: "ki-tree",
      x: 1580,
      y: 2780,
      width: 290,
      height: 330,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 75,
        height: 60
      }
    },
    {
      id: "x-garden-32",
      kind: "garden",
      asset: "garden",
      x: 3850,
      y: 2150,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "x-garden-33",
      kind: "garden",
      asset: "garden",
      x: 4300,
      y: 2120,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "x-garden-34",
      kind: "garden",
      asset: "garden",
      x: 3550,
      y: 2700,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "x-garden-35",
      kind: "garden",
      asset: "garden",
      x: 2720,
      y: 3230,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "x-garden-36",
      kind: "garden",
      asset: "garden",
      x: 4350,
      y: 2980,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "x-garden-37",
      kind: "garden",
      asset: "garden",
      x: 3900,
      y: 2950,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "x-garden-38",
      kind: "garden",
      asset: "garden",
      x: 3100,
      y: 2920,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "x-garden-39",
      kind: "garden",
      asset: "garden",
      x: 1900,
      y: 3320,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "x-cloud-peak-40",
      kind: "cloud-peak",
      asset: "cloud-peak",
      x: 3760,
      y: 1140,
      width: 420,
      height: 270,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "x-cloud-peak-41",
      kind: "cloud-peak",
      asset: "cloud-peak",
      x: 4210,
      y: 1140,
      width: 420,
      height: 270,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "x-cloud-peak-42",
      kind: "cloud-peak",
      asset: "cloud-peak",
      x: 4560,
      y: 1140,
      width: 420,
      height: 270,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false,
      expansion: true
    },
    {
      id: "nature-crystal-tree-65",
      kind: "crystal-tree",
      asset: "nature.crystal-tree",
      x: 2473,
      y: 3193,
      width: 210,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "nature-crystal-tree-66",
      kind: "crystal-tree",
      asset: "nature.crystal-tree",
      x: 4151,
      y: 2769,
      width: 190,
      height: 236,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "nature-crystal-tree-67",
      kind: "crystal-tree",
      asset: "nature.crystal-tree",
      x: 3203,
      y: 1736,
      width: 200,
      height: 248,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "nature-crystal-tree-68",
      kind: "crystal-tree",
      asset: "nature.crystal-tree",
      x: 3521,
      y: 2181,
      width: 180,
      height: 224,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "nature-crystal-tree-69",
      kind: "crystal-tree",
      asset: "nature.crystal-tree",
      x: 1504,
      y: 1748,
      width: 200,
      height: 248,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "nature-patch-waterfall-70",
      kind: "patch-waterfall",
      asset: "nature.patch-waterfall",
      x: 3847,
      y: 2802,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "nature-flower-bush-71",
      kind: "flower-bush",
      asset: "nature.flower-bush",
      x: 4265,
      y: 1326,
      width: 150,
      height: 132,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "nature-flower-bush-72",
      kind: "flower-bush",
      asset: "nature.flower-bush",
      x: 4538,
      y: 1375,
      width: 150,
      height: 132,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "nature-reed-clump-73",
      kind: "reed-clump",
      asset: "nature.reed-clump",
      x: 3558,
      y: 1954,
      width: 130,
      height: 144,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-north-mountain-peak-0",
      kind: "mountain-peak",
      asset: "nature.mountain-peak",
      x: 1283,
      y: 648,
      width: 430,
      height: 430,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 215,
        height: 77,
        offsetY: -17
      }
    },
    {
      id: "zone-north-patch-glacier-block-1",
      kind: "patch-glacier-block",
      asset: "nature.patch-glacier-block",
      x: 5341,
      y: 487,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-north-patch-ice-spires-2",
      kind: "patch-ice-spires",
      asset: "nature.patch-ice-spires",
      x: 4166,
      y: 708,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-north-mountain-peak-3",
      kind: "mountain-peak",
      asset: "nature.mountain-peak",
      x: 1858,
      y: 663,
      width: 430,
      height: 430,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 215,
        height: 77,
        offsetY: -17
      }
    },
    {
      id: "zone-north-patch-glacier-block-4",
      kind: "patch-glacier-block",
      asset: "nature.patch-glacier-block",
      x: 2571,
      y: 627,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-north-patch-ice-spires-5",
      kind: "patch-ice-spires",
      asset: "nature.patch-ice-spires",
      x: 3562,
      y: 704,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-north-mountain-peak-6",
      kind: "mountain-peak",
      asset: "nature.mountain-peak",
      x: 511,
      y: 673,
      width: 430,
      height: 430,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 215,
        height: 77,
        offsetY: -17
      }
    },
    {
      id: "zone-north-patch-glacier-block-7",
      kind: "patch-glacier-block",
      asset: "nature.patch-glacier-block",
      x: 3224,
      y: 494,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-north-patch-ice-spires-8",
      kind: "patch-ice-spires",
      asset: "nature.patch-ice-spires",
      x: 4824,
      y: 507,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-waterfall-0",
      kind: "patch-waterfall",
      asset: "nature.patch-waterfall",
      x: 2710,
      y: 3967,
      width: 320,
      height: 320,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-reed-clump-1",
      kind: "reed-clump",
      asset: "nature.reed-clump",
      x: 4165,
      y: 4035,
      width: 150,
      height: 150,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-south-flower-bush-2",
      kind: "flower-bush",
      asset: "nature.flower-bush",
      x: 1778,
      y: 3864,
      width: 150,
      height: 150,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-south-grassy-hill-3",
      kind: "grassy-hill",
      asset: "nature.grassy-hill",
      x: 4728,
      y: 3890,
      width: 330,
      height: 330,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-south-patch-waterfall-4",
      kind: "patch-waterfall",
      asset: "nature.patch-waterfall",
      x: 1273,
      y: 3721,
      width: 320,
      height: 320,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-reed-clump-5",
      kind: "reed-clump",
      asset: "nature.reed-clump",
      x: 860,
      y: 3659,
      width: 150,
      height: 150,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-south-flower-bush-6",
      kind: "flower-bush",
      asset: "nature.flower-bush",
      x: 5448,
      y: 3787,
      width: 150,
      height: 150,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-south-grassy-hill-7",
      kind: "grassy-hill",
      asset: "nature.grassy-hill",
      x: 5106,
      y: 3883,
      width: 330,
      height: 330,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-south-patch-waterfall-8",
      kind: "patch-waterfall",
      asset: "nature.patch-waterfall",
      x: 437,
      y: 3785,
      width: 320,
      height: 320,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-reed-clump-9",
      kind: "reed-clump",
      asset: "nature.reed-clump",
      x: 2058,
      y: 3976,
      width: 150,
      height: 150,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-south-flower-bush-10",
      kind: "flower-bush",
      asset: "nature.flower-bush",
      x: 4230,
      y: 3771,
      width: 150,
      height: 150,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-south-grassy-hill-11",
      kind: "grassy-hill",
      asset: "nature.grassy-hill",
      x: 2326,
      y: 3653,
      width: 330,
      height: 330,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-east-crystal-tree-0",
      kind: "crystal-tree",
      asset: "nature.crystal-tree",
      x: 5216,
      y: 1846,
      width: 240,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 120,
        height: 43,
        offsetY: -10
      }
    },
    {
      id: "zone-east-patch-glacier-block-1",
      kind: "patch-glacier-block",
      asset: "nature.patch-glacier-block",
      x: 5064,
      y: 2753,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-patch-ice-spires-2",
      kind: "patch-ice-spires",
      asset: "nature.patch-ice-spires",
      x: 5397,
      y: 1320,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-crystal-tree-3",
      kind: "crystal-tree",
      asset: "nature.crystal-tree",
      x: 5220,
      y: 3209,
      width: 240,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 120,
        height: 43,
        offsetY: -10
      }
    },
    {
      id: "zone-east-patch-glacier-block-4",
      kind: "patch-glacier-block",
      asset: "nature.patch-glacier-block",
      x: 5604,
      y: 2185,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-patch-ice-spires-5",
      kind: "patch-ice-spires",
      asset: "nature.patch-ice-spires",
      x: 5424,
      y: 2604,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-crystal-tree-6",
      kind: "crystal-tree",
      asset: "nature.crystal-tree",
      x: 5121,
      y: 1497,
      width: 240,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 120,
        height: 43,
        offsetY: -10
      }
    },
    {
      id: "zone-east-patch-glacier-block-7",
      kind: "patch-glacier-block",
      asset: "nature.patch-glacier-block",
      x: 5574,
      y: 3166,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-patch-ice-spires-8",
      kind: "patch-ice-spires",
      asset: "nature.patch-ice-spires",
      x: 5049,
      y: 1166,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-crystal-tree-9",
      kind: "crystal-tree",
      asset: "nature.crystal-tree",
      x: 5578,
      y: 1804,
      width: 240,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 120,
        height: 43,
        offsetY: -10
      }
    },
    {
      id: "zone-east-patch-glacier-block-10",
      kind: "patch-glacier-block",
      asset: "nature.patch-glacier-block",
      x: 5069,
      y: 2417,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-cliff-outcrop-0",
      kind: "patch-cliff-outcrop",
      asset: "nature.patch-cliff-outcrop",
      x: 444,
      y: 2049,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-boulder-group-1",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 465,
      y: 2415,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-pine-tree-2",
      kind: "pine-tree",
      asset: "nature.pine-tree",
      x: 542,
      y: 1255,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 115,
        height: 41,
        offsetY: -9
      }
    },
    {
      id: "zone-west-patch-cliff-outcrop-3",
      kind: "patch-cliff-outcrop",
      asset: "nature.patch-cliff-outcrop",
      x: 888,
      y: 2476,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-boulder-group-4",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 750,
      y: 1605,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-pine-tree-5",
      kind: "pine-tree",
      asset: "nature.pine-tree",
      x: 705,
      y: 2964,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 115,
        height: 41,
        offsetY: -9
      }
    },
    {
      id: "zone-west-patch-cliff-outcrop-6",
      kind: "patch-cliff-outcrop",
      asset: "nature.patch-cliff-outcrop",
      x: 379,
      y: 3181,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-boulder-group-7",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 956,
      y: 1341,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-pine-tree-8",
      kind: "pine-tree",
      asset: "nature.pine-tree",
      x: 912,
      y: 1867,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 115,
        height: 41,
        offsetY: -9
      }
    },
    {
      id: "zone-west-patch-cliff-outcrop-9",
      kind: "patch-cliff-outcrop",
      asset: "nature.patch-cliff-outcrop",
      x: 388,
      y: 2774,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-boulder-group-10",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 394,
      y: 1538,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-pine-tree-11",
      kind: "pine-tree",
      asset: "nature.pine-tree",
      x: 977,
      y: 3254,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 115,
        height: 41,
        offsetY: -9
      }
    },
    {
      kind: "stone-lantern",
      asset: "stone-lantern",
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      },
      id: "city-lantern-2",
      x: 2620,
      y: 2090
    },
    {
      kind: "stone-lantern",
      asset: "stone-lantern",
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      },
      id: "city-lantern-3",
      x: 2900,
      y: 2060
    },
    {
      kind: "stone-lantern",
      asset: "stone-lantern",
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      },
      id: "city-lantern-4",
      x: 3100,
      y: 2130
    },
    {
      kind: "stone-lantern",
      asset: "stone-lantern",
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      },
      id: "city-lantern-5",
      x: 3520,
      y: 2090
    },
    {
      kind: "stone-lantern",
      asset: "stone-lantern",
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      },
      id: "city-lantern-6",
      x: 3760,
      y: 1960
    },
    {
      kind: "stone-lantern",
      asset: "stone-lantern",
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      },
      id: "city-lantern-8",
      x: 2180,
      y: 2090
    },
    {
      kind: "stone-lantern",
      asset: "stone-lantern",
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      },
      id: "city-lantern-10",
      x: 3680,
      y: 2400
    },
    {
      kind: "stone-lantern",
      asset: "stone-lantern",
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      },
      id: "city-lantern-11",
      x: 3920,
      y: 2660
    },
    {
      kind: "stone-lantern",
      asset: "stone-lantern",
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      },
      id: "city-lantern-12",
      x: 2560,
      y: 2760
    },
    {
      kind: "stone-lantern",
      asset: "stone-lantern",
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      },
      id: "city-lantern-13",
      x: 2700,
      y: 3120
    },
    {
      kind: "stone-lantern",
      asset: "stone-lantern",
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      },
      id: "city-lantern-14",
      x: 3e3,
      y: 3130
    },
    {
      kind: "stone-lantern",
      asset: "stone-lantern",
      width: 70,
      height: 152,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      expansion: true,
      footprint: {
        width: 30,
        height: 22
      },
      id: "city-lantern-15",
      x: 2330,
      y: 3200
    },
    {
      id: "city-garden-0",
      kind: "garden",
      asset: "garden",
      x: 2150,
      y: 1770,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-garden-1",
      kind: "garden",
      asset: "garden",
      x: 2650,
      y: 1720,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-garden-2",
      kind: "garden",
      asset: "garden",
      x: 2850,
      y: 2400,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-garden-3",
      kind: "garden",
      asset: "garden",
      x: 3050,
      y: 2700,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-garden-4",
      kind: "garden",
      asset: "garden",
      x: 2250,
      y: 2550,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-garden-5",
      kind: "garden",
      asset: "garden",
      x: 3550,
      y: 2250,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-garden-7",
      kind: "garden",
      asset: "garden",
      x: 3700,
      y: 3050,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-garden-8",
      kind: "garden",
      asset: "garden",
      x: 2900,
      y: 3300,
      width: 170,
      height: 120,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    }
  ],
  obstacles: [
    {
      x: 0,
      y: 0,
      width: 6e3,
      height: 110
    },
    {
      x: 0,
      y: 110,
      width: 140,
      height: 4250
    },
    {
      x: 5860,
      y: 110,
      width: 140,
      height: 4250
    },
    {
      x: 140,
      y: 4260,
      width: 5720,
      height: 100
    },
    {
      x: 1400,
      y: 1840,
      width: 670,
      height: 70
    },
    {
      x: 2870,
      y: 2470,
      width: 550,
      height: 130
    },
    {
      x: 4100,
      y: 2200,
      width: 450,
      height: 80
    }
  ],
  terrain: {
    ground: "aether-ground",
    path: "aether-path",
    plaza: "aether-plaza",
    paths: [],
    plazas: [],
    roads: [
      {
        width: 170,
        points: [
          [2400, 1460],
          [2390, 1720],
          [2370, 1950],
          [2410, 2200],
          [2490, 2460],
          [2460, 2720],
          [2400, 3e3],
          [2430, 3300]
        ]
      },
      {
        width: 150,
        points: [
          [1760, 2010],
          [2e3, 1980],
          [2200, 2010],
          [2400, 2030]
        ]
      },
      {
        width: 120,
        points: [
          [1860, 1830],
          [1840, 1940],
          [1820, 2e3]
        ]
      },
      {
        width: 160,
        points: [
          [2400, 2030],
          [2650, 2020],
          [2920, 1990],
          [3180, 2060],
          [3450, 2030],
          [3680, 1920],
          [3900, 1860],
          [4080, 1820]
        ]
      },
      {
        width: 120,
        points: [
          [2900, 1760],
          [2910, 1880],
          [2920, 1990]
        ]
      },
      {
        width: 150,
        points: [
          [3450, 2030],
          [3620, 2280],
          [3850, 2550],
          [4100, 2800],
          [4280, 3050]
        ]
      },
      {
        width: 140,
        points: [
          [2460, 2720],
          [2200, 2860],
          [1990, 2980],
          [1840, 3070]
        ]
      },
      {
        width: 130,
        points: [
          [2400, 3e3],
          [2700, 3070],
          [3e3, 3060],
          [3320, 3050]
        ]
      },
      {
        width: 120,
        points: [
          [4150, 1860],
          [4280, 1680],
          [4350, 1460]
        ]
      },
      {
        width: 130,
        points: [
          [3e3, 920],
          [3007, 821],
          [3004, 684],
          [3023, 601],
          [3e3, 515]
        ]
      },
      {
        width: 130,
        points: [
          [3e3, 3440],
          [2940, 3523],
          [2911, 3661],
          [2956, 3790],
          [3e3, 3845]
        ]
      },
      {
        width: 130,
        points: [
          [1220, 2180],
          [1070, 2178],
          [914, 2109],
          [779, 2171],
          [665, 2180]
        ]
      },
      {
        width: 130,
        points: [
          [4780, 2180],
          [4959, 2175],
          [5122, 2157],
          [5210, 2144],
          [5335, 2180]
        ]
      },
      {
        width: 110,
        points: [
          [3250, 1890],
          [3230, 1990],
          [3180, 2060]
        ]
      },
      {
        width: 110,
        points: [
          [1850, 2275],
          [1960, 2210],
          [1990, 2090],
          [2e3, 1980]
        ]
      }
    ],
    courts: [
      {
        points: [
          [2658, 1590],
          [2641, 1628],
          [2608, 1660],
          [2576, 1687],
          [2541, 1713],
          [2497, 1731],
          [2448, 1736],
          [2400, 1736],
          [2351, 1738],
          [2295, 1742],
          [2237, 1732],
          [2197, 1703],
          [2187, 1661],
          [2195, 1623],
          [2198, 1590],
          [2192, 1557],
          [2194, 1521],
          [2216, 1488],
          [2254, 1463],
          [2298, 1442],
          [2346, 1424],
          [2400, 1416],
          [2454, 1426],
          [2495, 1453],
          [2524, 1482],
          [2557, 1503],
          [2602, 1522],
          [2643, 1551]
        ]
      },
      {
        points: [
          [2696, 2080],
          [2685, 2117],
          [2665, 2153],
          [2625, 2182],
          [2568, 2200],
          [2511, 2212],
          [2459, 2228],
          [2400, 2250],
          [2327, 2262],
          [2257, 2249],
          [2210, 2216],
          [2186, 2177],
          [2164, 2145],
          [2136, 2114],
          [2116, 2080],
          [2120, 2044],
          [2142, 2009],
          [2171, 1976],
          [2207, 1942],
          [2260, 1914],
          [2330, 1907],
          [2400, 1920],
          [2456, 1940],
          [2508, 1952],
          [2572, 1958],
          [2639, 1971],
          [2687, 2001],
          [2702, 2041]
        ]
      },
      {
        points: [
          [4342, 1860],
          [4327, 1892],
          [4290, 1917],
          [4250, 1936],
          [4219, 1958],
          [4189, 1987],
          [4142, 2012],
          [4080, 2019],
          [4021, 2006],
          [3974, 1983],
          [3935, 1962],
          [3895, 1943],
          [3861, 1919],
          [3845, 1890],
          [3842, 1860],
          [3840, 1829],
          [3840, 1795],
          [3859, 1761],
          [3908, 1739],
          [3972, 1734],
          [4031, 1739],
          [4080, 1739],
          [4132, 1733],
          [4191, 1731],
          [4246, 1743],
          [4286, 1768],
          [4312, 1797],
          [4333, 1828]
        ]
      },
      {
        points: [
          [2619, 3010],
          [2597, 3033],
          [2585, 3055],
          [2580, 3083],
          [2563, 3112],
          [2523, 3132],
          [2470, 3136],
          [2420, 3130],
          [2375, 3123],
          [2331, 3115],
          [2293, 3101],
          [2265, 3081],
          [2246, 3058],
          [2224, 3036],
          [2199, 3010],
          [2187, 2980],
          [2207, 2951],
          [2252, 2933],
          [2301, 2925],
          [2340, 2916],
          [2377, 2902],
          [2420, 2890],
          [2468, 2889],
          [2514, 2899],
          [2554, 2914],
          [2593, 2931],
          [2624, 2954],
          [2633, 2982]
        ]
      },
      {
        points: [
          [3506, 3030],
          [3518, 3051],
          [3523, 3076],
          [3507, 3099],
          [3474, 3114],
          [3435, 3122],
          [3398, 3127],
          [3360, 3130],
          [3323, 3126],
          [3291, 3114],
          [3265, 3100],
          [3237, 3088],
          [3202, 3075],
          [3172, 3055],
          [3166, 3030],
          [3186, 3007],
          [3216, 2989],
          [3241, 2974],
          [3262, 2957],
          [3288, 2942],
          [3322, 2932],
          [3360, 2930],
          [3398, 2931],
          [3439, 2934],
          [3477, 2943],
          [3502, 2963],
          [3508, 2988],
          [3504, 3011]
        ]
      }
    ],
    zones: [
      {
        id: "north",
        texture: "nature-snow",
        points: [
          [60, 60],
          [300, 60],
          [540, 60],
          [780, 60],
          [1020, 60],
          [1260, 60],
          [1500, 60],
          [1740, 60],
          [1980, 60],
          [2220, 60],
          [2460, 60],
          [2700, 60],
          [2940, 60],
          [3180, 60],
          [3420, 60],
          [3660, 60],
          [3900, 60],
          [4140, 60],
          [4380, 60],
          [4620, 60],
          [4860, 60],
          [5100, 60],
          [5340, 60],
          [5580, 60],
          [5820, 60],
          [5940, 60],
          [5940, 300],
          [5940, 540],
          [5940, 780],
          [5940, 958],
          [5700, 962],
          [5460, 996],
          [5220, 953],
          [4980, 986],
          [4740, 904],
          [4500, 1018],
          [4260, 978],
          [4020, 957],
          [3780, 943],
          [3540, 996],
          [3300, 977],
          [3060, 938],
          [2820, 1007],
          [2580, 997],
          [2340, 1024],
          [2100, 1021],
          [1860, 922],
          [1620, 966],
          [1380, 1018],
          [1140, 1032],
          [900, 1030],
          [660, 968],
          [420, 955],
          [180, 910],
          [60, 970],
          [60, 730],
          [60, 490],
          [60, 250]
        ]
      },
      {
        id: "south",
        texture: "nature-meadow-grass",
        points: [
          [60, 3402],
          [300, 3396],
          [540, 3444],
          [780, 3359],
          [1020, 3449],
          [1260, 3434],
          [1500, 3410],
          [1740, 3447],
          [1980, 3348],
          [2220, 3430],
          [2460, 3350],
          [2700, 3350],
          [2940, 3404],
          [3180, 3359],
          [3420, 3420],
          [3660, 3339],
          [3900, 3390],
          [4140, 3339],
          [4380, 3351],
          [4620, 3457],
          [4860, 3433],
          [5100, 3419],
          [5340, 3453],
          [5580, 3432],
          [5820, 3348],
          [5940, 3390],
          [5940, 3630],
          [5940, 3870],
          [5940, 4110],
          [5940, 4300],
          [5700, 4300],
          [5460, 4300],
          [5220, 4300],
          [4980, 4300],
          [4740, 4300],
          [4500, 4300],
          [4260, 4300],
          [4020, 4300],
          [3780, 4300],
          [3540, 4300],
          [3300, 4300],
          [3060, 4300],
          [2820, 4300],
          [2580, 4300],
          [2340, 4300],
          [2100, 4300],
          [1860, 4300],
          [1620, 4300],
          [1380, 4300],
          [1140, 4300],
          [900, 4300],
          [660, 4300],
          [420, 4300],
          [180, 4300],
          [60, 4300],
          [60, 4060],
          [60, 3820],
          [60, 3580]
        ]
      },
      {
        id: "east",
        texture: "nature-ice-glacier",
        points: [
          [4730, 756],
          [4970, 753],
          [5210, 805],
          [5450, 767],
          [5690, 817],
          [5930, 872],
          [5940, 810],
          [5940, 1050],
          [5940, 1290],
          [5940, 1530],
          [5940, 1770],
          [5940, 2010],
          [5940, 2250],
          [5940, 2490],
          [5940, 2730],
          [5940, 2970],
          [5940, 3210],
          [5940, 3450],
          [5940, 3587],
          [5700, 3575],
          [5460, 3533],
          [5220, 3605],
          [4980, 3591],
          [4740, 3557],
          [4723, 3550],
          [4683, 3310],
          [4731, 3070],
          [4780, 2830],
          [4697, 2590],
          [4733, 2350],
          [4756, 2110],
          [4699, 1870],
          [4665, 1630],
          [4723, 1390],
          [4721, 1150],
          [4771, 910]
        ]
      },
      {
        id: "west",
        texture: "nature-cliff-rock",
        points: [
          [60, 794],
          [300, 763],
          [540, 794],
          [780, 825],
          [1020, 856],
          [1260, 843],
          [1299, 810],
          [1205, 1050],
          [1230, 1290],
          [1300, 1530],
          [1267, 1770],
          [1304, 2010],
          [1233, 2250],
          [1259, 2490],
          [1321, 2730],
          [1260, 2970],
          [1310, 3210],
          [1331, 3450],
          [1270, 3558],
          [1030, 3557],
          [790, 3618],
          [550, 3531],
          [310, 3505],
          [70, 3484],
          [60, 3550],
          [60, 3310],
          [60, 3070],
          [60, 2830],
          [60, 2590],
          [60, 2350],
          [60, 2110],
          [60, 1870],
          [60, 1630],
          [60, 1390],
          [60, 1150],
          [60, 910]
        ]
      }
    ]
  },
  border: 4,
  layout: 2,
  legacyShift: {
    x: 1200,
    y: 900
  },
  city: {
    name: "Sanktuarium Tysi\u0105ca \u0179r\xF3de\u0142",
    bounds: {
      x: 1400,
      y: 1150,
      width: 3300,
      height: 2150
    },
    buildings: [
      {
        id: "hall",
        name: "Sala Rady \u0179r\xF3de\u0142",
        district: "Wzg\xF3rze \u0179r\xF3d\u0142a",
        description: "G\u0142\xF3wny gmach Sanktuarium. Opiekunowie \u017Ar\xF3de\u0142 przyjmuj\u0105 tu nowych uczni\xF3w i wydaj\u0105 zadania.",
        objectId: "sanctum-0",
        door: {
          x: 2400,
          y: 1460
        }
      },
      {
        id: "shop",
        name: "Pawilon Wymiany",
        district: "Targ Wymiany",
        description: "Archiwum towar\xF3w, gdzie wiedza kr\u0105\u017Cy tak jak mikstury, zwoje i wyposa\u017Cenie.",
        objectId: "archive-2",
        door: {
          x: 3250,
          y: 1880
        }
      },
      {
        id: "arena",
        name: "Dziedziniec Skupienia",
        district: "Ogr\xF3d Pag\xF3d",
        description: "Pawilon i dziedziniec treningowy z manekinem. Tu \u0107wiczy si\u0119 prawdziwe zdolno\u015Bci bez ryzyka.",
        objectId: "x-pagoda-0",
        door: {
          x: 3980,
          y: 1780
        }
      },
      {
        id: "depot",
        name: "Skarbiec Zwoj\xF3w",
        district: "Zachodnie Tarasy",
        description: "Bezpieczne archiwum z osobist\u0105 skrzyni\u0105 na przedmioty ka\u017Cdej postaci.",
        objectId: "archive-1",
        door: {
          x: 1850,
          y: 2277
        }
      },
      {
        id: "smithy",
        name: "Warsztat Piecz\u0119ci",
        district: "Dziedziniec Piecz\u0119ci",
        description: "Rzemie\u015Blnicy piecz\u0119ci ostrz\u0105, wzmacniaj\u0105 i naprawiaj\u0105 wyposa\u017Cenie.",
        objectId: "x-archive-2",
        door: {
          x: 3360,
          y: 3002
        }
      },
      {
        id: "inn",
        name: "Herbaciarnia Cichych W\xF3d",
        district: "Staw Koi",
        description: "Cicha herbaciarnia nad stawem, gdzie mo\u017Cna odpocz\u0105\u0107 i odzyska\u0107 si\u0142y.",
        objectId: "x-pagoda-1",
        door: {
          x: 1850,
          y: 2990
        }
      }
    ],
    roads: []
  }
};

// src/game/world/regions/nexus.json
var nexus_default = {
  id: "nexus",
  race: "android",
  name: "Nexus-9",
  settlement: "W\u0119ze\u0142 \u015Awiadomo\u015Bci",
  description: "Metaliczne r\xF3wniny, pola kryszta\u0142\xF3w i o\u015Bwietlone korytarze dawnej sieci.",
  architecture: "Laboratoria, reaktory i szklane terminale po\u0142\u0105czone sieci\u0105 platform.",
  width: 4800,
  height: 3592,
  spawn: {
    x: 1800,
    y: 2020
  },
  background: "#122536",
  minimap: "/game/assets/stage3/nexus-minimap.webp",
  market: {
    x: 2850,
    y: 1520,
    radius: 85,
    label: "Rdze\u0144 \u015Awiadomo\u015Bci",
    instruction: "Odwied\u017A oznaczony punkt: Rdze\u0144 \u015Awiadomo\u015Bci",
    action: "Podejd\u017A: Rdze\u0144 \u015Awiadomo\u015Bci"
  },
  npcs: [
    {
      id: "guide",
      name: "LYRA-7",
      role: "Przewodniczka sieci",
      x: 1890,
      y: 2020,
      tint: 11071695,
      dialogue: "Pierwsze pytanie brzmi: kim chcesz si\u0119 sta\u0107? Zsynchronizuj si\u0119 z Rdzeniem \u015Awiadomo\u015Bci, a potem wr\xF3\u0107 do w\u0119z\u0142a."
    },
    {
      id: "hunter",
      name: "AXON",
      role: "Stra\u017Cnik perymetru",
      x: 3110,
      y: 1620,
      tint: 16762788,
      dialogue: "Organiczne dziki naruszaj\u0105 obwody na obrze\u017Cach sieci. Pokonaj trzy i przynie\u015B dane z patrolu."
    },
    {
      id: "steward",
      name: "VEGA-3",
      role: "Zarz\u0105dca synchronizacji",
      x: 2400,
      y: 1275,
      tint: 15390133,
      dialogue: "Po\u0142\u0105czenie ustanowione. Ka\u017Cda historia w sieci zaczyna si\u0119 od zapytania, nie od odpowiedzi.",
      building: "hall"
    },
    {
      id: "merchant",
      name: "MIRA-2",
      role: "Operatorka wymiany",
      x: 3100,
      y: 1577,
      tint: 14070783,
      dialogue: "Wymiana zasob\xF3w stabilizuje w\u0119ze\u0142. Przyjmuj\u0119 k\u0142y; oferuj\u0119 mikstury i pancerze.",
      building: "shop"
    },
    {
      id: "trainer",
      name: "KRON-9",
      role: "Instruktor kalibracji",
      x: 3100,
      y: 2327,
      tint: 16755370,
      dialogue: "Manekin nie oddaje cios\xF3w i nie wyp\u0142aca nagr\xF3d. U\u017Cyj ka\u017Cdej zdolno\u015Bci i odczytaj wyniki.",
      building: "arena"
    },
    {
      id: "keeper",
      name: "ARCH-5",
      role: "Stra\u017Cnik magazynu",
      x: 1650,
      y: 2517,
      tint: 12116191,
      dialogue: "Twoje przedmioty s\u0105 zaszyfrowane i przypisane tylko do tej postaci. Skrzynia czeka.",
      building: "depot"
    },
    {
      id: "smith",
      name: "HEF-4",
      role: "In\u017Cynier uzbrojenia",
      x: 2400,
      y: 2570,
      tint: 10802687,
      dialogue: "Ulepszenie zwi\u0119ksza skuteczno\u015B\u0107 ostrza. Najpierw je za\u0142\xF3\u017C; kalibracja kosztuje 15 monet.",
      building: "smithy"
    },
    {
      id: "innkeeper",
      name: "SOLA-6",
      role: "Operatorka regeneracji",
      x: 1700,
      y: 1577,
      tint: 16766139,
      dialogue: "Wejd\u017A do kapsu\u0142y. Cykl regeneracji potrwa tyle, ile potrzebujesz.",
      building: "inn"
    }
  ],
  enemies: [
    {
      x: 3337,
      y: 330
    },
    {
      x: 3476,
      y: 659
    },
    {
      x: 1936,
      y: 639
    },
    {
      x: 4435,
      y: 604
    },
    {
      x: 3430,
      y: 497
    },
    {
      x: 4435,
      y: 3033
    },
    {
      x: 3359,
      y: 3094
    },
    {
      x: 2498,
      y: 3194
    },
    {
      x: 4272,
      y: 2958
    },
    {
      x: 2195,
      y: 2954
    },
    {
      x: 4201,
      y: 1702
    },
    {
      x: 3832,
      y: 1234
    },
    {
      x: 4349,
      y: 1886
    },
    {
      x: 3885,
      y: 1633
    },
    {
      x: 4082,
      y: 1891
    },
    {
      x: 551,
      y: 2133
    },
    {
      x: 383,
      y: 2311
    },
    {
      x: 411,
      y: 1678
    },
    {
      x: 691,
      y: 2408
    },
    {
      x: 977,
      y: 1656
    }
  ],
  enemyName: "Dzik z perymetru",
  huntName: "Patrol perymetru",
  landmarks: [
    {
      x: 1770,
      y: 2e3,
      label: "W\u0119ze\u0142 \u015Awiadomo\u015Bci",
      kind: "settlement"
    },
    {
      x: 2850,
      y: 1520,
      label: "Rdze\u0144",
      kind: "energy"
    },
    {
      x: 3700,
      y: 2400,
      label: "Perymetr",
      kind: "danger"
    },
    {
      x: 2400,
      y: 515,
      label: "P\u0142askowy\u017C P\xF3\u0142nocny",
      kind: "danger"
    },
    {
      x: 2400,
      y: 3077,
      label: "Pustkowia Rdzeni",
      kind: "danger"
    },
    {
      x: 4135,
      y: 1796,
      label: "Doki Wschodnie",
      kind: "danger"
    },
    {
      x: 665,
      y: 1796,
      label: "Zbocza Zachodnie",
      kind: "danger"
    },
    {
      x: 2400,
      y: 1275,
      label: "Centrum Synchronizacji",
      kind: "settlement",
      city: true
    },
    {
      x: 3100,
      y: 1577,
      label: "W\u0119ze\u0142 Wymiany",
      kind: "settlement",
      city: true
    },
    {
      x: 3100,
      y: 2327,
      label: "Komora Kalibracji Bojowej",
      kind: "settlement",
      city: true
    },
    {
      x: 2400,
      y: 2570,
      label: "Warsztat Uzbrojenia",
      kind: "settlement",
      city: true
    },
    {
      x: 1650,
      y: 2517,
      label: "Magazyn Rdzeni",
      kind: "settlement",
      city: true
    },
    {
      x: 1700,
      y: 1577,
      label: "Modu\u0142 Regeneracji",
      kind: "settlement",
      city: true
    }
  ],
  objects: [
    {
      id: "lab-0",
      kind: "lab",
      asset: "lab",
      x: 3100,
      y: 1450,
      width: 430,
      height: 340,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 320,
        height: 145
      }
    },
    {
      id: "lab-1",
      kind: "lab",
      asset: "lab",
      x: 2400,
      y: 1150,
      width: 390,
      height: 310,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 285,
        height: 140
      }
    },
    {
      id: "reactor-2",
      kind: "reactor",
      asset: "reactor",
      x: 2850,
      y: 1330,
      width: 340,
      height: 350,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 245,
        height: 125
      }
    },
    {
      id: "lab-3",
      kind: "lab",
      asset: "lab",
      x: 2400,
      y: 2450,
      width: 380,
      height: 320,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 280,
        height: 130
      }
    },
    {
      id: "terminal-5",
      kind: "terminal",
      asset: "terminal",
      x: 2370,
      y: 2070,
      width: 140,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 75,
        height: 65
      }
    },
    {
      id: "crystal-8",
      kind: "crystal",
      asset: "crystal",
      x: 2710,
      y: 2460,
      width: 210,
      height: 270,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 100,
        height: 75
      }
    },
    {
      id: "detail-pylon-9",
      kind: "pylon",
      asset: "pylon",
      x: 1540,
      y: 1830,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-pylon-10",
      kind: "pylon",
      asset: "pylon",
      x: 2040,
      y: 1920,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-pylon-11",
      kind: "pylon",
      asset: "pylon",
      x: 2600,
      y: 1820,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-pylon-12",
      kind: "pylon",
      asset: "pylon",
      x: 3100,
      y: 1780,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-pylon-13",
      kind: "pylon",
      asset: "pylon",
      x: 2700,
      y: 2180,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-pylon-14",
      kind: "pylon",
      asset: "pylon",
      x: 3200,
      y: 2230,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-tech-garden-15",
      kind: "tech-garden",
      asset: "tech-garden",
      x: 1520,
      y: 2120,
      width: 190,
      height: 160,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-tech-garden-16",
      kind: "tech-garden",
      asset: "tech-garden",
      x: 2120,
      y: 2070,
      width: 190,
      height: 160,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-tech-garden-17",
      kind: "tech-garden",
      asset: "tech-garden",
      x: 3120,
      y: 1480,
      width: 190,
      height: 160,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-tech-garden-18",
      kind: "tech-garden",
      asset: "tech-garden",
      x: 2370,
      y: 1500,
      width: 190,
      height: 160,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-tech-garden-19",
      kind: "tech-garden",
      asset: "tech-garden",
      x: 3090,
      y: 2350,
      width: 190,
      height: 160,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "nature-patch-ice-spires-20",
      kind: "patch-ice-spires",
      asset: "nature.patch-ice-spires",
      x: 1845,
      y: 1329,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "nature-patch-ice-spires-21",
      kind: "patch-ice-spires",
      asset: "nature.patch-ice-spires",
      x: 3172,
      y: 1272,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "nature-patch-boulder-group-22",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 2563,
      y: 1251,
      width: 200,
      height: 200,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-north-patch-cliff-outcrop-0",
      kind: "patch-cliff-outcrop",
      asset: "nature.patch-cliff-outcrop",
      x: 1830,
      y: 549,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-north-mountain-peak-1",
      kind: "mountain-peak",
      asset: "nature.mountain-peak",
      x: 942,
      y: 691,
      width: 430,
      height: 430,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 215,
        height: 77,
        offsetY: -17
      }
    },
    {
      id: "zone-north-patch-boulder-group-2",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 2819,
      y: 656,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-north-patch-cliff-outcrop-3",
      kind: "patch-cliff-outcrop",
      asset: "nature.patch-cliff-outcrop",
      x: 4114,
      y: 629,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-north-mountain-peak-4",
      kind: "mountain-peak",
      asset: "nature.mountain-peak",
      x: 1408,
      y: 667,
      width: 430,
      height: 430,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 215,
        height: 77,
        offsetY: -17
      }
    },
    {
      id: "zone-north-patch-boulder-group-5",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 3723,
      y: 545,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-north-patch-cliff-outcrop-6",
      kind: "patch-cliff-outcrop",
      asset: "nature.patch-cliff-outcrop",
      x: 3209,
      y: 693,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-north-mountain-peak-7",
      kind: "mountain-peak",
      asset: "nature.mountain-peak",
      x: 454,
      y: 645,
      width: 430,
      height: 430,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 215,
        height: 77,
        offsetY: -17
      }
    },
    {
      id: "zone-north-patch-boulder-group-8",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 2128,
      y: 574,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-basalt-columns-0",
      kind: "patch-basalt-columns",
      asset: "nature.patch-basalt-columns",
      x: 1036,
      y: 3150,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-boulder-group-1",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 1926,
      y: 3015,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-lava-rocks-2",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 521,
      y: 3210,
      width: 220,
      height: 220,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-basalt-columns-3",
      kind: "patch-basalt-columns",
      asset: "nature.patch-basalt-columns",
      x: 3508,
      y: 2976,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-boulder-group-4",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 4431,
      y: 2939,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-lava-rocks-5",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 2720,
      y: 3119,
      width: 220,
      height: 220,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-basalt-columns-6",
      kind: "patch-basalt-columns",
      asset: "nature.patch-basalt-columns",
      x: 4139,
      y: 2890,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-boulder-group-7",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 3780,
      y: 2891,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-lava-rocks-8",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 367,
      y: 2890,
      width: 220,
      height: 220,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-basalt-columns-9",
      kind: "patch-basalt-columns",
      asset: "nature.patch-basalt-columns",
      x: 2249,
      y: 3269,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-boulder-group-10",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 3085,
      y: 2990,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-lava-rocks-11",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 1442,
      y: 2897,
      width: 220,
      height: 220,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-patch-sea-stacks-0",
      kind: "patch-sea-stacks",
      asset: "nature.patch-sea-stacks",
      x: 4040,
      y: 2463,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-patch-small-island-1",
      kind: "patch-small-island",
      asset: "nature.patch-small-island",
      x: 4388,
      y: 1777,
      width: 280,
      height: 280,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-reed-clump-2",
      kind: "reed-clump",
      asset: "nature.reed-clump",
      x: 4394,
      y: 2083,
      width: 150,
      height: 150,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-east-patch-sea-stacks-3",
      kind: "patch-sea-stacks",
      asset: "nature.patch-sea-stacks",
      x: 4087,
      y: 1098,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-patch-small-island-4",
      kind: "patch-small-island",
      asset: "nature.patch-small-island",
      x: 4245,
      y: 1444,
      width: 280,
      height: 280,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-reed-clump-5",
      kind: "reed-clump",
      asset: "nature.reed-clump",
      x: 3952,
      y: 2011,
      width: 150,
      height: 150,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-east-patch-sea-stacks-6",
      kind: "patch-sea-stacks",
      asset: "nature.patch-sea-stacks",
      x: 4389,
      y: 2509,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-patch-small-island-7",
      kind: "patch-small-island",
      asset: "nature.patch-small-island",
      x: 3943,
      y: 1557,
      width: 280,
      height: 280,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-reed-clump-8",
      kind: "reed-clump",
      asset: "nature.reed-clump",
      x: 3823,
      y: 1121,
      width: 150,
      height: 150,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-east-patch-sea-stacks-9",
      kind: "patch-sea-stacks",
      asset: "nature.patch-sea-stacks",
      x: 4419,
      y: 1102,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-ice-spires-0",
      kind: "patch-ice-spires",
      asset: "nature.patch-ice-spires",
      x: 400,
      y: 2011,
      width: 270,
      height: 270,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-glacier-block-1",
      kind: "patch-glacier-block",
      asset: "nature.patch-glacier-block",
      x: 854,
      y: 1519,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-mountain-peak-2",
      kind: "mountain-peak",
      asset: "nature.mountain-peak",
      x: 828,
      y: 2226,
      width: 400,
      height: 400,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 200,
        height: 72,
        offsetY: -16
      }
    },
    {
      id: "zone-west-patch-ice-spires-3",
      kind: "patch-ice-spires",
      asset: "nature.patch-ice-spires",
      x: 437,
      y: 1314,
      width: 270,
      height: 270,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-glacier-block-4",
      kind: "patch-glacier-block",
      asset: "nature.patch-glacier-block",
      x: 814,
      y: 1147,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "city-lab-arena",
      kind: "lab",
      asset: "lab",
      x: 3100,
      y: 2200,
      width: 430,
      height: 340,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 320,
        height: 145
      }
    },
    {
      id: "city-lab-depot",
      kind: "lab",
      asset: "lab",
      x: 1650,
      y: 2390,
      width: 430,
      height: 340,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 320,
        height: 145
      }
    },
    {
      id: "city-lab-inn",
      kind: "lab",
      asset: "lab",
      x: 1700,
      y: 1450,
      width: 430,
      height: 340,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 320,
        height: 145
      }
    },
    {
      id: "city-pylon-0-0",
      kind: "pylon",
      asset: "pylon",
      x: 2215,
      y: 1365,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-pylon-0-1",
      kind: "pylon",
      asset: "pylon",
      x: 2585,
      y: 1365,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-pylon-1-0",
      kind: "pylon",
      asset: "pylon",
      x: 2915,
      y: 1667,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-pylon-1-1",
      kind: "pylon",
      asset: "pylon",
      x: 3285,
      y: 1667,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-pylon-2-0",
      kind: "pylon",
      asset: "pylon",
      x: 2915,
      y: 2417,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-pylon-2-1",
      kind: "pylon",
      asset: "pylon",
      x: 3285,
      y: 2417,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-pylon-3-0",
      kind: "pylon",
      asset: "pylon",
      x: 2215,
      y: 2660,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-pylon-3-1",
      kind: "pylon",
      asset: "pylon",
      x: 2585,
      y: 2660,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-pylon-4-0",
      kind: "pylon",
      asset: "pylon",
      x: 1465,
      y: 2607,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-pylon-4-1",
      kind: "pylon",
      asset: "pylon",
      x: 1835,
      y: 2607,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-pylon-5-0",
      kind: "pylon",
      asset: "pylon",
      x: 1515,
      y: 1667,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-pylon-5-1",
      kind: "pylon",
      asset: "pylon",
      x: 1885,
      y: 1667,
      width: 100,
      height: 170,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    }
  ],
  obstacles: [
    {
      x: 0,
      y: 0,
      width: 4800,
      height: 110
    },
    {
      x: 0,
      y: 110,
      width: 140,
      height: 3482
    },
    {
      x: 4660,
      y: 110,
      width: 140,
      height: 3482
    },
    {
      x: 140,
      y: 3492,
      width: 4520,
      height: 100
    },
    {
      x: 2020,
      y: 1570,
      width: 470,
      height: 180
    }
  ],
  terrain: {
    ground: "nexus-ground",
    path: "nexus-path",
    plaza: "nexus-plaza",
    paths: [
      {
        x: 1670,
        y: 1830,
        width: 1350,
        height: 180
      },
      {
        x: 2680,
        y: 1410,
        width: 220,
        height: 600
      },
      {
        x: 1810,
        y: 1400,
        width: 900,
        height: 150
      },
      {
        x: 1630,
        y: 1950,
        width: 180,
        height: 450
      },
      {
        x: 2870,
        y: 1930,
        width: 210,
        height: 420
      }
    ],
    plazas: [
      {
        x: 1540,
        y: 1870,
        width: 460,
        height: 340
      },
      {
        x: 2620,
        y: 1430,
        width: 470,
        height: 340
      },
      {
        x: 2820,
        y: 2220,
        width: 480,
        height: 210
      }
    ],
    zones: [
      {
        id: "north",
        texture: "nature-cliff-rock",
        points: [
          [60, 60],
          [300, 60],
          [540, 60],
          [780, 60],
          [1020, 60],
          [1260, 60],
          [1500, 60],
          [1740, 60],
          [1980, 60],
          [2220, 60],
          [2460, 60],
          [2700, 60],
          [2940, 60],
          [3180, 60],
          [3420, 60],
          [3660, 60],
          [3900, 60],
          [4140, 60],
          [4380, 60],
          [4620, 60],
          [4740, 60],
          [4740, 300],
          [4740, 540],
          [4740, 780],
          [4740, 904],
          [4500, 970],
          [4260, 978],
          [4020, 948],
          [3780, 985],
          [3540, 1038],
          [3300, 925],
          [3060, 927],
          [2820, 1006],
          [2580, 935],
          [2340, 981],
          [2100, 930],
          [1860, 1035],
          [1620, 985],
          [1380, 965],
          [1140, 1007],
          [900, 998],
          [660, 981],
          [420, 1019],
          [180, 999],
          [60, 970],
          [60, 730],
          [60, 490],
          [60, 250]
        ]
      },
      {
        id: "south",
        texture: "nature-ash-ground",
        points: [
          [60, 2623],
          [300, 2561],
          [540, 2649],
          [780, 2564],
          [1020, 2574],
          [1260, 2628],
          [1500, 2563],
          [1740, 2620],
          [1980, 2659],
          [2220, 2690],
          [2460, 2632],
          [2700, 2569],
          [2940, 2582],
          [3180, 2604],
          [3420, 2623],
          [3660, 2615],
          [3900, 2553],
          [4140, 2581],
          [4380, 2570],
          [4620, 2620],
          [4740, 2622],
          [4740, 2862],
          [4740, 3102],
          [4740, 3342],
          [4740, 3532],
          [4500, 3532],
          [4260, 3532],
          [4020, 3532],
          [3780, 3532],
          [3540, 3532],
          [3300, 3532],
          [3060, 3532],
          [2820, 3532],
          [2580, 3532],
          [2340, 3532],
          [2100, 3532],
          [1860, 3532],
          [1620, 3532],
          [1380, 3532],
          [1140, 3532],
          [900, 3532],
          [660, 3532],
          [420, 3532],
          [180, 3532],
          [60, 3532],
          [60, 3292],
          [60, 3052],
          [60, 2812]
        ]
      },
      {
        id: "east",
        texture: "nature-sand-beach",
        points: [
          [3530, 769],
          [3770, 853],
          [4010, 794],
          [4250, 765],
          [4490, 801],
          [4730, 783],
          [4740, 810],
          [4740, 1050],
          [4740, 1290],
          [4740, 1530],
          [4740, 1770],
          [4740, 2010],
          [4740, 2250],
          [4740, 2490],
          [4740, 2730],
          [4740, 2725],
          [4500, 2748],
          [4260, 2789],
          [4020, 2727],
          [3780, 2724],
          [3540, 2775],
          [3595, 2782],
          [3545, 2542],
          [3466, 2302],
          [3528, 2062],
          [3595, 1822],
          [3540, 1582],
          [3475, 1342],
          [3578, 1102],
          [3592, 862]
        ]
      },
      {
        id: "west",
        texture: "nature-ice-glacier",
        points: [
          [60, 799],
          [300, 787],
          [540, 788],
          [780, 831],
          [1020, 828],
          [1260, 808],
          [1305, 810],
          [1309, 1050],
          [1226, 1290],
          [1313, 1530],
          [1308, 1770],
          [1248, 2010],
          [1275, 2250],
          [1310, 2490],
          [1314, 2730],
          [1270, 2811],
          [1030, 2800],
          [790, 2760],
          [550, 2800],
          [310, 2830],
          [70, 2780],
          [60, 2782],
          [60, 2542],
          [60, 2302],
          [60, 2062],
          [60, 1822],
          [60, 1582],
          [60, 1342],
          [60, 1102],
          [60, 862]
        ]
      }
    ],
    roads: [
      {
        width: 130,
        points: [
          [2400, 920],
          [2421, 792],
          [2437, 653],
          [2383, 587],
          [2400, 515]
        ]
      },
      {
        width: 130,
        points: [
          [2400, 2672],
          [2379, 2708],
          [2363, 2808],
          [2377, 2936],
          [2400, 3077]
        ]
      },
      {
        width: 130,
        points: [
          [1220, 1796],
          [1034, 1764],
          [893, 1773],
          [789, 1801],
          [665, 1796]
        ]
      },
      {
        width: 130,
        points: [
          [3580, 1796],
          [3647, 1810],
          [3781, 1815],
          [3946, 1818],
          [4135, 1796]
        ]
      },
      {
        width: 110,
        city: true,
        points: [
          [2400, 1275],
          [2382, 1358],
          [2400, 1440]
        ]
      },
      {
        width: 110,
        city: true,
        points: [
          [3100, 1577],
          [3057, 1577],
          [3050, 1577]
        ]
      },
      {
        width: 110,
        city: true,
        points: [
          [2400, 2570],
          [2648, 2480],
          [2860, 2390]
        ]
      },
      {
        width: 110,
        city: true,
        points: [
          [1650, 2517],
          [1678, 2438],
          [1670, 2360]
        ]
      },
      {
        width: 110,
        city: true,
        points: [
          [1700, 1577],
          [1793, 1544],
          [1850, 1510]
        ]
      }
    ]
  },
  border: 4,
  layout: 2,
  legacyShift: {
    x: 1200,
    y: 900
  },
  city: {
    name: "W\u0119ze\u0142 \u015Awiadomo\u015Bci",
    bounds: {
      x: 1350,
      y: 950,
      width: 2050,
      height: 1750
    },
    buildings: [
      {
        id: "hall",
        name: "Centrum Synchronizacji",
        district: "Rdze\u0144 Sieci",
        description: "G\u0142\xF3wny w\u0119ze\u0142 miasta. Tu nowi u\u017Cytkownicy synchronizuj\u0105 si\u0119 z sieci\u0105 i odbieraj\u0105 zadania.",
        objectId: "lab-1",
        door: {
          x: 2400,
          y: 1275
        }
      },
      {
        id: "shop",
        name: "W\u0119ze\u0142 Wymiany",
        district: "Targ W\u0119z\u0142\xF3w",
        description: "Automatyczny punkt wymiany zasob\xF3w: mikstury, pancerze i modu\u0142y.",
        objectId: "lab-0",
        door: {
          x: 3100,
          y: 1577
        }
      },
      {
        id: "arena",
        name: "Komora Kalibracji Bojowej",
        district: "Pole Kalibracji",
        description: "Komora z manekinem treningowym. Sprawdzaj prawdziwe zdolno\u015Bci bez ryzyka i nagr\xF3d.",
        objectId: "city-lab-arena",
        door: {
          x: 3100,
          y: 2327
        }
      },
      {
        id: "smithy",
        name: "Warsztat Uzbrojenia",
        district: "Ku\u017Ania Obwod\xF3w",
        description: "In\u017Cynierowie uzbrojenia kalibruj\u0105 i wzmacniaj\u0105 wyposa\u017Cenie.",
        objectId: "lab-3",
        door: {
          x: 2400,
          y: 2570
        }
      },
      {
        id: "depot",
        name: "Magazyn Rdzeni",
        district: "Archiwum Danych",
        description: "Zabezpieczony magazyn z osobist\u0105 skrzyni\u0105 na przedmioty ka\u017Cdej postaci.",
        objectId: "city-lab-depot",
        door: {
          x: 1650,
          y: 2517
        }
      },
      {
        id: "inn",
        name: "Modu\u0142 Regeneracji",
        district: "Strefa Regeneracji",
        description: "Cicha kapsu\u0142a regeneracyjna, gdzie mo\u017Cna odpocz\u0105\u0107 i odzyska\u0107 energi\u0119.",
        objectId: "city-lab-inn",
        door: {
          x: 1700,
          y: 1577
        }
      }
    ],
    roads: []
  }
};

// src/game/world/regions/pyra.json
var pyra_default = {
  id: "pyra",
  race: "legend",
  name: "Pyra",
  settlement: "Twierdza Popio\u0142u",
  description: "Czerwone kaniony, obsydianowe ska\u0142y i szczeliny roz\u017Carzone pradawn\u0105 energi\u0105.",
  architecture: "Monumentalna forteca, arena klan\xF3w i \u015Bwi\u0105tynie dawnych mistrz\xF3w.",
  width: 4800,
  height: 3592,
  spawn: {
    x: 2380,
    y: 2230
  },
  background: "#35272f",
  minimap: "/game/assets/stage3/pyra-minimap.webp",
  market: {
    x: 2400,
    y: 1650,
    radius: 85,
    label: "Arena Dziedzictwa",
    instruction: "Odwied\u017A oznaczony punkt: Arena Dziedzictwa",
    action: "Podejd\u017A: Arena Dziedzictwa"
  },
  npcs: [
    {
      id: "guide",
      name: "Kaena",
      role: "Stra\u017Cniczka przysi\u0119gi",
      x: 2470,
      y: 2230,
      tint: 11071695,
      dialogue: "Honor zaczyna si\u0119 od dotrzymanej obietnicy. Sta\u0144 na Arenie Dziedzictwa, potem wr\xF3\u0107 i opowiedz, co us\u0142ysza\u0142e\u015B w ciszy ruin."
    },
    {
      id: "hunter",
      name: "Rokan",
      role: "Mistrz polowania",
      x: 2660,
      y: 1750,
      tint: 16762788,
      dialogue: "Dziki z kanionu podchodz\u0105 pod bramy. Pokonaj trzy, a otrzymasz ostrze godne pierwszej pr\xF3by."
    },
    {
      id: "steward",
      name: "Tsubasa",
      role: "Zarz\u0105dca Sali Przysi\u0119gi",
      x: 2400,
      y: 1285,
      tint: 15390133,
      dialogue: "Sala stoi otworem. Przysi\u0119ga z\u0142o\u017Cona w popiele trwa d\u0142u\u017Cej ni\u017C ta spisana atramentem.",
      building: "hall"
    },
    {
      id: "merchant",
      name: "Yumi",
      role: "Kupczyni klan\xF3w",
      x: 3100,
      y: 1572,
      tint: 14070783,
      dialogue: "Nawet wojownik potrzebuje zapas\xF3w. K\u0142y wymienisz tu na monety, mikstury i pancerze.",
      building: "shop"
    },
    {
      id: "trainer",
      name: "Kenzo",
      role: "Mistrz \u0107wicze\u0144",
      x: 3100,
      y: 2325,
      tint: 16755370,
      dialogue: "Manekin nie oddaje cios\xF3w i nie p\u0142aci nagr\xF3d. U\u017Cyj ka\u017Cdej zdolno\u015Bci i zapami\u0119taj, jak dzia\u0142a.",
      building: "arena"
    },
    {
      id: "keeper",
      name: "Mitsu",
      role: "Stra\u017Cniczka skarbca",
      x: 1650,
      y: 2512,
      tint: 12116191,
      dialogue: "Skrzynia jest twoja i tylko twoja. Klan strze\u017Ce jej jak w\u0142asnego ognia.",
      building: "depot"
    },
    {
      id: "smith",
      name: "Goro",
      role: "Kowal \u017Caru",
      x: 2400,
      y: 2582,
      tint: 10802687,
      dialogue: "Ostrze nie walczy za ciebie. Za\u0142\xF3\u017C je i wr\xF3\u0107; za 15 monet zahartuj\u0119 je w ogniu szczelin.",
      building: "smithy"
    },
    {
      id: "innkeeper",
      name: "Akane",
      role: "Gospodyni ogniska",
      x: 1700,
      y: 1572,
      tint: 16766139,
      dialogue: "Usi\u0105d\u017A przy ogniu. Zm\u0119czony wojownik to martwy wojownik, a ja nie lubi\u0119 pustych \u0142aw.",
      building: "inn"
    }
  ],
  enemies: [
    {
      x: 2616,
      y: 348
    },
    {
      x: 3559,
      y: 374
    },
    {
      x: 2045,
      y: 381
    },
    {
      x: 1369,
      y: 641
    },
    {
      x: 2082,
      y: 614
    },
    {
      x: 2293,
      y: 2894
    },
    {
      x: 2698,
      y: 3056
    },
    {
      x: 2256,
      y: 3103
    },
    {
      x: 807,
      y: 3240
    },
    {
      x: 3322,
      y: 3148
    },
    {
      x: 4155,
      y: 2406
    },
    {
      x: 3832,
      y: 1765
    },
    {
      x: 4102,
      y: 1678
    },
    {
      x: 3911,
      y: 1476
    },
    {
      x: 4136,
      y: 1360
    },
    {
      x: 657,
      y: 1766
    },
    {
      x: 873,
      y: 1709
    },
    {
      x: 400,
      y: 2409
    },
    {
      x: 713,
      y: 1571
    },
    {
      x: 888,
      y: 2135
    }
  ],
  enemyName: "Dzik z popielnych kanion\xF3w",
  huntName: "Pr\xF3ba stra\u017Cnika",
  landmarks: [
    {
      x: 2380,
      y: 2220,
      label: "Twierdza Popio\u0142u",
      kind: "settlement"
    },
    {
      x: 2400,
      y: 1650,
      label: "Arena Dziedzictwa",
      kind: "energy"
    },
    {
      x: 3700,
      y: 2300,
      label: "Szczeliny",
      kind: "danger"
    },
    {
      x: 2400,
      y: 515,
      label: "Pola Wulkaniczne",
      kind: "danger"
    },
    {
      x: 2400,
      y: 3077,
      label: "Rzeki Lawy",
      kind: "danger"
    },
    {
      x: 4135,
      y: 1796,
      label: "Czerwone Kaniony",
      kind: "danger"
    },
    {
      x: 665,
      y: 1796,
      label: "Czarne Pustkowia",
      kind: "danger"
    },
    {
      x: 2400,
      y: 1285,
      label: "Sala Przysi\u0119gi",
      kind: "settlement",
      city: true
    },
    {
      x: 3100,
      y: 1572,
      label: "Targ Klan\xF3w",
      kind: "settlement",
      city: true
    },
    {
      x: 3100,
      y: 2325,
      label: "Plac \u0106wicze\u0144 Klan\xF3w",
      kind: "settlement",
      city: true
    },
    {
      x: 2400,
      y: 2582,
      label: "Ku\u017Ania \u017Baru",
      kind: "settlement",
      city: true
    },
    {
      x: 1650,
      y: 2512,
      label: "Skarbiec Klanu",
      kind: "settlement",
      city: true
    },
    {
      x: 1700,
      y: 1572,
      label: "Gospoda Pod \u017Barem",
      kind: "settlement",
      city: true
    }
  ],
  objects: [
    {
      id: "fortress-0",
      kind: "fortress",
      asset: "fortress",
      x: 2400,
      y: 1150,
      width: 570,
      height: 390,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 470,
        height: 160
      }
    },
    {
      id: "war-shrine-1",
      kind: "war-shrine",
      asset: "war-shrine",
      x: 1700,
      y: 1450,
      width: 340,
      height: 340,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 260,
        height: 135
      }
    },
    {
      id: "war-shrine-2",
      kind: "war-shrine",
      asset: "war-shrine",
      x: 3100,
      y: 2200,
      width: 350,
      height: 340,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 270,
        height: 140
      }
    },
    {
      id: "statue-3",
      kind: "statue",
      asset: "statue",
      x: 2060,
      y: 1670,
      width: 160,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 80,
        height: 65
      }
    },
    {
      id: "statue-4",
      kind: "statue",
      asset: "statue",
      x: 2740,
      y: 1670,
      width: 160,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 80,
        height: 65
      }
    },
    {
      id: "detail-volcano-9",
      kind: "patch-volcano-active",
      asset: "nature.patch-volcano-active",
      x: 1650,
      y: 1230,
      width: 420,
      height: 420,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-volcano-10",
      kind: "patch-volcano-dormant",
      asset: "nature.patch-volcano-dormant",
      x: 3170,
      y: 1230,
      width: 420,
      height: 420,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-clan-banner-11",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 2130,
      y: 2080,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-clan-banner-12",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 2710,
      y: 2060,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-clan-banner-13",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 1890,
      y: 2220,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-clan-banner-14",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 3e3,
      y: 2260,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-clan-banner-15",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 2130,
      y: 1450,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-clan-banner-16",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 2680,
      y: 1450,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-basalt-17",
      kind: "basalt",
      asset: "basalt",
      x: 1480,
      y: 2070,
      width: 140,
      height: 140,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-basalt-18",
      kind: "basalt",
      asset: "basalt",
      x: 3380,
      y: 1880,
      width: 140,
      height: 140,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-basalt-19",
      kind: "basalt",
      asset: "basalt",
      x: 2700,
      y: 2560,
      width: 140,
      height: 140,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "detail-basalt-20",
      kind: "basalt",
      asset: "basalt",
      x: 2080,
      y: 1370,
      width: 140,
      height: 140,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "nature-patch-lava-rocks-21",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 2939,
      y: 1503,
      width: 200,
      height: 200,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "nature-patch-boulder-group-22",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 2805,
      y: 1249,
      width: 200,
      height: 200,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "zone-north-patch-volcano-active-0",
      kind: "patch-volcano-active",
      asset: "nature.patch-volcano-active",
      x: 917,
      y: 666,
      width: 440,
      height: 440,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: true,
      footprint: {
        width: 220,
        height: 79,
        offsetY: -18
      }
    },
    {
      id: "zone-north-patch-volcano-dormant-1",
      kind: "patch-volcano-dormant",
      asset: "nature.patch-volcano-dormant",
      x: 3998,
      y: 686,
      width: 440,
      height: 440,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: true,
      footprint: {
        width: 220,
        height: 79,
        offsetY: -18
      }
    },
    {
      id: "zone-north-patch-lava-rocks-2",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 2826,
      y: 454,
      width: 240,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-north-patch-volcano-active-3",
      kind: "patch-volcano-active",
      asset: "nature.patch-volcano-active",
      x: 3278,
      y: 623,
      width: 440,
      height: 440,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: true,
      footprint: {
        width: 220,
        height: 79,
        offsetY: -18
      }
    },
    {
      id: "zone-north-patch-volcano-dormant-4",
      kind: "patch-volcano-dormant",
      asset: "nature.patch-volcano-dormant",
      x: 1698,
      y: 625,
      width: 440,
      height: 440,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: true,
      footprint: {
        width: 220,
        height: 79,
        offsetY: -18
      }
    },
    {
      id: "zone-north-patch-lava-rocks-5",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 384,
      y: 636,
      width: 240,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-lava-rocks-0",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 3583,
      y: 3197,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-basalt-columns-1",
      kind: "patch-basalt-columns",
      asset: "nature.patch-basalt-columns",
      x: 3086,
      y: 3180,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-boulder-group-2",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 3849,
      y: 3150,
      width: 220,
      height: 220,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-lava-rocks-3",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 4396,
      y: 3038,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-basalt-columns-4",
      kind: "patch-basalt-columns",
      asset: "nature.patch-basalt-columns",
      x: 2101,
      y: 2901,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-boulder-group-5",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 2575,
      y: 2914,
      width: 220,
      height: 220,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-lava-rocks-6",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 987,
      y: 3069,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-basalt-columns-7",
      kind: "patch-basalt-columns",
      asset: "nature.patch-basalt-columns",
      x: 1610,
      y: 3168,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-boulder-group-8",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 1267,
      y: 3118,
      width: 220,
      height: 220,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-lava-rocks-9",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 357,
      y: 3188,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-basalt-columns-10",
      kind: "patch-basalt-columns",
      asset: "nature.patch-basalt-columns",
      x: 3094,
      y: 2886,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-south-patch-boulder-group-11",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 693,
      y: 2920,
      width: 220,
      height: 220,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-patch-cliff-outcrop-0",
      kind: "patch-cliff-outcrop",
      asset: "nature.patch-cliff-outcrop",
      x: 4003,
      y: 2113,
      width: 320,
      height: 320,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-mountain-peak-1",
      kind: "mountain-peak",
      asset: "nature.mountain-peak",
      x: 3876,
      y: 1304,
      width: 430,
      height: 430,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 215,
        height: 77,
        offsetY: -17
      }
    },
    {
      id: "zone-east-patch-boulder-group-2",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 4444,
      y: 2505,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-patch-cliff-outcrop-3",
      kind: "patch-cliff-outcrop",
      asset: "nature.patch-cliff-outcrop",
      x: 4419,
      y: 1749,
      width: 320,
      height: 320,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-mountain-peak-4",
      kind: "mountain-peak",
      asset: "nature.mountain-peak",
      x: 4355,
      y: 1219,
      width: 430,
      height: 430,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 215,
        height: 77,
        offsetY: -17
      }
    },
    {
      id: "zone-east-patch-boulder-group-5",
      kind: "patch-boulder-group",
      asset: "nature.patch-boulder-group",
      x: 3907,
      y: 2384,
      width: 230,
      height: 230,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-east-patch-cliff-outcrop-6",
      kind: "patch-cliff-outcrop",
      asset: "nature.patch-cliff-outcrop",
      x: 4378,
      y: 2157,
      width: 320,
      height: 320,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-basalt-columns-0",
      kind: "patch-basalt-columns",
      asset: "nature.patch-basalt-columns",
      x: 438,
      y: 1752,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-lava-rocks-1",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 379,
      y: 1254,
      width: 240,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-cliff-outcrop-2",
      kind: "patch-cliff-outcrop",
      asset: "nature.patch-cliff-outcrop",
      x: 937,
      y: 2483,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-basalt-columns-3",
      kind: "patch-basalt-columns",
      asset: "nature.patch-basalt-columns",
      x: 673,
      y: 1083,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-lava-rocks-4",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 929,
      y: 1395,
      width: 240,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-cliff-outcrop-5",
      kind: "patch-cliff-outcrop",
      asset: "nature.patch-cliff-outcrop",
      x: 594,
      y: 2441,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-basalt-columns-6",
      kind: "patch-basalt-columns",
      asset: "nature.patch-basalt-columns",
      x: 690,
      y: 2100,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-lava-rocks-7",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 976,
      y: 2064,
      width: 240,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-cliff-outcrop-8",
      kind: "patch-cliff-outcrop",
      asset: "nature.patch-cliff-outcrop",
      x: 1009,
      y: 1086,
      width: 300,
      height: 300,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-basalt-columns-9",
      kind: "patch-basalt-columns",
      asset: "nature.patch-basalt-columns",
      x: 367,
      y: 2091,
      width: 260,
      height: 260,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "zone-west-patch-lava-rocks-10",
      kind: "patch-lava-rocks",
      asset: "nature.patch-lava-rocks",
      x: 666,
      y: 1372,
      width: 240,
      height: 240,
      anchorX: 0.5,
      anchorY: 0.6,
      solid: false
    },
    {
      id: "city-shrine-shop",
      kind: "war-shrine",
      asset: "war-shrine",
      x: 3100,
      y: 1450,
      width: 340,
      height: 340,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 260,
        height: 135
      }
    },
    {
      id: "city-shrine-smithy",
      kind: "war-shrine",
      asset: "war-shrine",
      x: 2400,
      y: 2460,
      width: 340,
      height: 340,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 260,
        height: 135
      }
    },
    {
      id: "city-shrine-depot",
      kind: "war-shrine",
      asset: "war-shrine",
      x: 1650,
      y: 2390,
      width: 340,
      height: 340,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: true,
      footprint: {
        width: 260,
        height: 135
      }
    },
    {
      id: "city-banner-0-0",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 2215,
      y: 1375,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-banner-0-1",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 2585,
      y: 1375,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-banner-1-0",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 2915,
      y: 1662,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-banner-1-1",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 3285,
      y: 1662,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-banner-2-0",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 2915,
      y: 2415,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-banner-2-1",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 3285,
      y: 2415,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-banner-3-0",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 2215,
      y: 2672,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-banner-3-1",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 2585,
      y: 2672,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-banner-4-0",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 1465,
      y: 2602,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-banner-4-1",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 1835,
      y: 2602,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-banner-5-0",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 1515,
      y: 1662,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    },
    {
      id: "city-banner-5-1",
      kind: "clan-banner",
      asset: "clan-banner",
      x: 1885,
      y: 1662,
      width: 110,
      height: 180,
      anchorX: 0.5,
      anchorY: 0.92,
      solid: false
    }
  ],
  obstacles: [
    {
      x: 0,
      y: 0,
      width: 4800,
      height: 110
    },
    {
      x: 0,
      y: 110,
      width: 140,
      height: 3482
    },
    {
      x: 4660,
      y: 110,
      width: 140,
      height: 3482
    },
    {
      x: 140,
      y: 3492,
      width: 4520,
      height: 100
    },
    {
      x: 2640,
      y: 2390,
      width: 310,
      height: 80
    }
  ],
  terrain: {
    ground: "pyra-ground",
    path: "pyra-path",
    plaza: "pyra-plaza",
    paths: [
      {
        x: 2280,
        y: 1350,
        width: 240,
        height: 1e3
      },
      {
        x: 1850,
        y: 2120,
        width: 1190,
        height: 160
      },
      {
        x: 1710,
        y: 1770,
        width: 170,
        height: 500
      },
      {
        x: 2890,
        y: 1750,
        width: 170,
        height: 500
      }
    ],
    plazas: [
      {
        x: 2e3,
        y: 1510,
        width: 800,
        height: 420
      },
      {
        x: 2160,
        y: 2080,
        width: 520,
        height: 320
      }
    ],
    zones: [
      {
        id: "north",
        texture: "nature-lava-crust",
        points: [
          [60, 60],
          [300, 60],
          [540, 60],
          [780, 60],
          [1020, 60],
          [1260, 60],
          [1500, 60],
          [1740, 60],
          [1980, 60],
          [2220, 60],
          [2460, 60],
          [2700, 60],
          [2940, 60],
          [3180, 60],
          [3420, 60],
          [3660, 60],
          [3900, 60],
          [4140, 60],
          [4380, 60],
          [4620, 60],
          [4740, 60],
          [4740, 300],
          [4740, 540],
          [4740, 780],
          [4740, 1007],
          [4500, 1001],
          [4260, 936],
          [4020, 1032],
          [3780, 966],
          [3540, 940],
          [3300, 1e3],
          [3060, 944],
          [2820, 964],
          [2580, 936],
          [2340, 921],
          [2100, 978],
          [1860, 918],
          [1620, 953],
          [1380, 936],
          [1140, 959],
          [900, 939],
          [660, 987],
          [420, 1019],
          [180, 995],
          [60, 970],
          [60, 730],
          [60, 490],
          [60, 250]
        ]
      },
      {
        id: "south",
        texture: "nature-basalt-columns",
        points: [
          [60, 2681],
          [300, 2629],
          [540, 2602],
          [780, 2643],
          [1020, 2556],
          [1260, 2644],
          [1500, 2589],
          [1740, 2656],
          [1980, 2581],
          [2220, 2556],
          [2460, 2653],
          [2700, 2571],
          [2940, 2602],
          [3180, 2625],
          [3420, 2661],
          [3660, 2578],
          [3900, 2674],
          [4140, 2553],
          [4380, 2671],
          [4620, 2565],
          [4740, 2622],
          [4740, 2862],
          [4740, 3102],
          [4740, 3342],
          [4740, 3532],
          [4500, 3532],
          [4260, 3532],
          [4020, 3532],
          [3780, 3532],
          [3540, 3532],
          [3300, 3532],
          [3060, 3532],
          [2820, 3532],
          [2580, 3532],
          [2340, 3532],
          [2100, 3532],
          [1860, 3532],
          [1620, 3532],
          [1380, 3532],
          [1140, 3532],
          [900, 3532],
          [660, 3532],
          [420, 3532],
          [180, 3532],
          [60, 3532],
          [60, 3292],
          [60, 3052],
          [60, 2812]
        ]
      },
      {
        id: "east",
        texture: "nature-cliff-rock",
        points: [
          [3530, 796],
          [3770, 773],
          [4010, 815],
          [4250, 857],
          [4490, 830],
          [4730, 865],
          [4740, 810],
          [4740, 1050],
          [4740, 1290],
          [4740, 1530],
          [4740, 1770],
          [4740, 2010],
          [4740, 2250],
          [4740, 2490],
          [4740, 2730],
          [4740, 2832],
          [4500, 2741],
          [4260, 2787],
          [4020, 2794],
          [3780, 2804],
          [3540, 2834],
          [3510, 2782],
          [3500, 2542],
          [3529, 2302],
          [3588, 2062],
          [3525, 1822],
          [3462, 1582],
          [3507, 1342],
          [3508, 1102],
          [3588, 862]
        ]
      },
      {
        id: "west",
        texture: "nature-ash-ground",
        points: [
          [60, 773],
          [300, 863],
          [540, 741],
          [780, 824],
          [1020, 822],
          [1260, 826],
          [1336, 810],
          [1298, 1050],
          [1283, 1290],
          [1246, 1530],
          [1269, 1770],
          [1206, 2010],
          [1283, 2250],
          [1286, 2490],
          [1338, 2730],
          [1270, 2798],
          [1030, 2794],
          [790, 2763],
          [550, 2717],
          [310, 2717],
          [70, 2714],
          [60, 2782],
          [60, 2542],
          [60, 2302],
          [60, 2062],
          [60, 1822],
          [60, 1582],
          [60, 1342],
          [60, 1102],
          [60, 862]
        ]
      }
    ],
    roads: [
      {
        width: 130,
        points: [
          [2400, 920],
          [2344, 827],
          [2338, 753],
          [2360, 606],
          [2400, 515]
        ]
      },
      {
        width: 130,
        points: [
          [2400, 2672],
          [2337, 2793],
          [2326, 2914],
          [2324, 2985],
          [2400, 3077]
        ]
      },
      {
        width: 130,
        points: [
          [1220, 1796],
          [1116, 1800],
          [1013, 1858],
          [805, 1827],
          [665, 1796]
        ]
      },
      {
        width: 130,
        points: [
          [3580, 1796],
          [3736, 1819],
          [3947, 1777],
          [4030, 1781],
          [4135, 1796]
        ]
      },
      {
        width: 110,
        city: true,
        points: [
          [2400, 1285],
          [2382, 1338],
          [2400, 1390]
        ]
      },
      {
        width: 110,
        city: true,
        points: [
          [3100, 1572],
          [3042, 1681],
          [3020, 1790]
        ]
      },
      {
        width: 110,
        city: true,
        points: [
          [3100, 2325],
          [3032, 2282],
          [3e3, 2240]
        ]
      },
      {
        width: 110,
        city: true,
        points: [
          [2400, 2582],
          [2382, 2471],
          [2400, 2360]
        ]
      },
      {
        width: 110,
        city: true,
        points: [
          [1650, 2512],
          [1718, 2371],
          [1750, 2230]
        ]
      },
      {
        width: 110,
        city: true,
        points: [
          [1700, 1572],
          [1743, 1691],
          [1750, 1810]
        ]
      }
    ]
  },
  border: 4,
  layout: 2,
  legacyShift: {
    x: 1200,
    y: 900
  },
  city: {
    name: "Twierdza Popio\u0142u",
    bounds: {
      x: 1350,
      y: 950,
      width: 2050,
      height: 1750
    },
    buildings: [
      {
        id: "hall",
        name: "Sala Przysi\u0119gi",
        district: "Bramy Twierdzy",
        description: "Serce Twierdzy Popio\u0142u. Tu sk\u0142ada si\u0119 przysi\u0119g\u0119, przyjmuje zadania i poznaje histori\u0119 klan\xF3w.",
        objectId: "fortress-0",
        door: {
          x: 2400,
          y: 1285
        }
      },
      {
        id: "shop",
        name: "Targ Klan\xF3w",
        district: "Targ Klanowy",
        description: "Kupcy klan\xF3w wymieniaj\u0105 k\u0142y na monety, mikstury i pancerze.",
        objectId: "city-shrine-shop",
        door: {
          x: 3100,
          y: 1572
        }
      },
      {
        id: "arena",
        name: "Plac \u0106wicze\u0144 Klan\xF3w",
        district: "Pole Treningowe",
        description: "Plac z manekinem treningowym. Sprawdzaj prawdziwe zdolno\u015Bci bez ryzyka i nagr\xF3d.",
        objectId: "war-shrine-2",
        door: {
          x: 3100,
          y: 2325
        }
      },
      {
        id: "smithy",
        name: "Ku\u017Ania \u017Baru",
        district: "Palenisko",
        description: "Kowale \u017Caru hartuj\u0105 i wzmacniaj\u0105 ostrza w ogniu szczelin.",
        objectId: "city-shrine-smithy",
        door: {
          x: 2400,
          y: 2582
        }
      },
      {
        id: "depot",
        name: "Skarbiec Klanu",
        district: "Skarbce",
        description: "Strze\u017Cony skarbiec z osobist\u0105 skrzyni\u0105 na przedmioty ka\u017Cdej postaci.",
        objectId: "city-shrine-depot",
        door: {
          x: 1650,
          y: 2512
        }
      },
      {
        id: "inn",
        name: "Gospoda Pod \u017Barem",
        district: "Ostoja",
        description: "Ciep\u0142a gospoda przy ognisku, gdzie mo\u017Cna odpocz\u0105\u0107 i odzyska\u0107 si\u0142y.",
        objectId: "war-shrine-1",
        door: {
          x: 1700,
          y: 1572
        }
      }
    ],
    roads: []
  }
};

// src/game/city/verdantia.ts
var plots = [
  {
    id: "shop",
    name: "Dom Handlowy Mio",
    district: "Dzielnica kupiecka",
    kind: "cottage",
    x: 500,
    y: 650,
    description: "Mikstury, wyposa\u017Cenie i skup materia\u0142\xF3w."
  },
  {
    id: "hall",
    name: "Dom Zgromadze\u0144",
    district: "G\xF3rny taras",
    kind: "inn",
    x: 1400,
    y: 420,
    description: "Mieszka\u0144cy i przewodnik po us\u0142ugach miasta."
  },
  {
    id: "inn",
    name: "Gospoda pod Li\u015Bciem",
    district: "Ogrody wschodnie",
    kind: "inn",
    x: 2100,
    y: 620,
    description: "Odpoczynek i regeneracja \u017Cycia oraz KI."
  },
  {
    id: "smithy",
    name: "Ku\u017Ania Taro",
    district: "Dzielnica rzemie\u015Blnicza",
    kind: "forge",
    x: 500,
    y: 1530,
    description: "Ulepszanie ostrza i przygotowanie wyposa\u017Cenia."
  },
  {
    id: "depot",
    name: "Depozyt Korzeni",
    district: "Po\u0142udniowa aleja",
    kind: "cottage",
    x: 1380,
    y: 1720,
    description: "Osobista skrzynia tej postaci: przedmioty i materia\u0142y."
  },
  {
    id: "arena",
    name: "Dom Treningu",
    district: "Dziedziniec stra\u017Cy",
    kind: "inn",
    x: 2080,
    y: 1580,
    description: "Bezpieczna arena z manekinem i pomiarem obra\u017Ce\u0144."
  }
];
var roads = [
  { x: 420, y: 735, width: 1660, height: 120 },
  { x: 420, y: 780, width: 140, height: 900 },
  { x: 1320, y: 490, width: 160, height: 1380 },
  { x: 2020, y: 690, width: 140, height: 1050 },
  { x: 460, y: 1110, width: 1770, height: 140 },
  { x: 460, y: 1670, width: 1690, height: 120 }
];
var VERDANT_CITY = {
  name: "Zielona Przysta\u0144",
  buildings: plots.map((p) => ({ ...p, objectId: "city-" + p.id, door: { x: p.x, y: p.y + 75 } })),
  roads
};
var oldBuildings = /* @__PURE__ */ new Set(["cottage", "inn", "forge", "market"]);
var inClearing = (o) => plots.some((p) => Math.abs(o.x - p.x) < 355 && o.y > p.y - 450 && o.y < p.y + 190) || roads.some(
  (r) => o.x > r.x - 95 && o.x < r.x + r.width + 95 && o.y > r.y - 70 && o.y < r.y + r.height + 70
);
var CITY_OBJECTS = [
  ...FOREST_OBJECTS.filter(
    (o) => !oldBuildings.has(o.kind) && (!inClearing(o) || ["bridge", "fountain", "lamp"].includes(o.kind))
  ),
  ...plots.map((p) => ({
    id: "city-" + p.id,
    kind: p.kind,
    x: p.x,
    y: p.y,
    width: 500,
    height: 440,
    anchorX: 0.5,
    anchorY: 0.85,
    solid: true,
    footprint: { width: 330, height: 110, offsetY: -30 }
  }))
];
var CITY_OBSTACLES = [
  ...FOREST.riverRows,
  ...CITY_OBJECTS.filter((o) => o.solid && o.footprint).map((o) => ({
    x: o.x - o.footprint.width / 2,
    y: o.y + (o.footprint.offsetY ?? 0) - o.footprint.height / 2,
    width: o.footprint.width,
    height: o.footprint.height
  }))
];
var CITY_NPCS = [
  {
    id: "guide",
    name: "Aira",
    role: "Przewodniczka miasta",
    x: 1570,
    y: 1250,
    tint: 11071695,
    dialogue: "Witaj w Zielonej Przystani. Odwied\u017A Rynek na p\xF3\u0142noc od fontanny i wr\xF3\u0107 po 40 XP oraz 40 monet na pierwsze wyposa\u017Cenie. Miasto jest bezpieczne. Us\u0142ugi znajdziesz w osobnych dzielnicach \u2014 otw\xF3rz plan miasta."
  },
  {
    id: "hunter",
    name: "Ren",
    role: "Stra\u017Cnik bramy",
    x: 2210,
    y: 1150,
    tint: 16762788,
    dialogue: "W mie\u015Bcie nie ma dzik\xF3w ani wrogich spawn\xF3w. Najpierw przygotuj wyposa\u017Cenie i po\u0107wicz w Domu Treningu. Wyprawy i przeciwnicy za bram\u0105 powstan\u0105 w nast\u0119pnym etapie."
  },
  {
    id: "merchant",
    name: "Mio",
    role: "Kupczyni",
    x: 500,
    y: 725,
    tint: 14070783,
    building: "shop"
  },
  {
    id: "smith",
    name: "Taro",
    role: "Kowal",
    x: 500,
    y: 1605,
    tint: 10802687,
    building: "smithy",
    dialogue: "Ostrze kupisz u Mio. Po zapoznaniu si\u0119 z miastem mog\u0119 nauczy\u0107 ci\u0119 wyposa\u017Cania broni. Ulepszenie za\u0142o\u017Conego ostrza kosztuje 15 monet i dodaje 4 ataku."
  },
  {
    id: "keeper",
    name: "Nela",
    role: "Opiekunka depozytu",
    x: 1380,
    y: 1795,
    tint: 14931099,
    building: "depot",
    dialogue: "Skrzynia po prawej nale\u017Cy wy\u0142\u0105cznie do tej postaci. Mo\u017Cesz od\u0142o\u017Cy\u0107 przedmioty i materia\u0142y oraz odebra\u0107 je p\xF3\u017Aniej. Najpierw zdejmij rzeczy, kt\xF3re nosisz. Depozyt jest zapisywany na tym urz\u0105dzeniu."
  },
  {
    id: "trainer",
    name: "Iwo",
    role: "Mistrz treningu",
    x: 2080,
    y: 1655,
    tint: 16765329,
    building: "arena",
    dialogue: "Manekin nie atakuje i nie daje \u0142up\xF3w, monet ani XP. U\u017Cywaj swoich prawdziwych umiej\u0119tno\u015Bci: koszty KI i odnowienia dzia\u0142aj\u0105 normalnie. Licznik poka\u017Ce trafienia i obra\u017Cenia."
  },
  {
    id: "innkeeper",
    name: "Lina",
    role: "Gospodyni",
    x: 2100,
    y: 695,
    tint: 15578568,
    building: "inn",
    dialogue: "Odpoczynek kosztuje 5 monet i przywraca \u017Cycie oraz KI. Przy pe\u0142nych zasobach nic nie zap\u0142acisz."
  },
  {
    id: "steward",
    name: "Oren",
    role: "Opiekun miasta",
    x: 1400,
    y: 495,
    tint: 13295538,
    building: "hall",
    dialogue: "Zielona Przysta\u0144 ma sze\u015B\u0107 dzielnic us\u0142ugowych po\u0142\u0105czonych alejami. Kupcy s\u0105 na p\xF3\u0142nocnym zachodzie, ku\u017Ania na po\u0142udniowym zachodzie, a depozyt przy po\u0142udniowej alei. Gospoda i trening le\u017C\u0105 na wschodzie."
  }
];

// src/game/world/worlds.ts
var WORLDS = {
  verdant: {
    id: "verdant",
    race: "planetary",
    name: "Verdantia",
    settlement: VERDANT_CITY.name,
    description: "Le\u015Bna dolina, rzeka i kamienne szlaki podr\xF3\u017Cnik\xF3w. \u017Bywa planeta zaprasza do odkrywania.",
    architecture: "Drewniane i kamienne domy, most i ku\u017Ania w\u015Br\xF3d drzew.",
    width: FOREST.width,
    height: FOREST.height,
    spawn: FOREST.spawn,
    background: "#172b1a",
    minimap: "/game/assets/city-verdant-v1/minimap.svg",
    market: { ...TUTORIAL_MARKET, action: "Podejd\u017A do rynku" },
    npcs: CITY_NPCS,
    city: VERDANT_CITY,
    enemies: [],
    enemyName: "Dzik le\u015Bny",
    huntName: "Zagro\u017Cenie w lesie",
    landmarks: [
      { x: 1480, y: 800, label: "Rynek", kind: "settlement" },
      ...VERDANT_CITY.buildings.map((b) => ({
        ...b.door,
        label: b.name,
        kind: "settlement"
      }))
    ],
    objects: CITY_OBJECTS,
    obstacles: CITY_OBSTACLES
  },
  aether: aether_default,
  nexus: nexus_default,
  pyra: pyra_default
};
function worldObstacles(world) {
  if (world.id === "verdant") return [...world.obstacles];
  return [
    ...world.obstacles,
    ...world.objects.filter((o) => o.solid && o.footprint).map((o) => ({
      x: o.x - o.footprint.width / 2,
      y: o.y + (o.footprint.offsetY ?? 0) - o.footprint.height / 2,
      width: o.footprint.width,
      height: o.footprint.height
    }))
  ];
}

// src/game/world/races.ts
var RACE_IDS = ["planetary", "sage", "android", "legend"];
var WORLD_IDS = ["verdant", "aether", "nexus", "pyra"];
var RACES = {
  planetary: {
    name: "Planetarni",
    world: "verdant",
    title: "W rytmie \u017Cywej planety",
    description: "Odkrywcy i stra\u017Cnicy r\xF3wnowagi. Ka\u017Cda \u015Bcie\u017Cka prowadzi do nowej historii.",
    culture: "Wsp\xF3lnoty podr\xF3\u017Cnik\xF3w, rzemie\u015Blnik\xF3w i obro\u0144c\xF3w natury.",
    energy: "\u017Bywa energia ziemi \xB7 adaptacja",
    color: "#b9d994",
    portrait: "/game/assets/stage3/references/planetary.jpg",
    visual: "human-v2"
  },
  sage: {
    name: "M\u0119drcy",
    world: "aether",
    title: "Wiedza jest form\u0105 pot\u0119gi",
    description: "Stra\u017Cnicy pradawnych \u017Ar\xF3de\u0142 KI. Cisza sanktuari\xF3w skrywa pami\u0119\u0107 ca\u0142ych epok.",
    culture: "Szko\u0142y energii, medytacja i mistrzowie staro\u017Cytnych rytua\u0142\xF3w.",
    energy: "Skupione KI \xB7 duchowa dyscyplina",
    color: "#8ee8da",
    portrait: "/game/assets/stage3/references/sage.jpg",
    visual: "human-v2"
  },
  android: {
    name: "Androidy",
    world: "nexus",
    title: "\u015Awiadomo\u015B\u0107 poza granicami cia\u0142a",
    description: "Syntetyczni odkrywcy, kt\xF3rzy pytaj\u0105, gdzie ko\u0144czy si\u0119 maszyna, a zaczyna dusza.",
    culture: "Logika, doskonalenie i odpowiedzialno\u015B\u0107 za rozw\xF3j \u015Bwiadomo\u015Bci.",
    energy: "Energia rdzenia \xB7 precyzja",
    color: "#85caff",
    portrait: "/game/assets/stage3/references/android.jpg",
    visual: "human-v2"
  },
  legend: {
    name: "Legendy",
    world: "pyra",
    title: "Twoje czyny stan\u0105 si\u0119 dziedzictwem",
    description: "Wojownicze klany strzeg\u0105 aren i ruin, w kt\xF3rych nadal p\u0142onie energia dawnych mistrz\xF3w.",
    culture: "Honor, rywalizacja i trening pod okiem stra\u017Cnik\xF3w dziedzictwa.",
    energy: "\u017Bywio\u0142owe KI \xB7 si\u0142a woli",
    color: "#ffad78",
    portrait: "/game/assets/stage3/references/legend.jpg",
    visual: "human-v2"
  }
};

// src/game/city/types.ts
var BUILDING_IDS = ["shop", "hall", "inn", "smithy", "depot", "arena"];
var isCityStage = (world) => !!world.city && !world.city.bounds;
function inSafeCity(world, p, interior) {
  const c = world.city;
  if (!c) return false;
  if (interior || !c.bounds) return true;
  const b = c.bounds;
  return p.x >= b.x && p.x <= b.x + b.width && p.y >= b.y && p.y <= b.y + b.height;
}

// src/game/city/room.ts
function cityRoom(building) {
  const furniture = building === "arena" ? [] : [
    { x: 400, y: 175, width: 160, height: 45 },
    { x: 150, y: 155, width: 80, height: 45 },
    { x: 730, y: 155, width: 80, height: 45 }
  ];
  if (building === "depot" || building === "smithy")
    furniture.push({ x: 610, y: 365, width: 80, height: 30 });
  if (building === "inn")
    furniture.push(
      { x: 610, y: 325, width: 125, height: 85 },
      { x: 185, y: 450, width: 70, height: 30 }
    );
  if (building === "shop")
    furniture.push(
      { x: 625, y: 380, width: 70, height: 28 },
      { x: 705, y: 458, width: 70, height: 38 }
    );
  return {
    width: 960,
    height: 760,
    entry: { x: 480, y: 610 },
    exit: { x: 480, y: 684 },
    npc: { x: 300, y: 330 },
    chest: { x: 650, y: 390 },
    dummy: { x: 600, y: 300 },
    obstacles: [
      { x: 0, y: 0, width: 960, height: 100 },
      { x: 0, y: 0, width: 100, height: 760 },
      { x: 860, y: 0, width: 100, height: 760 },
      { x: 0, y: 710, width: 960, height: 50 },
      ...furniture
    ]
  };
}

// src/game/world/terrain.ts
function terrainAt(world, p) {
  if (world.id !== "verdant") return "open";
  for (const r of FOREST.riverRows)
    if (p.x >= r.x && p.x <= r.x + r.width && p.y >= r.y && p.y <= r.y + r.height) return "water";
  const row = FOREST.vertices[Math.round(p.y / FOREST.tileSize)];
  const corner = row?.[Math.round(p.x / FOREST.tileSize)];
  return corner === 2 ? "rock" : "forest";
}

// src/game/geometry.ts
var FOOT_RADIUS = 12;
var WORLD_EDGE_MARGIN = 16;

// src/game/movement.ts
function blockedAt(x, y, obstacles, radius = FOOT_RADIUS) {
  return obstacles.some((b) => {
    const dx = x - Math.max(b.x, Math.min(x, b.x + b.width));
    const dy = y - Math.max(b.y, Math.min(y, b.y + b.height));
    return dx * dx + dy * dy <= radius * radius;
  });
}
function clearSight(ax, ay, bx, by, obstacles) {
  const steps = Math.max(1, Math.ceil(Math.hypot(bx - ax, by - ay) / 4));
  for (let i = 0; i <= steps; i++) {
    if (blockedAt(ax + (bx - ax) * i / steps, ay + (by - ay) * i / steps, obstacles, 1))
      return false;
  }
  return true;
}

// src/game/navigation.ts
var distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
var Navigation = class {
  constructor(width, height, obstacles, field) {
    this.width = width;
    this.height = height;
    this.obstacles = obstacles;
    this.field = field;
    this.cell = field?.cell ?? 24;
    this.cols = Math.ceil(width / this.cell);
    this.rows = Math.ceil(height / this.cell);
    if (field) {
      if (field.blocked.length !== this.cols * this.rows)
        throw new Error("Invalid navigation field size");
      this.blocked = field.blocked;
      return;
    }
    this.blocked = new Uint8Array(this.cols * this.rows);
    for (let i = 0; i < this.blocked.length; i++) {
      const p = this.point(i);
      this.blocked[i] = this.walkable(p) ? 0 : 1;
    }
  }
  width;
  height;
  obstacles;
  field;
  cell;
  cols;
  rows;
  blocked;
  walkable(p) {
    if (this.field)
      return Number.isFinite(p.x) && Number.isFinite(p.y) && p.x >= WORLD_EDGE_MARGIN && p.y >= WORLD_EDGE_MARGIN && p.x <= this.width - WORLD_EDGE_MARGIN && p.y <= this.height - WORLD_EDGE_MARGIN && this.field.walkable(p);
    return p.x >= WORLD_EDGE_MARGIN && p.y >= WORLD_EDGE_MARGIN && p.x <= this.width - WORLD_EDGE_MARGIN && p.y <= this.height - WORLD_EDGE_MARGIN && !blockedAt(p.x, p.y, this.obstacles, FOOT_RADIUS);
  }
  visible(a, b) {
    return this.field ? this.segment(a, b) : clearSight(a.x, a.y, b.x, b.y, this.obstacles);
  }
  segment(a, b) {
    const steps = Math.max(1, Math.ceil(distance(a, b) / 8));
    for (let i = 1; i <= steps; i++)
      if (!this.walkable({ x: a.x + (b.x - a.x) * i / steps, y: a.y + (b.y - a.y) * i / steps }))
        return false;
    return true;
  }
  index(p) {
    return Math.max(0, Math.min(this.rows - 1, Math.floor(p.y / this.cell))) * this.cols + Math.max(0, Math.min(this.cols - 1, Math.floor(p.x / this.cell)));
  }
  point(i) {
    return {
      x: (i % this.cols + 0.5) * this.cell,
      y: (Math.floor(i / this.cols) + 0.5) * this.cell
    };
  }
  accessibleCell(p) {
    const at = this.index(p), cx = at % this.cols, cy = Math.floor(at / this.cols);
    let best = -1, nearest = Infinity;
    for (let dy = -2; dy <= 2; dy++)
      for (let dx = -2; dx <= 2; dx++) {
        const x = cx + dx, y = cy + dy, i = y * this.cols + x;
        if (x < 0 || y < 0 || x >= this.cols || y >= this.rows || this.blocked[i]) continue;
        const point = this.point(i), d = distance(p, point);
        if (d < nearest && this.segment(p, point)) {
          best = i;
          nearest = d;
        }
      }
    return best;
  }
  safe(p) {
    if (this.walkable(p)) return { ...p };
    const start = this.point(this.index(p));
    for (let r = this.cell; r < 600; r += this.cell)
      for (let angle = 0; angle < 16; angle++) {
        const q = {
          x: start.x + Math.cos(angle * Math.PI / 8) * r,
          y: start.y + Math.sin(angle * Math.PI / 8) * r
        };
        if (this.walkable(q)) return q;
      }
    throw new Error("Brak bezpiecznego punktu na mapie.");
  }
  path(from, requested) {
    const to = this.safe(requested);
    if (this.segment(from, to)) return [to];
    const start = this.accessibleCell(from), goal = this.accessibleCell(to);
    if (start < 0 || goal < 0) return [];
    if (this.field) return this.fieldPath(start, goal, to);
    const open = /* @__PURE__ */ new Set([start]), closed = /* @__PURE__ */ new Set();
    const parent = /* @__PURE__ */ new Map(), cost = /* @__PURE__ */ new Map([[start, 0]]);
    const score = (i) => (cost.get(i) ?? Infinity) + distance(this.point(i), to);
    for (let attempts = 0; open.size && attempts < this.blocked.length; attempts++) {
      let cur = -1, best = Infinity;
      for (const i of open) {
        const s = score(i);
        if (s < best) {
          best = s;
          cur = i;
        }
      }
      if (cur === goal) {
        const result = [to];
        let at = cur;
        while (at !== start) {
          result.unshift(this.point(at));
          at = parent.get(at);
        }
        result.unshift(this.point(start));
        return result;
      }
      open.delete(cur);
      closed.add(cur);
      const cx = cur % this.cols, cy = Math.floor(cur / this.cols);
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue;
          const x = cx + dx, y = cy + dy, n = y * this.cols + x;
          if (x < 0 || y < 0 || x >= this.cols || y >= this.rows || this.blocked[n] || closed.has(n))
            continue;
          if (dx && dy && (this.blocked[cy * this.cols + x] || this.blocked[y * this.cols + cx]))
            continue;
          const c = (cost.get(cur) ?? Infinity) + this.cell * Math.hypot(dx, dy);
          if (c < (cost.get(n) ?? Infinity)) {
            cost.set(n, c);
            parent.set(n, cur);
            open.add(n);
          }
        }
    }
    return [];
  }
  fieldPath(start, goal, to) {
    const queue = [];
    const push = (item) => {
      let i = queue.length;
      queue.push(item);
      while (i > 0) {
        const p = i - 1 >> 1;
        if (queue[p].score <= item.score) break;
        queue[i] = queue[p];
        i = p;
      }
      queue[i] = item;
    };
    const pop = () => {
      const first = queue[0], last = queue.pop();
      if (queue.length) {
        let i = 0;
        while (i * 2 + 1 < queue.length) {
          let child = i * 2 + 1;
          if (child + 1 < queue.length && queue[child + 1].score < queue[child].score) child++;
          if (queue[child].score >= last.score) break;
          queue[i] = queue[child];
          i = child;
        }
        queue[i] = last;
      }
      return first;
    };
    const costs = /* @__PURE__ */ new Map([[start, 0]]), parents = /* @__PURE__ */ new Map();
    const closed = /* @__PURE__ */ new Set();
    push({ id: start, cost: 0, score: distance(this.point(start), to) });
    while (queue.length && closed.size < 1e6) {
      const current = pop(), at = current.id;
      if (closed.has(at)) continue;
      if (at === goal) {
        const path = [to];
        let v = at;
        while (v !== start) {
          path.push(this.point(v));
          v = parents.get(v);
        }
        path.push(this.point(start));
        return path.reverse();
      }
      closed.add(at);
      const x = at % this.cols, y = Math.floor(at / this.cols);
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue;
          const nx = x + dx, ny = y + dy, next = ny * this.cols + nx;
          if (nx < 0 || ny < 0 || nx >= this.cols || ny >= this.rows || this.blocked[next] || closed.has(next))
            continue;
          if (dx && dy && (this.blocked[y * this.cols + nx] || this.blocked[ny * this.cols + x]))
            continue;
          const cost = current.cost + Math.hypot(dx, dy) * this.cell;
          if (cost >= (costs.get(next) ?? Infinity)) continue;
          costs.set(next, cost);
          parents.set(next, at);
          push({ id: next, cost, score: cost + distance(this.point(next), to) });
        }
    }
    return [];
  }
  step(p, to, amount) {
    const d = distance(p, to);
    if (d < 0.01) return p;
    const step = Math.min(amount, d);
    const next = { x: p.x + (to.x - p.x) / d * step, y: p.y + (to.y - p.y) / d * step };
    if (this.walkable(next) && (!this.field || this.segment(p, next))) return next;
    if (this.walkable({ x: next.x, y: p.y }) && (!this.field || this.segment(p, { x: next.x, y: p.y })))
      return { x: next.x, y: p.y };
    if (this.walkable({ x: p.x, y: next.y }) && (!this.field || this.segment(p, { x: p.x, y: next.y })))
      return { x: p.x, y: next.y };
    return p;
  }
};

// src/game/kit/balance.ts
var SPEED_GROWTH_PER_LEVEL = 0.05;
var SPEED_GROWTH_UNTIL = 20;
var speedGrowth = (level) => 1 + SPEED_GROWTH_PER_LEVEL * (Math.min(level, SPEED_GROWTH_UNTIL) - 1);

// src/game/kit/nodes.generated.ts
var RACE_BASE = {
  planetary: {
    base: {
      hp: 125,
      ki: 50,
      attack: 12,
      defense: 5,
      speed: 185,
      kiRegen: 1,
      criticalChancePercent: 5,
      attackIntervalMs: 650
    },
    perLevel: {
      hp: 36,
      ki: 4,
      attack: 4,
      defense: 2.4,
      speed: 0,
      kiRegen: 0.05,
      criticalChancePercent: 0.25,
      attackIntervalMs: 0
    },
    mechanic: "Adaptacja do terenu",
    role: "Mobilny wojownik wr\u0119cz",
    start: "Cios Szlaku"
  },
  sage: {
    base: {
      hp: 100,
      ki: 80,
      attack: 14,
      defense: 3,
      speed: 170,
      kiRegen: 2,
      criticalChancePercent: 5,
      attackIntervalMs: 800
    },
    perLevel: {
      hp: 28,
      ki: 7,
      attack: 4.6,
      defense: 1.6,
      speed: 0,
      kiRegen: 0.1,
      criticalChancePercent: 0.2,
      attackIntervalMs: 0
    },
    mechanic: "Kr\u0119gi \u015Bwiat\u0142a",
    role: "Mag dystansowy i wsparcie",
    start: "Pocisk Ki"
  },
  android: {
    base: {
      hp: 115,
      ki: 60,
      attack: 12,
      defense: 7,
      speed: 175,
      kiRegen: 1.2,
      criticalChancePercent: 8,
      attackIntervalMs: 700
    },
    perLevel: {
      hp: 34,
      ki: 5,
      attack: 3.8,
      defense: 3,
      speed: 0,
      kiRegen: 0.06,
      criticalChancePercent: 0.4,
      attackIntervalMs: 0
    },
    mechanic: "\u0141adunek Rdzenia",
    role: "Precyzyjny strzelec z tarczami",
    start: "Strza\u0142 Impulsowy"
  },
  legend: {
    base: {
      hp: 140,
      ki: 40,
      attack: 14,
      defense: 4,
      speed: 170,
      kiRegen: 0.8,
      criticalChancePercent: 6,
      attackIntervalMs: 750
    },
    perLevel: {
      hp: 42,
      ki: 3,
      attack: 4.6,
      defense: 2,
      speed: 0,
      kiRegen: 0.04,
      criticalChancePercent: 0.3,
      attackIntervalMs: 0
    },
    mechanic: "\u017Bar",
    role: "Wojownik w zwarciu i burst",
    start: "Uderzenie \u017Baru"
  }
};
var KIT_NODES = {
  planetary: [
    {
      id: "R",
      name: "Cios Szlaku",
      type: "starting",
      minLevel: 1,
      requires: [],
      text: "Atak wr\u0119cz \xD71,0 co 650 ms; trzeci cios serii \xD71,3. Bez kosztu Ki."
    },
    {
      id: "A1",
      name: "Szybki Unik",
      type: "active",
      minLevel: 2,
      requires: ["R"],
      text: "Zryw w wybranym kierunku (160 j.), 0,4 s nietykalno\u015Bci; 8 Ki; odn. 6 s."
    },
    {
      id: "A2",
      name: "Lekki Krok",
      type: "passive",
      minLevel: 4,
      requires: ["A1"],
      text: "+6% szybko\u015Bci ruchu."
    },
    {
      id: "A3",
      name: "P\u0119d Szlaku",
      type: "passive",
      minLevel: 4,
      requires: ["A1"],
      text: "Po uniku nast\u0119pny atak zadaje +25% obra\u017Ce\u0144 (5 s)."
    },
    {
      id: "A4",
      name: "Wir Energii",
      type: "active",
      minLevel: 7,
      requires: ["A2", "A3"],
      text: "Wiruj\u0105cy atak wok\xF3\u0142 postaci \xD71,8, promie\u0144 140 j.; 18 Ki; odn. 10 s."
    },
    {
      id: "A5",
      name: "Wiatr w Plecy",
      type: "passive",
      minLevel: 10,
      requires: ["A4"],
      text: "Po pokonaniu wroga +15% szybko\u015Bci ruchu przez 4 s."
    },
    {
      id: "A6",
      name: "Oko Zwiadowcy",
      type: "passive",
      minLevel: 10,
      requires: ["A4"],
      text: "+5% szansy krytyku."
    },
    {
      id: "A7",
      name: "Cios z Cienia",
      type: "choice",
      minLevel: 13,
      requires: ["A5"],
      text: "Pierwszy atak po uniku zawsze jest krytyczny. Wyklucza A8.",
      excludes: "A8"
    },
    {
      id: "A8",
      name: "Nieuchwytny",
      type: "choice",
      minLevel: 13,
      requires: ["A6"],
      text: "Odnowienie Uniku \u221230%, po uniku +20% obrony przez 1 s. Wyklucza A7.",
      excludes: "A7"
    },
    {
      id: "A9",
      name: "Burza W\u0119drowca",
      type: "ultimate",
      minLevel: 16,
      requires: ["A7", "A8"],
      text: "Seria 5 szybkich uderze\u0144 w pobliskich wrog\xF3w, \u0142\u0105cznie \xD74,0; 35 Ki; odn. 30 s."
    },
    {
      id: "B1",
      name: "Impuls Ziemi",
      type: "active",
      minLevel: 2,
      requires: ["R"],
      text: "Uderzenie w ziemi\u0119 \xD71,4, promie\u0144 120 j., spowolnienie 30% na 2 s; 10 Ki; odn. 6 s."
    },
    {
      id: "B2",
      name: "Adaptacja",
      type: "passive",
      minLevel: 4,
      requires: ["B1"],
      text: "Bonus zale\u017Cny od terenu: las +30% regeneracji Ki, ska\u0142y +10% obrony, woda +8% szybko\u015Bci."
    },
    {
      id: "B3",
      name: "Kamienna Sk\xF3ra",
      type: "passive",
      minLevel: 4,
      requires: ["B1"],
      text: "+8% obrony."
    },
    {
      id: "B4",
      name: "Krusz\u0105cy St\u0105p",
      type: "active",
      minLevel: 7,
      requires: ["B2", "B3"],
      text: "Skok i uderzenie \xD72,0, og\u0142uszenie 1 s; 18 Ki; odn. 10 s."
    },
    {
      id: "B5",
      name: "Rezonans",
      type: "passive",
      minLevel: 10,
      requires: ["B4"],
      text: "Impuls Ziemi uderza drugi raz po 0,5 s za 60% obra\u017Ce\u0144."
    },
    {
      id: "B6",
      name: "\u017By\u0142a Ziemi",
      type: "passive",
      minLevel: 10,
      requires: ["B4"],
      text: "Impuls Ziemi zwraca 5 Ki za ka\u017Cdego trafionego wroga (maks. 15)."
    },
    {
      id: "B7",
      name: "G\u0142az Stra\u017Cnik",
      type: "choice",
      minLevel: 13,
      requires: ["B5"],
      text: "Krusz\u0105cy St\u0105p tworzy os\u0142on\u0119 poch\u0142aniaj\u0105c\u0105 15% maks. \u017Cycia przez 5 s. Wyklucza B8.",
      excludes: "B8"
    },
    {
      id: "B8",
      name: "Trz\u0119sienie",
      type: "choice",
      minLevel: 13,
      requires: ["B6"],
      text: "Impuls Ziemi: promie\u0144 +40% i og\u0142uszenie 0,5 s. Wyklucza B7.",
      excludes: "B7"
    },
    {
      id: "B9",
      name: "Gniew Doliny",
      type: "ultimate",
      minLevel: 16,
      requires: ["B7", "B8"],
      text: "Ogromne uderzenie obszarowe \xD74,0, og\u0142uszenie 1,5 s; 35 Ki; odn. 30 s."
    },
    {
      id: "C1",
      name: "Korzenny Oddech",
      type: "active",
      minLevel: 2,
      requires: ["R"],
      text: "Leczy 12% maks. \u017Cycia w ci\u0105gu 4 s; 12 Ki; odn. 12 s."
    },
    {
      id: "C2",
      name: "Zielona Krew",
      type: "passive",
      minLevel: 4,
      requires: ["C1"],
      text: "+10% maks. \u017Cycia."
    },
    {
      id: "C3",
      name: "Le\u015Bna Cierpliwo\u015B\u0107",
      type: "passive",
      minLevel: 4,
      requires: ["C1"],
      text: "Poza walk\u0105 regeneracja \u017Cycia 1% maks. na sekund\u0119."
    },
    {
      id: "C4",
      name: "Tarcza Li\u015Bci",
      type: "active",
      minLevel: 7,
      requires: ["C2", "C3"],
      text: "Tarcza poch\u0142aniaj\u0105ca 18% maks. \u017Cycia przez 5 s; 18 Ki; odn. 12 s."
    },
    {
      id: "C5",
      name: "Korzenie Odporno\u015Bci",
      type: "passive",
      minLevel: 10,
      requires: ["C4"],
      text: "Czas trwania efekt\xF3w kontroli na postaci \u221225%."
    },
    {
      id: "C6",
      name: "Ziarno \u017Bycia",
      type: "passive",
      minLevel: 10,
      requires: ["C4"],
      text: "Leczenie z Korzennego Oddechu +30%."
    },
    {
      id: "C7",
      name: "Stra\u017Cnik Gaju",
      type: "choice",
      minLevel: 13,
      requires: ["C5"],
      text: "Tarcza Li\u015Bci odbija 20% obra\u017Ce\u0144 wr\u0119cz. Wyklucza C8.",
      excludes: "C8"
    },
    {
      id: "C8",
      name: "Dar Lasu",
      type: "choice",
      minLevel: 13,
      requires: ["C6"],
      text: "Korzenny Oddech zwraca 15 Ki. Wyklucza C7.",
      excludes: "C7"
    },
    {
      id: "C9",
      name: "Pie\u015B\u0144 Korzeni",
      type: "ultimate",
      minLevel: 16,
      requires: ["C7", "C8"],
      text: "Leczy 40% maks. \u017Cycia i daje tarcz\u0119 20% na 6 s; 35 Ki; odn. 45 s."
    },
    {
      id: "T",
      name: "Forma Rezonansu \u015Awiata",
      type: "ki-mode",
      minLevel: 20,
      requires: ["A9", "B9", "C9"],
      text: "20 s: +20% Ataku, +15% Obrony, +10% szybko\u015Bci ruchu; aura jako osobny efekt; 50 Ki; odn. 120 s."
    }
  ],
  sage: [
    {
      id: "R",
      name: "Pocisk Ki",
      type: "starting",
      minLevel: 1,
      requires: [],
      text: "Pocisk dystansowy \xD71,0 co 800 ms, zasi\u0119g 420 j. Bez kosztu Ki."
    },
    {
      id: "A1",
      name: "Piecz\u0119\u0107 Energii",
      type: "active",
      minLevel: 2,
      requires: ["R"],
      text: "Znak na celu; po 3 s wybucha za \xD72,0; 12 Ki; odn. 8 s."
    },
    {
      id: "A2",
      name: "Znak Wiedzy",
      type: "passive",
      minLevel: 4,
      requires: ["A1"],
      text: "Wrogowie z piecz\u0119ci\u0105 przyjmuj\u0105 +10% obra\u017Ce\u0144."
    },
    {
      id: "A3",
      name: "Szybka Piecz\u0119\u0107",
      type: "passive",
      minLevel: 4,
      requires: ["A1"],
      text: "Odnowienie Piecz\u0119ci Energii \u221220%."
    },
    {
      id: "A4",
      name: "Strumie\u0144 Ki",
      type: "active",
      minLevel: 7,
      requires: ["A2", "A3"],
      text: "Kana\u0142owany promie\u0144 3 s, \u0142\u0105cznie \xD72,4 (co 0,5 s); 20 Ki; odn. 12 s."
    },
    {
      id: "A5",
      name: "Echo Piecz\u0119ci",
      type: "passive",
      minLevel: 10,
      requires: ["A4"],
      text: "Wybuch Piecz\u0119ci rani te\u017C pobliskich wrog\xF3w za 50% obra\u017Ce\u0144."
    },
    {
      id: "A6",
      name: "Precyzja M\u0119drca",
      type: "passive",
      minLevel: 10,
      requires: ["A4"],
      text: "+8% szansy krytyku."
    },
    {
      id: "A7",
      name: "Z\u0142oty Kr\u0105g",
      type: "choice",
      minLevel: 13,
      requires: ["A5"],
      text: "Wybuch Piecz\u0119ci tworzy kr\u0105g obra\u017Ce\u0144 o promieniu 120 j. Wyklucza A8.",
      excludes: "A8"
    },
    {
      id: "A8",
      name: "Piecz\u0119\u0107 Skupienia",
      type: "choice",
      minLevel: 13,
      requires: ["A6"],
      text: "Wybuch Piecz\u0119ci zwraca 15 Ki. Wyklucza A7.",
      excludes: "A7"
    },
    {
      id: "A9",
      name: "S\u0105d \u015Awiat\u0142a",
      type: "ultimate",
      minLevel: 16,
      requires: ["A7", "A8"],
      text: "Po 1,5 s s\u0142up \u015Bwiat\u0142a w du\u017Cym obszarze \xD74,2; 35 Ki; odn. 30 s."
    },
    {
      id: "B1",
      name: "\u015Awietlista Bariera",
      type: "active",
      minLevel: 2,
      requires: ["R"],
      text: "Tarcza poch\u0142aniaj\u0105ca 15% maks. \u017Cycia przez 4 s; 12 Ki; odn. 10 s."
    },
    {
      id: "B2",
      name: "Kontrola Kr\u0119gu",
      type: "passive",
      minLevel: 4,
      requires: ["B1"],
      text: "Zdolno\u015Bci zostawiaj\u0105 kr\u0105g \u015Bwiat\u0142a (5 s): +10% obrony postaci w jego obr\u0119bie."
    },
    {
      id: "B3",
      name: "G\u0119ste \u015Awiat\u0142o",
      type: "passive",
      minLevel: 4,
      requires: ["B1"],
      text: "Bariera trwa o 2 s d\u0142u\u017Cej."
    },
    {
      id: "B4",
      name: "Kr\u0105g Spowolnienia",
      type: "active",
      minLevel: 7,
      requires: ["B2", "B3"],
      text: "Kr\u0105g na 5 s: wrogowie w nim \u221240% szybko\u015Bci; 18 Ki; odn. 12 s."
    },
    {
      id: "B5",
      name: "Odbicie",
      type: "passive",
      minLevel: 10,
      requires: ["B4"],
      text: "Bariera odbija 15% obra\u017Ce\u0144 z pocisk\xF3w."
    },
    {
      id: "B6",
      name: "Stra\u017Cnik Kr\u0119gu",
      type: "passive",
      minLevel: 10,
      requires: ["B4"],
      text: "Wrogowie w kr\u0119gach zadaj\u0105 \u221210% obra\u017Ce\u0144."
    },
    {
      id: "B7",
      name: "Kopu\u0142a",
      type: "choice",
      minLevel: 13,
      requires: ["B5"],
      text: "Pojemno\u015B\u0107 Bariery +30%. Wyklucza B8.",
      excludes: "B8"
    },
    {
      id: "B8",
      name: "Lustro",
      type: "choice",
      minLevel: 13,
      requires: ["B6"],
      text: "Bariera odbija pierwszy atak wroga w ca\u0142o\u015Bci. Wyklucza B7.",
      excludes: "B7"
    },
    {
      id: "B9",
      name: "\u015Awi\u0105tynia \u015Awiat\u0142a",
      type: "ultimate",
      minLevel: 16,
      requires: ["B7", "B8"],
      text: "Wielki kr\u0105g na 8 s: +30% obrony postaci, wrogowie \u221230% szybko\u015Bci; 35 Ki; odn. 40 s."
    },
    {
      id: "C1",
      name: "Skupienie KI",
      type: "active",
      minLevel: 2,
      requires: ["R"],
      text: "Kana\u0142owanie 3 s: odnawia 30% maks. Ki (przerywane ruchem lub trafieniem); odn. 15 s."
    },
    {
      id: "C2",
      name: "G\u0142\u0119boki Oddech",
      type: "passive",
      minLevel: 4,
      requires: ["C1"],
      text: "+15% maks. Ki."
    },
    {
      id: "C3",
      name: "M\u0105dro\u015B\u0107 Stra\u017Cnik\xF3w",
      type: "passive",
      minLevel: 4,
      requires: ["C1"],
      text: "Koszty Ki zdolno\u015Bci \u22128%."
    },
    {
      id: "C4",
      name: "Medytacja Bojowa",
      type: "active",
      minLevel: 7,
      requires: ["C2", "C3"],
      text: "Kana\u0142owanie 3 s: leczy 20% maks. \u017Cycia; 10 Ki; odn. 15 s."
    },
    {
      id: "C5",
      name: "Czysty Umys\u0142",
      type: "passive",
      minLevel: 10,
      requires: ["C4"],
      text: "Czas trwania efekt\xF3w kontroli na postaci \u221225%."
    },
    {
      id: "C6",
      name: "Strumie\u0144 Wiedzy",
      type: "passive",
      minLevel: 10,
      requires: ["C4"],
      text: "Po Skupieniu KI nast\u0119pna zdolno\u015B\u0107 zadaje +25% obra\u017Ce\u0144 (6 s)."
    },
    {
      id: "C7",
      name: "Dar M\u0119drca",
      type: "choice",
      minLevel: 13,
      requires: ["C5"],
      text: "Medytacja Bojowa leczy o 50% wi\u0119cej. Wyklucza C8.",
      excludes: "C8"
    },
    {
      id: "C8",
      name: "Skupienie Mistrza",
      type: "choice",
      minLevel: 13,
      requires: ["C6"],
      text: "Skupienie KI nie jest przerywane ruchem. Wyklucza C7.",
      excludes: "C7"
    },
    {
      id: "C9",
      name: "Pe\u0142nia Skupienia",
      type: "ultimate",
      minLevel: 16,
      requires: ["C7", "C8"],
      text: "8 s: zdolno\u015Bci nie kosztuj\u0105 Ki i zadaj\u0105 +30% obra\u017Ce\u0144; 20 Ki; odn. 60 s."
    },
    {
      id: "T",
      name: "Forma O\u015Bwiecenia",
      type: "ki-mode",
      minLevel: 20,
      requires: ["A9", "B9", "C9"],
      text: "20 s: +25% Ataku, odnowienia zdolno\u015Bci \u221230%, +15% Obrony; aura jako osobny efekt; 50 Ki; odn. 120 s."
    }
  ],
  android: [
    {
      id: "R",
      name: "Strza\u0142 Impulsowy",
      type: "starting",
      minLevel: 1,
      requires: [],
      text: "Strza\u0142 \xD71,0 co 700 ms, zasi\u0119g 360 j.; ka\u017Cdy strza\u0142 +4 \u0141adunku Rdzenia (maks. 100). Przy 100 przegrzanie: 2 s bez strza\u0142\xF3w. \u0141adunek opada o 6/s poza strzelaniem."
    },
    {
      id: "A1",
      name: "Namierzanie",
      type: "active",
      minLevel: 2,
      requires: ["R"],
      text: "Oznacza cel na 6 s: +15% szansy krytyku przeciw niemu; 8 Ki; odn. 8 s."
    },
    {
      id: "A2",
      name: "Kalibracja",
      type: "passive",
      minLevel: 4,
      requires: ["A1"],
      text: "+6% szansy krytyku."
    },
    {
      id: "A3",
      name: "Stabilizatory",
      type: "passive",
      minLevel: 4,
      requires: ["A1"],
      text: "Zasi\u0119g strza\u0142\xF3w +15%."
    },
    {
      id: "A4",
      name: "Salwa Precyzyjna",
      type: "active",
      minLevel: 7,
      requires: ["A2", "A3"],
      text: "Trzy strza\u0142y w oznaczony cel, \u0142\u0105cznie \xD72,2; 18 Ki; odn. 10 s."
    },
    {
      id: "A5",
      name: "Analiza S\u0142abo\u015Bci",
      type: "passive",
      minLevel: 10,
      requires: ["A4"],
      text: "Oznaczeni wrogowie maj\u0105 \u221210% obrony."
    },
    {
      id: "A6",
      name: "Szybkie Prze\u0142adowanie",
      type: "passive",
      minLevel: 10,
      requires: ["A4"],
      text: "Odst\u0119p strza\u0142\xF3w \u22128%."
    },
    {
      id: "A7",
      name: "Snajper",
      type: "choice",
      minLevel: 13,
      requires: ["A5"],
      text: "+40% obra\u017Ce\u0144 przeciw oznaczonym, odst\u0119p strza\u0142\xF3w +10%. Wyklucza A8.",
      excludes: "A8"
    },
    {
      id: "A8",
      name: "R\xF3j",
      type: "choice",
      minLevel: 13,
      requires: ["A6"],
      text: "Strza\u0142 rozdziela si\u0119 na 2 dodatkowe pobliskie cele (po 40% obra\u017Ce\u0144). Wyklucza A7.",
      excludes: "A7"
    },
    {
      id: "A9",
      name: "Protok\xF3\u0142 Egzekucji",
      type: "ultimate",
      minLevel: 16,
      requires: ["A7", "A8"],
      text: "Strza\u0142 \xD74,0 w oznaczony cel, \xD76,0 gdy cel ma poni\u017Cej 30% \u017Cycia; 35 Ki; odn. 30 s."
    },
    {
      id: "B1",
      name: "Tarcza Plazmowa",
      type: "active",
      minLevel: 2,
      requires: ["R"],
      text: "Tarcza poch\u0142aniaj\u0105ca 18% maks. \u017Cycia przez 5 s; 12 Ki; odn. 10 s."
    },
    {
      id: "B2",
      name: "P\u0142yty Pancerne",
      type: "passive",
      minLevel: 4,
      requires: ["B1"],
      text: "+8% obrony."
    },
    {
      id: "B3",
      name: "Generator Tarczy",
      type: "passive",
      minLevel: 4,
      requires: ["B1"],
      text: "Pojemno\u015B\u0107 Tarczy +25%."
    },
    {
      id: "B4",
      name: "Impuls Odpychaj\u0105cy",
      type: "active",
      minLevel: 7,
      requires: ["B2", "B3"],
      text: "Fala \xD71,2 odpycha pobliskich wrog\xF3w i og\u0142usza na 0,5 s; 18 Ki; odn. 12 s."
    },
    {
      id: "B5",
      name: "Protok\xF3\u0142 Adaptacji",
      type: "passive",
      minLevel: 10,
      requires: ["B4"],
      text: "Tarcza Plazmowa odbija 25% obra\u017Ce\u0144 z pocisk\xF3w."
    },
    {
      id: "B6",
      name: "Samonaprawa",
      type: "passive",
      minLevel: 10,
      requires: ["B4"],
      text: "Regeneracja \u017Cycia 0,5% maks. na sekund\u0119."
    },
    {
      id: "B7",
      name: "Tarcza Kolcowa",
      type: "choice",
      minLevel: 13,
      requires: ["B5"],
      text: "Tarcza odbija 30% obra\u017Ce\u0144 wr\u0119cz. Wyklucza B8.",
      excludes: "B8"
    },
    {
      id: "B8",
      name: "Tarcza Modu\u0142owa",
      type: "choice",
      minLevel: 13,
      requires: ["B6"],
      text: "Odnowienie Tarczy \u221235%. Wyklucza B7.",
      excludes: "B7"
    },
    {
      id: "B9",
      name: "Fortyfikacja",
      type: "ultimate",
      minLevel: 16,
      requires: ["B7", "B8"],
      text: "6 s: +60% obrony i odporno\u015B\u0107 na efekty kontroli; 35 Ki; odn. 40 s."
    },
    {
      id: "C1",
      name: "Wy\u0142adowanie Rdzenia",
      type: "active",
      minLevel: 2,
      requires: ["R"],
      text: "Zu\u017Cywa ca\u0142y \u0141adunek: obra\u017Cenia \xD7(1,0 + \u0141adunek/50), do \xD73,0 przy 100, w linii przed postaci\u0105; 15 Ki; odn. 8 s."
    },
    {
      id: "C2",
      name: "Zarz\u0105dzanie Rdzeniem",
      type: "passive",
      minLevel: 4,
      requires: ["C1"],
      text: "Przegrzanie trwa 1 s zamiast 2 s; \u0141adunek opada o 50% szybciej."
    },
    {
      id: "C3",
      name: "Radiatory",
      type: "passive",
      minLevel: 4,
      requires: ["C1"],
      text: "Ka\u017Cdy strza\u0142 dodaje o 15% mniej \u0141adunku."
    },
    {
      id: "C4",
      name: "Roz\u0142adowanie Awaryjne",
      type: "active",
      minLevel: 7,
      requires: ["C2", "C3"],
      text: "Zeruje \u0141adunek i leczy 10% maks. \u017Cycia; 0 Ki; odn. 20 s."
    },
    {
      id: "C5",
      name: "Rezerwowy Akumulator",
      type: "passive",
      minLevel: 10,
      requires: ["C4"],
      text: "+12% maks. Ki."
    },
    {
      id: "C6",
      name: "Optymalizacja",
      type: "passive",
      minLevel: 10,
      requires: ["C4"],
      text: "Koszt Ki Wy\u0142adowania Rdzenia \u221220%."
    },
    {
      id: "C7",
      name: "Przeci\u0105\u017Cony Rdze\u0144",
      type: "choice",
      minLevel: 13,
      requires: ["C5"],
      text: "Maks. \u0141adunek 150 (Wy\u0142adowanie do \xD74,0); przegrzanie przy 150. Wyklucza C8.",
      excludes: "C8"
    },
    {
      id: "C8",
      name: "Stabilny Rdze\u0144",
      type: "choice",
      minLevel: 13,
      requires: ["C6"],
      text: "Przegrzanie nigdy nie nast\u0119puje; maks. \u0141adunek 70. Wyklucza C7.",
      excludes: "C7"
    },
    {
      id: "C9",
      name: "Przeci\u0105\u017Cenie Systemu",
      type: "ultimate",
      minLevel: 16,
      requires: ["C7", "C8"],
      text: "6 s: zdolno\u015Bci nie kosztuj\u0105 Ki, +40% obra\u017Ce\u0144; potem 2 s wy\u0142\u0105czenia (brak akcji); 35 Ki; odn. 45 s."
    },
    {
      id: "T",
      name: "Forma Pe\u0142nego Rdzenia",
      type: "ki-mode",
      minLevel: 20,
      requires: ["A9", "B9", "C9"],
      text: "20 s: +25% Ataku, +15% Obrony, przegrzanie wy\u0142\u0105czone; aura jako osobny efekt; 50 Ki; odn. 120 s."
    }
  ],
  legend: [
    {
      id: "R",
      name: "Uderzenie \u017Baru",
      type: "starting",
      minLevel: 1,
      requires: [],
      text: "Cios wr\u0119cz \xD71,0 co 750 ms; ka\u017Cde trafienie +4 \u017Baru (maks. 100). \u017Bar daje +0,1% obra\u017Ce\u0144 za punkt (maks. +10%) i opada o 5/s poza walk\u0105."
    },
    {
      id: "A1",
      name: "Ogniste Ci\u0119cie",
      type: "active",
      minLevel: 2,
      requires: ["R"],
      text: "Kombinacja 3 ci\u0119\u0107, \u0142\u0105cznie \xD71,8; 10 Ki; odn. 6 s."
    },
    {
      id: "A2",
      name: "Rozgrzane Ostrza",
      type: "passive",
      minLevel: 4,
      requires: ["A1"],
      text: "Ci\u0119cia podpalaj\u0105 na 3 s (\u0142\u0105cznie 30% Ataku)."
    },
    {
      id: "A3",
      name: "\u0141a\u0144cuch Cios\xF3w",
      type: "passive",
      minLevel: 4,
      requires: ["A1"],
      text: "Po 3 trafieniach z rz\u0119du odst\u0119p atak\xF3w \u221210% na 4 s."
    },
    {
      id: "A4",
      name: "Szar\u017Ca P\u0142omienia",
      type: "active",
      minLevel: 7,
      requires: ["A2", "A3"],
      text: "Doskok (200 j.) i ci\u0119cie \xD72,2; 18 Ki; odn. 10 s."
    },
    {
      id: "A5",
      name: "Roz\u017Carzone Pi\u0119\u015Bci",
      type: "passive",
      minLevel: 10,
      requires: ["A4"],
      text: "+8% Ataku."
    },
    {
      id: "A6",
      name: "Okrucie\u0144stwo",
      type: "passive",
      minLevel: 10,
      requires: ["A4"],
      text: "+6% szansy krytyku."
    },
    {
      id: "A7",
      name: "Taniec P\u0142omieni",
      type: "choice",
      minLevel: 13,
      requires: ["A5"],
      text: "Ogniste Ci\u0119cie ma 5 ci\u0119\u0107 (\u0142\u0105cznie \xD72,6). Wyklucza A8.",
      excludes: "A8"
    },
    {
      id: "A8",
      name: "Pojedynkowicz",
      type: "choice",
      minLevel: 13,
      requires: ["A6"],
      text: "+25% obra\u017Ce\u0144, gdy w zasi\u0119gu 200 j. jest tylko jeden wr\xF3g. Wyklucza A7.",
      excludes: "A7"
    },
    {
      id: "A9",
      name: "Tysi\u0105c Ci\u0119\u0107",
      type: "ultimate",
      minLevel: 16,
      requires: ["A7", "A8"],
      text: "Seria 8 ci\u0119\u0107, \u0142\u0105cznie \xD74,2; 35 Ki; odn. 30 s."
    },
    {
      id: "B1",
      name: "Prze\u0142amanie",
      type: "active",
      minLevel: 2,
      requires: ["R"],
      text: "Cios krusz\u0105cy \xD71,5, og\u0142uszenie 1,2 s i zniszczenie os\u0142on wroga; 12 Ki; odn. 8 s."
    },
    {
      id: "B2",
      name: "Hartowana Sk\xF3ra",
      type: "passive",
      minLevel: 4,
      requires: ["B1"],
      text: "+8% obrony."
    },
    {
      id: "B3",
      name: "Honor Wojownika",
      type: "passive",
      minLevel: 4,
      requires: ["B1"],
      text: "+10% maks. \u017Cycia."
    },
    {
      id: "B4",
      name: "P\u0142omienny Sza\u0142",
      type: "active",
      minLevel: 7,
      requires: ["B2", "B3"],
      text: "8 s: +30% Ataku, \u221220% obrony; 18 Ki; odn. 25 s."
    },
    {
      id: "B5",
      name: "\u017Belazna Wola",
      type: "passive",
      minLevel: 10,
      requires: ["B4"],
      text: "W Szale odporno\u015B\u0107 na og\u0142uszenie."
    },
    {
      id: "B6",
      name: "Krew Legendy",
      type: "passive",
      minLevel: 10,
      requires: ["B4"],
      text: "Po pokonaniu wroga leczy 3% maks. \u017Cycia."
    },
    {
      id: "B7",
      name: "W\u015Bciek\u0142o\u015B\u0107",
      type: "choice",
      minLevel: 13,
      requires: ["B5"],
      text: "Sza\u0142 trwa o 4 s d\u0142u\u017Cej i daje dodatkowe +10% Ataku. Wyklucza B8.",
      excludes: "B8"
    },
    {
      id: "B8",
      name: "Kontrolowany \u017Bar",
      type: "choice",
      minLevel: 13,
      requires: ["B6"],
      text: "Sza\u0142 nie obni\u017Ca obrony. Wyklucza B7.",
      excludes: "B7"
    },
    {
      id: "B9",
      name: "Ostatni P\u0142omie\u0144",
      type: "ultimate",
      minLevel: 16,
      requires: ["B7", "B8"],
      text: "5 s: pierwszy \u015Bmiertelny cios zostawia 1 punkt \u017Cycia i leczy 30% maks. \u017Cycia; 35 Ki; odn. 90 s."
    },
    {
      id: "C1",
      name: "Wybuch Ki",
      type: "active",
      minLevel: 2,
      requires: ["R"],
      text: "Eksplozja wok\xF3\u0142 postaci \xD71,8, promie\u0144 150 j.; 15 Ki; odn. 8 s."
    },
    {
      id: "C2",
      name: "\u017Bar",
      type: "passive",
      minLevel: 4,
      requires: ["C1"],
      text: "\u017Bar ro\u015Bnie o 50% szybciej i opada 2\xD7 wolniej."
    },
    {
      id: "C3",
      name: "Ognisty Oddech",
      type: "passive",
      minLevel: 4,
      requires: ["C1"],
      text: "Wybuch Ki podpala na 4 s (\u0142\u0105cznie 40% Ataku)."
    },
    {
      id: "C4",
      name: "Eksplozja \u017Baru",
      type: "active",
      minLevel: 7,
      requires: ["C2", "C3"],
      text: "Zu\u017Cywa ca\u0142y \u017Bar: obszarowo \xD7(1,0 + \u017Bar/50), do \xD73,0 przy 100; 20 Ki; odn. 12 s."
    },
    {
      id: "C5",
      name: "Szybkie Roz\u017Carzenie",
      type: "passive",
      minLevel: 10,
      requires: ["C4"],
      text: "Walka zaczyna si\u0119 z 20 \u017Baru."
    },
    {
      id: "C6",
      name: "Nieugaszony",
      type: "passive",
      minLevel: 10,
      requires: ["C4"],
      text: "Przy 100 \u017Baru regeneracja Ki +50%."
    },
    {
      id: "C7",
      name: "Wulkan",
      type: "choice",
      minLevel: 13,
      requires: ["C5"],
      text: "Eksplozja \u017Baru: promie\u0144 +50%. Wyklucza C8.",
      excludes: "C8"
    },
    {
      id: "C8",
      name: "Detonator",
      type: "choice",
      minLevel: 13,
      requires: ["C6"],
      text: "Eksplozja \u017Baru: +25% obra\u017Ce\u0144, promie\u0144 \u221220%. Wyklucza C7.",
      excludes: "C7"
    },
    {
      id: "C9",
      name: "Ognisty Kataklizm",
      type: "ultimate",
      minLevel: 16,
      requires: ["C7", "C8"],
      text: "Kolumna ognia w du\u017Cym obszarze \xD74,5 i podpalenie na 5 s; 35 Ki; odn. 30 s."
    },
    {
      id: "T",
      name: "Forma P\u0142omiennego Legendy",
      type: "ki-mode",
      minLevel: 20,
      requires: ["A9", "B9", "C9"],
      text: "20 s: +30% Ataku, \u017Bar utrzymuje si\u0119 na 100; aura jako osobny efekt; 50 Ki; odn. 120 s."
    }
  ]
};

// src/game/kit/base.ts
var CRIT_MULT = 1.5;
var roundHalfUp = (x) => Math.floor(x + 0.5);
var Kit = class {
  constructor(port, race, learned) {
    this.port = port;
    this.race = race;
    this.nodes = KIT_NODES[race];
    this.learned = new Set(learned);
  }
  port;
  race;
  nodes;
  learned;
  cooldowns = {};
  buffs = [];
  shields = [];
  circles = [];
  channel;
  /** Time during which the player can do nothing (Przeciążenie Systemu shutdown, overheating is separate). */
  lockMs = 0;
  timers = [];
  /** Last time the player made a basic attack (series logic). */
  lastBasic = -1e9;
  nextBasicAt = 0;
  has(id) {
    return this.learned.has(id);
  }
  /** Recomputes anything derived from the learned set; called after learning or forgetting. */
  refresh() {
  }
  learn(id) {
    this.learned.add(id);
    this.refresh();
  }
  forgetAll(ids) {
    this.learned.clear();
    for (const id of ids) this.learned.add(id);
    this.cooldowns = {};
    this.buffs = [];
    this.shields = [];
    this.circles = [];
    this.channel = void 0;
    this.timers = [];
    this.refresh();
  }
  /** Racial resource for the HUD. */
  resource() {
    return void 0;
  }
  node(id) {
    return this.nodes.find((n) => n.id === id);
  }
  onTick(_dt) {
  }
  onKill(_foe) {
  }
  /** Bonus to the crit chance against this foe, in percentage points. */
  critVs(_foe) {
    return 0;
  }
  /** Extra damage multiplier (fraction) against this foe. */
  dealtVs(_foe) {
    return 0;
  }
  /** Cooldown multiplier for one ability on top of the global one. */
  cooldownOf(id) {
    return this.defs[id]?.cd ?? 0;
  }
  /** Lets a race react to taking damage (e.g. reset series). */
  onHurt(_amount) {
  }
  /** Whether the shot/attack can be made at all (overheating and so on). */
  canAttack() {
    return "";
  }
  buffSum(field) {
    let total = 0;
    for (const b of this.buffs) total += b[field] ?? 0;
    return total;
  }
  hasBuff(flag) {
    return this.buffs.some((b) => b[flag]);
  }
  get stats() {
    const b = RACE_BASE[this.race];
    const level = this.port.player.level;
    const v = (k) => b.base[k] + b.perLevel[k] * (level - 1);
    const m = this.mods();
    const gear = this.port.gear;
    const atkPct = (m.atkPct ?? 0) + this.buffSum("atkPct");
    const defPct = (m.defPct ?? 0) + this.buffSum("defPct") + this.circleDefence();
    return {
      maxHp: roundHalfUp(v("hp") * (1 + (m.hpPct ?? 0))),
      maxKi: roundHalfUp(v("ki") * (1 + (m.kiPct ?? 0))),
      attack: Math.max(1, roundHalfUp((v("attack") + gear.attack) * (1 + atkPct))),
      defense: Math.max(0, roundHalfUp((v("defense") + gear.defense) * (1 + defPct))),
      speed: b.base.speed * speedGrowth(level) * (1 + (m.speedPct ?? 0) + this.buffSum("speedPct")),
      kiRegen: v("kiRegen") * (1 + (m.kiRegenPct ?? 0)),
      crit: v("criticalChancePercent") + (m.critAdd ?? 0) * 100,
      attackInterval: Math.max(
        200,
        b.base.attackIntervalMs * (1 + (m.intervalPct ?? 0) + this.buffSum("intervalPct"))
      ),
      dealt: 1 + (m.dealtPct ?? 0) + this.buffSum("dealtPct"),
      cooldownMul: Math.max(0.1, 1 + this.buffSum("cooldownPct")),
      kiCostMul: this.hasBuff("noKi") ? 0 : Math.max(0, 1 + (m.kiCostPct ?? 0)),
      ccMul: this.hasBuff("ccImmune") ? 0 : Math.max(0, 1 + (m.ccPct ?? 0)),
      range: this.baseRange * (1 + (m.rangePct ?? 0))
    };
  }
  /** Regeneration of HP per second as a fraction of max HP. */
  hpRegen() {
    const m = this.mods();
    return (m.hpRegenAlways ?? 0) + (this.port.inCombat ? 0 : m.hpRegenOoc ?? 0);
  }
  circleDefence() {
    const p = this.port.player;
    let total = 0;
    for (const c of this.circles)
      if (c.defPct && Math.hypot(c.x - p.x, c.y - p.y) <= c.radius)
        total = Math.max(total, c.defPct);
    return total;
  }
  // --- buffs, shields, timers ------------------------------------------------------------
  addBuff(buff) {
    this.buffs = this.buffs.filter((b) => b.id !== buff.id);
    this.buffs.push(buff);
  }
  removeBuff(id) {
    this.buffs = this.buffs.filter((b) => b.id !== id);
  }
  buff(id) {
    return this.buffs.find((b) => b.id === id);
  }
  addShield(shield) {
    this.shields = this.shields.filter((s) => s.id !== shield.id);
    this.shields.push(shield);
    this.port.emit({
      type: "shield",
      x: this.port.player.x,
      y: this.port.player.y,
      ability: shield.id,
      text: "Tarcza " + Math.round(shield.amount)
    });
  }
  get shieldPoints() {
    return this.shields.reduce((n, s) => n + s.amount, 0);
  }
  removeShields() {
    this.shields = [];
  }
  schedule(ms, fn) {
    this.timers.push({ ms, fn });
  }
  addCircle(c) {
    this.circles.push(c);
    this.port.emit({ type: "circle", x: c.x, y: c.y, ability: c.id, radius: c.radius, ms: c.ms });
  }
  startChannel(c) {
    this.channel = { ...c, total: c.ms, next: c.every };
    this.port.emit({
      type: "channel",
      x: this.port.player.x,
      y: this.port.player.y,
      ability: c.id,
      ms: c.ms
    });
  }
  interruptChannel(reason) {
    const c = this.channel;
    if (!c) return;
    if (reason === "move" && !c.breakOnMove || reason === "hit" && !c.breakOnHit) return;
    this.channel = void 0;
    c.onEnd(false);
  }
  // --- damage ----------------------------------------------------------------------------
  /** Rolls a crit and deals `mult` × ATK (× buffs) to the foe through the session's damage model. */
  strike(foe, mult, hit, extra = 0, forceCrit = false) {
    const s = this.stats;
    let raw = s.attack * mult * s.dealt * (1 + extra + this.dealtVs(foe));
    const chance = s.crit + this.critVs(foe);
    const crit = forceCrit || this.port.random() * 100 < chance;
    if (crit) raw *= CRIT_MULT;
    return this.port.hurtFoe(foe, raw, { ...hit, crit });
  }
  /** Consumes one-shot "next hit" buffs and returns their bonus plus whether a crit is guaranteed. */
  takeNextHit() {
    let bonus = 0;
    let crit = false;
    for (const b of this.buffs) {
      if (b.nextHitPct) bonus += b.nextHitPct;
      if (b.guaranteedCrit) crit = true;
    }
    this.buffs = this.buffs.filter((b) => !b.nextHitPct && !b.guaranteedCrit);
    return { bonus, crit };
  }
  /** The foe to act on: current target or the nearest within `reach` of the player. */
  pickFoe(reach) {
    const p = this.port.player;
    const t = this.port.target();
    if (t && Math.hypot(t.x - p.x, t.y - p.y) <= reach + 400) return t;
    return this.port.foesIn(p, reach + 120).sort((a, b) => Math.hypot(a.x - p.x, a.y - p.y) - Math.hypot(b.x - p.x, b.y - p.y))[0];
  }
  dist(a, b) {
    return Math.hypot(a.x - b.x, a.y - b.y);
  }
  /** Damage the player takes. Returns what is left after shields; reflects to `from` when set. */
  absorb(amount, kind, from) {
    if (this.hasBuff("invulnerable")) return 0;
    this.onHurt(amount);
    this.interruptChannel("hit");
    let left = amount;
    for (const sh of this.shields) {
      if (sh.amount <= 0) continue;
      if (sh.mirror) {
        sh.mirror = false;
        if (from) this.port.hurtFoe(from, amount, { tags: ["physical"], indirect: true });
        this.port.say("Lustro odbi\u0142o atak.");
        return 0;
      }
      const reflect = kind === "melee" ? sh.reflectMelee : kind === "projectile" ? sh.reflectProjectile : 0;
      if (reflect && from)
        this.port.hurtFoe(from, amount * reflect, { tags: ["physical"], indirect: true });
      const take = Math.min(left, sh.amount);
      sh.amount -= take;
      left -= take;
      if (left <= 0) break;
    }
    this.shields = this.shields.filter((s) => s.amount > 0.5);
    return left;
  }
  /** Last-chance effects (Ostatni Płomień). Returns the damage actually applied to HP. */
  lethalSave() {
    return false;
  }
  saveFromDeath() {
    return this.lethalSave();
  }
  // --- use -------------------------------------------------------------------------------
  abilities() {
    const out = [];
    let n = 1;
    const basicNode = this.node("R");
    out.push({
      id: "R",
      name: basicNode.name,
      type: "starting",
      ki: 0,
      cd: Math.round(this.stats.attackInterval),
      remaining: Math.max(0, this.nextBasicAt - this.port.nowMs),
      channel: false,
      key: "",
      ready: this.nextBasicAt <= this.port.nowMs,
      reason: this.canAttack()
    });
    for (const node of this.nodes) {
      const def = this.defs[node.id];
      if (!def || !this.has(node.id)) continue;
      const remaining = this.cooldowns[node.id] ?? 0;
      out.push({
        id: node.id,
        name: node.name,
        type: node.type,
        ki: Math.round(def.ki * this.stats.kiCostMul),
        cd: Math.round(this.cooldownOf(node.id) * this.stats.cooldownMul),
        remaining,
        channel: !!def.channel,
        key: n <= 9 ? String(n) : n === 10 ? "0" : "",
        ready: remaining <= 0,
        reason: ""
      });
      n++;
    }
    return out;
  }
  use(id) {
    if (this.lockMs > 0) return { ok: false, reason: "Uk\u0142ady wy\u0142\u0105czone." };
    if (id === "R") {
      const why = this.canAttack();
      if (why) return { ok: false, reason: why };
      if (this.nextBasicAt > this.port.nowMs) return { ok: false, reason: "" };
      const r2 = this.basic();
      if (r2.ok) {
        this.nextBasicAt = this.port.nowMs + this.stats.attackInterval;
        this.lastBasic = this.port.nowMs;
      }
      return r2;
    }
    const def = this.defs[id];
    if (!def || !this.has(id)) return { ok: false, reason: "Nie znasz tej zdolno\u015Bci." };
    const left = this.cooldowns[id] ?? 0;
    if (left > 0) return { ok: false, reason: "Odnowienie: " + Math.ceil(left / 1e3) + " s." };
    const cost = Math.round(def.ki * this.stats.kiCostMul);
    if (this.port.player.ki < cost) return { ok: false, reason: "Za ma\u0142o KI (" + cost + ")." };
    if (this.channel) return { ok: false, reason: "Trwa kana\u0142owanie." };
    const r = this.cast(id);
    if (!r.ok) return r;
    this.port.addKi(-cost);
    this.cooldowns[id] = Math.round(this.cooldownOf(id) * this.stats.cooldownMul);
    return r;
  }
  tick(dt, moving) {
    for (const key of Object.keys(this.cooldowns))
      this.cooldowns[key] = Math.max(0, (this.cooldowns[key] ?? 0) - dt);
    this.lockMs = Math.max(0, this.lockMs - dt);
    for (const b of this.buffs) b.ms -= dt;
    this.buffs = this.buffs.filter((b) => b.ms > 0);
    for (const s of this.shields) s.ms -= dt;
    this.shields = this.shields.filter((s) => s.ms > 0 && s.amount > 0.5);
    for (const c of this.circles) {
      c.ms -= dt;
      for (const f of this.port.foesIn(c, c.radius)) {
        if (c.slow) this.port.slowFoe(f, c.slow, 300);
        if (c.weaken) this.port.weakenFoe(f, c.weaken, 300);
        if (c.dps)
          this.port.hurtFoe(f, this.stats.attack * c.dps * dt / 1e3, {
            tags: ["ki"],
            indirect: true
          });
      }
    }
    this.circles = this.circles.filter((c) => c.ms > 0);
    const due = [];
    for (const t of this.timers) {
      t.ms -= dt;
      if (t.ms <= 0) due.push(t.fn);
    }
    this.timers = this.timers.filter((t) => t.ms > 0);
    for (const fn of due) fn();
    if (this.channel) {
      if (moving) this.interruptChannel("move");
      const c = this.channel;
      if (c) {
        c.ms -= dt;
        c.next -= dt;
        if (c.next <= 0) {
          c.next += c.every;
          c.onTick();
        }
        if (c.ms <= 0) {
          this.channel = void 0;
          c.onEnd(true);
        }
      }
    }
    this.onTick(dt);
  }
};

// src/game/kit/android.ts
var AndroidKit = class extends Kit {
  defs = {
    A1: { id: "A1", ki: 8, cd: 8e3, needsFoe: true },
    A4: { id: "A4", ki: 18, cd: 1e4, needsFoe: true },
    A9: { id: "A9", ki: 35, cd: 3e4, needsFoe: true },
    B1: { id: "B1", ki: 12, cd: 1e4 },
    B4: { id: "B4", ki: 18, cd: 12e3 },
    B9: { id: "B9", ki: 35, cd: 4e4 },
    C1: { id: "C1", ki: 15, cd: 8e3 },
    C4: { id: "C4", ki: 0, cd: 2e4 },
    C9: { id: "C9", ki: 35, cd: 45e3 },
    T: { id: "T", ki: 50, cd: 12e4 }
  };
  baseRange = 360;
  ranged = true;
  charge = 0;
  overheatMs = 0;
  lastShot = -1e9;
  constructor(port, learned) {
    super(port, "android", learned);
    this.refresh();
  }
  refresh() {
    this.defs["C1"] = { ...this.defs["C1"], ki: this.has("C6") ? 12 : 15 };
  }
  get maxCharge() {
    return this.has("C8") ? 70 : this.has("C7") ? 150 : 100;
  }
  mods() {
    const m = {};
    if (this.has("A2")) m.critAdd = (m.critAdd ?? 0) + 0.06;
    if (this.has("A3")) m.rangePct = 0.15;
    let interval = 0;
    if (this.has("A6")) interval -= 0.08;
    if (this.has("A7")) interval += 0.1;
    if (interval) m.intervalPct = interval;
    if (this.has("B2")) m.defPct = 0.08;
    if (this.has("B6")) m.hpRegenAlways = 5e-3;
    if (this.has("C5")) m.kiPct = 0.12;
    return m;
  }
  cooldownOf(id) {
    const base = this.defs[id]?.cd ?? 0;
    return id === "B1" && this.has("B8") ? base * 0.65 : base;
  }
  critVs(foe) {
    return this.has("A1") && this.port.isMarked(foe) ? 15 : 0;
  }
  dealtVs(foe) {
    return this.has("A7") && this.port.isMarked(foe) ? 0.4 : 0;
  }
  get overheatEnabled() {
    return !this.has("C8") && !this.buff("T");
  }
  canAttack() {
    return this.overheatMs > 0 ? "Przegrzanie rdzenia." : "";
  }
  resource() {
    return {
      label: "\u0141adunek Rdzenia",
      value: Math.round(this.charge),
      max: this.maxCharge,
      state: this.overheatMs > 0 ? "overheat" : this.charge >= this.maxCharge ? "full" : ""
    };
  }
  addCharge(n) {
    this.charge = Math.min(this.maxCharge, this.charge + n * (this.has("C3") ? 0.85 : 1));
    this.lastShot = this.port.nowMs;
    if (this.charge >= this.maxCharge && this.overheatEnabled) {
      this.overheatMs = this.has("C2") ? 1e3 : 2e3;
      this.port.say("Przegrzanie rdzenia!");
    }
  }
  onTick(dt) {
    if (this.overheatMs > 0) {
      this.overheatMs = Math.max(0, this.overheatMs - dt);
      if (this.overheatMs === 0) this.charge = Math.min(this.charge, this.maxCharge * 0.5);
    }
    if (this.port.nowMs - this.lastShot > 1e3 && this.charge > 0) {
      const rate = 6 * (this.has("C2") ? 1.5 : 1);
      this.charge = Math.max(0, this.charge - rate * dt / 1e3);
    }
    if (this.charge > this.maxCharge) this.charge = this.maxCharge;
  }
  basic() {
    const s = this.stats;
    const p = this.port.player;
    const foe = this.pickFoe(s.range);
    if (!foe) return { ok: false, reason: "Wybierz cel." };
    if (this.dist(p, foe) > s.range) return { ok: false, reason: "Cel poza zasi\u0119giem." };
    if (!this.port.visible(p, foe)) return { ok: false, reason: "Przeszkoda zas\u0142ania cel." };
    const next = this.takeNextHit();
    this.port.emit({ type: "attack", x: p.x, y: p.y, ability: "R", to: { x: foe.x, y: foe.y } });
    this.strike(foe, 1, { tags: ["electric"], ranged: true, ability: "R" }, next.bonus, next.crit);
    if (this.has("A8")) {
      const others = this.port.foesIn(foe, 220).filter((f) => f !== foe).sort((a, b) => this.dist(a, foe) - this.dist(b, foe)).slice(0, 2);
      for (const o of others)
        this.strike(o, 0.4, { tags: ["electric"], ranged: true, ability: "R" });
    }
    this.addCharge(4);
    return { ok: true };
  }
  markedFoe() {
    const s = this.stats;
    const foe = this.pickFoe(s.range);
    if (!foe) return "Wybierz cel.";
    if (this.dist(this.port.player, foe) > s.range) return "Cel poza zasi\u0119giem.";
    if (!this.port.isMarked(foe)) return "Najpierw oznacz cel (Namierzanie).";
    return foe;
  }
  cast(id) {
    const p = this.port.player;
    const s = this.stats;
    switch (id) {
      case "A1": {
        const foe = this.pickFoe(s.range);
        if (!foe) return { ok: false, reason: "Wybierz cel." };
        if (this.dist(p, foe) > s.range) return { ok: false, reason: "Cel poza zasi\u0119giem." };
        this.port.markFoe(foe, 6e3, 15, this.has("A5") ? 0.1 : 0);
        this.port.emit({
          type: "attack",
          x: p.x,
          y: p.y,
          ability: "A1",
          to: { x: foe.x, y: foe.y }
        });
        return { ok: true };
      }
      case "A4": {
        const foe = this.markedFoe();
        if (typeof foe === "string") return { ok: false, reason: foe };
        for (let i = 0; i < 3; i++)
          this.schedule(i * 150, () => {
            if (foe.hp <= 0) return;
            this.port.emit({
              type: "attack",
              x: this.port.player.x,
              y: this.port.player.y,
              ability: "A4",
              to: { x: foe.x, y: foe.y }
            });
            this.strike(foe, 2.2 / 3, { tags: ["electric"], ranged: true, ability: "A4" });
          });
        return { ok: true };
      }
      case "A9": {
        const foe = this.markedFoe();
        if (typeof foe === "string") return { ok: false, reason: foe };
        const mult = this.port.foeHpFraction(foe) < 0.3 ? 6 : 4;
        this.port.emit({
          type: "attack",
          x: p.x,
          y: p.y,
          ability: "A9",
          to: { x: foe.x, y: foe.y }
        });
        this.strike(foe, mult, { tags: ["electric"], ranged: true, ability: "A9" });
        return { ok: true };
      }
      case "B1": {
        const amount = s.maxHp * 0.18 * (this.has("B3") ? 1.25 : 1);
        this.addShield({
          id: "B1",
          ms: 5e3,
          amount,
          max: amount,
          reflectProjectile: this.has("B5") ? 0.25 : void 0,
          reflectMelee: this.has("B7") ? 0.3 : void 0
        });
        return { ok: true };
      }
      case "B4": {
        const foes = this.port.foesIn(p, 160);
        this.port.emit({ type: "burst", x: p.x, y: p.y, ability: "B4", radius: 160 });
        for (const f of foes) {
          this.strike(f, 1.2, { tags: ["electric", "area", "stun"], ranged: true, ability: "B4" });
          this.port.pushFoe(f, p, 120);
          this.port.stunFoe(f, 500);
        }
        return { ok: true };
      }
      case "B9": {
        this.addBuff({ id: "B9", ms: 6e3, defPct: 0.6, ccImmune: true });
        this.port.emit({ type: "buff", x: p.x, y: p.y, ability: "B9", text: "Fortyfikacja" });
        return { ok: true };
      }
      case "C1": {
        const used = Math.min(this.charge, this.maxCharge);
        const mult = 1 + used / 50;
        const f = this.port.facing;
        const foes = this.port.foesIn(p, 360).filter((foe) => {
          const dx = foe.x - p.x;
          const dy = foe.y - p.y;
          const along = dx * f.x + dy * f.y;
          const across = Math.abs(dx * f.y - dy * f.x);
          return along > 0 && along <= 360 && across <= 50;
        });
        this.port.emit({
          type: "attack",
          x: p.x,
          y: p.y,
          ability: "C1",
          to: { x: p.x + f.x * 360, y: p.y + f.y * 360 }
        });
        for (const foe of foes)
          this.strike(foe, mult, { tags: ["electric", "area"], ranged: true, ability: "C1" });
        this.charge = 0;
        return { ok: true };
      }
      case "C4": {
        this.charge = 0;
        this.overheatMs = 0;
        this.port.heal(s.maxHp * 0.1);
        this.port.emit({ type: "heal", x: p.x, y: p.y, ability: "C4", text: "Roz\u0142adowanie" });
        return { ok: true };
      }
      case "C9": {
        this.addBuff({ id: "C9", ms: 6e3, noKi: true, dealtPct: 0.4 });
        this.schedule(6e3, () => {
          this.lockMs = 2e3;
          this.port.say("Przeci\u0105\u017Cenie: uk\u0142ady wy\u0142\u0105czone na 2 s.");
        });
        this.port.emit({
          type: "buff",
          x: p.x,
          y: p.y,
          ability: "C9",
          text: "Przeci\u0105\u017Cenie Systemu"
        });
        return { ok: true };
      }
      case "T": {
        this.addBuff({ id: "T", ms: 2e4, atkPct: 0.25, defPct: 0.15 });
        this.overheatMs = 0;
        this.port.emit({
          type: "buff",
          x: p.x,
          y: p.y,
          ability: "T",
          text: "Forma Pe\u0142nego Rdzenia"
        });
        return { ok: true };
      }
    }
    return { ok: false, reason: "Nieznana zdolno\u015B\u0107." };
  }
};

// src/game/kit/legend.ts
var LegendKit = class extends Kit {
  defs = {
    A1: { id: "A1", ki: 10, cd: 6e3, needsFoe: true },
    A4: { id: "A4", ki: 18, cd: 1e4, needsFoe: true },
    A9: { id: "A9", ki: 35, cd: 3e4, needsFoe: true },
    B1: { id: "B1", ki: 12, cd: 8e3, needsFoe: true },
    B4: { id: "B4", ki: 18, cd: 25e3 },
    B9: { id: "B9", ki: 35, cd: 9e4 },
    C1: { id: "C1", ki: 15, cd: 8e3 },
    C4: { id: "C4", ki: 20, cd: 12e3 },
    C9: { id: "C9", ki: 35, cd: 3e4 },
    T: { id: "T", ki: 50, cd: 12e4 }
  };
  baseRange = 78;
  ranged = false;
  ember = 0;
  streak = 0;
  lastHitAt = -1e9;
  wasInCombat = false;
  constructor(port, learned) {
    super(port, "legend", learned);
  }
  mods() {
    const m = {};
    if (this.has("A5")) m.atkPct = 0.08;
    if (this.has("A6")) m.critAdd = 0.06;
    if (this.has("B2")) m.defPct = 0.08;
    if (this.has("B3")) m.hpPct = 0.1;
    if (this.has("C6") && this.ember >= 100) m.kiRegenPct = 0.5;
    return m;
  }
  dealtVs(_foe) {
    let bonus = Math.min(0.1, this.ember * 1e-3);
    if (this.has("A8") && this.port.foesIn(this.port.player, 200).length === 1) bonus += 0.25;
    return bonus;
  }
  resource() {
    return {
      label: "\u017Bar",
      value: Math.round(this.ember),
      max: 100,
      state: this.ember >= 100 ? "full" : ""
    };
  }
  gainEmber(n) {
    this.ember = Math.min(100, this.ember + n * (this.has("C2") ? 1.5 : 1));
  }
  strike(foe, mult, hit, extra = 0, forceCrit = false) {
    const dealt = super.strike(foe, mult, hit, extra, forceCrit);
    if (!hit.indirect) {
      this.gainEmber(4);
      const now = this.port.nowMs;
      this.streak = now - this.lastHitAt > 2500 ? 1 : this.streak + 1;
      this.lastHitAt = now;
      if (this.has("A3") && this.streak >= 3) {
        this.streak = 0;
        this.addBuff({ id: "A3", ms: 4e3, intervalPct: -0.1 });
      }
    }
    return dealt;
  }
  onTick(dt) {
    const inCombat = this.port.inCombat;
    if (this.buff("T")) this.ember = 100;
    else if (inCombat && !this.wasInCombat && this.has("C5")) this.ember = Math.max(this.ember, 20);
    else if (!inCombat)
      this.ember = Math.max(0, this.ember - (this.has("C2") ? 2.5 : 5) * dt / 1e3);
    this.wasInCombat = inCombat;
  }
  lethalSave() {
    const b = this.buff("B9");
    if (!b?.lethal) return false;
    this.removeBuff("B9");
    this.port.heal(this.stats.maxHp * 0.3);
    this.port.say("Ostatni P\u0142omie\u0144 ocali\u0142 Ci\u0119 przed \u015Bmierci\u0105.");
    return true;
  }
  onKill(_foe) {
    if (this.has("B6")) this.port.heal(this.stats.maxHp * 0.03);
  }
  ignite(foe, totalAtk, ms) {
    this.port.burnFoe(foe, this.stats.attack * totalAtk / (ms / 1e3), ms);
  }
  basic() {
    const s = this.stats;
    const p = this.port.player;
    const foe = this.pickFoe(s.range);
    if (!foe) return { ok: false, reason: "Wybierz cel." };
    if (this.dist(p, foe) > s.range) return { ok: false, reason: "Cel poza zasi\u0119giem." };
    if (!this.port.visible(p, foe)) return { ok: false, reason: "Przeszkoda zas\u0142ania cel." };
    const next = this.takeNextHit();
    this.port.emit({ type: "attack", x: p.x, y: p.y, ability: "R", to: { x: foe.x, y: foe.y } });
    this.strike(
      foe,
      1,
      { tags: ["physical", "fire"], melee: true, ability: "R" },
      next.bonus,
      next.crit
    );
    return { ok: true };
  }
  cuts(id, foe, count, total, gap, burn2) {
    const each = total / count;
    for (let i = 0; i < count; i++)
      this.schedule(i * gap, () => {
        if (foe.hp <= 0) return;
        const p = this.port.player;
        this.port.emit({ type: "attack", x: p.x, y: p.y, ability: id, to: { x: foe.x, y: foe.y } });
        this.strike(foe, each, { tags: ["physical", "fire"], melee: true, ability: id });
        if (burn2 && i === count - 1) this.ignite(foe, burn2[0], burn2[1]);
      });
  }
  cast(id) {
    const p = this.port.player;
    const s = this.stats;
    const reach = s.range + 14;
    const near = () => {
      const foe = this.pickFoe(reach);
      if (!foe) return "Wybierz cel.";
      if (this.dist(p, foe) > reach) return "Cel poza zasi\u0119giem.";
      return foe;
    };
    switch (id) {
      case "A1": {
        const foe = near();
        if (typeof foe === "string") return { ok: false, reason: foe };
        const five = this.has("A7");
        this.cuts(
          "A1",
          foe,
          five ? 5 : 3,
          five ? 2.6 : 1.8,
          150,
          this.has("A2") ? [0.3, 3e3] : void 0
        );
        return { ok: true };
      }
      case "A4": {
        const foe = this.pickFoe(300);
        if (!foe) return { ok: false, reason: "Wybierz cel." };
        const gap = Math.max(0, this.dist(p, foe) - 50);
        if (gap > 220) return { ok: false, reason: "Cel zbyt daleko (200)." };
        this.port.dash(foe, Math.min(200, gap));
        this.port.emit({
          type: "attack",
          x: p.x,
          y: p.y,
          ability: "A4",
          to: { x: foe.x, y: foe.y }
        });
        this.strike(foe, 2.2, { tags: ["physical", "fire"], melee: true, ability: "A4" });
        return { ok: true };
      }
      case "A9": {
        const foe = near();
        if (typeof foe === "string") return { ok: false, reason: foe };
        this.cuts("A9", foe, 8, 4.2, 120);
        return { ok: true };
      }
      case "B1": {
        const foe = near();
        if (typeof foe === "string") return { ok: false, reason: foe };
        this.port.emit({
          type: "attack",
          x: p.x,
          y: p.y,
          ability: "B1",
          to: { x: foe.x, y: foe.y }
        });
        this.strike(foe, 1.5, { tags: ["physical", "stun"], melee: true, ability: "B1" });
        this.port.stunFoe(foe, 1200);
        this.port.breakFoeShield(foe);
        return { ok: true };
      }
      case "B4": {
        this.addBuff({
          id: "B4",
          ms: 8e3 + (this.has("B7") ? 4e3 : 0),
          atkPct: 0.3 + (this.has("B7") ? 0.1 : 0),
          defPct: this.has("B8") ? 0 : -0.2,
          stunImmune: this.has("B5") ? true : void 0
        });
        this.port.emit({ type: "buff", x: p.x, y: p.y, ability: "B4", text: "P\u0142omienny Sza\u0142" });
        return { ok: true };
      }
      case "B9": {
        this.addBuff({ id: "B9", ms: 5e3, lethal: true });
        this.port.emit({ type: "buff", x: p.x, y: p.y, ability: "B9", text: "Ostatni P\u0142omie\u0144" });
        return { ok: true };
      }
      case "C1": {
        const foes = this.port.foesIn(p, 150);
        this.port.emit({ type: "burst", x: p.x, y: p.y, ability: "C1", radius: 150 });
        for (const f of foes) {
          this.strike(f, 1.8, { tags: ["fire", "area"], melee: true, ability: "C1" });
          if (this.has("C3")) this.ignite(f, 0.4, 4e3);
        }
        return { ok: true };
      }
      case "C4": {
        const mult = (1 + Math.min(100, this.ember) / 50) * (this.has("C8") ? 1.25 : 1);
        const radius = 160 * (this.has("C7") ? 1.5 : this.has("C8") ? 0.8 : 1);
        const foes = this.port.foesIn(p, radius);
        this.port.emit({ type: "burst", x: p.x, y: p.y, ability: "C4", radius });
        for (const f of foes)
          this.strike(f, mult, { tags: ["fire", "area"], melee: true, ability: "C4" });
        this.ember = 0;
        return { ok: true };
      }
      case "C9": {
        const foe = this.port.target();
        const f = this.port.facing;
        const at = foe ? { x: foe.x, y: foe.y } : { x: p.x + f.x * 150, y: p.y + f.y * 150 };
        const foes = this.port.foesIn(at, 240);
        this.port.emit({ type: "burst", x: at.x, y: at.y, ability: "C9", radius: 240 });
        for (const x of foes) {
          this.strike(x, 4.5, { tags: ["fire", "area"], melee: true, ability: "C9" });
          this.ignite(x, 0.5, 5e3);
        }
        return { ok: true };
      }
      case "T": {
        this.addBuff({ id: "T", ms: 2e4, atkPct: 0.3 });
        this.ember = 100;
        this.port.emit({
          type: "buff",
          x: p.x,
          y: p.y,
          ability: "T",
          text: "Forma P\u0142omiennego Legendy"
        });
        return { ok: true };
      }
    }
    return { ok: false, reason: "Nieznana zdolno\u015B\u0107." };
  }
};

// src/game/kit/planetary.ts
var PlanetaryKit = class extends Kit {
  defs = {
    A1: { id: "A1", ki: 8, cd: 6e3 },
    A4: { id: "A4", ki: 18, cd: 1e4 },
    A9: { id: "A9", ki: 35, cd: 3e4, needsFoe: true },
    B1: { id: "B1", ki: 10, cd: 6e3 },
    B4: { id: "B4", ki: 18, cd: 1e4, needsFoe: true },
    B9: { id: "B9", ki: 35, cd: 3e4 },
    C1: { id: "C1", ki: 12, cd: 12e3 },
    C4: { id: "C4", ki: 18, cd: 12e3 },
    C9: { id: "C9", ki: 35, cd: 45e3 },
    T: { id: "T", ki: 50, cd: 12e4 }
  };
  baseRange = 78;
  ranged = false;
  /** Third hit of a series deals ×1.3. */
  series = 0;
  lastHealed = 0;
  constructor(port, learned) {
    super(port, "planetary", learned);
  }
  mods() {
    const m = {};
    const terrain = this.has("B2") ? this.port.terrain() : "open";
    if (this.has("A2")) m.speedPct = (m.speedPct ?? 0) + 0.06;
    if (this.has("A6")) m.critAdd = 0.05;
    if (this.has("B3")) m.defPct = (m.defPct ?? 0) + 0.08;
    if (this.has("C2")) m.hpPct = 0.1;
    if (this.has("C3")) m.hpRegenOoc = 0.01;
    if (this.has("C5")) m.ccPct = -0.25;
    if (terrain === "forest") m.kiRegenPct = 0.3;
    if (terrain === "rock") m.defPct = (m.defPct ?? 0) + 0.1;
    if (terrain === "water") m.speedPct = (m.speedPct ?? 0) + 0.08;
    return m;
  }
  cooldownOf(id) {
    const base = this.defs[id]?.cd ?? 0;
    return id === "A1" && this.has("A8") ? base * 0.7 : base;
  }
  basic() {
    const s = this.stats;
    const foe = this.pickFoe(s.range);
    const p = this.port.player;
    if (!foe) return { ok: false, reason: "Wybierz cel." };
    if (this.dist(p, foe) > s.range) return { ok: false, reason: "Cel poza zasi\u0119giem." };
    if (!this.port.visible(p, foe)) return { ok: false, reason: "Przeszkoda zas\u0142ania cel." };
    this.series = this.port.nowMs - this.lastBasic > 1800 ? 1 : this.series + 1;
    const third = this.series % 3 === 0;
    const next = this.takeNextHit();
    this.port.emit({ type: "attack", x: p.x, y: p.y, ability: "R", to: { x: foe.x, y: foe.y } });
    this.strike(
      foe,
      third ? 1.3 : 1,
      { tags: ["physical"], melee: true, ability: "R" },
      next.bonus,
      next.crit
    );
    return { ok: true };
  }
  onKill(_foe) {
    if (this.has("A5")) this.addBuff({ id: "A5", ms: 4e3, speedPct: 0.15 });
  }
  aoe(id, center, radius, mult, extra) {
    const next = this.takeNextHit();
    const foes = this.port.foesIn(center, radius);
    this.port.emit({ type: "burst", x: center.x, y: center.y, ability: id, radius });
    for (const f of foes) {
      this.strike(
        f,
        mult,
        { tags: ["physical", "area"], melee: true, ability: id },
        next.bonus,
        next.crit
      );
      extra(f);
    }
    return foes;
  }
  cast(id) {
    const p = this.port.player;
    const f = this.port.facing;
    switch (id) {
      case "A1": {
        this.port.dash({ x: p.x + f.x * 160, y: p.y + f.y * 160 }, 160);
        this.addBuff({ id: "dodge", ms: 400, invulnerable: true });
        if (this.has("A3")) this.addBuff({ id: "A3", ms: 5e3, nextHitPct: 0.25 });
        if (this.has("A7")) this.addBuff({ id: "A7", ms: 5e3, guaranteedCrit: true });
        if (this.has("A8")) this.addBuff({ id: "A8", ms: 1e3, defPct: 0.2 });
        this.port.emit({ type: "buff", x: p.x, y: p.y, ability: "A1", text: "Unik" });
        return { ok: true };
      }
      case "A4": {
        this.aoe("A4", p, 140, 1.8, () => {
        });
        return { ok: true };
      }
      case "A9": {
        const near = this.port.foesIn(p, 160);
        if (!near.length) return { ok: false, reason: "Brak wrog\xF3w w pobli\u017Cu." };
        this.port.emit({ type: "burst", x: p.x, y: p.y, ability: "A9", radius: 160 });
        for (let i = 0; i < 5; i++)
          this.schedule(i * 150, () => {
            const alive = this.port.foesIn(this.port.player, 160);
            const foe = alive[i % Math.max(1, alive.length)];
            if (foe) this.strike(foe, 0.8, { tags: ["physical"], melee: true, ability: "A9" });
          });
        return { ok: true };
      }
      case "B1": {
        const radius = 120 * (this.has("B8") ? 1.4 : 1);
        let got = 0;
        const hitAll = (mult, first) => {
          const foes = this.port.foesIn(this.port.player, radius);
          this.port.emit({
            type: "burst",
            x: this.port.player.x,
            y: this.port.player.y,
            ability: "B1",
            radius
          });
          for (const foe of foes) {
            this.strike(foe, mult, { tags: ["physical", "area"], melee: true, ability: "B1" });
            if (first) {
              this.port.slowFoe(foe, 0.3, 2e3);
              if (this.has("B8")) this.port.stunFoe(foe, 500);
            }
          }
          return foes.length;
        };
        got = hitAll(1.4, true);
        if (this.has("B6")) this.port.addKi(Math.min(15, got * 5));
        if (this.has("B5")) this.schedule(500, () => hitAll(1.4 * 0.6, false));
        return { ok: true };
      }
      case "B4": {
        const foe = this.pickFoe(300);
        if (!foe) return { ok: false, reason: "Wybierz cel." };
        const gap = Math.max(0, this.dist(p, foe) - 40);
        if (gap > 220) return { ok: false, reason: "Cel zbyt daleko (220)." };
        this.port.dash(foe, gap);
        const q = this.port.player;
        const foes = this.port.foesIn(q, 100);
        this.port.emit({ type: "burst", x: q.x, y: q.y, ability: "B4", radius: 100 });
        for (const x of foes) {
          this.strike(x, 2, { tags: ["physical", "area", "stun"], melee: true, ability: "B4" });
          this.port.stunFoe(x, 1e3);
        }
        if (this.has("B7"))
          this.addShield({
            id: "B7",
            ms: 5e3,
            amount: this.stats.maxHp * 0.15,
            max: this.stats.maxHp * 0.15
          });
        return { ok: true };
      }
      case "B9": {
        const foes = this.aoe("B9", p, 220, 4, (x) => this.port.stunFoe(x, 1500));
        return foes.length ? { ok: true } : { ok: true };
      }
      case "C1": {
        const total = this.stats.maxHp * 0.12 * (this.has("C6") ? 1.3 : 1);
        this.hot(total, 4e3);
        if (this.has("C8")) this.port.addKi(15);
        this.port.emit({ type: "heal", x: p.x, y: p.y, ability: "C1", text: "Oddech" });
        return { ok: true };
      }
      case "C4": {
        const amount = this.stats.maxHp * 0.18;
        this.addShield({
          id: "C4",
          ms: 5e3,
          amount,
          max: amount,
          reflectMelee: this.has("C7") ? 0.2 : void 0
        });
        return { ok: true };
      }
      case "C9": {
        this.port.heal(this.stats.maxHp * 0.4);
        const amount = this.stats.maxHp * 0.2;
        this.addShield({ id: "C9", ms: 6e3, amount, max: amount });
        return { ok: true };
      }
      case "T": {
        this.addBuff({ id: "T", ms: 2e4, atkPct: 0.2, defPct: 0.15, speedPct: 0.1 });
        this.port.emit({
          type: "buff",
          x: p.x,
          y: p.y,
          ability: "T",
          text: "Forma Rezonansu \u015Awiata"
        });
        return { ok: true };
      }
    }
    return { ok: false, reason: "Nieznana zdolno\u015B\u0107." };
  }
  /** Heal over time spread across `ms` in 4 equal steps. */
  hot(total, ms) {
    const step = total / 4;
    for (let i = 1; i <= 4; i++) this.schedule(ms / 4 * i, () => this.port.heal(step));
    this.lastHealed = total;
  }
  get lastHeal() {
    return this.lastHealed;
  }
};

// src/game/kit/sage.ts
var SageKit = class extends Kit {
  defs = {
    A1: { id: "A1", ki: 12, cd: 8e3, needsFoe: true },
    A4: { id: "A4", ki: 20, cd: 12e3, needsFoe: true, channel: true },
    A9: { id: "A9", ki: 35, cd: 3e4, needsFoe: true },
    B1: { id: "B1", ki: 12, cd: 1e4 },
    B4: { id: "B4", ki: 18, cd: 12e3 },
    B9: { id: "B9", ki: 35, cd: 4e4 },
    C1: { id: "C1", ki: 0, cd: 15e3, channel: true },
    C4: { id: "C4", ki: 10, cd: 15e3, channel: true },
    C9: { id: "C9", ki: 20, cd: 6e4 },
    T: { id: "T", ki: 50, cd: 12e4 }
  };
  baseRange = 420;
  ranged = true;
  constructor(port, learned) {
    super(port, "sage", learned);
  }
  mods() {
    const m = {};
    if (this.has("A6")) m.critAdd = 0.08;
    if (this.has("C2")) m.kiPct = 0.15;
    if (this.has("C3")) m.kiCostPct = -0.08;
    if (this.has("C5")) m.ccPct = -0.25;
    return m;
  }
  cooldownOf(id) {
    const base = this.defs[id]?.cd ?? 0;
    return id === "A1" && this.has("A3") ? base * 0.8 : base;
  }
  /** Bonus for the next damaging ability after Skupienie KI (C6). */
  abilityBonus() {
    const b = this.buff("C6");
    if (!b) return 0;
    this.removeBuff("C6");
    return 0.25;
  }
  basic() {
    const s = this.stats;
    const p = this.port.player;
    const foe = this.pickFoe(s.range);
    if (!foe) return { ok: false, reason: "Wybierz cel." };
    if (this.dist(p, foe) > s.range) return { ok: false, reason: "Cel poza zasi\u0119giem." };
    if (!this.port.visible(p, foe)) return { ok: false, reason: "Przeszkoda zas\u0142ania cel." };
    const next = this.takeNextHit();
    this.port.emit({ type: "attack", x: p.x, y: p.y, ability: "R", to: { x: foe.x, y: foe.y } });
    this.strike(foe, 1, { tags: ["ki"], ranged: true, ability: "R" }, next.bonus, next.crit);
    return { ok: true };
  }
  leaveCircle(radius, x = this.port.player.x, y = this.port.player.y) {
    if (!this.has("B2")) return;
    this.addCircle({
      id: "B2",
      x,
      y,
      radius,
      ms: 5e3,
      kind: "light",
      defPct: 0.1,
      weaken: this.has("B6") ? 0.1 : void 0
    });
  }
  explodeSeal(foe, id) {
    if (foe.hp <= 0) return;
    const bonus = this.abilityBonus();
    this.port.emit({ type: "burst", x: foe.x, y: foe.y, ability: id, radius: 120 });
    this.strike(foe, 2, { tags: ["ki", "area"], ranged: true, ability: id }, bonus);
    if (this.has("A5")) {
      for (const other of this.port.foesIn(foe, 150))
        if (other !== foe)
          this.strike(other, 1, { tags: ["ki", "area"], ranged: true, ability: id });
    }
    if (this.has("A7"))
      this.addCircle({
        id: "A7",
        x: foe.x,
        y: foe.y,
        radius: 120,
        ms: 3e3,
        kind: "light",
        dps: 0.4
      });
    if (this.has("A8")) this.port.addKi(15);
  }
  cast(id) {
    const p = this.port.player;
    const s = this.stats;
    switch (id) {
      case "A1": {
        const foe = this.pickFoe(s.range);
        if (!foe) return { ok: false, reason: "Wybierz cel." };
        if (this.dist(p, foe) > s.range) return { ok: false, reason: "Cel poza zasi\u0119giem." };
        this.port.sealFoe(foe, 3e3, this.has("A2") ? 0.1 : 0);
        this.port.emit({
          type: "attack",
          x: p.x,
          y: p.y,
          ability: "A1",
          to: { x: foe.x, y: foe.y }
        });
        this.schedule(3e3, () => this.explodeSeal(foe, "A1"));
        this.leaveCircle(100);
        return { ok: true };
      }
      case "A4": {
        const foe = this.pickFoe(s.range);
        if (!foe) return { ok: false, reason: "Wybierz cel." };
        if (this.dist(p, foe) > s.range) return { ok: false, reason: "Cel poza zasi\u0119giem." };
        const bonus = this.abilityBonus();
        this.startChannel({
          id: "A4",
          ms: 3e3,
          every: 500,
          breakOnMove: false,
          breakOnHit: false,
          onTick: () => {
            if (foe.hp <= 0) return this.interruptChannel("other");
            this.port.emit({
              type: "attack",
              x: p.x,
              y: p.y,
              ability: "A4",
              to: { x: foe.x, y: foe.y }
            });
            this.strike(foe, 0.4, { tags: ["ki"], ranged: true, ability: "A4" }, bonus);
          },
          onEnd: () => {
          }
        });
        this.leaveCircle(100);
        return { ok: true };
      }
      case "A9": {
        const foe = this.pickFoe(s.range);
        if (!foe) return { ok: false, reason: "Wybierz cel." };
        if (this.dist(p, foe) > s.range) return { ok: false, reason: "Cel poza zasi\u0119giem." };
        const at = { x: foe.x, y: foe.y };
        const bonus = this.abilityBonus();
        this.port.emit({ type: "burst", x: at.x, y: at.y, ability: "A9", radius: 200, ms: 1500 });
        this.schedule(1500, () => {
          for (const f of this.port.foesIn(at, 200))
            this.strike(f, 4.2, { tags: ["ki", "area"], ranged: true, ability: "A9" }, bonus);
        });
        this.leaveCircle(100);
        return { ok: true };
      }
      case "B1": {
        const amount = s.maxHp * 0.15 * (this.has("B7") ? 1.3 : 1);
        this.addShield({
          id: "B1",
          ms: 4e3 + (this.has("B3") ? 2e3 : 0),
          amount,
          max: amount,
          reflectProjectile: this.has("B5") ? 0.15 : void 0,
          mirror: this.has("B8") ? true : void 0
        });
        this.leaveCircle(100);
        return { ok: true };
      }
      case "B4": {
        const foe = this.port.target();
        const at = foe && this.dist(p, foe) <= s.range ? { x: foe.x, y: foe.y } : { x: p.x, y: p.y };
        this.addCircle({
          id: "B4",
          x: at.x,
          y: at.y,
          radius: 140,
          ms: 5e3,
          kind: "slow",
          slow: 0.4,
          weaken: this.has("B6") ? 0.1 : void 0
        });
        return { ok: true };
      }
      case "B9": {
        this.addCircle({
          id: "B9",
          x: p.x,
          y: p.y,
          radius: 220,
          ms: 8e3,
          kind: "temple",
          slow: 0.3,
          defPct: 0.3,
          weaken: this.has("B6") ? 0.1 : void 0
        });
        return { ok: true };
      }
      case "C1": {
        this.startChannel({
          id: "C1",
          ms: 3e3,
          every: 500,
          breakOnMove: !this.has("C8"),
          breakOnHit: true,
          onTick: () => this.port.addKi(this.stats.maxKi * 0.05),
          onEnd: (done) => {
            if (done && this.has("C6")) this.addBuff({ id: "C6", ms: 6e3 });
          }
        });
        return { ok: true };
      }
      case "C4": {
        const share = (this.has("C7") ? 1.5 : 1) * 0.2;
        this.startChannel({
          id: "C4",
          ms: 3e3,
          every: 500,
          breakOnMove: true,
          breakOnHit: true,
          onTick: () => this.port.heal(this.stats.maxHp * share / 6),
          onEnd: () => {
          }
        });
        return { ok: true };
      }
      case "C9": {
        this.addBuff({ id: "C9", ms: 8e3, noKi: true, dealtPct: 0.3 });
        return { ok: true };
      }
      case "T": {
        this.addBuff({ id: "T", ms: 2e4, atkPct: 0.25, cooldownPct: -0.3, defPct: 0.15 });
        this.port.emit({ type: "buff", x: p.x, y: p.y, ability: "T", text: "Forma O\u015Bwiecenia" });
        return { ok: true };
      }
    }
    return { ok: false, reason: "Nieznana zdolno\u015B\u0107." };
  }
};

// src/game/kit/progression.ts
var MAX_SKILL_LEVEL = 20;
var skillPointsAt = (level) => Math.min(level, MAX_SKILL_LEVEL);
var spentPoints = (learned) => learned.length;
var freePoints = (level, learned) => skillPointsAt(level) - spentPoints(learned);
function canLearn(race, level, learned, id) {
  const nodes = KIT_NODES[race];
  const node = nodes.find((n) => n.id === id);
  if (!node) return { ok: false, reason: "Nieznany w\u0119ze\u0142." };
  if (learned.includes(id)) return { ok: false, reason: "Ju\u017C poznane." };
  if (level < node.minLevel) return { ok: false, reason: "Wymaga poziomu " + node.minLevel + "." };
  if (freePoints(level, learned) < 1) return { ok: false, reason: "Brak punkt\xF3w umiej\u0119tno\u015Bci." };
  if (node.requires.length && !node.requires.some((r) => learned.includes(r)))
    return {
      ok: false,
      reason: "Wymaga: " + node.requires.map((r) => nodes.find((n) => n.id === r)?.name ?? r).join(" lub ") + "."
    };
  if (node.excludes && learned.includes(node.excludes))
    return {
      ok: false,
      reason: "Wyklucza si\u0119 z: " + (nodes.find((n) => n.id === node.excludes)?.name ?? node.excludes) + "."
    };
  return { ok: true };
}

// src/game/kit/index.ts
function createKit(race, port, learned) {
  switch (race) {
    case "planetary":
      return new PlanetaryKit(port, learned);
    case "sage":
      return new SageKit(port, learned);
    case "android":
      return new AndroidKit(port, learned);
    case "legend":
      return new LegendKit(port, learned);
  }
}

// src/game/monsters/base.generated.ts
var MONSTER_BASE = [
  {
    id: "verdant-mchowy-szlamak",
    world: "verdant",
    name: "Mchowy Szlamak",
    level: 1,
    hp: 73,
    atk: 5,
    def: 4,
    xp: 16,
    speed: 0.5,
    range: 90,
    agro: 250,
    archetype: "blob",
    size: "S",
    loot: ["Mchowa galaretka", "Zielone ziele"]
  },
  {
    id: "verdant-cierniowy-wilk",
    world: "verdant",
    name: "Cierniowy Wilk",
    level: 2,
    hp: 67,
    atk: 12,
    def: 4,
    xp: 24,
    speed: 1.2,
    range: 90,
    agro: 400,
    archetype: "quad",
    size: "M",
    loot: ["Cier\u0144 wilka", "Sk\xF3ra wilcza"]
  },
  {
    id: "verdant-lisciak-skrytobojca",
    world: "verdant",
    name: "Li\u015Bciak Skrytob\xF3jca",
    level: 4,
    hp: 95,
    atk: 23,
    def: 4,
    xp: 42,
    speed: 1.1,
    range: 90,
    agro: 200,
    archetype: "crawl",
    size: "M",
    loot: ["Zielone ostrze", "Sok li\u015Bciaka"]
  },
  {
    id: "verdant-korzeniowy-pelzacz",
    world: "verdant",
    name: "Korzeniowy Pe\u0142zacz",
    level: 6,
    hp: 255,
    atk: 20,
    def: 13,
    xp: 60,
    speed: 0.4,
    range: 160,
    agro: 300,
    archetype: "slither",
    size: "L",
    loot: ["\u017Bywy korze\u0144", "Nasiona"]
  },
  {
    id: "verdant-grzybowy-zarodnik",
    world: "verdant",
    name: "Grzybowy Zarodnik",
    level: 8,
    hp: 370,
    atk: 23,
    def: 11,
    xp: 76,
    speed: 0,
    range: 350,
    agro: 350,
    archetype: "plant",
    size: "M",
    loot: ["Zarodniki", "Czerwony grzyb"]
  },
  {
    id: "verdant-bursztynowa-osa",
    world: "verdant",
    name: "Bursztynowa Osa",
    level: 10,
    hp: 238,
    atk: 39,
    def: 10,
    xp: 80,
    speed: 1.4,
    range: 300,
    agro: 450,
    archetype: "fly",
    size: "M",
    loot: ["Bursztyn", "\u017B\u0105d\u0142o osy"]
  },
  {
    id: "verdant-skalny-jelen",
    world: "verdant",
    name: "Skalny Jele\u0144",
    level: 12,
    hp: 594,
    atk: 39,
    def: 28,
    xp: 118,
    speed: 1,
    range: 100,
    agro: 300,
    archetype: "quad",
    size: "L",
    loot: ["Poro\u017Ce", "Skalna sk\xF3ra"]
  },
  {
    id: "verdant-lesny-pajak",
    world: "verdant",
    name: "Le\u015Bny Paj\u0105k",
    level: 14,
    hp: 516,
    atk: 48,
    def: 21,
    xp: 119,
    speed: 0.9,
    range: 280,
    agro: 400,
    archetype: "crawl",
    size: "M",
    loot: ["Jedwab paj\u0105ka", "Jad"]
  },
  {
    id: "verdant-puchacz-pylowy",
    world: "verdant",
    name: "Puchacz Py\u0142owy",
    level: 16,
    hp: 554,
    atk: 63,
    def: 18,
    xp: 140,
    speed: 1.3,
    range: 120,
    agro: 500,
    archetype: "fly",
    size: "M",
    loot: ["Pi\xF3ro puchacza", "Py\u0142"]
  },
  {
    id: "verdant-straznik-ruin",
    world: "verdant",
    name: "Stra\u017Cnik Ruin",
    level: 18,
    hp: 1448,
    atk: 60,
    def: 58,
    xp: 218,
    speed: 0.6,
    range: 100,
    agro: 300,
    archetype: "stomp",
    size: "L",
    loot: ["Kamie\u0144 runiczny", "Fragment ruin"]
  },
  {
    id: "aether-swietlik-pieczeci",
    world: "aether",
    name: "\u015Awietlik Piecz\u0119ci",
    level: 1,
    hp: 43,
    atk: 6,
    def: 2,
    xp: 13,
    speed: 0.7,
    range: 250,
    agro: 300,
    archetype: "hover",
    size: "S",
    loot: ["Py\u0142 \u015Bwiat\u0142a"]
  },
  {
    id: "aether-pergaminowy-straznik",
    world: "aether",
    name: "Pergaminowy Stra\u017Cnik",
    level: 2,
    hp: 84,
    atk: 10,
    def: 4,
    xp: 24,
    speed: 0.8,
    range: 300,
    agro: 300,
    archetype: "stomp",
    size: "M",
    loot: ["Karta pergaminu"]
  },
  {
    id: "aether-krysztalowy-motyl",
    world: "aether",
    name: "Kryszta\u0142owy Motyl",
    level: 4,
    hp: 82,
    atk: 12,
    def: 10,
    xp: 27,
    speed: 1.2,
    range: 90,
    agro: 250,
    archetype: "fly",
    size: "M",
    loot: ["Skrzyd\u0142o kryszta\u0142owe"]
  },
  {
    id: "aether-szmaragdowy-waz",
    world: "aether",
    name: "Szmaragdowy W\u0105\u017C",
    level: 6,
    hp: 196,
    atk: 24,
    def: 10,
    xp: 57,
    speed: 1,
    range: 100,
    agro: 350,
    archetype: "slither",
    size: "M",
    loot: ["Szmaragdowa \u0142uska"]
  },
  {
    id: "aether-duch-bibliotekarza",
    world: "aether",
    name: "Duch Bibliotekarza",
    level: 8,
    hp: 211,
    atk: 25,
    def: 4,
    xp: 59,
    speed: 0.9,
    range: 250,
    agro: 300,
    archetype: "hover",
    size: "M",
    loot: ["Eter bibliotekarza"]
  },
  {
    id: "aether-zloty-skarabeusz",
    world: "aether",
    name: "Z\u0142oty Skarabeusz",
    level: 10,
    hp: 510,
    atk: 30,
    def: 31,
    xp: 100,
    speed: 0.7,
    range: 90,
    agro: 300,
    archetype: "crawl",
    size: "S",
    loot: ["Z\u0142oty pancerz", "Skarabeusz"]
  },
  {
    id: "aether-lew-swiatyni",
    world: "aether",
    name: "Lew \u015Awi\u0105tyni",
    level: 12,
    hp: 678,
    atk: 46,
    def: 30,
    xp: 136,
    speed: 1,
    range: 100,
    agro: 350,
    archetype: "quad",
    size: "L",
    loot: ["Kamie\u0144 \u015Bwi\u0105tynny"]
  },
  {
    id: "aether-oko-wiedzy",
    world: "aether",
    name: "Oko Wiedzy",
    level: 14,
    hp: 464,
    atk: 40,
    def: 18,
    xp: 103,
    speed: 0.5,
    range: 400,
    agro: 450,
    archetype: "hover",
    size: "M",
    loot: ["Soczewka wiedzy"]
  },
  {
    id: "aether-marionetka-rytualu",
    world: "aether",
    name: "Marionetka Rytua\u0142u",
    level: 16,
    hp: 739,
    atk: 59,
    def: 26,
    xp: 153,
    speed: 0.9,
    range: 100,
    agro: 350,
    archetype: "stomp",
    size: "M",
    loot: ["Ni\u0107 eteru", "Maska rytua\u0142u"]
  },
  {
    id: "aether-mgielny-zuraw",
    world: "aether",
    name: "Mgielny \u017Buraw",
    level: 18,
    hp: 724,
    atk: 65,
    def: 26,
    xp: 156,
    speed: 1.1,
    range: 350,
    agro: 500,
    archetype: "fly",
    size: "L",
    loot: ["Pi\xF3ro mg\u0142y"]
  },
  {
    id: "nexus-dron-zwiadowca",
    world: "nexus",
    name: "Dron Zwiadowca",
    level: 1,
    hp: 37,
    atk: 6,
    def: 2,
    xp: 12,
    speed: 1.1,
    range: 250,
    agro: 450,
    archetype: "hover",
    size: "S",
    loot: ["Z\u0142om", "Modu\u0142 optyczny"]
  },
  {
    id: "nexus-pelzacz-serwisowy",
    world: "nexus",
    name: "Pe\u0142zacz Serwisowy",
    level: 2,
    hp: 76,
    atk: 7,
    def: 5,
    xp: 19,
    speed: 0.7,
    range: 90,
    agro: 250,
    archetype: "crawl",
    size: "S",
    loot: ["Zestaw naprawczy"]
  },
  {
    id: "nexus-skaner-gasienicowy",
    world: "nexus",
    name: "Skaner G\u0105sienicowy",
    level: 4,
    hp: 177,
    atk: 15,
    def: 10,
    xp: 44,
    speed: 0.5,
    range: 400,
    agro: 450,
    archetype: "stomp",
    size: "L",
    loot: ["G\u0105sienica", "Soczewka"]
  },
  {
    id: "nexus-pajak-spawalniczy",
    world: "nexus",
    name: "Paj\u0105k Spawalniczy",
    level: 6,
    hp: 196,
    atk: 26,
    def: 10,
    xp: 60,
    speed: 1,
    range: 150,
    agro: 350,
    archetype: "crawl",
    size: "M",
    loot: ["Elektroda", "Z\u0142om"]
  },
  {
    id: "nexus-wiezyczka-autonomiczna",
    world: "nexus",
    name: "Wie\u017Cyczka Autonomiczna",
    level: 8,
    hp: 396,
    atk: 35,
    def: 21,
    xp: 96,
    speed: 0,
    range: 450,
    agro: 500,
    archetype: "turret",
    size: "M",
    loot: ["Cewka", "Lufa"]
  },
  {
    id: "nexus-roj-nanitow",
    world: "nexus",
    name: "R\xF3j Nanit\xF3w",
    level: 10,
    hp: 272,
    atk: 30,
    def: 10,
    xp: 72,
    speed: 1.2,
    range: 90,
    agro: 350,
    archetype: "blob",
    size: "M",
    loot: ["Nanopy\u0142"]
  },
  {
    id: "nexus-pies-lowca",
    world: "nexus",
    name: "Pies \u0141owca",
    level: 12,
    hp: 424,
    atk: 49,
    def: 18,
    xp: 113,
    speed: 1.4,
    range: 90,
    agro: 600,
    archetype: "quad",
    size: "M",
    loot: ["Si\u0142ownik", "Czujnik"]
  },
  {
    id: "nexus-straznik-rdzenia",
    world: "nexus",
    name: "Stra\u017Cnik Rdzenia",
    level: 14,
    hp: 877,
    atk: 52,
    def: 41,
    xp: 162,
    speed: 0.8,
    range: 120,
    agro: 350,
    archetype: "stomp",
    size: "L",
    loot: ["Rdze\u0144 energii", "P\u0142yta pancerna"]
  },
  {
    id: "nexus-latarnia-plazmowa",
    world: "nexus",
    name: "Latarnia Plazmowa",
    level: 16,
    hp: 616,
    atk: 72,
    def: 21,
    xp: 159,
    speed: 0.3,
    range: 450,
    agro: 500,
    archetype: "hover",
    size: "M",
    loot: ["Rdze\u0144 plazmy"]
  },
  {
    id: "nexus-kruk-danych",
    world: "nexus",
    name: "Kruk Danych",
    level: 18,
    hp: 579,
    atk: 60,
    def: 23,
    xp: 136,
    speed: 1.3,
    range: 300,
    agro: 500,
    archetype: "fly",
    size: "M",
    loot: ["Pami\u0119\u0107 danych"]
  },
  {
    id: "pyra-wegielek",
    world: "pyra",
    name: "W\u0119gielek",
    level: 1,
    hp: 61,
    atk: 7,
    def: 3,
    xp: 16,
    speed: 0.6,
    range: 90,
    agro: 250,
    archetype: "blob",
    size: "S",
    loot: ["W\u0119giel"]
  },
  {
    id: "pyra-ognista-salamandra",
    world: "pyra",
    name: "Ognista Salamandra",
    level: 2,
    hp: 67,
    atk: 12,
    def: 3,
    xp: 24,
    speed: 1.2,
    range: 100,
    agro: 400,
    archetype: "slither",
    size: "M",
    loot: ["\u0141uska salamandry"]
  },
  {
    id: "pyra-popielny-wilk",
    world: "pyra",
    name: "Popielny Wilk",
    level: 4,
    hp: 122,
    atk: 18,
    def: 6,
    xp: 40,
    speed: 1.2,
    range: 90,
    agro: 450,
    archetype: "quad",
    size: "M",
    loot: ["Popielne futro"]
  },
  {
    id: "pyra-skalny-berserker",
    world: "pyra",
    name: "Skalny Berserker",
    level: 6,
    hp: 255,
    atk: 28,
    def: 11,
    xp: 70,
    speed: 1,
    range: 100,
    agro: 350,
    archetype: "stomp",
    size: "L",
    loot: ["Skalny kastet"]
  },
  {
    id: "pyra-magmowy-krab",
    world: "pyra",
    name: "Magmowy Krab",
    level: 8,
    hp: 396,
    atk: 25,
    def: 28,
    xp: 83,
    speed: 0.6,
    range: 100,
    agro: 300,
    archetype: "crawl",
    size: "M",
    loot: ["Magmowy pancerz"]
  },
  {
    id: "pyra-zarowy-nietoperz",
    world: "pyra",
    name: "\u017Barowy Nietoperz",
    level: 10,
    hp: 238,
    atk: 36,
    def: 10,
    xp: 76,
    speed: 1.4,
    range: 100,
    agro: 500,
    archetype: "fly",
    size: "M",
    loot: ["Skrzyd\u0142o \u017Caru"]
  },
  {
    id: "pyra-golem-ruin",
    world: "pyra",
    name: "Golem Ruin",
    level: 12,
    hp: 848,
    atk: 53,
    def: 40,
    xp: 165,
    speed: 0.5,
    range: 120,
    agro: 300,
    archetype: "stomp",
    size: "L",
    loot: ["Obsydian"]
  },
  {
    id: "pyra-plomien-duch",
    world: "pyra",
    name: "P\u0142omie\u0144-Duch",
    level: 14,
    hp: 413,
    atk: 60,
    def: 12,
    xp: 124,
    speed: 0.8,
    range: 400,
    agro: 450,
    archetype: "hover",
    size: "M",
    loot: ["Esencja p\u0142omienia"]
  },
  {
    id: "pyra-byk-areny",
    world: "pyra",
    name: "Byk Areny",
    level: 16,
    hp: 1109,
    atk: 68,
    def: 36,
    xp: 201,
    speed: 1,
    range: 100,
    agro: 400,
    archetype: "quad",
    size: "L",
    loot: ["R\xF3g areny"]
  },
  {
    id: "pyra-skorpion-obsydianowy",
    world: "pyra",
    name: "Skorpion Obsydianowy",
    level: 18,
    hp: 869,
    atk: 75,
    def: 44,
    xp: 184,
    speed: 1,
    range: 150,
    agro: 400,
    archetype: "crawl",
    size: "M",
    loot: ["Szk\u0142o obsydianowe"]
  }
];

// src/game/monsters/catalog.ts
var poison = (atkPct, ms, stacks) => ({
  k: "dot",
  id: "poison",
  atkPct,
  ms,
  ...stacks ? { stacks } : {}
});
var burn = (atkPct, ms) => ({ k: "dot", id: "burn", atkPct, ms });
var bleed = (atkPct, ms) => ({ k: "dot", id: "bleed", atkPct, ms });
var BEHAVIOUR = {
  "verdant-mchowy-szlamak": {
    weak: { fire: 1.3 },
    traits: { provoked: true, giveUp: 6e3, leash: 300, wander: 300 },
    skills: [
      {
        id: "oblepienie",
        name: "Oblepienie",
        mode: "melee",
        cd: 5e3,
        range: 90,
        dmg: 0.6,
        fx: [{ k: "slow", pct: 0.2, ms: 3e3 }]
      }
    ]
  },
  "verdant-cierniowy-wilk": {
    weak: { area: 1.25 },
    traits: { leash: 520, pack: [2, 3], flank: true, retreat: { below: 0.25, ms: 4e3 } },
    skills: [
      { id: "wycie", name: "Wycie", mode: "self", cd: 1e3, range: 600, call: 1, once: true },
      { id: "skok", name: "Skok na cel", mode: "leap", cd: 6e3, range: 220, dmg: 1.2 }
    ]
  },
  "verdant-lisciak-skrytobojca": {
    weak: { area: 1.3 },
    traits: { leash: 350, ambush: { reveal: 200, hide: 8e3 } },
    skills: [
      {
        id: "cios-z-ukrycia",
        name: "Cios z ukrycia",
        mode: "melee",
        cd: 1e3,
        range: 90,
        dmg: 1,
        opener: 2,
        fx: [bleed(0.2, 3e3)]
      }
    ]
  },
  "verdant-korzeniowy-pelzacz": {
    weak: { fire: 1.3 },
    traits: { leash: 400, burrow: { under: 4e3, up: 3500, bonus: 0.25 } },
    skills: [
      {
        id: "oplatanie",
        name: "Opl\u0105tanie",
        mode: "burst",
        cd: 1e4,
        range: 300,
        dmg: 0.8,
        radius: 70,
        telegraph: 700,
        fx: [{ k: "root", ms: 2e3 }]
      },
      {
        id: "wybuch-korzeni",
        name: "Wybuch korzeni",
        mode: "burst",
        cd: 14e3,
        range: 200,
        dmg: 0.9,
        radius: 120,
        telegraph: 800,
        centred: true
      }
    ]
  },
  "verdant-grzybowy-zarodnik": {
    weak: { fire: 1.4 },
    basic: "none",
    traits: {
      leash: 40,
      still: true,
      deathZone: { kind: "poison", ms: 5e3, radius: 150, dps: 0.2, fx: [poison(0.15, 3e3)] }
    },
    skills: [
      {
        id: "chmura",
        name: "Chmura zarodnik\xF3w",
        mode: "burst",
        cd: 7e3,
        range: 350,
        dmg: 0.4,
        radius: 150,
        telegraph: 800,
        fx: [poison(0.15, 5e3)],
        zone: { kind: "poison", ms: 3e3, radius: 150, dps: 0.1 }
      }
    ]
  },
  "verdant-bursztynowa-osa": {
    weak: { area: 1.3 },
    traits: { fly: true, leash: 550, dive: { attacks: 3, away: 3e3 } },
    skills: [
      {
        id: "roj",
        name: "R\xF3j",
        mode: "self",
        cd: 1e3,
        range: 600,
        summon: { kind: "verdant-mala-osa", count: 2 },
        once: true,
        below: 0.4
      },
      {
        id: "zadlo",
        name: "\u017B\u0105d\u0142o",
        mode: "melee",
        cd: 3e3,
        range: 110,
        dmg: 1,
        fx: [poison(0.08, 5e3)]
      }
    ]
  },
  "verdant-skalny-jelen": {
    traits: { provoked: true, giveUp: 8e3, leash: 450 },
    skills: [
      {
        id: "szarza",
        name: "Szar\u017Ca",
        mode: "charge",
        cd: 8e3,
        range: 420,
        dmg: 1.5,
        telegraph: 700,
        fx: [{ k: "stun", ms: 1e3 }],
        missStun: 2e3,
        exposed: 0.3
      },
      {
        id: "tupniecie",
        name: "Tupni\u0119cie",
        mode: "burst",
        cd: 9e3,
        range: 130,
        dmg: 0.8,
        radius: 120,
        telegraph: 500,
        centred: true
      }
    ]
  },
  "verdant-lesny-pajak": {
    weak: { fire: 1.3 },
    basic: "ranged",
    attackCd: 2400,
    traits: {
      leash: 450,
      keep: 200,
      webSlow: 0.6,
      webs: {
        max: 3,
        radius: 300,
        zone: {
          kind: "web",
          ms: 12e4,
          radius: 55,
          dps: 0,
          fx: [{ k: "slow", pct: 0.4, ms: 4e3 }]
        }
      }
    },
    skills: [
      {
        id: "plwocina",
        name: "Plwocina",
        mode: "ranged",
        cd: 6e3,
        range: 300,
        dmg: 0.8,
        fx: [poison(0.12, 5e3)]
      }
    ]
  },
  "verdant-puchacz-pylowy": {
    traits: {
      fly: true,
      leash: 600,
      night: { day: 0.5 },
      opportunist: 0.6,
      dive: { attacks: 1, away: 1500 },
      exposedBonus: 0.2
    },
    skills: [
      {
        id: "nurkowanie",
        name: "Nurkowanie",
        mode: "leap",
        cd: 5e3,
        range: 260,
        dmg: 1.3,
        fx: [{ k: "blind", pct: 0.25, ms: 4e3 }]
      }
    ]
  },
  "verdant-straznik-ruin": {
    weak: { ki: 1.25 },
    traits: {
      guard: true,
      leash: 500,
      route: [
        [-120, 0],
        [0, -120],
        [120, 0],
        [0, 120]
      ]
    },
    skills: [
      {
        id: "kamienna-skora",
        name: "Kamienna sk\xF3ra",
        mode: "self",
        cd: 2e4,
        range: 0,
        reduce: { pct: 0.4, ms: 4e3 }
      },
      {
        id: "mlot",
        name: "Cios m\u0142otem",
        mode: "melee",
        cd: 6e3,
        range: 130,
        dmg: 1.8,
        telegraph: 1e3
      }
    ]
  },
  "aether-swietlik-pieczeci": {
    weak: { physical: 1.2 },
    basic: "ranged",
    attackCd: 2500,
    traits: { fly: true, guard: true, keep: 220, leash: 250 }
  },
  "aether-pergaminowy-straznik": {
    weak: { fire: 1.3 },
    basic: "ranged",
    attackCd: 4e3,
    traits: { keep: 230, leash: 400 },
    skills: [
      {
        id: "zapieczetowanie",
        name: "Zapiecz\u0119towanie",
        mode: "ranged",
        cd: 15e3,
        range: 320,
        dmg: 0.3,
        fx: [{ k: "silence", ms: 2e3 }]
      }
    ]
  },
  "aether-krysztalowy-motyl": {
    traits: { provoked: true, giveUp: 7e3, leash: 300, fly: true, reflect: 0.15 },
    skills: [
      {
        id: "pylek",
        name: "Py\u0142ek",
        mode: "melee",
        cd: 8e3,
        range: 100,
        dmg: 0.4,
        fx: [{ k: "blind", pct: 0.5, ms: 2e3 }]
      }
    ]
  },
  "aether-szmaragdowy-waz": {
    weak: { ki: 1.2 },
    traits: { leash: 400, dive: { attacks: 2, away: 2500 } },
    skills: [
      {
        id: "ukaszenie",
        name: "Uk\u0105szenie",
        mode: "melee",
        cd: 1800,
        range: 100,
        dmg: 1,
        fx: [poison(0.12, 5e3, 3)]
      },
      {
        id: "syk",
        name: "Syk",
        mode: "ranged",
        cd: 9e3,
        range: 220,
        dmg: 0,
        fx: [{ k: "slow", pct: 0.2, ms: 3e3 }]
      }
    ]
  },
  "aether-duch-bibliotekarza": {
    weak: { ki: 1.5, physical: 0.6 },
    traits: { ghost: true, fly: true, leash: 450, revive: 0.3 },
    skills: [
      {
        id: "uciszenie",
        name: "Uciszenie",
        mode: "ranged",
        cd: 12e3,
        range: 260,
        dmg: 0.2,
        fx: [{ k: "silence", ms: 3e3 }]
      },
      {
        id: "szept",
        name: "Szept",
        mode: "ranged",
        cd: 9e3,
        range: 260,
        dmg: 0,
        fx: [{ k: "weaken", pct: 0.15, ms: 4e3 }]
      }
    ]
  },
  "aether-zloty-skarabeusz": {
    weak: { ki: 1.3 },
    traits: { leash: 400, curl: { hits: 3, ms: 3e3, reduce: 0.7 } },
    skills: [
      {
        id: "rozbicie-bariery",
        name: "Rozbicie bariery",
        mode: "melee",
        cd: 8e3,
        range: 100,
        dmg: 0.8,
        fx: [{ k: "breakShield" }]
      },
      {
        id: "taran",
        name: "Taran",
        mode: "charge",
        cd: 9e3,
        range: 260,
        dmg: 1.2,
        telegraph: 500
      }
    ]
  },
  "aether-lew-swiatyni": {
    traits: { guard: true, leash: 450, backBonus: 0.25 },
    skills: [
      {
        id: "ryk",
        name: "Ryk",
        mode: "burst",
        cd: 14e3,
        range: 220,
        dmg: 0,
        radius: 220,
        telegraph: 500,
        centred: true,
        fx: [{ k: "fear", ms: 1500 }]
      },
      { id: "pazur", name: "Pazur", mode: "melee", cd: 2500, range: 110, dmg: 1.5 }
    ]
  },
  "aether-oko-wiedzy": {
    basic: "none",
    traits: { fly: true, keep: 320, leash: 500, fleeAfterHits: { hits: 2, ms: 5e3 } },
    skills: [
      {
        id: "znak",
        name: "Znak",
        mode: "ranged",
        cd: 1e4,
        range: 400,
        dmg: 0,
        fx: [{ k: "mark", pct: 0.2, ms: 5e3 }]
      },
      {
        id: "wzmocnienie",
        name: "Wzmocnienie",
        mode: "self",
        cd: 12e3,
        range: 450,
        buff: { pct: 0.15, ms: 6e3 }
      },
      {
        id: "promien",
        name: "Promie\u0144 skupienia",
        mode: "ranged",
        cd: 6e3,
        range: 400,
        dmg: 1,
        telegraph: 400
      }
    ]
  },
  "aether-marionetka-rytualu": {
    weak: { physical: 1.15 },
    traits: { leash: 500, slowBelow: { hp: 0.3, mult: 0.7 } },
    skills: [
      { id: "combo", name: "Combo", mode: "melee", cd: 6e3, range: 110, dmg: 0.7, volley: 3 },
      {
        id: "nic",
        name: "Ni\u0107 energii",
        mode: "ranged",
        cd: 12e3,
        range: 300,
        dmg: 0.3,
        fx: [{ k: "pull", dist: 150 }]
      }
    ]
  },
  "aether-mgielny-zuraw": {
    weakRanged: 1.2,
    traits: {
      fly: true,
      leash: 600,
      retreat: { below: 0.2, ms: 8e3 },
      dive: { attacks: 2, away: 2500 }
    },
    skills: [
      {
        id: "mgla",
        name: "Mg\u0142a",
        mode: "ranged",
        cd: 12e3,
        range: 380,
        dmg: 0,
        fx: [{ k: "fog", pct: 0.5, ms: 5e3 }]
      },
      { id: "szpon", name: "Szpon z powietrza", mode: "leap", cd: 5e3, range: 260, dmg: 1.1 }
    ]
  },
  "nexus-dron-zwiadowca": {
    weak: { electric: 1.3 },
    basic: "none",
    traits: {
      machine: true,
      fly: true,
      keep: 200,
      leash: 450,
      route: [
        [-150, 0],
        [0, -100],
        [150, 0],
        [0, 100]
      ]
    },
    skills: [
      { id: "alarm", name: "Alarm", mode: "self", cd: 1e3, range: 600, call: 1, once: true },
      { id: "wiazka", name: "Wi\u0105zka", mode: "ranged", cd: 3e3, range: 260, dmg: 0.6, volley: 2 }
    ]
  },
  "nexus-pelzacz-serwisowy": {
    weak: { electric: 1.3 },
    traits: { machine: true, leash: 350, medic: 200 },
    skills: [
      {
        id: "naprawa",
        name: "Naprawa",
        mode: "self",
        cd: 6e3,
        range: 200,
        heal: { pct: 0.05, ms: 4e3 }
      },
      { id: "kleszcze", name: "Kleszcze", mode: "melee", cd: 2e3, range: 90, dmg: 1 }
    ]
  },
  "nexus-skaner-gasienicowy": {
    basic: "ranged",
    attackCd: 5e3,
    traits: { machine: true, keep: 300, leash: 450, ramp: 0.25, backBonus: 0.25 },
    skills: [
      {
        id: "namierzenie",
        name: "Namierzenie",
        mode: "self",
        cd: 12e3,
        range: 0,
        nextAttack: 0.2
      }
    ]
  },
  "nexus-pajak-spawalniczy": {
    weak: { electric: 1.2 },
    traits: { machine: true, leash: 450 },
    skills: [
      { id: "luk", name: "\u0141uk spawalniczy", mode: "ranged", cd: 5e3, range: 220, dmg: 1 },
      {
        id: "zar",
        name: "Strefa \u017Caru",
        mode: "burst",
        cd: 9e3,
        range: 260,
        dmg: 0.2,
        radius: 100,
        telegraph: 600,
        zone: { kind: "metal", ms: 4e3, radius: 100, dps: 0.25 }
      }
    ]
  },
  "nexus-wiezyczka-autonomiczna": {
    basic: "none",
    traits: {
      machine: true,
      still: true,
      leash: 20,
      turret: { turn: 90, shots: 12, off: 3e3 },
      exposedBonus: 0.3
    },
    skills: [
      {
        id: "seria",
        name: "Seria 3 pocisk\xF3w",
        mode: "ranged",
        cd: 4e3,
        range: 450,
        dmg: 0.5,
        volley: 3,
        aimed: true
      }
    ]
  },
  "nexus-roj-nanitow": {
    weak: { area: 1.3 },
    basicFx: [{ k: "armorDown", pct: 0.1, ms: 8e3, stacks: 3 }],
    traits: { machine: true, leash: 400, split: { hpPct: 0.4, merge: 6e3 } }
  },
  "nexus-pies-lowca": {
    weak: { stun: 1.25 },
    traits: { machine: true, leash: 700 },
    skills: [
      { id: "skok", name: "Skok", mode: "leap", cd: 6e3, range: 260, dmg: 1 },
      { id: "szarpniecie", name: "Szarpni\u0119cie", mode: "melee", cd: 2200, range: 100, dmg: 1.2 }
    ]
  },
  "nexus-straznik-rdzenia": {
    weak: { electric: 1.3 },
    traits: { machine: true, guard: true, leash: 500 },
    skills: [
      {
        id: "tarcza",
        name: "Tarcza plazmowa",
        mode: "self",
        cd: 25e3,
        range: 0,
        guard: { pct: 0.25, ms: 12e3 },
        below: 0.5
      },
      {
        id: "impuls",
        name: "Cios impulsowy",
        mode: "burst",
        cd: 6e3,
        range: 150,
        dmg: 1,
        radius: 130,
        telegraph: 600,
        centred: true
      }
    ]
  },
  "nexus-latarnia-plazmowa": {
    traits: { machine: true, fly: true, leash: 500, interrupt: { pct: 0.15, stun: 2e3 } },
    basic: "ranged",
    attackCd: 3e3,
    skills: [
      {
        id: "wyladowanie",
        name: "Wy\u0142adowanie plazmy",
        mode: "burst",
        cd: 9e3,
        range: 420,
        dmg: 2.5,
        radius: 180,
        telegraph: 2500
      }
    ]
  },
  "nexus-kruk-danych": {
    weak: { electric: 1.3 },
    basic: "none",
    traits: { machine: true, fly: true, keep: 300, leash: 600, retreat: { below: 0.3, ms: 6e3 } },
    skills: [
      {
        id: "zaklocenie",
        name: "Zak\u0142\xF3cenie",
        mode: "ranged",
        cd: 14e3,
        range: 420,
        dmg: 0,
        fx: [{ k: "jam", ms: 4e3 }]
      },
      {
        id: "znak-lowcy",
        name: "Znak \u0142owcy",
        mode: "ranged",
        cd: 12e3,
        range: 420,
        dmg: 0,
        fx: [{ k: "mark", pct: 0.15, ms: 6e3, from: "machine" }]
      }
    ]
  },
  "pyra-wegielek": {
    weak: { water: 1.3 },
    basicFx: [burn(0.15, 3e3)],
    traits: { leash: 350, explode: { atk: 0.4, radius: 120 } }
  },
  "pyra-ognista-salamandra": {
    weak: { water: 1.3 },
    basicFx: [burn(0.15, 3e3)],
    traits: { leash: 450, trail: { kind: "fire", ms: 3e3, radius: 40, dps: 0.3 } }
  },
  "pyra-popielny-wilk": {
    weak: { area: 1.25 },
    traits: {
      pack: [3, 3],
      flank: true,
      leash: 550,
      retreat: { below: 0.3, ms: 5e3, hide: true, regen: 0.06 }
    },
    skills: [
      { id: "skok", name: "Skok", mode: "leap", cd: 6e3, range: 220, dmg: 1 },
      {
        id: "oblok",
        name: "Ob\u0142ok popio\u0142u",
        mode: "burst",
        cd: 14e3,
        range: 260,
        dmg: 0,
        radius: 140,
        telegraph: 400,
        fx: [{ k: "fog", pct: 0.3, ms: 4e3 }]
      }
    ]
  },
  "pyra-skalny-berserker": {
    weak: { stun: 1.25 },
    traits: { leash: 450, rage: { dmg: 0.4, below: 0.5, speed: 0.2 } },
    skills: [
      { id: "mlot", name: "M\u0142ot", mode: "melee", cd: 5e3, range: 100, dmg: 1.4, telegraph: 500 }
    ]
  },
  "pyra-magmowy-krab": {
    weak: { water: 1.25 },
    traits: { frontArmor: 0.6, backBonus: 0.4, leash: 350 },
    skills: [
      { id: "kleszcze", name: "Kleszcze", mode: "melee", cd: 5e3, range: 110, dmg: 1.2 },
      {
        id: "zalew",
        name: "Zalew magm\u0105",
        mode: "burst",
        cd: 12e3,
        range: 200,
        dmg: 0.3,
        radius: 120,
        telegraph: 700,
        zone: { kind: "lava", ms: 4e3, radius: 120, dps: 0.3, fx: [burn(0.15, 2e3)] }
      }
    ]
  },
  "pyra-zarowy-nietoperz": {
    weak: { area: 1.3 },
    traits: { fly: true, pack: [3, 3], leash: 600, dive: { attacks: 1, away: 1800 } },
    skills: [
      {
        id: "nurkowanie",
        name: "Nurkowanie",
        mode: "leap",
        cd: 4e3,
        range: 260,
        dmg: 1,
        fx: [burn(0.1, 2e3)]
      }
    ]
  },
  "pyra-golem-ruin": {
    weak: { ki: 1.2 },
    traits: { leash: 400 },
    skills: [
      {
        id: "odlamki",
        name: "Od\u0142amki",
        mode: "burst",
        cd: 1e4,
        range: 300,
        dmg: 0.8,
        radius: 200,
        telegraph: 700,
        centred: true,
        below: 0.5
      },
      {
        id: "miazdzenie",
        name: "Mia\u017Cd\u017Cenie",
        mode: "melee",
        cd: 7e3,
        range: 130,
        dmg: 2.2,
        telegraph: 1500
      }
    ]
  },
  "pyra-plomien-duch": {
    weak: { water: 1.4 },
    basic: "ranged",
    attackCd: 3500,
    basicFx: [burn(0.1, 2e3)],
    traits: {
      fly: true,
      keep: 280,
      leash: 550,
      deathZone: { kind: "fire", ms: 5e3, radius: 120, dps: 0.3, fx: [burn(0.15, 2e3)] }
    },
    skills: [
      {
        id: "pierscien",
        name: "Pier\u015Bcie\u0144 ognia",
        mode: "burst",
        cd: 12e3,
        range: 200,
        dmg: 1,
        radius: 160,
        telegraph: 800,
        centred: true
      }
    ]
  },
  "pyra-byk-areny": {
    traits: { leash: 500 },
    skills: [
      {
        id: "szarza",
        name: "Szar\u017Ca",
        mode: "charge",
        cd: 9e3,
        range: 500,
        dmg: 2,
        telegraph: 1e3,
        fx: [{ k: "stun", ms: 1e3 }],
        missStun: 2500,
        exposed: 0.2
      },
      {
        id: "tupniecie",
        name: "Tupni\u0119cie",
        mode: "burst",
        cd: 7e3,
        range: 130,
        dmg: 0.7,
        radius: 100,
        telegraph: 500,
        centred: true
      }
    ]
  },
  "pyra-skorpion-obsydianowy": {
    weak: { water: 1.2 },
    traits: { leash: 500, burrow: { under: 3e3, up: 6e3 }, brittleTail: 3 },
    skills: [
      {
        id: "zadlo",
        name: "\u017B\u0105d\u0142o",
        mode: "melee",
        cd: 2500,
        range: 110,
        dmg: 1,
        fx: [poison(0.12, 6e3, 5)]
      },
      {
        id: "pulapka",
        name: "Pu\u0142apka piaskowa",
        mode: "burst",
        cd: 12e3,
        range: 260,
        dmg: 0,
        radius: 100,
        telegraph: 600,
        zone: { kind: "sand", ms: 4e3, radius: 100, dps: 0, fx: [{ k: "root", ms: 1e3 }] }
      }
    ]
  }
};
var lootOf = (names, chances) => names.map((name, i) => ({ name, chance: chances?.[i] ?? (i === 0 ? 0.7 : 0.35) }));
var build = () => MONSTER_BASE.map((b) => {
  const rules = BEHAVIOUR[b.id];
  if (!rules) throw new Error("Brak zachowania potwora " + b.id);
  return {
    id: b.id,
    world: b.world,
    name: b.name,
    level: b.level,
    hp: b.hp,
    atk: b.atk,
    def: b.def,
    xp: b.xp,
    speed: b.speed,
    range: b.range,
    agro: b.agro,
    attackCd: rules.attackCd ?? 1600,
    basic: rules.basic ?? "melee",
    ...rules.basicFx ? { basicFx: rules.basicFx } : {},
    ...rules.weakRanged ? { weakRanged: rules.weakRanged } : {},
    weak: rules.weak ?? {},
    traits: rules.traits,
    skills: rules.skills ?? [],
    loot: lootOf(b.loot, rules.chances),
    gold: [Math.max(1, b.level), Math.max(3, b.level * 3)],
    respawn: rules.respawn ?? 25e3
  };
});
var MONSTERS = build();
var EXTRA = [
  {
    id: "boar",
    world: "verdant",
    name: "Dzik",
    level: 1,
    hp: 66,
    atk: 9,
    def: 0,
    xp: 20,
    speed: 1,
    range: 68,
    agro: 155,
    attackCd: 1400,
    basic: "melee",
    weak: {},
    traits: { leash: 330, wander: 65 },
    skills: [],
    loot: [{ name: "tusk", chance: 1 }],
    gold: [4, 4],
    respawn: 18e3,
    minion: true
  },
  {
    id: "verdant-mala-osa",
    world: "verdant",
    name: "Ma\u0142a osa",
    level: 4,
    hp: 40,
    atk: 14,
    def: 3,
    xp: 8,
    speed: 1.5,
    range: 90,
    agro: 400,
    attackCd: 1500,
    basic: "melee",
    weak: { area: 1.3 },
    traits: { fly: true, leash: 600 },
    skills: [],
    loot: [],
    gold: [0, 0],
    respawn: 0,
    minion: true
  }
];
var MONSTER_DEFS = Object.fromEntries(
  [...MONSTERS, ...EXTRA].map((m) => [m.id, m])
);
var monsterDef = (id) => {
  const def = MONSTER_DEFS[id];
  if (!def) throw new Error("Nieznany potw\xF3r: " + id);
  return def;
};

// src/game/monsters/materials.ts
var slug = (name) => name.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/ł/g, "l").replace(/Ł/g, "l").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
var MATERIALS = {};
for (const monster of MONSTERS)
  for (const entry of monster.loot) {
    const id = slug(entry.name);
    const existing = MATERIALS[id];
    if (!existing || monster.level < existing.level)
      MATERIALS[id] = {
        id,
        name: entry.name,
        level: monster.level,
        sell: Math.round(2 + monster.level * 1.5)
      };
  }
var MATERIAL_IDS = Object.keys(MATERIALS);
var isMaterial = (id) => Object.hasOwn(MATERIALS, id);

// src/game/monsters/system.ts
var BASE_SPEED = 0.12;
var newFx = () => ({
  stunMs: 0,
  slow: { pct: 0, ms: 0 },
  weaken: { pct: 0, ms: 0 },
  dots: [],
  seal: null,
  mark: null
});
function newState(def, now) {
  const hidden = !!(def.traits.ambush || def.traits.burrow);
  return {
    def,
    phase: hidden ? "hidden" : "idle",
    phaseMs: 0,
    hidden,
    invulnerable: false,
    facing: { x: 0, y: 1 },
    cooldowns: {},
    used: /* @__PURE__ */ new Set(),
    hitsTaken: 0,
    attacksMade: 0,
    sinceHit: 1e9,
    provoked: false,
    engaged: false,
    revived: false,
    split: false,
    parent: void 0,
    guard: 0,
    guardMs: 0,
    reduce: 0,
    reduceMs: 0,
    buff: 0,
    buffMs: 0,
    regen: 0,
    regenMs: 0,
    curlMs: 0,
    curlHits: 0,
    exposed: 0,
    exposedMs: 0,
    stunMs: 0,
    shots: 0,
    heatMs: 0,
    castDamage: 0,
    cast: void 0,
    charge: void 0,
    volley: void 0,
    scanStacks: 0,
    scanReady: false,
    tailHits: 0,
    tailBroken: false,
    trailMs: 0,
    webs: [],
    orbit: 1,
    routeIndex: 0,
    aim: 0,
    nextWander: 0,
    attackCount: 0,
    nextAttack: 0,
    spawnedAt: now
  };
}
var unit = (a, b) => {
  const d = distance(a, b);
  return d < 1e-6 ? { x: 0, y: 1 } : { x: (b.x - a.x) / d, y: (b.y - a.y) / d };
};
var clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
var MonsterSystem = class {
  constructor(host) {
    this.host = host;
  }
  host;
  zones = [];
  seq = 0;
  zoneSeq = 0;
  paths = /* @__PURE__ */ new Map();
  splits = /* @__PURE__ */ new Map();
  // --- spawning -----------------------------------------------------------------------------
  spawn(kind, at, id) {
    const def = monsterDef(kind);
    const home = this.host.nav.safe(at);
    const e = {
      id: id ?? kind + "#" + this.seq++,
      kind,
      ...home,
      home,
      hp: def.hp,
      maxHp: def.hp,
      mode: "patrol",
      timer: 0,
      attackIn: 900,
      patrol: { ...home },
      m: newState(def, this.host.nowMs),
      fx: newFx()
    };
    this.host.enemies.push(e);
    if (def.traits.webs) this.layWebs(e);
    return e;
  }
  /** Spawns a pack (wolves, bats) around a point. Returns the members. */
  spawnGroup(kind, at) {
    const def = monsterDef(kind);
    const [lo, hi] = def.traits.pack ?? [1, 1];
    const n = lo + Math.floor(this.host.random() * (hi - lo + 1));
    const out = [];
    for (let i = 0; i < n; i++) {
      const a = Math.PI * 2 * i / Math.max(1, n);
      out.push(this.spawn(kind, { x: at.x + Math.cos(a) * 55, y: at.y + Math.sin(a) * 55 }));
    }
    return out;
  }
  /** Monsters that can be hit or targeted. */
  get targetable() {
    return this.host.enemies.filter((e) => e.mode !== "dead" && !e.m.hidden && !e.m.invulnerable);
  }
  // --- damage from the player ---------------------------------------------------------------
  /** Player → monster damage after the annex model `max(1, raw − DEF/2)` and monster modifiers. */
  damage(e, raw, hit) {
    const m = e.m;
    const def = m.def;
    if (e.mode === "dead" || m.hidden || m.invulnerable) return 0;
    if (m.phase === "return" && !hit.indirect) {
      this.host.say(def.name + " wraca na swoje terytorium.");
      return 0;
    }
    const p = this.host.player;
    const toPlayer = unit(e, p);
    const rel = m.facing.x * toPlayer.x + m.facing.y * toPlayer.y;
    let mult = 1;
    for (const tag of hit.tags) {
      const w = def.weak[tag];
      if (w === void 0) continue;
      mult = w > 1 ? Math.max(mult, w) : Math.min(mult, w);
    }
    if (hit.ranged && def.weakRanged) mult = Math.max(mult, def.weakRanged);
    if (e.fx.seal && e.fx.seal.ms > 0) mult *= 1 + e.fx.seal.bonus;
    if (def.traits.frontArmor && rel > 0.5) mult *= 1 - def.traits.frontArmor;
    if (def.traits.backBonus && rel < -0.5) mult *= 1 + def.traits.backBonus;
    const retreating = m.phase === "retreat" && !!def.traits.dive;
    if (def.traits.exposedBonus && (retreating || m.heatMs > 0))
      mult *= 1 + def.traits.exposedBonus;
    if (def.traits.burrow?.bonus && m.phase === "engage") mult *= 1 + def.traits.burrow.bonus;
    if (m.curlMs > 0 && !hit.tags.includes("ki") && def.traits.curl)
      mult *= 1 - def.traits.curl.reduce;
    if (m.reduceMs > 0) mult *= 1 - m.reduce;
    let defense = def.def;
    if (e.fx.mark && e.fx.mark.ms > 0) defense *= 1 - e.fx.mark.def;
    if (m.exposedMs > 0) defense *= 1 - m.exposed;
    let dmg = Math.max(1, raw * mult - defense / 2);
    if (m.guard > 0) {
      const absorbed = Math.min(m.guard, dmg);
      m.guard -= absorbed;
      dmg -= absorbed;
      if (dmg <= 0) {
        this.host.emit({ type: "hit", ...e, target: e.id, text: "Tarcza" });
        return 0;
      }
    }
    e.hp = Math.max(0, e.hp - dmg);
    m.sinceHit = 0;
    this.host.emit({
      type: "hit",
      x: e.x,
      y: e.y,
      target: e.id,
      text: "-" + Math.round(dmg) + (hit.crit ? "!" : ""),
      crit: !!hit.crit
    });
    if (def.traits.webs && hit.tags.includes("fire")) this.burnWebs(e);
    if (!hit.indirect) {
      m.hitsTaken++;
      if (def.traits.brittleTail && rel < -0.5 && !m.tailBroken) {
        m.tailHits++;
        if (m.tailHits >= def.traits.brittleTail) {
          m.tailBroken = true;
          this.host.say(def.name + ": ogon p\u0119ka \u2014 \u017C\u0105d\u0142o wy\u0142\u0105czone.");
        }
      }
      if (def.traits.curl && m.curlMs <= 0 && !hit.tags.includes("ki")) {
        m.curlHits++;
        if (m.curlHits >= def.traits.curl.hits) {
          m.curlHits = 0;
          m.curlMs = def.traits.curl.ms;
          m.cast = void 0;
        }
      }
      if (def.traits.reflect && !hit.tags.includes("ki") && !hit.tags.includes("area")) {
        const back = Math.round(dmg * def.traits.reflect);
        if (back > 0) this.host.hurtPlayer(back, e, "other", true);
      }
    }
    m.castDamage += dmg;
    if (m.cast && def.traits.interrupt && m.castDamage >= e.maxHp * def.traits.interrupt.pct) {
      m.cast = void 0;
      m.stunMs = def.traits.interrupt.stun;
      this.host.say(def.name + ": \u0142adowanie przerwane!");
    }
    if (def.traits.split && !m.split && e.hp > 0) this.split(e);
    if (e.hp <= 0) {
      if (def.traits.revive && !m.revived) {
        m.revived = true;
        e.hp = Math.max(1, Math.round(e.maxHp * def.traits.revive));
        m.invulnerable = true;
        m.phase = "recover";
        m.phaseMs = 1500;
        m.cast = void 0;
        m.charge = void 0;
        this.host.emit({ type: "respawn", x: e.x, y: e.y, target: e.id });
        this.host.say(def.name + " powraca!");
      } else this.die(e);
      return dmg;
    }
    if (!m.provoked) m.provoked = true;
    if (m.phase === "idle" && !hit.indirect) this.engage(e);
    if (def.traits.fleeAfterHits && m.hitsTaken >= def.traits.fleeAfterHits.hits && m.phase === "engage") {
      m.hitsTaken = 0;
      this.retreat(e, def.traits.fleeAfterHits.ms);
    }
    return dmg;
  }
  engage(e) {
    e.m.phase = "engage";
    e.m.engaged = true;
    e.m.hidden = false;
    e.mode = "chase";
  }
  split(e) {
    const t = e.m.def.traits.split;
    const origMax = e.maxHp;
    const part = Math.max(1, Math.round(origMax * t.hpPct));
    e.maxHp = part;
    e.hp = Math.min(e.hp, part);
    e.m.split = true;
    const clone = this.spawn(e.kind, { x: e.x + 30, y: e.y + 20 });
    clone.maxHp = part;
    clone.hp = part;
    clone.m.split = true;
    clone.m.parent = e.id;
    clone.home = { ...e.home };
    this.engage(clone);
    this.splits.set(e.id, { cloneId: clone.id, origMax, ms: t.merge });
    this.host.say(e.m.def.name + " rozdziela si\u0119!");
  }
  die(e) {
    const m = e.m;
    const def = m.def;
    e.hp = 0;
    e.mode = "dead";
    e.timer = def.respawn;
    m.phase = "idle";
    m.hidden = false;
    m.invulnerable = false;
    m.cast = void 0;
    m.charge = void 0;
    m.volley = void 0;
    this.paths.delete(e.id);
    this.burnWebs(e);
    this.host.emit({ type: "death", x: e.x, y: e.y, target: e.id });
    const t = def.traits;
    if (t.explode) {
      this.host.emit({
        type: "telegraph",
        x: e.x,
        y: e.y,
        radius: t.explode.radius,
        ms: 0,
        ability: "explode"
      });
      if (distance(e, this.host.player) <= t.explode.radius && !this.host.player.dead) {
        const r = this.host.hurtPlayer(def.atk * t.explode.atk, e, "area");
        if (!r.evaded) for (const fx of t.explode.fx ?? []) this.host.applyPlayerFx(fx, e);
      }
    }
    if (t.deathZone) this.addZone(t.deathZone, e, e);
    this.host.killed(e);
  }
  // --- status effects from the player's abilities ----------------------------------------------
  stun(e, ms) {
    if (e.mode === "dead" || e.m.hidden) return;
    e.fx.stunMs = Math.max(e.fx.stunMs, ms);
    e.m.cast = void 0;
    e.m.charge = void 0;
  }
  slow(e, pct, ms) {
    e.fx.slow = {
      pct: Math.max(e.fx.slow.ms > 0 ? e.fx.slow.pct : 0, pct),
      ms: Math.max(e.fx.slow.ms, ms)
    };
  }
  weaken(e, pct, ms) {
    e.fx.weaken = { pct, ms: Math.max(e.fx.weaken.ms, ms) };
  }
  burn(e, dps, ms) {
    e.fx.dots.push({ dps, ms });
  }
  seal(e, ms, bonus) {
    e.fx.seal = { ms, bonus };
  }
  mark(e, ms, crit, def) {
    e.fx.mark = { ms, crit, def };
  }
  push(e, from, distancePx) {
    if (e.mode === "dead" || e.m.hidden || e.m.def.traits.still) return;
    const u = unit(from, e);
    const to = { x: e.x + u.x * distancePx, y: e.y + u.y * distancePx };
    if (e.m.def.traits.fly || e.m.def.traits.ghost) Object.assign(e, this.clampWorld(to));
    else Object.assign(e, this.host.nav.step(e, to, distancePx));
  }
  breakShield(e) {
    e.m.guard = 0;
    e.m.guardMs = 0;
  }
  // --- zones --------------------------------------------------------------------------------
  addZone(spec, at, owner) {
    const z = {
      id: "z" + this.zoneSeq++,
      kind: spec.kind,
      x: at.x,
      y: at.y,
      radius: spec.radius,
      ms: spec.ms,
      dps: spec.dps,
      atk: owner.m.def.atk,
      owner: owner.id,
      machine: !!owner.m.def.traits.machine,
      fx: spec.fx ?? [],
      fxMs: 0
    };
    this.zones.push(z);
    this.host.emit({
      type: "zone",
      x: z.x,
      y: z.y,
      radius: z.radius,
      ms: z.ms,
      kind: z.kind,
      ability: z.id
    });
    return z;
  }
  burnWebs(e) {
    const ids = new Set(e.m.webs);
    this.zones = this.zones.filter((z) => !ids.has(z.id));
    e.m.webs = [];
  }
  layWebs(e) {
    const w = e.m.def.traits.webs;
    for (let i = 0; i < w.max; i++) {
      const a = this.host.random() * Math.PI * 2;
      const r = 90 + this.host.random() * (w.radius - 90);
      const at = this.host.nav.safe({
        x: e.home.x + Math.cos(a) * r,
        y: e.home.y + Math.sin(a) * r
      });
      e.m.webs.push(this.addZone(w.zone, at, e).id);
    }
  }
  tickZones(dt) {
    const p = this.host.player;
    for (const z of this.zones) {
      z.ms -= dt;
      z.fxMs -= dt;
      if (p.dead || distance(z, p) > z.radius) continue;
      const owner = this.host.enemies.find((x) => x.id === z.owner);
      if (!owner) continue;
      if (z.dps > 0) this.host.hurtPlayer(z.atk * z.dps * dt / 1e3, owner, "dot", true);
      if (z.fx.length && z.fxMs <= 0) {
        z.fxMs = 400;
        for (const fx of z.fx) this.host.applyPlayerFx(fx, owner);
      }
    }
    this.zones = this.zones.filter((z) => z.ms > 0);
  }
  // --- the main loop ------------------------------------------------------------------------
  tick(dt) {
    this.tickZones(dt);
    for (const [pid, s] of [...this.splits]) {
      s.ms -= dt;
      if (s.ms > 0) continue;
      this.splits.delete(pid);
      const a = this.host.enemies.find((x) => x.id === pid);
      const b = this.host.enemies.find((x) => x.id === s.cloneId);
      if (a && b && a.mode !== "dead" && b.mode !== "dead") {
        a.maxHp = s.origMax;
        a.hp = Math.min(s.origMax, a.hp + b.hp);
        a.m.split = true;
        this.host.enemies.splice(this.host.enemies.indexOf(b), 1);
        this.host.say(a.m.def.name + " \u0142\u0105czy si\u0119 z powrotem.");
      }
    }
    for (const e of [...this.host.enemies]) this.step(e, dt);
    this.host.enemies.splice(
      0,
      this.host.enemies.length,
      ...this.host.enemies.filter(
        (e) => !(e.mode === "dead" && e.m.def.respawn <= 0 && e.timer <= -1e3)
      )
    );
  }
  decay(e, dt) {
    const m = e.m;
    e.attackIn = Math.max(0, e.attackIn - dt);
    m.sinceHit += dt;
    for (const k of Object.keys(m.cooldowns))
      m.cooldowns[k] = Math.max(0, (m.cooldowns[k] ?? 0) - dt);
    if (m.guardMs > 0 && (m.guardMs -= dt) <= 0) m.guard = 0;
    if (m.reduceMs > 0 && (m.reduceMs -= dt) <= 0) m.reduce = 0;
    if (m.buffMs > 0 && (m.buffMs -= dt) <= 0) m.buff = 0;
    if (m.regenMs > 0) {
      m.regenMs -= dt;
      e.hp = Math.min(e.maxHp, e.hp + e.maxHp * m.regen * dt / 1e3);
    }
    if (m.curlMs > 0) m.curlMs -= dt;
    if (m.exposedMs > 0) m.exposedMs -= dt;
    if (m.heatMs > 0) m.heatMs -= dt;
    if (m.stunMs > 0) m.stunMs -= dt;
    const f = e.fx;
    f.stunMs = Math.max(0, f.stunMs - dt);
    f.slow.ms = Math.max(0, f.slow.ms - dt);
    f.weaken.ms = Math.max(0, f.weaken.ms - dt);
    if (f.seal && (f.seal.ms -= dt) <= 0) f.seal = null;
    if (f.mark && (f.mark.ms -= dt) <= 0) f.mark = null;
    if (f.dots.length) {
      let sum = 0;
      for (const d of f.dots) {
        sum += d.dps * Math.min(dt, d.ms) / 1e3;
        d.ms -= dt;
      }
      f.dots = f.dots.filter((d) => d.ms > 0);
      if (sum > 0 && e.mode !== "dead") this.damage(e, sum, { tags: ["fire"], indirect: true });
    }
  }
  step(e, dt) {
    const m = e.m;
    const def = m.def;
    const host = this.host;
    const p = host.player;
    this.decay(e, dt);
    if (e.mode === "dead") {
      e.timer -= dt;
      if (def.respawn > 0 && e.timer <= 0 && distance(p, e.home) > 160) this.reset(e);
      return;
    }
    if (m.stunMs > 0 || e.fx.stunMs > 0) return;
    if (m.curlMs > 0) return;
    if (m.phase === "recover") {
      m.phaseMs -= dt;
      if (m.phaseMs <= 0) {
        m.invulnerable = false;
        m.phase = "engage";
      }
      return;
    }
    const d = distance(e, p);
    if (m.phase === "under") {
      m.phaseMs -= dt;
      if (m.phaseMs <= 0) {
        m.invulnerable = false;
        m.phase = "hidden";
        m.hidden = true;
      }
      return;
    }
    if (m.phase === "hidden") return this.stepHidden(e, dt, d);
    if (m.phase === "retreat") return this.stepRetreat(e, dt, d);
    if (m.phase === "return") return this.stepReturn(e, dt);
    if (m.phase === "idle") {
      const radius = def.agro * (def.traits.night && !host.isNight() ? def.traits.night.day : 1);
      const calm = def.traits.provoked && !m.provoked;
      if (!calm && !p.dead && !host.safe && d <= radius && host.nav.visible(e, p)) this.engage(e);
      else return this.stepIdle(e, dt);
    }
    const reachBonus = Math.max(0, host.playerRange - 100);
    if (p.dead || host.safe || distance(e, e.home) > def.traits.leash + reachBonus + 10) {
      if (def.traits.still && !p.dead && !host.safe) {
      } else return this.beginReturn(e);
    }
    if (d > Math.max(def.agro * 2 + 100, host.playerRange + 180) && !def.traits.still)
      return this.beginReturn(e);
    if (def.traits.provoked && m.sinceHit > (def.traits.giveUp ?? 6e3) && !m.cast)
      return this.beginReturn(e);
    this.stepEngaged(e, dt, d);
  }
  reset(e) {
    const def = e.m.def;
    Object.assign(e, e.home);
    e.hp = e.maxHp = def.hp;
    e.m = newState(def, this.host.nowMs);
    e.fx = newFx();
    e.mode = "patrol";
    e.attackIn = 1e3;
    e.timer = 1e3;
    this.host.emit({ type: "respawn", x: e.x, y: e.y, target: e.id });
    if (def.traits.webs) this.layWebs(e);
  }
  // --- idle, return, hidden, retreat -----------------------------------------------------------
  stepIdle(e, dt) {
    const m = e.m;
    const t = m.def.traits;
    e.mode = "patrol";
    if (t.still) return;
    if (t.route) {
      const [ox, oy] = t.route[m.routeIndex % t.route.length];
      const goal = this.host.nav.safe({ x: e.home.x + ox, y: e.home.y + oy });
      this.moveTo(e, goal, BASE_SPEED * 0.4 * dt);
      if (distance(e, goal) < 12) m.routeIndex++;
      return;
    }
    e.timer -= dt;
    if (e.timer <= 0) {
      e.timer = 2800;
      const phase = (this.seq++ + e.id.length) * 2.4;
      const r = t.wander ?? 65;
      e.patrol = this.host.nav.safe({
        x: e.home.x + Math.cos(phase) * r,
        y: e.home.y + Math.sin(phase) * r
      });
    }
    this.moveTo(e, e.patrol, dt * 0.035);
  }
  beginReturn(e) {
    e.m.phase = "return";
    e.m.cast = void 0;
    e.m.charge = void 0;
    e.m.volley = void 0;
    e.mode = "return";
    this.paths.delete(e.id);
  }
  stepReturn(e, dt) {
    this.moveTo(e, e.home, dt * 0.14);
    if (distance(e, e.home) < 8) {
      e.m.phase = e.m.def.traits.ambush ? "hidden" : "idle";
      e.m.hidden = !!e.m.def.traits.ambush;
      e.m.provoked = false;
      e.m.engaged = false;
      e.mode = "patrol";
      if (!e.m.def.traits.noRegen) e.hp = e.maxHp;
      e.timer = 1e3;
    }
  }
  stepHidden(e, dt, d) {
    const m = e.m;
    const t = m.def.traits;
    const p = this.host.player;
    if (m.cast) {
      m.cast.ms -= dt;
      if (m.cast.ms <= 0) this.resolveCast(e);
      return;
    }
    if (m.phaseMs > 0) {
      m.phaseMs -= dt;
      return;
    }
    if (p.dead) return;
    if (t.ambush && d <= t.ambush.reveal && this.host.nav.visible(e, p)) {
      m.hidden = false;
      m.phase = "engage";
      m.engaged = true;
      e.mode = "chase";
      m.nextAttack = 0;
      m.cooldowns = {};
      return;
    }
    if (t.burrow && d <= m.def.agro) {
      const skill = m.def.skills[0];
      const away = unit(p, e);
      const at = skill?.mode === "burst" ? { x: p.x, y: p.y } : this.host.nav.safe({ x: p.x + away.x * 50, y: p.y + away.y * 50 });
      const telegraph = skill?.telegraph ?? 600;
      m.cast = {
        skill: skill ?? { id: "surface", name: "", mode: "burst", cd: 0, range: 0 },
        ms: telegraph,
        at,
        opener: false
      };
      m.castDamage = 0;
      this.host.emit({
        type: "telegraph",
        x: at.x,
        y: at.y,
        radius: skill?.radius ?? 60,
        ms: telegraph,
        ability: "surface"
      });
    }
  }
  retreat(e, ms, hide = false, regen = 0) {
    const m = e.m;
    m.phase = "retreat";
    m.phaseMs = ms;
    m.cast = void 0;
    m.charge = void 0;
    m.volley = void 0;
    if (hide) {
      m.hidden = true;
      m.invulnerable = true;
      m.regen = regen;
      m.regenMs = ms;
    }
  }
  stepRetreat(e, dt, d) {
    const m = e.m;
    const t = m.def.traits;
    m.phaseMs -= dt;
    const p = this.host.player;
    if (!m.hidden && !t.still) {
      const u = unit(p, e);
      const goal = { x: e.x + u.x * 160, y: e.y + u.y * 160 };
      if (distance(goal, e.home) <= t.leash * 1.3) this.moveTo(e, goal, this.speed(e) * dt * 1.1);
      else this.moveTo(e, e.home, this.speed(e) * dt);
    }
    if (m.phaseMs > 0) return;
    m.invulnerable = false;
    m.hidden = false;
    m.regenMs = 0;
    if (t.ambush) {
      m.phase = "hidden";
      m.hidden = true;
      m.phaseMs = t.ambush.hide;
      m.nextAttack = 0;
    } else m.phase = d > 0 ? "engage" : "engage";
  }
  // --- engaged: choosing and executing actions --------------------------------------------------
  speed(e) {
    const m = e.m;
    const t = m.def.traits;
    let s = BASE_SPEED * m.def.speed;
    if (e.fx.slow.ms > 0) s *= 1 - e.fx.slow.pct;
    if (t.rage && e.hp / e.maxHp < t.rage.below) s *= 1 + t.rage.speed * 0.5;
    if (t.slowBelow && e.hp / e.maxHp < t.slowBelow.hp) s *= t.slowBelow.mult;
    if (t.webSlow && !m.webs.some((id) => {
      const z = this.zones.find((x) => x.id === id);
      return z && distance(z, e) < z.radius + 10;
    }))
      s *= t.webSlow;
    return s;
  }
  clampWorld(p) {
    const w = this.host.world;
    return { x: clamp(p.x, 20, w.width - 20), y: clamp(p.y, 20, w.height - 20) };
  }
  moveTo(e, goal, amount) {
    const t = e.m.def.traits;
    if (e.m.hidden) return;
    const before = { x: e.x, y: e.y };
    if (t.fly || t.ghost) {
      const d = distance(e, goal);
      if (d < 1e-6) return;
      const k = Math.min(1, amount / d);
      Object.assign(
        e,
        this.clampWorld({ x: e.x + (goal.x - e.x) * k, y: e.y + (goal.y - e.y) * k })
      );
    } else {
      let route = this.paths.get(e.id);
      if (!route || distance(route.goal, goal) > 36 || route.remaining <= 0) {
        route = {
          goal: { x: goal.x, y: goal.y },
          points: this.host.nav.path(e, goal),
          remaining: 700
        };
        this.paths.set(e.id, route);
      }
      route.remaining -= amount / Math.max(1e-3, BASE_SPEED);
      if (!route.points.length) return;
      const next = route.points[0];
      Object.assign(e, this.host.nav.step(e, next, amount));
      if (distance(e, next) < 5) route.points.shift();
    }
    const moved = distance(before, e);
    if (moved > 0.01) {
      e.m.facing = unit(before, e);
      if (t.trail) {
        e.m.trailMs -= moved / BASE_SPEED;
        if (e.m.trailMs <= 0) {
          e.m.trailMs = 400;
          this.addZone(t.trail, e, e);
        }
      }
    }
  }
  face(e, to) {
    e.m.facing = unit(e, to);
  }
  damageMult(e) {
    const m = e.m;
    const t = m.def.traits;
    let k = 1;
    if (m.buffMs > 0) k += m.buff;
    if (t.rage) {
      const frac = e.hp / e.maxHp;
      k += t.rage.dmg * clamp((1 - frac) / 0.7, 0, 1);
    }
    if (m.nextAttack) {
      k += m.nextAttack;
      m.nextAttack = 0;
    }
    return k;
  }
  /** Hits the player. Returns false when the player evaded (invulnerable), so effects are skipped. */
  hitPlayer(e, mult, kind, fx, extra = 1) {
    const raw = e.m.def.atk * mult * this.damageMult(e) * extra;
    this.host.emit({
      type: "attack",
      x: e.x,
      y: e.y,
      source: e.id,
      target: "player",
      to: { x: this.host.player.x, y: this.host.player.y },
      kind
    });
    const r = this.host.hurtPlayer(raw, e, kind);
    if (!r.evaded) for (const f of fx ?? []) this.host.applyPlayerFx(f, e);
    return !r.evaded;
  }
  ready(e, s) {
    const m = e.m;
    if (m.cooldowns[s.id] > 0) return false;
    if (s.once && m.used.has(s.id)) return false;
    if (s.below !== void 0 && e.hp / e.maxHp >= s.below) return false;
    if (s.opener && !(m.attackCount === 0)) return false;
    if (m.tailBroken && s.id === "zadlo") return false;
    return true;
  }
  allies(e, range) {
    return this.host.enemies.filter(
      (x) => x !== e && x.mode !== "dead" && !x.m.hidden && distance(x, e) <= range
    );
  }
  stepEngaged(e, dt, d) {
    const m = e.m;
    const def = m.def;
    const t = def.traits;
    const p = this.host.player;
    e.mode = "chase";
    if (t.burrow) {
      m.phaseMs -= dt;
      if (m.phaseMs <= 0 && !m.cast && !m.charge) {
        m.phase = "under";
        m.phaseMs = t.burrow.under;
        m.hidden = true;
        m.invulnerable = true;
        this.host.emit({ type: "status", x: e.x, y: e.y, target: e.id, text: "Zakopuje si\u0119" });
        return;
      }
    }
    if (m.cast) {
      m.cast.ms -= dt;
      if (!t.still) this.face(e, p);
      if (m.cast.ms <= 0) this.resolveCast(e);
      return;
    }
    if (m.charge) return this.runCharge(e, dt);
    if (m.volley) return this.runVolley(e, dt);
    if (t.turret) this.aimTurret(e, dt);
    else this.face(e, p);
    if (t.retreat && e.hp / e.maxHp < t.retreat.below && !m.used.has("retreat")) {
      m.used.add("retreat");
      if (t.retreat.hide) {
        this.retreat(e, t.retreat.ms, true, t.retreat.regen ?? 0);
        this.host.emit({ type: "status", x: e.x, y: e.y, target: e.id, text: "Ukrywa si\u0119" });
      } else this.retreat(e, t.retreat.ms);
      return;
    }
    if (t.dive && m.attacksMade >= t.dive.attacks) {
      m.attacksMade = 0;
      this.retreat(e, t.dive.away);
      return;
    }
    if (t.turret && m.heatMs > 0) return;
    const action = this.pickSkill(e, d);
    if (action) return this.useSkill(e, action, d);
    const medicBusy = t.medic !== void 0 && this.allies(e, t.medic).some((a) => a.hp < a.maxHp * 0.95);
    const opportunistic = t.opportunist !== void 0 && p.hp >= this.host.playerMaxHp * t.opportunist;
    if (def.basic !== "none" && def.range > 0 && !medicBusy && !opportunistic) {
      const inReach = d <= def.range && (def.basic === "melee" ? this.host.nav.visible(e, p) || t.ghost || t.fly : this.host.nav.visible(e, p) || t.fly);
      if (inReach && e.attackIn <= 0) return this.basicAttack(e);
    }
    this.positioning(e, dt, d, medicBusy || opportunistic);
  }
  aimTurret(e, dt) {
    const m = e.m;
    const p = this.host.player;
    const want = Math.atan2(p.y - e.y, p.x - e.x);
    let diff = want - m.aim;
    diff = Math.atan2(Math.sin(diff), Math.cos(diff));
    const maxTurn = m.def.traits.turret.turn * Math.PI / 180 * (dt / 1e3);
    m.aim += clamp(diff, -maxTurn, maxTurn);
    m.facing = { x: Math.cos(m.aim), y: Math.sin(m.aim) };
  }
  aimed(e) {
    const p = this.host.player;
    const want = Math.atan2(p.y - e.y, p.x - e.x);
    const diff = Math.atan2(Math.sin(want - e.m.aim), Math.cos(want - e.m.aim));
    return Math.abs(diff) < 12 * Math.PI / 180;
  }
  positioning(e, dt, d, circle) {
    const m = e.m;
    const t = m.def.traits;
    const p = this.host.player;
    if (t.still || m.heatMs > 0) return;
    const spd = this.speed(e) * dt;
    const reach = Math.max(30, m.def.range * 0.8);
    if (circle) {
      const around = Math.atan2(e.y - p.y, e.x - p.x) + 0.5 * m.orbit;
      const ring = Math.max(120, t.keep ?? 150);
      this.moveTo(e, { x: p.x + Math.cos(around) * ring, y: p.y + Math.sin(around) * ring }, spd);
      return;
    }
    if (t.keep) {
      if (d < t.keep - 30) {
        const u = unit(p, e);
        this.moveTo(e, { x: e.x + u.x * 100, y: e.y + u.y * 100 }, spd);
      } else if (d > t.keep + 25) this.moveTo(e, p, spd);
      return;
    }
    if (t.flank && d > m.def.range * 1.5) {
      const around = Math.atan2(e.y - p.y, e.x - p.x) + 0.45 * m.orbit;
      this.moveTo(
        e,
        { x: p.x + Math.cos(around) * d * 0.9, y: p.y + Math.sin(around) * d * 0.9 },
        spd
      );
      return;
    }
    if (d > reach) this.moveTo(e, p, spd);
  }
  pickSkill(e, d) {
    const m = e.m;
    const t = m.def.traits;
    const p = this.host.player;
    for (const s of m.def.skills) {
      if (!this.ready(e, s)) continue;
      if (s.mode === "self") {
        if (s.call !== void 0) return s;
        if (s.summon) return s;
        if (s.heal) {
          if (this.allies(e, s.range).some((a) => a.hp < a.maxHp * 0.95)) return s;
          continue;
        }
        if (s.guard) {
          if (m.guard <= 0) return s;
          continue;
        }
        if (s.reduce) {
          if (d <= 260) return s;
          continue;
        }
        if (s.buff) {
          if (this.allies(e, s.range).length) return s;
          continue;
        }
        if (s.nextAttack) {
          if (!m.nextAttack && d <= m.def.range + 40) return s;
          continue;
        }
        continue;
      }
      if (t.opportunist !== void 0 && p.hp >= this.host.playerMaxHp * t.opportunist) continue;
      if (s.aimed && !this.aimed(e)) continue;
      if (d > s.range) continue;
      if (!(t.fly || t.ghost) && !this.host.nav.visible(e, p) && s.mode !== "burst") continue;
      if (t.medic !== void 0 && this.allies(e, t.medic).some((a) => a.hp < a.maxHp * 0.95))
        continue;
      return s;
    }
    return void 0;
  }
  basicAttack(e) {
    const m = e.m;
    const def = m.def;
    const t = def.traits;
    let cd = def.attackCd;
    if (t.rage && e.hp / e.maxHp < t.rage.below) cd *= 1 - t.rage.speed;
    e.attackIn = cd;
    this.face(e, this.host.player);
    let extra = 1;
    if (t.ramp) {
      extra += t.ramp * m.scanStacks;
      m.scanStacks = Math.min(4, m.scanStacks + 1);
    }
    const kind = def.basic === "ranged" ? "projectile" : "melee";
    this.hitPlayer(e, 1, kind, def.basicFx, extra);
    m.attackCount++;
    m.attacksMade++;
  }
  useSkill(e, s, d) {
    const m = e.m;
    const t = m.def.traits;
    let cd = s.cd;
    if (t.rage && e.hp / e.maxHp < t.rage.below) cd *= 1 - t.rage.speed;
    m.cooldowns[s.id] = cd;
    if (s.once) m.used.add(s.id);
    const p = this.host.player;
    this.face(e, p);
    if (s.mode === "self") return this.useSelf(e, s);
    const opener = !!s.opener && m.attackCount === 0;
    const at = s.centred ? { x: e.x, y: e.y } : { x: p.x, y: p.y };
    if (s.mode === "leap") {
      m.charge = { to: { x: p.x, y: p.y }, skill: s, hit: false };
      return;
    }
    if (s.telegraph && s.telegraph > 0) {
      m.cast = { skill: s, ms: s.telegraph, at, opener };
      m.castDamage = 0;
      const radius = s.mode === "burst" ? s.radius ?? 100 : Math.max(40, s.range * 0.6);
      this.host.emit({
        type: "telegraph",
        x: s.mode === "charge" ? e.x : at.x,
        y: s.mode === "charge" ? e.y : at.y,
        radius,
        ms: s.telegraph,
        ability: s.id,
        ...s.mode === "charge" ? { to: { x: p.x, y: p.y } } : {}
      });
      void d;
      return;
    }
    m.cast = { skill: s, ms: 0, at, opener };
    this.resolveCast(e);
  }
  useSelf(e, s) {
    const m = e.m;
    this.host.emit({ type: "status", x: e.x, y: e.y, target: e.id, text: s.name, ability: s.id });
    if (s.call !== void 0) {
      let n = s.call;
      const near = this.host.enemies.filter((x) => x !== e && x.mode !== "dead" && !x.m.engaged && distance(x, e) <= 600).sort((a, b) => distance(a, e) - distance(b, e));
      for (const x of near) {
        if (n-- <= 0) break;
        x.m.provoked = true;
        x.m.hidden = false;
        this.engage(x);
      }
    }
    if (s.summon) {
      for (let i = 0; i < s.summon.count; i++) {
        const a = Math.PI * 2 * i / s.summon.count + 0.5;
        const minion = this.spawn(s.summon.kind, {
          x: e.x + Math.cos(a) * 40,
          y: e.y + Math.sin(a) * 40
        });
        minion.m.parent = e.id;
        this.engage(minion);
      }
    }
    if (s.heal)
      for (const a of this.allies(e, s.range)) {
        a.m.regen = s.heal.pct;
        a.m.regenMs = s.heal.ms;
      }
    if (s.guard) {
      m.guard = e.maxHp * s.guard.pct;
      m.guardMs = s.guard.ms;
    }
    if (s.reduce) {
      m.reduce = s.reduce.pct;
      m.reduceMs = s.reduce.ms;
    }
    if (s.buff) {
      const targets = s.range > 0 ? this.allies(e, s.range) : [e];
      for (const a of targets) {
        a.m.buff = s.buff.pct;
        a.m.buffMs = s.buff.ms;
      }
    }
    if (s.nextAttack) m.nextAttack = s.nextAttack;
  }
  resolveCast(e) {
    const m = e.m;
    const c = m.cast;
    if (!c) return;
    m.cast = void 0;
    const s = c.skill;
    const p = this.host.player;
    if (m.phase === "hidden") {
      Object.assign(e, c.at);
      m.hidden = false;
      m.phase = "engage";
      m.engaged = true;
      m.phaseMs = m.def.traits.burrow?.up ?? 0;
      e.mode = "chase";
      m.cooldowns = { [s.id]: s.cd };
    }
    switch (s.mode) {
      case "melee":
      case "ranged": {
        const reach = s.mode === "melee" ? s.range + 24 : s.range + 40;
        const total = s.volley ?? 1;
        const first = distance(e, p) <= reach && !p.dead;
        if (first) this.hitSkill(e, s, c.opener);
        else if (s.mode === "melee") {
        }
        if (total > 1)
          m.volley = {
            skill: s,
            left: total - 1,
            next: s.mode === "melee" ? 260 : 220,
            opener: false
          };
        this.finishAttack(e);
        break;
      }
      case "burst": {
        const radius = s.radius ?? 100;
        this.host.emit({
          type: "telegraph",
          x: c.at.x,
          y: c.at.y,
          radius,
          ms: 0,
          ability: s.id + ":hit"
        });
        if (!p.dead && distance(c.at, p) <= radius + 12) {
          if ((s.dmg ?? 0) > 0) {
            const evaded = !this.hitPlayer(e, s.dmg, "area", s.fx);
            void evaded;
          } else for (const f of s.fx ?? []) this.host.applyPlayerFx(f, e);
        }
        if (s.zone) this.addZone(s.zone, c.at, e);
        this.finishAttack(e);
        break;
      }
      case "charge": {
        const u = unit(e, p);
        const run = Math.max(distance(e, p) + 120, s.range);
        m.charge = {
          to: this.clampWorld({ x: e.x + u.x * run, y: e.y + u.y * run }),
          skill: s,
          hit: false
        };
        break;
      }
      default:
        break;
    }
  }
  hitSkill(e, s, opener) {
    const kind = s.mode === "ranged" ? "projectile" : "melee";
    const connected = (s.dmg ?? 0) > 0 ? this.hitPlayer(e, s.dmg, kind, s.fx, opener && s.opener ? s.opener : 1) : (this.applyOnly(e, s), true);
    void connected;
  }
  applyOnly(e, s) {
    this.host.emit({
      type: "attack",
      x: e.x,
      y: e.y,
      source: e.id,
      target: "player",
      to: { x: this.host.player.x, y: this.host.player.y },
      kind: "projectile"
    });
    for (const f of s.fx ?? []) this.host.applyPlayerFx(f, e);
  }
  finishAttack(e) {
    const m = e.m;
    m.attackCount++;
    m.attacksMade++;
    const t = m.def.traits;
    if (t.ambush && m.attackCount >= 1 && m.phase === "engage") {
      m.attackCount = 0;
      this.retreat(e, 1200);
    }
    if (t.turret) {
      m.shots += m.def.skills[0]?.volley ?? 1;
      if (m.shots >= t.turret.shots) {
        m.shots = 0;
        m.heatMs = t.turret.off;
        this.host.say(m.def.name + " przegrzewa si\u0119!");
      }
    }
  }
  runVolley(e, dt) {
    const m = e.m;
    const v = m.volley;
    v.next -= dt;
    this.face(e, this.host.player);
    if (v.next > 0) return;
    const s = v.skill;
    v.left--;
    v.next = s.mode === "melee" ? 260 : 220;
    const p = this.host.player;
    if (!p.dead && distance(e, p) <= s.range + 40) this.hitSkill(e, s, false);
    if (m.def.traits.turret) {
      m.shots++;
      if (m.shots >= m.def.traits.turret.shots) {
        m.shots = 0;
        m.heatMs = m.def.traits.turret.off;
        v.left = 0;
        this.host.say(m.def.name + " przegrzewa si\u0119!");
      }
    }
    if (v.left <= 0) m.volley = void 0;
  }
  runCharge(e, dt) {
    const m = e.m;
    const c = m.charge;
    const p = this.host.player;
    const leap = c.skill.mode === "leap";
    const speed = (leap ? 0.55 : 0.5) * dt;
    const before = { x: e.x, y: e.y };
    const goal = leap ? { x: p.x, y: p.y } : c.to;
    const left = distance(e, goal);
    const step = Math.min(speed, left);
    const u = unit(e, goal);
    let to = { x: e.x + u.x * step, y: e.y + u.y * step };
    if (!m.def.traits.fly && !m.def.traits.ghost) {
      const moved = this.host.nav.step(e, to, step);
      to = moved;
    } else to = this.clampWorld(to);
    Object.assign(e, to);
    m.facing = unit(before, e);
    const blocked = distance(before, e) < step * 0.4 && step > 0.5;
    const reach = leap ? 70 : 52;
    if (!c.hit && !p.dead && distance(e, p) <= reach) {
      c.hit = true;
      this.hitPlayer(e, c.skill.dmg ?? 1, "melee", c.skill.fx);
      m.charge = void 0;
      m.attackCount++;
      m.attacksMade++;
      if (!leap) m.exposedMs = 0;
      return;
    }
    if (left <= step + 1 || blocked) {
      m.charge = void 0;
      m.attackCount++;
      m.attacksMade++;
      if (!leap) {
        const s = c.skill;
        if (s.missStun) m.stunMs = s.missStun;
        if (s.exposed) {
          m.exposed = s.exposed;
          m.exposedMs = Math.max(s.missStun ?? 0, 2e3);
        }
        this.host.emit({ type: "status", x: e.x, y: e.y, target: e.id, text: "Chybi\u0142!" });
      }
    }
  }
  /** Loot rolls for a dead monster (the session creates the drop). Deterministic through `random()`. */
  rollLoot(e) {
    const def = e.m.def;
    const out = [];
    for (const entry of def.loot) {
      if (this.host.random() > entry.chance) continue;
      out.push({ item: entry.name === "tusk" ? "tusk" : slug(entry.name), quantity: 1, gold: 0 });
    }
    const [lo, hi] = def.gold;
    const gold = hi > 0 ? lo + Math.floor(this.host.random() * (hi - lo + 1)) : 0;
    if (gold > 0) {
      if (out.length) out[0].gold = gold;
      else out.push({ item: "", quantity: 0, gold });
    }
    return out;
  }
};

// src/game/monsters/fx.ts
var PlayerFx = class {
  slow = { pct: 0, ms: 0 };
  rootMs = 0;
  stunMs = 0;
  fearMs = 0;
  fearFrom;
  silenceMs = 0;
  blind = { pct: 0, ms: 0 };
  fog = { pct: 0, ms: 0 };
  jamMs = 0;
  mark = { pct: 0, ms: 0, machine: false };
  armor = { pct: 0, ms: 0, stacks: 0 };
  weaken = { pct: 0, ms: 0 };
  dots = [];
  missAcc = 0;
  get speedMul() {
    return this.slow.ms > 0 ? 1 - this.slow.pct : 1;
  }
  get cannotMove() {
    return this.rootMs > 0 || this.stunMs > 0;
  }
  get cannotAct() {
    return this.stunMs > 0 || this.fearMs > 0;
  }
  get silenced() {
    return this.silenceMs > 0;
  }
  get fogPct() {
    return this.fog.ms > 0 ? this.fog.pct : 0;
  }
  get jammed() {
    return this.jamMs > 0;
  }
  markPct(machine) {
    if (this.mark.ms <= 0) return 0;
    return this.mark.machine && !machine ? 0 : this.mark.pct;
  }
  get armorPct() {
    return this.armor.ms > 0 ? this.armor.pct * this.armor.stacks : 0;
  }
  get weakenPct() {
    return this.weaken.ms > 0 ? this.weaken.pct : 0;
  }
  get active() {
    const list = [];
    if (this.slow.ms > 0) list.push({ id: "slow", ms: this.slow.ms });
    if (this.rootMs > 0) list.push({ id: "root", ms: this.rootMs });
    if (this.stunMs > 0) list.push({ id: "stun", ms: this.stunMs });
    if (this.fearMs > 0) list.push({ id: "fear", ms: this.fearMs });
    if (this.silenceMs > 0) list.push({ id: "silence", ms: this.silenceMs });
    if (this.blind.ms > 0) list.push({ id: "blind", ms: this.blind.ms });
    if (this.fog.ms > 0) list.push({ id: "fog", ms: this.fog.ms });
    if (this.jamMs > 0) list.push({ id: "jam", ms: this.jamMs });
    if (this.mark.ms > 0) list.push({ id: "mark", ms: this.mark.ms });
    if (this.armor.ms > 0) list.push({ id: "armor", ms: this.armor.ms, stacks: this.armor.stacks });
    if (this.weaken.ms > 0) list.push({ id: "weaken", ms: this.weaken.ms });
    for (const d of this.dots) list.push({ id: d.id, ms: d.ms, stacks: d.stack });
    return list;
  }
  clear() {
    this.slow = { pct: 0, ms: 0 };
    this.rootMs = this.stunMs = this.fearMs = this.silenceMs = this.jamMs = 0;
    this.blind = { pct: 0, ms: 0 };
    this.fog = { pct: 0, ms: 0 };
    this.mark = { pct: 0, ms: 0, machine: false };
    this.armor = { pct: 0, ms: 0, stacks: 0 };
    this.weaken = { pct: 0, ms: 0 };
    this.dots = [];
    this.missAcc = 0;
    this.fearFrom = void 0;
  }
  /**
   * Applies one effect. `cc` scales control durations (Korzenie Odporności, Czysty Umysł); 0 means immune.
   * `stunImmune` ignores stuns only. `atk` is the attacker's ATK for damage over time.
   */
  apply(fx, opts) {
    const t = (ms) => Math.round(ms * opts.cc);
    switch (fx.k) {
      case "slow":
        if (opts.cc > 0)
          this.slow = {
            pct: Math.max(this.slow.ms > 0 ? this.slow.pct : 0, fx.pct),
            ms: Math.max(this.slow.ms, t(fx.ms))
          };
        break;
      case "root":
        this.rootMs = Math.max(this.rootMs, t(fx.ms));
        break;
      case "stun":
        if (!opts.stunImmune) this.stunMs = Math.max(this.stunMs, t(fx.ms));
        break;
      case "fear":
        if (opts.cc > 0) {
          this.fearMs = Math.max(this.fearMs, t(fx.ms));
          if (opts.from) this.fearFrom = { ...opts.from };
        }
        break;
      case "silence":
        this.silenceMs = Math.max(this.silenceMs, t(fx.ms));
        break;
      case "dot": {
        const dps = fx.atkPct * opts.atk;
        const same = this.dots.filter((d) => d.id === fx.id);
        const max = fx.stacks ?? 1;
        if (same.length >= max) {
          const weakest = same.reduce((a, b) => a.ms < b.ms ? a : b);
          weakest.ms = fx.ms;
          weakest.dps = Math.max(weakest.dps, dps);
        } else this.dots.push({ id: fx.id, dps, ms: fx.ms, stack: same.length + 1 });
        break;
      }
      case "blind":
        this.blind = { pct: fx.pct, ms: Math.max(this.blind.ms, t(fx.ms)) };
        break;
      case "fog":
        this.fog = { pct: fx.pct, ms: Math.max(this.fog.ms, fx.ms) };
        break;
      case "jam":
        this.jamMs = Math.max(this.jamMs, fx.ms);
        break;
      case "weaken":
        this.weaken = { pct: fx.pct, ms: Math.max(this.weaken.ms, fx.ms) };
        break;
      case "armorDown": {
        const stacks = Math.min(fx.stacks ?? 1, this.armor.ms > 0 ? this.armor.stacks + 1 : 1);
        this.armor = { pct: fx.pct, ms: fx.ms, stacks };
        break;
      }
      case "mark":
        this.mark = { pct: fx.pct, ms: fx.ms, machine: fx.from === "machine" };
        break;
      case "breakShield":
      case "pull":
        break;
    }
    void opts.machine;
  }
  /** Returns damage over time dealt during `dt`. */
  tick(dt) {
    let dot = 0;
    for (const d of this.dots) {
      dot += d.dps * Math.min(dt, d.ms) / 1e3;
      d.ms -= dt;
    }
    this.dots = this.dots.filter((d) => d.ms > 0);
    this.dots.forEach((d) => {
      d.stack = this.dots.filter((x) => x.id === d.id).indexOf(d) + 1;
    });
    for (const key of ["slow", "blind", "fog", "mark", "armor", "weaken"])
      this[key].ms = Math.max(0, this[key].ms - dt);
    this.rootMs = Math.max(0, this.rootMs - dt);
    this.stunMs = Math.max(0, this.stunMs - dt);
    this.fearMs = Math.max(0, this.fearMs - dt);
    this.silenceMs = Math.max(0, this.silenceMs - dt);
    this.jamMs = Math.max(0, this.jamMs - dt);
    return dot;
  }
  /** True when the next attack of the player misses (accumulator, no randomness). */
  rollMiss() {
    if (this.blind.ms <= 0) return false;
    this.missAcc += this.blind.pct;
    if (this.missAcc >= 1) {
      this.missAcc -= 1;
      return true;
    }
    return false;
  }
};

// src/game/session.ts
var ITEMS = {
  potion: {
    name: "Mikstura \u017Cycia",
    type: "consumable",
    icon: 4,
    attack: 0,
    defense: 0,
    price: 8,
    sell: 3
  },
  tusk: { name: "Kie\u0142 dzika", type: "material", icon: 8, attack: 0, defense: 0, price: 0, sell: 5 },
  sword: {
    name: "Ostrze stra\u017Cnika",
    type: "weapon",
    icon: 2,
    attack: 8,
    defense: 0,
    price: 40,
    sell: 18
  },
  vest: {
    name: "Kamizelka podr\xF3\u017Cnika",
    type: "armor",
    icon: 3,
    attack: 0,
    defense: 3,
    price: 25,
    sell: 10
  }
};
var ITEM_IDS = Object.keys(ITEMS);
var BAG_CAPACITY = 12;
var MATERIAL_CAPACITY = 30;
var POTION = { cooldown: 6e3, heal: 0.4 };
var QUEST_NAMES = {
  steps: "Pierwsze kroki",
  boars: "Zagro\u017Cenie w lesie",
  gear: "Pierwsze wyposa\u017Cenie"
};
var BASE_HP_REGEN = 3e-3;
var status = external_exports.enum(["locked", "active", "ready", "done"]);
var finite = (max) => external_exports.number().finite().min(0).max(max);
var itemSchema = external_exports.enum(["potion", "tusk", "sword", "vest"]);
var storedItems = external_exports.object({
  potion: finite(99).int(),
  tusk: finite(99).int(),
  sword: finite(99).int(),
  vest: finite(99).int()
});
var emptyDepot = () => ({
  items: { potion: 0, tusk: 0, sword: 0, vest: 0 },
  materials: {},
  upgrade: 0
});
var PlayerSchema = external_exports.object({
  race: external_exports.enum(RACE_IDS),
  continent: external_exports.enum(WORLD_IDS),
  startContinent: external_exports.enum(WORLD_IDS),
  level: external_exports.number().int().min(1).max(100),
  xp: finite(1e6).int(),
  hp: finite(1e5),
  ki: finite(1e5),
  gold: finite(1e6).int(),
  x: finite(8192),
  y: finite(6144),
  /** Open-world layout revision the position belongs to; older saves are shifted on load. */
  layout: external_exports.number().int().min(1).max(99).optional(),
  items: external_exports.object({
    potion: finite(99).int(),
    tusk: finite(99).int(),
    sword: finite(99).int(),
    vest: finite(99).int()
  }),
  weapon: external_exports.literal("sword").nullable(),
  armor: external_exports.literal("vest").nullable(),
  upgrade: external_exports.number().int().min(0).max(1),
  quests: external_exports.object({ steps: status, boars: status, gear: status }),
  visited: external_exports.boolean(),
  kills: external_exports.number().int().min(0).max(3),
  dead: external_exports.boolean(),
  /** Skill-tree nodes learned (the root "R" is always among them). */
  skills: external_exports.array(external_exports.string().max(4)).max(30).default(["R"]),
  /** Loot materials by id. */
  materials: external_exports.record(external_exports.string().max(60), finite(99).int()).default({}),
  /** How many times the skill tree was reset. */
  respecs: external_exports.number().int().min(0).max(1e5).default(0),
  /** Chosen at character creation; saves from before nicknames have none and show the default. */
  name: external_exports.string().refine(isValidNick, "nick").optional(),
  interior: external_exports.enum(BUILDING_IDS).nullable().default(null),
  depot: external_exports.object({
    items: storedItems,
    materials: external_exports.record(external_exports.string().max(60), finite(99).int()),
    upgrade: external_exports.number().int().min(0).max(1)
  }).default(emptyDepot)
});
var NPCS = WORLDS.verdant.npcs;
var xpNeeded = (level) => 100 + (level - 1) * 60;
var noop = () => {
};
function statsPort(p) {
  return {
    nowMs: 0,
    gear: {
      attack: p.weapon ? ITEMS[p.weapon].attack + p.upgrade * 4 : 0,
      defense: p.armor ? ITEMS[p.armor].defense : 0
    },
    inCombat: false,
    terrain: () => "open",
    player: { x: 0, y: 0, level: p.level, hp: 0, ki: 0 },
    facing: { x: 1, y: 0 },
    random: () => 0.5,
    say: noop,
    foesIn: () => [],
    target: () => void 0,
    visible: () => true,
    hurtFoe: () => 0,
    stunFoe: noop,
    slowFoe: noop,
    burnFoe: noop,
    sealFoe: noop,
    markFoe: noop,
    pushFoe: noop,
    weakenFoe: noop,
    breakFoeShield: noop,
    isSealed: () => false,
    isMarked: () => false,
    foeHpFraction: () => 1,
    dash: (to) => to,
    emit: noop,
    heal: noop,
    addKi: noop
  };
}
var stats = (p) => {
  const s = createKit(p.race, statsPort(p), p.skills).stats;
  return {
    maxHp: s.maxHp,
    maxKi: s.maxKi,
    attack: s.attack,
    defense: s.defense,
    speed: s.speed,
    crit: s.crit,
    kiRegen: s.kiRegen,
    attackInterval: s.attackInterval,
    range: s.range
  };
};
function newPlayer(race = "planetary") {
  const continent = RACES[race].world;
  const base = { race, level: 1, weapon: null, armor: null, upgrade: 0, skills: ["R"] };
  const s = stats(base);
  return {
    level: 1,
    xp: 0,
    hp: s.maxHp,
    ki: s.maxKi,
    gold: 20,
    race,
    continent,
    startContinent: continent,
    ...WORLDS[continent].spawn,
    ...WORLDS[continent].layout ? { layout: WORLDS[continent].layout } : {},
    items: { potion: 3, tusk: 0, sword: 0, vest: 0 },
    weapon: null,
    armor: null,
    upgrade: 0,
    quests: { steps: "locked", boars: "locked", gear: "locked" },
    visited: false,
    kills: 0,
    dead: false,
    skills: ["R"],
    materials: {},
    respecs: 0,
    interior: null,
    depot: emptyDepot()
  };
}
var LegacyPlayerSchema = PlayerSchema.extend({
  race: external_exports.enum(RACE_IDS).default("planetary"),
  continent: external_exports.enum(WORLD_IDS).default("verdant"),
  startContinent: external_exports.enum(WORLD_IDS).default("verdant")
});
var SaveSchema = external_exports.discriminatedUnion("version", [
  external_exports.object({ version: external_exports.literal(1), revision: external_exports.string(), player: LegacyPlayerSchema }),
  external_exports.object({ version: external_exports.literal(3), revision: external_exports.string(), player: PlayerSchema }),
  external_exports.object({ version: external_exports.literal(4), revision: external_exports.string(), player: PlayerSchema }),
  external_exports.object({ version: external_exports.literal(5), revision: external_exports.string(), player: PlayerSchema })
]);
var mulberry = (seed) => () => {
  seed = seed + 1831565813 | 0;
  let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
  t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
  return ((t ^ t >>> 14) >>> 0) / 4294967296;
};
var DAY_MS = 48e4;
var NIGHT_FROM = 3e5;
var GameSession = class {
  constructor(saves, race = "planetary", options = {}) {
    this.saves = saves;
    this.rng = options.random ?? mulberry(Date.now() & 2147483647);
    const restored = saves?.load();
    this.player = restored ?? newPlayer(race);
    this.world = options.world ?? WORLDS[this.player.continent];
    if (options.world && !restored) Object.assign(this.player, this.world.spawn);
    this.outsideNav = options.navigation ?? new Navigation(this.world.width, this.world.height, worldObstacles(this.world));
    this.nav = this.outsideNav;
    if (this.player.dead || this.player.hp <= 0) this.player.interior = null;
    if (this.player.interior && this.world.city) {
      const room = cityRoom(this.player.interior);
      this.nav = new Navigation(room.width, room.height, room.obstacles);
    }
    this.kit = createKit(this.player.race, makePort(this), this.player.skills);
    const safe = this.nav.safe(this.player.dead ? this.world.spawn : this.player);
    Object.assign(this.player, safe);
    if (this.player.dead || this.player.hp <= 0) {
      this.player.dead = false;
      this.player.hp = this.kit.stats.maxHp;
      this.player.ki = this.kit.stats.maxKi;
    }
    this.monsters = new MonsterSystem(this);
    if (!isCityStage(this.world)) {
      this.world.enemies.forEach((p, i) => this.monsters.spawn("boar", p, "boar-" + i));
      for (const sp of this.world.monsters ?? [])
        this.monsters.spawnGroup(sp.kind, { x: sp.x, y: sp.y });
    }
    const nextQuest = Object.keys(QUEST_NAMES).find(
      (id) => this.player.quests[id] !== "done"
    );
    this.notice = nextQuest ? this.questText(nextQuest) : this.world.id === "verdant" ? "Wioska ocalona! Trenuj i zdobywaj wyposa\u017Cenie." : "Region ocalony! Trenuj i odkrywaj \u015Bwiat.";
    if (saves?.warning) this.say(saves.warning);
  }
  saves;
  player;
  nav;
  outsideNav;
  world;
  get npcs() {
    return this.world.npcs.filter((n) => (n.building ?? null) === this.player.interior).map((n) => ({
      ...n,
      ...n.building ? cityRoom(n.building).npc : this.outsideNav.safe(n)
    }));
  }
  enemies = [];
  /** No combat here: inside a building, on a city-stage map, or within the city bounds. */
  get safe() {
    return inSafeCity(this.world, this.player, this.player.interior);
  }
  monsters;
  kit;
  fx = new PlayerFx();
  loot = [];
  targetId = null;
  dialogue = null;
  paused = false;
  autoAttack = false;
  notice = "Porozmawiaj z Air\u0105. Klikaj postacie lub u\u017Cyj przycisku Rozmowa.";
  noticeId = 0;
  log = [];
  events = [];
  moving = false;
  facing = { x: 0, y: 1 };
  nowMs = 0;
  route = [];
  pendingNpc = null;
  pendingLoot = null;
  pendingBuilding = null;
  pendingService = null;
  pendingOutsideNpc = null;
  pendingChest = false;
  pendingExit = false;
  afterExit = null;
  depotOpen = false;
  training = { active: false, hits: 0, damage: 0 };
  dummy = { id: "training-dummy", x: 600, y: 300, hp: 1e9, maxHp: 1e9 };
  pathIn = 0;
  saveIn = 0;
  combatIn = 0;
  respawnIn = 0;
  counter = 0;
  potionIn = 0;
  rng;
  // --- MonsterHost -------------------------------------------------------------------------------
  get playerMaxHp() {
    return this.kit.stats.maxHp;
  }
  get playerRange() {
    return this.kit.stats.range;
  }
  isNight() {
    return this.nowMs % DAY_MS >= NIGHT_FROM;
  }
  random() {
    return this.rng();
  }
  hurtPlayer(raw, from, kind, fixed = false) {
    const p = this.player;
    if (this.safe) return { dealt: 0, evaded: true };
    if (p.dead) return { dealt: 0, evaded: true };
    if (this.kit.hasBuff("invulnerable")) {
      this.emit({ type: "hit", x: p.x, y: p.y, target: "player", text: "Unik" });
      return { dealt: 0, evaded: true };
    }
    let amount = raw;
    if (from.fx.weaken.ms > 0) amount *= 1 - from.fx.weaken.pct;
    let dmg;
    if (fixed) dmg = Math.max(1, amount);
    else {
      amount *= 1 + this.fx.markPct(!!from.m.def.traits.machine);
      dmg = Math.max(1, amount - this.kit.stats.defense / 2);
    }
    const through = this.kit.absorb(
      dmg,
      kind === "melee" ? "melee" : kind === "projectile" ? "projectile" : "other",
      from
    );
    this.combatIn = 4500;
    if (through <= 0) {
      this.emit({ type: "hit", x: p.x, y: p.y, target: "player", text: "Tarcza" });
      return { dealt: 0, evaded: false };
    }
    this.damagePlayer(through);
    return { dealt: through, evaded: false };
  }
  damagePlayer(amount) {
    const p = this.player;
    if (this.safe) return;
    if (p.dead) return;
    p.hp = Math.max(0, p.hp - amount);
    this.emit({ type: "hit", x: p.x, y: p.y, target: "player", text: "-" + Math.round(amount) });
    if (p.hp > 0) return;
    p.hp = 1;
    if (this.kit.saveFromDeath()) return;
    p.hp = 0;
    p.dead = true;
    this.respawnIn = 3e3;
    this.targetId = null;
    this.autoAttack = false;
    this.route = [];
    this.fx.clear();
    this.emit({ type: "death", x: p.x, y: p.y, target: "player" });
    this.say("Zosta\u0142e\u015B pokonany. Odrodzenie za 3 sekundy.");
    this.flush();
  }
  applyPlayerFx(spec, from) {
    const s = this.kit.stats;
    if (spec.k === "breakShield") {
      if (this.kit.shieldPoints > 0) this.say(from.m.def.name + " rozbija Twoj\u0105 os\u0142on\u0119!");
      this.kit.removeShields();
      return;
    }
    if (spec.k === "pull") {
      const to = this.nav.step(this.player, from, spec.dist);
      Object.assign(this.player, to);
      this.route = [];
      return;
    }
    this.fx.apply(spec, {
      cc: s.ccMul,
      stunImmune: this.kit.hasBuff("stunImmune"),
      atk: from.m.def.atk,
      machine: !!from.m.def.traits.machine,
      from: { x: from.x, y: from.y }
    });
    if (spec.k === "stun" || spec.k === "fear" || spec.k === "root") {
      this.kit.interruptChannel("hit");
      this.route = [];
    }
    this.emit({
      type: "status",
      x: this.player.x,
      y: this.player.y,
      target: "player",
      text: statusText(spec)
    });
  }
  killed(e) {
    const def = e.m.def;
    this.kit.onKill(e);
    if (this.targetId === e.id) {
      this.targetId = null;
      this.autoAttack = false;
      this.route = [];
    }
    for (const drop of this.monsters.rollLoot(e)) {
      this.loot.push({
        id: "loot-" + ++this.counter,
        x: e.x + this.counter % 3 * 8,
        y: e.y + this.counter % 2 * 6,
        item: drop.item,
        quantity: drop.quantity,
        gold: drop.gold
      });
    }
    if (e.kind === "boar" && this.player.quests.boars === "active") {
      this.player.kills = Math.min(3, this.player.kills + 1);
      if (this.player.kills === 3) {
        this.player.quests.boars = "ready";
        this.say(
          "3/3 dzik\xF3w. Wr\xF3\u0107 do " + (this.world.id === "verdant" ? "Rena" : this.npcName("hunter")) + " po nagrod\u0119."
        );
      }
    }
    if (def.xp > 0) this.award(def.xp);
  }
  get target() {
    return this.enemies.find(
      (e) => e.id === this.targetId && e.hp > 0 && !e.m.hidden && !e.m.invulnerable
    );
  }
  say(text) {
    this.noticeId++;
    this.notice = text;
    this.log = [...this.log.slice(-19), text];
  }
  flush() {
    this.saves?.save(this.player);
  }
  emit(event) {
    this.events.push(event);
  }
  award(xp) {
    this.player.xp += xp;
    this.say("+" + xp + " XP");
    while (this.player.level < 100 && this.player.xp >= xpNeeded(this.player.level)) {
      this.player.xp -= xpNeeded(this.player.level);
      this.player.level++;
      const s = this.kit.stats;
      this.player.hp = s.maxHp;
      this.player.ki = s.maxKi;
      this.emit({ type: "level", ...this.player, text: "Poziom " + this.player.level });
      const gained = this.player.level <= 20 ? " Nowy punkt umiej\u0119tno\u015Bci." : "";
      this.say("Awans! Poziom " + this.player.level + "." + gained);
    }
    if (this.player.level === 100) this.player.xp = Math.min(this.player.xp, xpNeeded(100) - 1);
  }
  add(item, n = 1) {
    if (this.player.items[item] + n > 99 || !this.player.items[item] && ITEM_IDS.filter((id) => this.player.items[id] > 0).length >= BAG_CAPACITY) {
      this.say("Brak miejsca w plecaku lub pe\u0142ny stos (99).");
      return false;
    }
    this.player.items[item] += n;
    return true;
  }
  addMaterial(id, n) {
    const mats = this.player.materials;
    const have = mats[id] ?? 0;
    if (have + n > 99 || !have && Object.keys(mats).length >= MATERIAL_CAPACITY) {
      this.say("Brak miejsca na materia\u0142y lub pe\u0142ny stos (99).");
      return false;
    }
    mats[id] = have + n;
    return true;
  }
  nearbyNpc() {
    return this.npcs.find((n) => n.id === this.dialogue && distance(n, this.player) <= 115);
  }
  clearDestinations() {
    this.pendingNpc = null;
    this.pendingLoot = null;
    this.pendingBuilding = null;
    this.pendingService = null;
    this.pendingOutsideNpc = null;
    this.pendingChest = false;
    this.pendingExit = false;
    this.afterExit = null;
  }
  npcName(id) {
    return this.world.npcs.find((npc) => npc.id === id)?.name ?? id;
  }
  get building() {
    return this.world.city?.buildings.find((b) => b.id === this.player.interior);
  }
  get trainingTarget() {
    return this.training.active && this.player.interior === "arena" ? this.dummy : void 0;
  }
  hitTraining(raw, hit) {
    if (!this.trainingTarget || !Number.isFinite(raw) || raw <= 0) return 0;
    const damage = Math.max(1, raw);
    this.training.hits++;
    this.training.damage += damage;
    this.emit({
      type: "hit",
      ...this.dummy,
      target: this.dummy.id,
      text: "-" + Math.round(damage),
      crit: !!hit.crit
    });
    return damage;
  }
  switchInterior(id) {
    const previous = this.building;
    const room = id ? cityRoom(id) : null;
    this.player.interior = id;
    this.nav = room ? new Navigation(room.width, room.height, room.obstacles) : this.outsideNav;
    Object.assign(this.player, this.nav.safe(room?.entry ?? previous?.door ?? this.world.spawn));
    this.dialogue = null;
    this.depotOpen = false;
    this.training.active = false;
    this.route = [];
    this.pendingNpc = null;
    this.pendingLoot = null;
    this.pendingChest = false;
    this.targetId = null;
    this.autoAttack = false;
    this.flush();
  }
  requestBuilding(id) {
    const b = this.world.city?.buildings.find((b2) => b2.id === id);
    if (!b) return;
    this.dialogue = null;
    this.depotOpen = false;
    this.targetId = null;
    this.autoAttack = false;
    this.pendingNpc = null;
    this.pendingChest = false;
    if (this.player.interior === id) return;
    if (this.player.interior) {
      this.afterExit = id;
      this.pendingExit = true;
      this.go(cityRoom(this.player.interior).exit);
    } else {
      this.pendingBuilding = id;
      this.go(b.door);
      this.say("Idziesz do: " + b.name + " \xB7 " + b.district);
    }
  }
  transferDepot(item, quantity, withdraw) {
    const p = this.player;
    if (!this.depotOpen || p.interior !== "depot" || distance(p, cityRoom("depot").chest) > 115)
      return this.say("Otw\xF3rz swoj\u0105 skrzyni\u0119 w budynku depozytu.");
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 99) return;
    const material = isMaterial(item);
    if (!material && !ITEM_IDS.includes(item)) return;
    const bag = material ? p.materials : p.items;
    const chest = material ? p.depot.materials : p.depot.items;
    const source = withdraw ? chest : bag, destination = withdraw ? bag : chest;
    const reserved = !withdraw && (p.weapon === item || p.armor === item) ? 1 : 0;
    if ((source[item] ?? 0) - reserved < quantity)
      return this.say("Brak tylu wolnych przedmiot\xF3w. Zdejmij wyposa\u017Cenie przed od\u0142o\u017Ceniem.");
    if ((destination[item] ?? 0) + quantity > 99 || material && !destination[item] && Object.values(destination).filter((n) => n > 0).length >= MATERIAL_CAPACITY)
      return this.say("Brak miejsca lub pe\u0142ny stos (99). Nic nie przeniesiono.");
    const upgradeFrom = withdraw ? p.depot : p;
    const upgradeTo = withdraw ? p : p.depot;
    const movingUpgrade = item === "sword" && upgradeFrom.upgrade > 0 && source[item] === quantity;
    if (movingUpgrade && upgradeTo.upgrade)
      return this.say("W tym schowku jest ju\u017C ulepszone ostrze. Najpierw je przenie\u015B.");
    source[item] = (source[item] ?? 0) - quantity;
    destination[item] = (destination[item] ?? 0) + quantity;
    if (movingUpgrade) {
      upgradeFrom.upgrade = 0;
      upgradeTo.upgrade = 1;
    }
    if (material && source[item] === 0) delete source[item];
    this.say(
      (withdraw ? "Odebrano ze skrzyni: " : "Od\u0142o\u017Cono do skrzyni: ") + quantity + " \xD7 " + (material ? MATERIALS[item].name : ITEMS[item].name)
    );
    this.flush();
  }
  go(to, silent = false) {
    this.route = this.nav.path(this.player, to);
    if (!this.route.length && !silent) this.say("Brak przej\u015Bcia. Wybierz inne miejsce.");
  }
  /** Skill points the player may still spend. */
  get skillPoints() {
    return freePoints(this.player.level, this.player.skills);
  }
  respecCost() {
    return this.player.respecs === 0 && this.player.level <= 10 ? 0 : 50 * this.player.level;
  }
  command(c) {
    const p = this.player;
    if (c.type === "pause") {
      this.paused = c.value;
      if (c.value) {
        this.route = [];
        this.autoAttack = false;
      }
      return;
    }
    if (c.type === "cancel") {
      this.clearDestinations();
      this.dialogue = null;
      this.pendingNpc = null;
      this.pendingLoot = null;
      this.route = [];
      this.targetId = null;
      this.autoAttack = false;
      this.pendingBuilding = null;
      this.pendingService = null;
      this.pendingExit = false;
      this.afterExit = null;
      this.pendingChest = false;
      this.depotOpen = false;
      return;
    }
    if (c.type === "dialogue" && c.action === "close") {
      this.dialogue = null;
      return;
    }
    if (p.dead) {
      this.say("Odradzasz si\u0119 w wiosce\u2026");
      return;
    }
    if (c.type === "storage-close") {
      this.depotOpen = false;
      return;
    }
    if (c.type === "depot") return this.transferDepot(c.item, c.quantity, c.withdraw);
    if (c.type === "enter") {
      this.clearDestinations();
      this.pendingService = null;
      return this.requestBuilding(c.building);
    }
    if (c.type === "exit") {
      if (!p.interior) return;
      this.clearDestinations();
      this.dialogue = null;
      this.depotOpen = false;
      this.pendingService = null;
      this.pendingChest = false;
      this.afterExit = null;
      this.pendingExit = true;
      this.go(cityRoom(p.interior).exit);
      return;
    }
    if (c.type === "chest") {
      if (p.interior !== "depot") return this.say("Skrzynia znajduje si\u0119 w Depozycie Korzeni.");
      this.clearDestinations();
      this.dialogue = null;
      this.pendingNpc = null;
      this.pendingExit = false;
      this.pendingChest = true;
      this.go(cityRoom("depot").chest);
      return;
    }
    if (c.type === "rest") {
      if (p.interior !== "inn" || this.nearbyNpc()?.id !== "innkeeper") return;
      if (p.hp >= this.kit.stats.maxHp && p.ki >= this.kit.stats.maxKi)
        return this.say("Masz pe\u0142ne \u017Cycie i KI. Nic nie zap\u0142acisz.");
      if (p.gold < 5) return this.say("Odpoczynek kosztuje 5 monet.");
      p.gold -= 5;
      p.hp = this.kit.stats.maxHp;
      p.ki = this.kit.stats.maxKi;
      this.say("Odpoczynek przywr\xF3ci\u0142 \u017Cycie i KI.");
      this.flush();
      return;
    }
    if (c.type === "training") {
      if (p.interior !== "arena") return this.say("Trening jest dost\u0119pny w Domu Treningu.");
      this.clearDestinations();
      this.dialogue = null;
      if (c.action === "stop") {
        this.route = [];
        this.training.active = false;
        return;
      }
      this.training = { active: true, hits: 0, damage: 0 };
      this.go({ x: this.dummy.x + 55, y: this.dummy.y + 25 });
      this.say("Trening: u\u017Cywaj ataku i poznanych zdolno\u015Bci. Manekin ma 0 obrony; brak nagr\xF3d.");
      return;
    }
    if (c.type === "learn") {
      const check = canLearn(p.race, p.level, p.skills, c.node);
      if (!check.ok) return this.say(check.reason);
      p.skills = [...p.skills, c.node];
      this.kit.learn(c.node);
      const node = KIT_NODES[p.race].find((n) => n.id === c.node);
      this.say("Poznano: " + node.name + ".");
      p.hp = Math.min(p.hp, this.kit.stats.maxHp);
      this.flush();
      return;
    }
    if (c.type === "respec") {
      const cost = this.respecCost();
      if (p.gold < cost) return this.say("Reset drzewka kosztuje " + cost + " monet.");
      p.gold -= cost;
      p.respecs++;
      p.skills = ["R"];
      this.kit.forgetAll(p.skills);
      p.hp = Math.min(p.hp, this.kit.stats.maxHp);
      p.ki = Math.min(p.ki, this.kit.stats.maxKi);
      this.say(
        cost ? "Drzewko zresetowane za " + cost + " monet." : "Drzewko zresetowane za darmo."
      );
      this.flush();
      return;
    }
    if (c.type === "dialogue") {
      const npc = this.nearbyNpc();
      if (!npc) return this.say("Podejd\u017A do rozm\xF3wcy.");
      if (c.action === "accept") {
        if (npc.id === "guide" && p.quests.steps === "locked") {
          p.quests.steps = "active";
          this.say(
            this.world.market.instruction + ", potem wr\xF3\u0107 do " + this.npcName("guide") + "."
          );
        } else if (npc.id === "hunter" && p.quests.steps === "done" && p.quests.boars === "locked") {
          if (isCityStage(this.world))
            return this.say(
              "Wyprawy poza miasto przygotujemy w nast\u0119pnym etapie. Skorzystaj z areny treningowej."
            );
          p.quests.boars = "active";
          this.say(
            this.world.huntName + ": pokonaj 3 dziki i wr\xF3\u0107 do " + this.npcName("hunter") + "."
          );
        } else if (npc.id === "smith" && (isCityStage(this.world) ? p.quests.steps === "done" : p.quests.boars === "done") && p.quests.gear === "locked") {
          p.quests.gear = p.weapon === "sword" ? "ready" : "active";
          this.say(
            "Za\u0142\xF3\u017C Ostrze stra\u017Cnika w ekwipunku, potem wr\xF3\u0107 do " + this.npcName("smith") + "."
          );
        } else this.say("To zadanie jest ju\u017C przyj\u0119te albo wymaga poprzedniego zadania.");
      }
      if (c.action === "claim") {
        if (npc.id === "guide" && p.quests.steps === "ready") {
          p.quests.steps = "done";
          if (isCityStage(this.world)) p.gold += 40;
          this.award(40);
          this.say(
            this.world.id === "verdant" ? "Pierwsze kroki uko\u0144czone. +40 XP, +40 monet. Odwied\u017A sklep i ku\u017Ani\u0119; trening znajdziesz we wschodniej dzielnicy." : "Pierwsze kroki uko\u0144czone. +40 XP. Odwied\u017A: " + this.npcName("hunter")
          );
        } else if (npc.id === "hunter" && p.quests.boars === "ready") {
          if (!this.add("sword")) return;
          p.quests.boars = "done";
          p.gold += 30;
          this.award(80);
          this.say("Zagro\u017Cenie uko\u0144czone: +80 XP, +30 monet, Ostrze stra\u017Cnika. Odwied\u017A kowala.");
        } else if (npc.id === "smith" && p.quests.gear === "ready") {
          p.quests.gear = "done";
          this.award(40);
          this.say("Pierwsze wyposa\u017Cenie uko\u0144czone. +40 XP. Mo\u017Cesz dalej trenowa\u0107 i handlowa\u0107.");
        } else this.say("Najpierw wykonaj cele. Odebranej nagrody nie mo\u017Cna odebra\u0107 ponownie.");
      }
      if (c.action === "upgrade") {
        if (npc.id !== "smith" || !p.weapon) return this.say("Najpierw za\u0142\xF3\u017C ostrze.");
        if (p.upgrade) return this.say("Ostrze zosta\u0142o ju\u017C ulepszone.");
        if (p.gold < 15) return this.say("Ulepszenie kosztuje 15 monet.");
        p.gold -= 15;
        p.upgrade = 1;
        this.say("Ostrze ulepszone: +4 ataku.");
      }
      this.flush();
      return;
    }
    if (c.type === "trade") {
      if (this.nearbyNpc()?.id !== "merchant")
        return this.say("Porozmawiaj z kupcem, aby handlowa\u0107.");
      if (isMaterial(c.item)) {
        const mat = MATERIALS[c.item];
        if (c.buy) return;
        if (!(p.materials[c.item] ?? 0)) return this.say("Brak materia\u0142u do sprzeda\u017Cy.");
        p.materials[c.item]--;
        if (!p.materials[c.item]) delete p.materials[c.item];
        p.gold += mat.sell;
        this.say("Sprzedano: " + mat.name);
        this.flush();
        return;
      }
      if (!(c.item in ITEMS)) return;
      const id = c.item;
      const item = ITEMS[id];
      if (c.buy) {
        if (!item.price) return;
        if (p.gold < item.price) return this.say("Za ma\u0142o monet.");
        if (!this.add(id)) return;
        p.gold -= item.price;
        this.say("Kupiono: " + item.name);
      } else {
        const reserved = p.weapon === id || p.armor === id ? 1 : 0;
        if (p.items[id] <= reserved)
          return this.say("Brak przedmiotu do sprzeda\u017Cy. Najpierw zdejmij wyposa\u017Cenie.");
        p.items[id]--;
        if (id === "sword" && p.items.sword === 0) p.upgrade = 0;
        p.gold += item.sell;
        this.say("Sprzedano: " + item.name);
      }
      this.flush();
      return;
    }
    if (c.type === "equip") {
      if (!p.items[c.item]) return this.say("Nie masz tego przedmiotu.");
      if (c.item === "potion") return this.use("potion");
      if (c.item === "sword") p.weapon = "sword";
      else if (c.item === "vest") p.armor = "vest";
      else return this.say("Ten materia\u0142 mo\u017Cesz sprzeda\u0107 kupcowi.");
      if (p.quests.gear === "active" && p.weapon) p.quests.gear = "ready";
      this.say("Za\u0142o\u017Cono: " + ITEMS[c.item].name);
      this.flush();
      return;
    }
    if (c.type === "unequip") {
      p[c.slot] = null;
      p.hp = Math.min(p.hp, this.kit.stats.maxHp);
      this.say("Zdj\u0119to wyposa\u017Cenie.");
      this.flush();
      return;
    }
    if (this.dialogue || this.depotOpen || this.paused)
      return this.say("Zamknij okno, aby kontynuowa\u0107.");
    if (c.type === "ability") return this.use(c.ability);
    if (this.fx.cannotAct && c.type !== "loot") return this.say("Nie mo\u017Cesz dzia\u0142a\u0107.");
    if (c.type === "move") {
      this.clearDestinations();
      if (!Number.isFinite(c.x) || !Number.isFinite(c.y)) return;
      this.targetId = null;
      this.autoAttack = false;
      this.pendingNpc = null;
      this.pendingLoot = null;
      this.pendingBuilding = null;
      this.pendingService = null;
      this.pendingExit = false;
      this.pendingChest = false;
      this.go(c);
      return;
    }
    if (c.type === "target") {
      if (this.safe) {
        if (c.id === "training-dummy" && p.interior === "arena")
          this.command({ type: "training", action: "start" });
        return;
      }
      const enemy = this.enemies.find(
        (e) => e.id === c.id && e.hp > 0 && !e.m.hidden && !e.m.invulnerable
      );
      if (!enemy) return this.say("Brak \u017Cywego przeciwnika.");
      this.pendingNpc = null;
      this.pendingLoot = null;
      this.targetId = c.id;
      this.autoAttack = true;
      this.pathIn = 0;
      this.say("Cel: " + enemy.m.def.name + ". Autoatak aktywny.");
      return;
    }
    if (c.type === "interact") {
      this.clearDestinations();
      const definition = this.world.npcs.find((n) => n.id === c.npc);
      if (definition?.building && definition.building !== p.interior) {
        this.pendingService = definition.id;
        this.requestBuilding(definition.building);
        return;
      }
      if (p.interior && !definition?.building) {
        if (!definition) return;
        this.pendingOutsideNpc = definition.id;
        this.pendingExit = true;
        this.go(cityRoom(p.interior).exit);
        return;
      }
      const npc = this.npcs.find((n) => n.id === c.npc);
      if (!npc) return;
      this.targetId = null;
      this.autoAttack = false;
      this.pendingNpc = npc.id;
      this.pendingLoot = null;
      this.go(npc);
      return;
    }
    if (c.type === "loot") {
      const loot = this.loot.find((l) => l.id === c.id);
      if (!loot) return this.say("Ten \u0142up zosta\u0142 ju\u017C podniesiony.");
      if (distance(p, loot) > 90) {
        this.pendingLoot = loot.id;
        this.targetId = null;
        this.autoAttack = false;
        this.go(loot);
        return;
      }
      let name = "";
      if (loot.quantity > 0) {
        if (isMaterial(loot.item)) {
          if (!this.addMaterial(loot.item, loot.quantity)) return;
          name = MATERIALS[loot.item].name;
        } else {
          if (!this.add(loot.item, loot.quantity)) return;
          name = ITEMS[loot.item].name;
        }
      }
      p.gold += loot.gold;
      this.loot = this.loot.filter((l) => l.id !== loot.id);
      this.pendingLoot = null;
      this.emit({
        type: "loot",
        x: loot.x,
        y: loot.y,
        text: name ? "+" + loot.quantity + " " + name : "+" + loot.gold + " monet"
      });
      this.say(
        name ? "\u0141up: " + name + ", +" + loot.gold + " monet." : "\u0141up: +" + loot.gold + " monet."
      );
      this.flush();
    }
  }
  /** Basic attack, tree abilities and the potion. */
  use(id) {
    const p = this.player;
    if (this.fx.cannotAct) return this.say("Nie mo\u017Cesz dzia\u0142a\u0107.");
    if (id === "potion") {
      if (this.potionIn > 0)
        return this.say("Odnowienie: " + Math.ceil(this.potionIn / 1e3) + " s.");
      if (!p.items.potion) return this.say("Brak mikstury. Kup j\u0105 u Mio.");
      const max = this.kit.stats.maxHp;
      if (p.hp >= max) return this.say("Masz pe\u0142ne HP.");
      p.items.potion--;
      this.potionIn = POTION.cooldown;
      makePort(this).heal(Math.round(max * POTION.heal));
      this.flush();
      return;
    }
    if (id !== "R" && this.fx.silenced) return this.say("Uciszony: nie mo\u017Cesz u\u017Cywa\u0107 zdolno\u015Bci.");
    const r = this.kit.use(id);
    if (!r.ok) {
      if (r.reason) this.say(r.reason);
      if (id === "R" && this.target && !r.reason) return;
      if (id === "R" && r.reason === "Cel poza zasi\u0119giem." && this.target) {
        this.autoAttack = true;
        this.pathIn = 0;
        this.say("Podchodzisz do celu.");
      }
      return;
    }
    this.combatIn = 4500;
    if (id !== "R") this.flush();
  }
  manual(dx, dy, dt) {
    if (this.paused || this.dialogue || this.depotOpen || this.player.dead || this.fx.cannotAct)
      return;
    this.clearDestinations();
    this.route = [];
    this.pendingNpc = null;
    this.pendingLoot = null;
    this.autoAttack = false;
    this.pendingBuilding = null;
    this.pendingService = null;
    this.pendingExit = false;
    this.afterExit = null;
    this.pendingChest = false;
    this.movePlayer({ x: this.player.x + dx * 100, y: this.player.y + dy * 100 }, dt);
  }
  movePlayer(to, dt) {
    if (this.fx.cannotMove || this.kit.lockMs < 0) return;
    const before = { x: this.player.x, y: this.player.y };
    const speed = this.kit.stats.speed * this.fx.speedMul;
    const next = this.nav.step(before, to, speed * dt / 1e3);
    Object.assign(this.player, next);
    this.moving = distance(before, next) > 0.01;
    if (this.moving) {
      const d = distance(before, next);
      this.facing = { x: (next.x - before.x) / d, y: (next.y - before.y) / d };
    }
  }
  tick(milliseconds) {
    const dt = Math.max(0, Math.min(100, milliseconds));
    const wasMoving = this.moving;
    this.moving = false;
    if (this.dialogue || this.depotOpen || this.paused) return;
    this.nowMs += dt;
    const p = this.player, s = this.kit.stats;
    this.potionIn = Math.max(0, this.potionIn - dt);
    this.combatIn = Math.max(0, this.combatIn - dt);
    if (p.dead) {
      this.respawnIn -= dt;
      if (this.respawnIn <= 0) {
        Object.assign(p, this.nav.safe(this.world.spawn));
        p.dead = false;
        const fresh = this.kit.stats;
        p.hp = fresh.maxHp;
        p.ki = fresh.maxKi;
        this.combatIn = 0;
        this.emit({ type: "respawn", ...p });
        this.say("Odrodzono w bezpiecznej wiosce. Zachowano przedmioty i zadania.");
        this.flush();
      }
      return;
    }
    this.kit.tick(dt, wasMoving);
    this.syncFxBuffs();
    const dot = this.fx.tick(dt);
    if (dot > 0) {
      this.dotCarry += dot;
      if (this.dotCarry >= 1) {
        const whole = Math.floor(this.dotCarry);
        this.dotCarry -= whole;
        this.damagePlayer(whole);
        if (p.dead) return;
      }
    }
    const live = this.kit.stats;
    p.hp = Math.min(p.hp, live.maxHp);
    p.ki = Math.min(live.maxKi, p.ki + live.kiRegen * dt / 1e3);
    p.hp = Math.min(
      live.maxHp,
      p.hp + live.maxHp * (this.kit.hpRegen() + (this.combatIn ? 0 : BASE_HP_REGEN)) * dt / 1e3
    );
    void s;
    if (this.fx.fearMs > 0 && this.fx.fearFrom) {
      const from = this.fx.fearFrom;
      const d = distance(from, p) || 1;
      this.route = [];
      this.autoAttack = false;
      this.movePlayer(
        { x: p.x + (p.x - from.x) / d * 100, y: p.y + (p.y - from.y) / d * 100 },
        dt
      );
    }
    this.pathIn -= dt;
    const target = this.target;
    if (this.autoAttack && target && !this.fx.cannotAct) {
      if (target.mode === "return") {
        this.autoAttack = false;
        this.targetId = null;
        this.route = [];
        this.say(target.m.def.name + " wraca na swoje terytorium.");
      } else if (distance(p, target) <= live.range && this.nav.visible(p, target)) {
        this.route = [];
        this.use("R");
      } else if (this.pathIn <= 0) {
        this.go(target, true);
        this.pathIn = 600;
      }
    } else if (this.autoAttack && !target) this.autoAttack = false;
    if (this.route.length && !this.fx.cannotAct) {
      this.movePlayer(this.route[0], dt);
      if (distance(p, this.route[0]) < 5) this.route.shift();
    }
    if (this.pendingExit && p.interior && distance(p, cityRoom(p.interior).exit) <= 80) {
      const next = this.afterExit;
      const outsideNpc = this.pendingOutsideNpc;
      this.pendingOutsideNpc = null;
      this.pendingExit = false;
      this.afterExit = null;
      this.switchInterior(null);
      if (next) this.requestBuilding(next);
      else if (outsideNpc) this.command({ type: "interact", npc: outsideNpc });
      return;
    }
    if (this.pendingBuilding && !p.interior) {
      const b = this.world.city.buildings.find((b2) => b2.id === this.pendingBuilding);
      if (distance(p, b.door) <= 75) {
        const service = this.pendingService;
        this.pendingBuilding = null;
        this.pendingService = null;
        this.switchInterior(b.id);
        this.say("Wchodzisz do: " + b.name);
        if (service) {
          const npc = this.npcs.find((n) => n.id === service);
          if (npc) {
            this.pendingNpc = service;
            this.go(npc);
          }
        }
        return;
      }
    }
    if (this.pendingChest && p.interior === "depot" && distance(p, cityRoom("depot").chest) <= 95) {
      this.pendingChest = false;
      this.depotOpen = true;
      this.route = [];
      this.say("Twoja skrzynia \xB7 Depozyt Korzeni");
      return;
    }
    if (this.pendingNpc) {
      const npc = this.npcs.find((n) => n.id === this.pendingNpc);
      if (distance(p, npc) <= 100) {
        this.dialogue = npc.id;
        this.pendingNpc = null;
        this.route = [];
        this.say(npc.name + ": " + npc.role);
        this.flush();
        return;
      }
    }
    if (this.pendingLoot) {
      const loot = this.loot.find((l) => l.id === this.pendingLoot);
      if (!loot) this.pendingLoot = null;
      else if (distance(p, loot) <= 90) this.command({ type: "loot", id: loot.id });
    }
    if (p.quests.steps === "active" && distance(p, this.world.market) < this.world.market.radius) {
      p.visited = true;
      p.quests.steps = "ready";
      this.say(
        this.world.id === "verdant" ? "Rynek odwiedzony. Wr\xF3\u0107 do Airy po nagrod\u0119." : this.world.market.label + " \u2014 odkryto. Wr\xF3\u0107 do: " + this.npcName("guide")
      );
      this.flush();
    }
    if (!isCityStage(this.world) && !p.interior) this.monsters.tick(dt);
    this.saveIn += dt;
    if (this.saveIn >= 2e3) {
      this.saveIn = 0;
      this.flush();
    }
  }
  dotCarry = 0;
  /** Debuffs that change the player's own numbers are mirrored into the kit as timed buffs. */
  syncFxBuffs() {
    if (this.fx.armor.ms > 0)
      this.kit.addBuff({ id: "fx-armor", ms: this.fx.armor.ms, defPct: -this.fx.armorPct });
    else this.kit.removeBuff("fx-armor");
    if (this.fx.weaken.ms > 0)
      this.kit.addBuff({ id: "fx-weaken", ms: this.fx.weaken.ms, dealtPct: -this.fx.weakenPct });
    else this.kit.removeBuff("fx-weaken");
  }
  questText(id) {
    const q = this.player.quests[id];
    const forest = this.world.id === "verdant";
    const names = forest ? { steps: "Airy", boars: "Rena", gear: "Taro" } : {
      steps: this.npcName("guide"),
      boars: this.npcName("hunter"),
      gear: this.npcName("smith")
    };
    if (q === "done") return "Uko\u0144czone \xB7 nagroda odebrana";
    if (q === "ready") return "Wr\xF3\u0107 do " + names[id] + " po nagrod\u0119";
    if (id === "steps")
      return q === "locked" ? "Porozmawiaj z " + names.steps + " przy miejscu startowym" : this.world.market.instruction;
    if (id === "boars" && isCityStage(this.world))
      return "Wyprawy poza miasto: nast\u0119pny etap. \u0106wicz w Domu Treningu; wcze\u015Bniejszy post\u0119p zachowano.";
    if (id === "gear" && isCityStage(this.world))
      return q === "locked" ? "Po Pierwszych krokach odwied\u017A Taro w ku\u017Ani. Ostrze kupisz u Mio." : "Za\u0142\xF3\u017C Ostrze stra\u017Cnika w ekwipunku";
    if (id === "boars")
      return q === "locked" ? "Po Pierwszych krokach porozmawiaj z " + names.boars : "Pokonaj dziki: " + this.player.kills + "/3";
    return q === "locked" ? "Po polowaniu porozmawiaj z kowalem " + names.gear : "Za\u0142\xF3\u017C Ostrze stra\u017Cnika w ekwipunku";
  }
  snapshot() {
    const live = this.kit.stats;
    const target = this.target;
    const abilities = this.kit.abilities();
    return {
      x: this.player.x,
      y: this.player.y,
      player: structuredClone(this.player),
      stats: {
        maxHp: live.maxHp,
        maxKi: live.maxKi,
        attack: live.attack,
        defense: live.defense,
        speed: Math.round(live.speed),
        crit: Math.round(live.crit * 10) / 10,
        kiRegen: Math.round(live.kiRegen * 100) / 100,
        attackInterval: Math.round(live.attackInterval),
        range: Math.round(live.range)
      },
      target: target ? {
        name: target.m.def.name,
        level: target.m.def.level,
        hp: target.hp,
        maxHp: target.maxHp,
        inRange: distance(this.player, target) <= live.range && this.nav.visible(this.player, target)
      } : null,
      defeated: this.player.kills,
      ready: true,
      dialogue: this.dialogue,
      building: this.building ?? null,
      activeNpcs: this.npcs,
      nearbyBuilding: !this.player.interior ? this.world.city?.buildings.find((b) => distance(b.door, this.player) <= 180) ?? null : null,
      depotOpen: this.depotOpen,
      training: { ...this.training, damage: Math.round(this.training.damage) },
      notice: this.notice,
      noticeId: this.noticeId,
      log: [...this.log],
      saveWarning: this.saves?.warning ?? "",
      quests: Object.keys(QUEST_NAMES).map((id) => ({
        id,
        name: id === "boars" ? this.world.huntName : QUEST_NAMES[id],
        status: this.player.quests[id],
        text: this.questText(id)
      })),
      nearbyLoot: this.loot.filter((l) => distance(l, this.player) < 140).map((l) => ({ ...l })),
      nearestNpc: [...this.npcs].sort((a, b) => distance(a, this.player) - distance(b, this.player))[0]?.id ?? "guide",
      autoAttack: this.autoAttack,
      abilities,
      potion: { remaining: this.potionIn, count: this.player.items.potion },
      resource: this.kit.resource(),
      shieldPoints: Math.round(this.kit.shieldPoints),
      buffs: this.kit.buffs.map((b) => ({ id: b.id, ms: Math.round(b.ms) })),
      statuses: this.fx.active.map((a) => ({ ...a, ms: Math.round(a.ms) })),
      channel: this.kit.channel ? {
        id: this.kit.channel.id,
        ms: Math.round(this.kit.channel.ms),
        total: this.kit.channel.total
      } : null,
      skillPoints: this.skillPoints,
      respecCost: this.respecCost(),
      minimapJammed: this.fx.jammed,
      fog: this.fx.fogPct,
      locked: this.kit.lockMs > 0,
      night: this.isNight()
    };
  }
  get zones() {
    return this.monsters.zones;
  }
};
var statusText = (fx) => {
  switch (fx.k) {
    case "slow":
      return "Spowolnienie";
    case "root":
      return "Unieruchomienie";
    case "stun":
      return "Og\u0142uszenie";
    case "fear":
      return "Strach";
    case "silence":
      return "Uciszenie";
    case "dot":
      return fx.id === "poison" ? "Trucizna" : fx.id === "burn" ? "Podpalenie" : "Krwawienie";
    case "blind":
      return "O\u015Blepienie";
    case "fog":
      return "Mg\u0142a";
    case "jam":
      return "Zak\u0142\xF3cenia";
    case "weaken":
      return "Os\u0142abienie";
    case "armorDown":
      return "Obrona w d\xF3\u0142";
    case "mark":
      return "Znak";
    default:
      return "";
  }
};
function makePort(s) {
  return {
    get nowMs() {
      return s.nowMs;
    },
    get gear() {
      const p = s.player;
      return {
        attack: p.weapon ? ITEMS[p.weapon].attack + p.upgrade * 4 : 0,
        defense: p.armor ? ITEMS[p.armor].defense : 0
      };
    },
    get inCombat() {
      return s.combatIn > 0;
    },
    terrain: () => terrainAt(s.world, s.player),
    get player() {
      return s.player;
    },
    get facing() {
      return s.facing;
    },
    random: () => s.rng(),
    say: (t) => s.say(t),
    foesIn: (c, r) => (s.safe ? s.trainingTarget ? [s.trainingTarget] : [] : s.monsters.targetable).filter(
      (e) => distance(e, c) <= r
    ),
    target: () => s.trainingTarget ?? s.target,
    visible: (a, b) => s.nav.visible(a, b),
    hurtFoe: (foe, raw, hit) => {
      if (foe.id === "training-dummy") return s.hitTraining(raw, hit);
      if (!hit.indirect && s.fx.rollMiss()) {
        s.emit({ type: "hit", x: foe.x, y: foe.y, target: foe.id, text: "Pud\u0142o" });
        return 0;
      }
      const dealt = s.monsters.damage(foe, raw, hit);
      if (!hit.indirect && dealt > 0) s.combatIn = 4500;
      return dealt;
    },
    stunFoe: (f, ms) => f.id === "training-dummy" ? void 0 : s.monsters.stun(f, ms),
    slowFoe: (f, pct, ms) => f.id === "training-dummy" ? void 0 : s.monsters.slow(f, pct, ms),
    burnFoe: (f, dps, ms) => f.id === "training-dummy" ? void 0 : s.monsters.burn(f, dps, ms),
    sealFoe: (f, ms, bonus) => f.id === "training-dummy" ? void 0 : s.monsters.seal(f, ms, bonus),
    markFoe: (f, ms, crit, def) => f.id === "training-dummy" ? void 0 : s.monsters.mark(f, ms, crit, def),
    pushFoe: (f, from, d) => f.id === "training-dummy" ? void 0 : s.monsters.push(f, from, d),
    weakenFoe: (f, pct, ms) => f.id === "training-dummy" ? void 0 : s.monsters.weaken(f, pct, ms),
    breakFoeShield: (f) => f.id === "training-dummy" ? void 0 : s.monsters.breakShield(f),
    isSealed: (f) => f.id !== "training-dummy" && !!f.fx.seal,
    isMarked: (f) => f.id !== "training-dummy" && !!f.fx.mark,
    foeHpFraction: (f) => f.hp / f.maxHp,
    dash: (to, d) => {
      const next = s.nav.step(s.player, to, d);
      const len = distance(s.player, next);
      if (len > 0.01) s.facing = { x: (next.x - s.player.x) / len, y: (next.y - s.player.y) / len };
      Object.assign(s.player, next);
      s.route = [];
      return next;
    },
    emit: (e) => {
      if (e.type === "attack" && e.to) {
        const d = distance(s.player, e.to);
        if (d > 0) s.facing = { x: (e.to.x - s.player.x) / d, y: (e.to.y - s.player.y) / d };
      }
      s.emit({ ...e });
    },
    heal: (n) => {
      const max = s.kit.stats.maxHp;
      const before = s.player.hp;
      s.player.hp = Math.min(max, s.player.hp + n);
      if (s.player.hp > before)
        s.emit({
          type: "heal",
          x: s.player.x,
          y: s.player.y,
          text: "+" + Math.round(s.player.hp - before)
        });
    },
    addKi: (n) => {
      s.player.ki = Math.max(0, Math.min(s.kit.stats.maxKi, s.player.ki + n));
    }
  };
}

// scripts/worldgen/simulate-balance.ts
var arg = (name, fallback) => {
  const at = process.argv.indexOf(name);
  return at >= 0 ? process.argv[at + 1] : fallback;
};
var trials = Number(arg("--trials", "16"));
var shard = Number(arg("--shard", "0"));
var shards = Number(arg("--shards", "1"));
var output = arg("--output", "/tmp/ki-balance");
if (!Number.isInteger(trials) || trials < 1 || trials > 1e3 || !Number.isInteger(shard) || shard < 0 || shard >= shards)
  throw Error("Invalid trials/shard");
var random = (value) => () => {
  value = Math.imul(value, 1664525) + 1013904223 >>> 0;
  return value / 4294967296;
};
var hash = (s) => [...s].reduce((a, c) => Math.imul(a ^ c.charCodeAt(0), 16777619) >>> 0, 2166136261);
var median = (v) => {
  const a = [...v].sort((a2, b) => a2 - b);
  return a.length ? a[Math.floor(a.length / 2)] : null;
};
var nav = new Navigation(8192, 8192, []);
var profiles = ["bare-basic", "equipped-basic", "equipped-skills-potions"];
var results = [];
var ordinal = 0;
var started = performance.now();
for (const monster of MONSTERS)
  for (const race of RACE_IDS)
    for (const level of [
      .../* @__PURE__ */ new Set([Math.max(1, monster.level - 2), monster.level, Math.min(20, monster.level + 2)])
    ])
      for (const profile of profiles) {
        const job = ordinal++;
        if (job % shards !== shard) continue;
        const key = [monster.id, race, level, profile].join("|");
        let wins = 0, deaths = 0, timeouts = 0, potions = 0, gold = 0, xp = 0, materialRevenue = 0, activeSkillsStarted = 0, fightSecondsTotal = 0;
        const times = [], remaining = [];
        for (let trial = 0; trial < trials; trial++) {
          const base = WORLDS[{ planetary: "verdant", sage: "aether", android: "nexus", legend: "pyra" }[race]];
          const world = {
            ...base,
            width: 8192,
            height: 8192,
            spawn: { x: 4096, y: 4096 },
            enemies: [],
            monsters: [],
            npcs: [],
            objects: [],
            obstacles: []
          };
          delete world.city;
          delete world.terrain;
          const g = new GameSession(void 0, race, {
            random: random(hash(key + "|" + trial)),
            world,
            navigation: nav
          });
          g.player.level = level;
          if (profile !== "bare-basic") {
            g.player.items.sword = 1;
            g.player.items.vest = 1;
            g.player.weapon = "sword";
            g.player.armor = "vest";
            g.player.upgrade = 1;
          }
          if (profile === "equipped-skills-potions")
            for (const id of ["A1", "A2", "A3", "A4", "A5", "A6", "A7", "A9"])
              g.command({ type: "learn", node: id });
          g.player.hp = g.kit.stats.maxHp;
          g.player.ki = g.kit.stats.maxKi;
          g.player.items.potion = profile === "equipped-skills-potions" ? 3 : 0;
          const initialPotions = g.player.items.potion;
          g.nowMs = trial % 2 ? 3e5 : 0;
          g.monsters.spawn(monster.id, { x: 4191, y: 4096 }, "subject");
          let elapsed = 0, result = "timeout";
          for (; elapsed < 9e4; elapsed += 50) {
            const targets = g.enemies.filter((e) => e.hp > 0 && e.mode !== "dead");
            if (!targets.length) {
              result = "win";
              break;
            }
            if (g.player.hp <= 0 || g.player.dead) {
              result = "death";
              break;
            }
            const target = targets.find((e) => !e.m.hidden && !e.m.invulnerable);
            if (target && (!g.autoAttack || !g.target))
              g.command({ type: "target", id: target.id });
            if (profile === "equipped-skills-potions") {
              if (g.player.hp < g.kit.stats.maxHp * 0.4)
                g.command({ type: "ability", ability: "potion" });
              for (const a of g.kit.abilities())
                if (a.id !== "R" && a.id !== "potion" && a.ready && a.ki <= g.player.ki) {
                  g.command({ type: "ability", ability: a.id });
                  if ((g.kit.cooldowns[a.id] ?? 0) > 0 || g.kit.channel?.id === a.id)
                    activeSkillsStarted++;
                }
            }
            g.tick(50);
            g.events.length = 0;
          }
          if (g.player.hp <= 0 || g.player.dead) result = "death";
          else if (!g.enemies.some((e) => e.hp > 0 && e.mode !== "dead")) result = "win";
          fightSecondsTotal += elapsed / 1e3;
          if (result === "win") {
            wins++;
            times.push(elapsed / 1e3);
            gold += g.loot.reduce((a, l) => a + l.gold, 0);
            materialRevenue += g.loot.reduce(
              (a, l) => a + (MATERIALS[l.item]?.sell ?? 0) * l.quantity,
              0
            );
            let earned = g.player.xp;
            for (let l = level; l < g.player.level; l++) earned += xpNeeded(l);
            xp += earned;
          } else if (result === "death") deaths++;
          else timeouts++;
          potions += initialPotions - g.player.items.potion;
          remaining.push(Math.max(0, g.player.hp) / g.kit.stats.maxHp);
        }
        const probability = wins / trials, z = 1.96, denom = 1 + z * z / trials, centre = (probability + z * z / (2 * trials)) / denom, half = z * Math.sqrt(
          probability * (1 - probability) / trials + z * z / (4 * trials * trials)
        ) / denom;
        const travelSeconds = 30;
        results.push({
          monster: monster.id,
          monsterLevel: monster.level,
          race,
          playerLevel: level,
          profile,
          trials,
          wins,
          deaths,
          timeouts,
          winRate: probability,
          winRate95: [Math.max(0, centre - half), Math.min(1, centre + half)],
          medianKillSeconds: median(times),
          fightSecondsTotal,
          meanFightSeconds: fightSecondsTotal / trials,
          meanRemainingHp: remaining.reduce((a, b) => a + b, 0) / trials,
          potionsConsumed: potions,
          activeSkillsStarted,
          goldDropped: gold,
          materialSellValue: materialRevenue,
          netGoldAfterPotionsAndInn: gold + materialRevenue - potions * ITEMS.potion.price - trials * 5,
          xpEarned: xp,
          estimatedXpPerHour: xp / trials * 3600 / (fightSecondsTotal / trials + travelSeconds + 5),
          flags: [
            ...level === monster.level && profile === "equipped-skills-potions" && probability < 0.2 ? ["same-level-low-win-rate"] : [],
            ...timeouts / trials > 0.25 ? ["frequent-timeout"] : []
          ]
        });
      }
mkdirSync(output, { recursive: true });
var report = {
  engine: "GameSession + all race kits + MonsterSystem",
  shard,
  shards,
  trialsPerScenario: trials,
  scenarios: results.length,
  fights: results.length * trials,
  wallSeconds: (performance.now() - started) / 1e3,
  assumptions: {
    fixedStepMs: 50,
    maxFightSeconds: 90,
    arena: "8192\xD78192 empty arena; stationary auto-chase, no human dodging",
    dayNight: "alternating existing 8-minute AI clock",
    equipment: "existing sword + one upgrade and vest; no new items",
    skillBuild: "legal A-branch purchases attempted through game commands",
    economy: "full material sale assumed; no inventory saturation; 30s travel + 5s recovery; inn cost 5 every trial",
    confidence: "16 seeded trials are exploratory; Wilson 95% intervals, not player telemetry"
  },
  results
};
writeFileSync(join(output, `shard-${shard}.json`), JSON.stringify(report));
console.log(
  JSON.stringify({
    shard,
    scenarios: results.length,
    fights: report.fights,
    seconds: report.wallSeconds
  })
);
