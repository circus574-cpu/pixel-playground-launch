// scripts/worldgen/check-content.ts
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

// src/game/geometry.ts
var FOOT_RADIUS = 12;
var WORLD_EDGE_MARGIN = 16;

// src/game/movement.ts
function blockedAt(x, y, obstacles, radius = FOOT_RADIUS) {
  return obstacles.some((b) => {
    const dx = x - Math.max(b.x, Math.min(x, b.x + b.width));
    const dy = y - Math.max(b.y, Math.min(y, b.y + b.height));
    return dx * dx + dy * dy <= radius * radius;
  });
}
function clearSight(ax, ay, bx, by, obstacles) {
  const steps = Math.max(1, Math.ceil(Math.hypot(bx - ax, by - ay) / 4));
  for (let i = 0; i <= steps; i++) {
    if (blockedAt(ax + (bx - ax) * i / steps, ay + (by - ay) * i / steps, obstacles, 1))
      return false;
  }
  return true;
}

// src/game/navigation.ts
var distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
var Navigation = class {
  constructor(width, height, obstacles, field) {
    this.width = width;
    this.height = height;
    this.obstacles = obstacles;
    this.field = field;
    this.cell = field?.cell ?? 24;
    this.cols = Math.ceil(width / this.cell);
    this.rows = Math.ceil(height / this.cell);
    if (field) {
      if (field.blocked.length !== this.cols * this.rows)
        throw new Error("Invalid navigation field size");
      this.blocked = field.blocked;
      return;
    }
    this.blocked = new Uint8Array(this.cols * this.rows);
    for (let i = 0; i < this.blocked.length; i++) {
      const p = this.point(i);
      this.blocked[i] = this.walkable(p) ? 0 : 1;
    }
  }
  width;
  height;
  obstacles;
  field;
  cell;
  cols;
  rows;
  blocked;
  walkable(p) {
    if (this.field)
      return Number.isFinite(p.x) && Number.isFinite(p.y) && p.x >= WORLD_EDGE_MARGIN && p.y >= WORLD_EDGE_MARGIN && p.x <= this.width - WORLD_EDGE_MARGIN && p.y <= this.height - WORLD_EDGE_MARGIN && this.field.walkable(p);
    return p.x >= WORLD_EDGE_MARGIN && p.y >= WORLD_EDGE_MARGIN && p.x <= this.width - WORLD_EDGE_MARGIN && p.y <= this.height - WORLD_EDGE_MARGIN && !blockedAt(p.x, p.y, this.obstacles, FOOT_RADIUS);
  }
  visible(a, b) {
    return this.field ? this.segment(a, b) : clearSight(a.x, a.y, b.x, b.y, this.obstacles);
  }
  segment(a, b) {
    const steps = Math.max(1, Math.ceil(distance(a, b) / 8));
    for (let i = 1; i <= steps; i++)
      if (!this.walkable({ x: a.x + (b.x - a.x) * i / steps, y: a.y + (b.y - a.y) * i / steps }))
        return false;
    return true;
  }
  index(p) {
    return Math.max(0, Math.min(this.rows - 1, Math.floor(p.y / this.cell))) * this.cols + Math.max(0, Math.min(this.cols - 1, Math.floor(p.x / this.cell)));
  }
  point(i) {
    return {
      x: (i % this.cols + 0.5) * this.cell,
      y: (Math.floor(i / this.cols) + 0.5) * this.cell
    };
  }
  accessibleCell(p) {
    const at = this.index(p), cx = at % this.cols, cy = Math.floor(at / this.cols);
    let best = -1, nearest = Infinity;
    for (let dy = -2; dy <= 2; dy++)
      for (let dx = -2; dx <= 2; dx++) {
        const x = cx + dx, y = cy + dy, i = y * this.cols + x;
        if (x < 0 || y < 0 || x >= this.cols || y >= this.rows || this.blocked[i]) continue;
        const point = this.point(i), d = distance(p, point);
        if (d < nearest && this.segment(p, point)) {
          best = i;
          nearest = d;
        }
      }
    return best;
  }
  safe(p) {
    if (this.walkable(p)) return { ...p };
    const start = this.point(this.index(p));
    for (let r = this.cell; r < 600; r += this.cell)
      for (let angle = 0; angle < 16; angle++) {
        const q = {
          x: start.x + Math.cos(angle * Math.PI / 8) * r,
          y: start.y + Math.sin(angle * Math.PI / 8) * r
        };
        if (this.walkable(q)) return q;
      }
    throw new Error("Brak bezpiecznego punktu na mapie.");
  }
  path(from, requested) {
    const to = this.safe(requested);
    if (this.segment(from, to)) return [to];
    const start = this.accessibleCell(from), goal = this.accessibleCell(to);
    if (start < 0 || goal < 0) return [];
    if (this.field) return this.fieldPath(start, goal, to);
    const open = /* @__PURE__ */ new Set([start]), closed = /* @__PURE__ */ new Set();
    const parent = /* @__PURE__ */ new Map(), cost = /* @__PURE__ */ new Map([[start, 0]]);
    const score = (i) => (cost.get(i) ?? Infinity) + distance(this.point(i), to);
    for (let attempts = 0; open.size && attempts < this.blocked.length; attempts++) {
      let cur = -1, best = Infinity;
      for (const i of open) {
        const s = score(i);
        if (s < best) {
          best = s;
          cur = i;
        }
      }
      if (cur === goal) {
        const result = [to];
        let at = cur;
        while (at !== start) {
          result.unshift(this.point(at));
          at = parent.get(at);
        }
        result.unshift(this.point(start));
        return result;
      }
      open.delete(cur);
      closed.add(cur);
      const cx = cur % this.cols, cy = Math.floor(cur / this.cols);
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue;
          const x = cx + dx, y = cy + dy, n = y * this.cols + x;
          if (x < 0 || y < 0 || x >= this.cols || y >= this.rows || this.blocked[n] || closed.has(n))
            continue;
          if (dx && dy && (this.blocked[cy * this.cols + x] || this.blocked[y * this.cols + cx]))
            continue;
          const c = (cost.get(cur) ?? Infinity) + this.cell * Math.hypot(dx, dy);
          if (c < (cost.get(n) ?? Infinity)) {
            cost.set(n, c);
            parent.set(n, cur);
            open.add(n);
          }
        }
    }
    return [];
  }
  fieldPath(start, goal, to) {
    const queue = [];
    const push = (item) => {
      let i = queue.length;
      queue.push(item);
      while (i > 0) {
        const p = i - 1 >> 1;
        if (queue[p].score <= item.score) break;
        queue[i] = queue[p];
        i = p;
      }
      queue[i] = item;
    };
    const pop = () => {
      const first = queue[0], last = queue.pop();
      if (queue.length) {
        let i = 0;
        while (i * 2 + 1 < queue.length) {
          let child = i * 2 + 1;
          if (child + 1 < queue.length && queue[child + 1].score < queue[child].score) child++;
          if (queue[child].score >= last.score) break;
          queue[i] = queue[child];
          i = child;
        }
        queue[i] = last;
      }
      return first;
    };
    const costs = /* @__PURE__ */ new Map([[start, 0]]), parents = /* @__PURE__ */ new Map();
    const closed = /* @__PURE__ */ new Set();
    push({ id: start, cost: 0, score: distance(this.point(start), to) });
    while (queue.length && closed.size < 1e6) {
      const current = pop(), at = current.id;
      if (closed.has(at)) continue;
      if (at === goal) {
        const path = [to];
        let v = at;
        while (v !== start) {
          path.push(this.point(v));
          v = parents.get(v);
        }
        path.push(this.point(start));
        return path.reverse();
      }
      closed.add(at);
      const x = at % this.cols, y = Math.floor(at / this.cols);
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue;
          const nx = x + dx, ny = y + dy, next = ny * this.cols + nx;
          if (nx < 0 || ny < 0 || nx >= this.cols || ny >= this.rows || this.blocked[next] || closed.has(next))
            continue;
          if (dx && dy && (this.blocked[y * this.cols + nx] || this.blocked[ny * this.cols + x]))
            continue;
          const cost = current.cost + Math.hypot(dx, dy) * this.cell;
          if (cost >= (costs.get(next) ?? Infinity)) continue;
          costs.set(next, cost);
          parents.set(next, at);
          push({ id: next, cost, score: cost + distance(this.point(next), to) });
        }
    }
    return [];
  }
  step(p, to, amount) {
    const d = distance(p, to);
    if (d < 0.01) return p;
    const step = Math.min(amount, d);
    const next = { x: p.x + (to.x - p.x) / d * step, y: p.y + (to.y - p.y) / d * step };
    if (this.walkable(next) && (!this.field || this.segment(p, next))) return next;
    if (this.walkable({ x: next.x, y: p.y }) && (!this.field || this.segment(p, { x: next.x, y: p.y })))
      return { x: next.x, y: p.y };
    if (this.walkable({ x: p.x, y: next.y }) && (!this.field || this.segment(p, { x: p.x, y: next.y })))
      return { x: p.x, y: next.y };
    return p;
  }
};

// src/game/world/generated/dungeonProgress.ts
var DungeonProgress = class {
  constructor(floor, canReach, snapshot) {
    this.floor = floor;
    this.canReach = canReach;
    const validIds = (values, allowed) => Array.isArray(values) && new Set(values).size === values.length && values.every((v) => typeof v === "string" && allowed.some((a) => a.id === v));
    if (snapshot && (snapshot.version !== 1 || snapshot.floor !== floor.id || !validIds(snapshot.keys, floor.keys) || !validIds(snapshot.gates, floor.gates) || !validIds(snapshot.chests, floor.chests) || snapshot.gates.some(
      (id) => !snapshot.keys.includes(floor.gates.find((g) => g.id === id).key)
    )))
      throw new Error("Unknown, inconsistent or newer dungeon state; preserve original save");
    this.state = snapshot ? structuredClone(snapshot) : { version: 1, floor: floor.id, keys: [], gates: [], chests: [] };
  }
  floor;
  canReach;
  state;
  snapshot() {
    return structuredClone(this.state);
  }
  near(p, target) {
    return Number.isFinite(p.x) && Number.isFinite(p.y) && distance(p, target) <= 96 && this.canReach(p, target);
  }
  pickup(id, p) {
    const key = this.floor.keys.find((k) => k.id === id);
    if (!key || this.state.keys.includes(id) || !this.near(p, key)) return false;
    this.state.keys.push(id);
    return true;
  }
  open(id, p) {
    const gate = this.floor.gates.find((g) => g.id === id);
    if (!gate || this.state.gates.includes(id) || !this.state.keys.includes(gate.key) || !this.near(p, gate))
      return false;
    this.state.gates.push(id);
    return true;
  }
  claim(id, p) {
    const chest = this.floor.chests.find((c) => c.id === id);
    if (!chest || this.state.chests.includes(id) || !this.near(p, chest)) return null;
    this.state.chests.push(id);
    return { ...chest.reward };
  }
  lockedGates() {
    return this.floor.gates.filter((g) => !this.state.gates.includes(g.id));
  }
};

// src/game/world/generated/settlementLife.ts
var SettlementLife = class {
  constructor(residents, routes, routines) {
    this.residents = residents;
    for (const r of routes) {
      if (!r.points.length || this.routes.has(r.id) || r.points.some((p) => !Number.isFinite(p.x) || !Number.isFinite(p.y)))
        throw Error("Invalid resident route");
      let length = 0;
      const cumulative = [0];
      for (let i = 1; i < r.points.length; i++) {
        length += distance(r.points[i - 1], r.points[i]);
        cumulative.push(length);
      }
      this.routes.set(r.id, { points: r.points.map((p) => ({ ...p })), length, cumulative });
    }
    for (const r of routines) {
      if (this.routines.has(r.id) || !Number.isFinite(r.dayMs) || r.dayMs <= 0 || !Number.isFinite(r.phaseOffsetMs) || !r.segments.length)
        throw Error("Invalid resident routine");
      let at = 0;
      const endpoint = (s, last) => s.route ? this.routes.get(s.route)?.points.at(last ? -1 : 0) : s.position;
      for (let i = 0; i < r.segments.length; i++) {
        const s = r.segments[i];
        if (s.fromMs !== at || s.toMs <= s.fromMs || s.toMs > r.dayMs || !Number.isFinite(s.toMs) || !endpoint(s, false) || !endpoint(s, true) || Boolean(s.route) === Boolean(s.position))
          throw Error("Routine has a gap or missing route");
        at = s.toMs;
        const next = r.segments[(i + 1) % r.segments.length];
        const a = endpoint(s, true), b = endpoint(next, false);
        if (!a || !b || distance(a, b) > 0.01) throw Error("Routine teleports between activities");
      }
      if (at !== r.dayMs) throw Error("Routine does not cover a day");
      this.routines.set(r.id, structuredClone(r));
    }
    if (new Set(residents.map((r) => r.id)).size !== residents.length || residents.some((r) => !this.routines.has(r.routine)))
      throw Error("Invalid resident identity");
  }
  residents;
  routes = /* @__PURE__ */ new Map();
  routines = /* @__PURE__ */ new Map();
  at(resident, worldMs) {
    if (!Number.isFinite(worldMs) || worldMs < 0) throw Error("Invalid world clock");
    const routine = this.routines.get(resident.routine);
    if (!routine) throw Error("Missing resident routine");
    const t = (worldMs + routine.phaseOffsetMs) % routine.dayMs;
    const s = routine.segments.find((s2) => t >= s2.fromMs && t < s2.toMs);
    let p = s.position;
    if (s.route) {
      const route = this.routes.get(s.route);
      const target = route.length * (t - s.fromMs) / (s.toMs - s.fromMs);
      let i = 1;
      while (i < route.cumulative.length - 1 && route.cumulative[i] < target) i++;
      const a = route.points[Math.max(0, i - 1)], b = route.points[Math.min(i, route.points.length - 1)], span = (route.cumulative[i] ?? 0) - (route.cumulative[i - 1] ?? 0), fraction = span > 0 ? (target - (route.cumulative[i - 1] ?? 0)) / span : 0;
      p = { x: a.x + (b.x - a.x) * fraction, y: a.y + (b.y - a.y) * fraction };
    }
    return { ...p, activity: s.activity, visible: !s.indoors };
  }
  nearby(player, worldMs, maximum = 16, radius = 1e3) {
    if (!Number.isFinite(radius) || radius < 0 || !Number.isInteger(maximum) || maximum < 0 || maximum > 16)
      throw Error("Invalid resident activation budget");
    return this.residents.map((r) => ({ resident: r, ...this.at(r, worldMs) })).filter((r) => r.visible && distance(r, player) <= radius).sort(
      (a, b) => distance(a, player) - distance(b, player) || a.resident.id.localeCompare(b.resident.id)
    ).slice(0, maximum);
  }
};

// src/game/world/generated/browserTerrain.ts
function decodeRuns(input, count) {
  if (!Number.isSafeInteger(count) || count < 1 || count > 16e6 || !Array.isArray(input))
    throw new Error("Invalid CPU grid size");
  const result = new Uint8Array(count);
  let at = 0;
  for (const run of input) {
    if (!Array.isArray(run) || run.length !== 2 || !Number.isInteger(run[0]) || run[0] < 0 || run[0] > 255 || !Number.isSafeInteger(run[1]) || run[1] < 1 || at + run[1] > count)
      throw new Error("Invalid CPU grid run");
    result.fill(run[0], at, at + run[1]);
    at += run[1];
  }
  if (at !== count) throw new Error("Incomplete CPU grid");
  return result;
}
function browserNavigation(width, height, navigation, terrain, colliders) {
  if (navigation.cell !== 16 || terrain.cell !== 32 || navigation.width * 16 !== width || navigation.height * 16 !== height || terrain.width * 32 !== width || terrain.height * 32 !== height)
    throw new Error("CPU grid geometry mismatch");
  const blocked = decodeRuns(navigation.blocked, navigation.width * navigation.height), flags = decodeRuns(terrain.flags, terrain.width * terrain.height);
  if (blocked.some((v) => v > 1)) throw new Error("Invalid CPU navigation occupancy");
  const index = /* @__PURE__ */ new Map();
  for (const r of colliders) {
    if (![r.x, r.y, r.width, r.height].every(Number.isFinite) || r.width <= 0 || r.height <= 0 || r.x < 0 || r.y < 0 || r.x + r.width > width + 1 || r.y + r.height > height + 1)
      throw new Error("Invalid CPU collider");
    for (let y = Math.floor(r.y / 256); y <= Math.floor((r.y + r.height) / 256); y++)
      for (let x = Math.floor(r.x / 256); x <= Math.floor((r.x + r.width) / 256); x++) {
        const key = x + ":" + y;
        const list = index.get(key) ?? [];
        list.push(r);
        index.set(key, list);
      }
  }
  const walkable = (p) => {
    if (!Number.isFinite(p.x) || !Number.isFinite(p.y) || p.x < WORLD_EDGE_MARGIN || p.y < WORLD_EDGE_MARGIN || p.x > width - WORLD_EDGE_MARGIN || p.y > height - WORLD_EDGE_MARGIN)
      return false;
    for (let y = Math.max(0, Math.floor((p.y - FOOT_RADIUS) / 32)); y <= Math.min(terrain.height - 1, Math.floor((p.y + FOOT_RADIUS) / 32)); y++)
      for (let x = Math.max(0, Math.floor((p.x - FOOT_RADIUS) / 32)); x <= Math.min(terrain.width - 1, Math.floor((p.x + FOOT_RADIUS) / 32)); x++)
        if (!(flags[y * terrain.width + x] & 1) && blockedAt(p.x, p.y, [{ x: x * 32, y: y * 32, width: 32, height: 32 }]))
          return false;
    for (let y = Math.floor((p.y - FOOT_RADIUS) / 256); y <= Math.floor((p.y + FOOT_RADIUS) / 256); y++)
      for (let x = Math.floor((p.x - FOOT_RADIUS) / 256); x <= Math.floor((p.x + FOOT_RADIUS) / 256); x++)
        if (blockedAt(p.x, p.y, index.get(x + ":" + y) ?? [])) return false;
    return true;
  };
  return new Navigation(width, height, [], { cell: 16, blocked, walkable });
}

// scripts/worldgen/check-content.ts
var [browser, dungeons, life, output] = process.argv.slice(2);
if (!browser || !dungeons || !life || !output)
  throw Error("Usage: check-content BROWSER DUNGEONS LIFE REPORT");
var read = (p) => JSON.parse(readFileSync(p, "utf8"));
var regions = read(join(browser, "conversion-report.json")).features;
var floors = 0;
var claims = 0;
var residentSamples = 0;
var residentsCount = 0;
for (const { feature } of regions) {
  const entries = read(join(dungeons, feature, "index.json"));
  for (const entry of entries) {
    const data = read(join(dungeons, feature, entry.path));
    const state = new DungeonProgress(data, () => true);
    for (const key of data.keys)
      if (!state.pickup(key.id, key)) throw Error("Key cannot be acquired");
    for (const gate of data.gates) if (!state.open(gate.id, gate)) throw Error("Gate cannot open");
    for (const chest of data.chests) {
      if (!state.claim(chest.id, chest) || state.claim(chest.id, chest))
        throw Error("Chest claim not single-use");
      claims++;
    }
    const restored = new DungeonProgress(data, () => true, state.snapshot());
    for (const chest of data.chests)
      if (restored.claim(chest.id, chest)) throw Error("Chest duplicated after reload");
    floors++;
  }
  const directory = join(browser, feature), world = read(join(directory, "world.json"));
  const nav = browserNavigation(
    world.geometry.width,
    world.geometry.height,
    read(join(directory, "navigation.json")),
    read(join(directory, "terrain.json")),
    read(join(directory, "collision.json"))
  );
  const people = read(join(life, feature, "residents.json")), routes = read(join(life, feature, "routes.json")), routines = read(join(life, feature, "routines.json"));
  const clock = new SettlementLife(people, routes, routines);
  residentsCount += people.length;
  for (const resident of people)
    for (let t = 0; t < 48e4; t += 1e3) {
      const position = clock.at(resident, t);
      if (!nav.walkable(position))
        throw Error("Resident intersects world collider: " + resident.id + " at " + t);
      residentSamples++;
    }
  if (clock.nearby(world.geometry.anchor, 12e4).length > 16)
    throw Error("Resident activation budget exceeded");
}
var report = {
  passed: true,
  engine: "DungeonProgress + SettlementLife + Navigation",
  regions: regions.length,
  dungeonFloors: floors,
  persistentChestClaims: claims,
  residents: residentsCount,
  residentSamples,
  sampleStepMs: 1e3
};
writeFileSync(output, JSON.stringify(report, null, 2));
console.log(JSON.stringify(report));
